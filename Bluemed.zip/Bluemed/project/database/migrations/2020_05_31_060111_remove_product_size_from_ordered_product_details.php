<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class RemoveProductSizeFromOrderedProductDetails extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('ordered_product_details', function (Blueprint $table) {
            $table->dropColumn('product_size');
            $table->dropColumn('product_length');
            $table->dropColumn('product_sleeve');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('ordered_product_details', function (Blueprint $table) {
            //
        });
    }
}
