<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class RemoveCustomerEmailFromOrders extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('orders', function (Blueprint $table) {
            $table->dropColumn('customer_email');
            $table->dropColumn('customer_name');
            $table->dropColumn('customer_country');
            $table->dropColumn('customer_phone');
            $table->dropColumn('customer_address');
            $table->dropColumn('customer_city');
            $table->dropColumn('customer_zip');
            $table->dropColumn('shipping_name');
            $table->dropColumn('shipping_country');
            $table->dropColumn('shipping_email');
            $table->dropColumn('shipping_phone');
            $table->dropColumn('shipping_address');
            $table->dropColumn('shipping_city');
            $table->dropColumn('shipping_zip');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('orders', function (Blueprint $table) {
            //
        });
    }
}
