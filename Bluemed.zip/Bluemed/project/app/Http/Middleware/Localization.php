<?php

namespace App\Http\Middleware;

use Closure;
use Cookie;
use Session;
use Cache;
use DB;
class Localization
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        $ip = $_SERVER['REMOTE_ADDR'];
        $lang = DB::table('language')->where('ip_address', $ip)->get()->first();
        if(!empty($lang))
        {
            \App::setlocale($lang->lang);
        }
        else
        {
            \App::setlocale('en');
        }
        //echo "test ".$value = $request->cookie('locale');exit;
        /*if(isset($_COOKIE['locale']))
        {
          echo "test".$_COOKIE['locale'];exit;    
        }*/
        /*if(Session::has('locale'))
       {
          echo "sfsdfdfds ".Session::get('locale');exit;
           \App::setlocale(Session::get('locale'));
       }*/
       return $next($request);
    }
}
