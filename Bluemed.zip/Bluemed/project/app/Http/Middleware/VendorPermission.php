<?php

namespace App\Http\Middleware;
use Illuminate\Support\Facades\Auth;
use Closure;
use DB;

class VendorPermission
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        if (Auth::guard('web')->check()) {
               $routeArray = app('request')->route()->getAction();
        $controllerAction = class_basename($routeArray['controller']);
        list($controller, $action) = explode('@', $controllerAction);

       

  
          
           
           if(Auth::user()->role_id=='0')
           {
                 return $next($request);
           }
           
            $id=Auth::user()->id;
        $cont=array();
        $permission=DB::table('vendor_permission')->join('vendor_modules', 'vendor_permission.module_id', '=', 'vendor_modules.id')->where('user_id','=',$id)->where('controller','=',$controller)->where('method','=',$action)->count();
          $cont=0;
         
$mod=DB::table('vendor_modules')->where('controller','=',$controller)->where('method','=',$action)->count();
if($mod==0)
{
    return $next($request);
}

        if($permission==1)
        {
            return $next($request);
          
        }
        else
        {
          return abort(404);
        }
        }
        return redirect()->back();
    }
}
