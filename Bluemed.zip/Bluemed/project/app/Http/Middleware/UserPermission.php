<?php

namespace App\Http\Middleware;
use Closure;
use Illuminate\Support\Facades\Auth;
use DB;
use Illuminate\Http\Request;
class UserPermission 
{
    
    public function handle($request, Closure $next, $guard = null)
    {
        if (Auth::guard('admin')->check()) {
            
            $routeArray = app('request')->route()->getAction();
        $controllerAction = class_basename($routeArray['controller']);
        list($controller, $action) = explode('@', $controllerAction);

       

  
          
           
           if(Auth::user()->role_id=='0')
           {
                 return $next($request);
           }
           
            $id=Auth::user()->id;
        $cont=array();
        $permission=DB::table('user_permission')->join('modules', 'user_permission.module_id', '=', 'modules.id')->where('user_id','=',$id)->where('controller','=',$controller)->where('method','=',$action)->count();
          $cont=0;
         
$mod=DB::table('modules')->where('controller','=',$controller)->where('method','=',$action)->count();
if($mod==0)
{
    return $next($request);
}

        if($permission==1)
        {
            return $next($request);
          
        }
        else
        {
          return abort(404);
        }
     
        }
        return redirect()->route('admin.dashboard')->with('unsuccess',"You don't have access to that section"); 
    }
}
