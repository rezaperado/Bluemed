<?php
   
namespace App\Http\Controllers\Admin;
   
use App\Http\Requests;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
   
class UploadimagesController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:admin');
        $this->middleware('user_permissions');
    }
    /**
     * Generate Image upload View
     *
     * @return void
     */
    public function uploadimages()
    {
        return view('admin.importimages.dropzone-view');
    }
    
    /**
     * Image Upload Code
     *
     * @return void
     */
    public function dropzoneStore(Request $request)
    {
        $image = $request->file('file');
        $imageName = $request->file->getClientOriginalName();
        $imageName = str_replace(' ','',$imageName);
        //$imageName = time().'.'.$image->extension();
        $image->move('assets/images/galleries',$imageName);
   
        return response()->json(['success'=>$imageName]);
    }
   
}