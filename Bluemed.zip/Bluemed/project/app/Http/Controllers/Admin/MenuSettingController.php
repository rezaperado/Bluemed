<?php

namespace App\Http\Controllers\Admin;

use Datatables;
use App\Models\MenuSetting;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Input;
use Validator;

class MenuSettingController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:admin');
        $this->middleware('user_permissions');
    }

    //*** JSON Request
    public function datatables()
    {
         $datas = MenuSetting::orderBy('id','desc')->get();
         //--- Integrating This Collection Into Datatables
         return Datatables::of($datas)
                             ->editColumn('title', function(MenuSetting $data) {
                                return  $data->title;
                            })
                             ->editColumn('title_ar', function(MenuSetting $data) {
                                return  $data->title_ar;
                            })
                            ->editColumn('link', function(MenuSetting $data) {
                                return  $data->link;
                            })
                            ->editColumn('parent', function(MenuSetting $data) {
                                $parent= MenuSetting::select('title')->where('id',$data->parent)->get()->first();
                                return !empty($data->parent) ? $parent->title : '-';
                            })
                            ->editColumn('order', function(MenuSetting $data) {
                                return !empty($data->order) ? $data->order : '-';
                            })
                            ->addColumn('status', function(MenuSetting $data) {
                                $class = $data->status == 1 ? 'drop-success' : 'drop-danger';
                                $s = $data->status == 1 ? 'selected' : '';
                                $ns = $data->status == 0 ? 'selected' : '';
                                return '<div class="action-list"><select class="process select droplinks '.$class.'"><option data-val="1" value="'. route('admin-menu-status',['id1' => $data->id, 'id2' => 1]).'" '.$s.'>Activated</option><<option data-val="0" value="'. route('admin-menu-status',['id1' => $data->id, 'id2' => 0]).'" '.$ns.'>Deactivated</option>/select></div>';
                            })  
                            ->addColumn('action', function(MenuSetting $data) {
                                return '<div class="action-list"><a data-href="' . route('admin-menu-edit',$data->id) . '" class="edit" data-toggle="modal" data-target="#modal1"> <i class="fas fa-edit"></i>Edit</a><a href="javascript:;" data-href="' . route('admin-menu-delete',$data->id) . '" data-toggle="modal" data-target="#confirm-delete" class="delete"><i class="fas fa-trash-alt"></i></a></div>';
                            }) 
                            ->rawColumns(['status','action'])
                            ->toJson(); //--- Returning Json Data To Client Side
    }
    public function status($id1,$id2)
    {
        $data = MenuSetting::findOrFail($id1);
        $data->status = $id2;
        $data->update();
    }
    //*** GET Request
    public function index()
    {
        return view('admin.menusetting.index');
    }

    //*** GET Request
    public function large()
    {
        return view('admin.banner.large');
    }

    //*** GET Request
    public function bottom()
    {
        return view('admin.banner.bottom');
    }

    //*** GET Request
    public function create()
    {
        $parents = MenuSetting::where('status',1)->get();
        return view('admin.menusetting.create',compact('parents'));
    }

    //*** GET Request
    public function largecreate()
    {
        return view('admin.banner.largecreate');
    }

    //*** GET Request
    public function bottomcreate()
    {
        return view('admin.banner.bottomcreate');
    }

    //*** POST Request
    public function store(Request $request)
    {
        //--- Validation Section
        $rules = [
               'title'      => 'required',
               'title_ar'      => 'required',
               'link' => 'required',
                ];

        $validator = Validator::make(Input::all(), $rules);
        
        if ($validator->fails()) {
          return response()->json(array('errors' => $validator->getMessageBag()->toArray()));
        }
        //--- Validation Section Ends

        //--- Logic Section
        $data = new MenuSetting();
        $input = $request->all();
        //print_r($input);exit;
        //$input['order'] = 0;
        $data->fill($input)->save();
        //--- Logic Section Ends

        //--- Redirect Section        
        $msg = 'New Data Added Successfully.';
        return response()->json($msg);      
        //--- Redirect Section Ends    
    }

    //*** GET Request
    public function edit($id)
    {
        $data = MenuSetting::findOrFail($id);
        $parents = MenuSetting::where('status',1)->get();
        return view('admin.menusetting.edit',compact('data','parents'));
    }

    //*** POST Request
    public function update(Request $request, $id)
    {
        //--- Validation Section
        $rules = [
               'title'      => 'required',
               'title_ar'      => 'required',
               'link' => 'required',
                ];

        $validator = Validator::make(Input::all(), $rules);
        
        if ($validator->fails()) {
          return response()->json(array('errors' => $validator->getMessageBag()->toArray()));
        }
        //--- Validation Section Ends

        //--- Logic Section
        $data = MenuSetting::findOrFail($id);
        $input = $request->all();
       // $input['order'] = 0;
        $data->update($input);
        //--- Logic Section Ends

        //--- Redirect Section     
        $msg = 'Data Updated Successfully.';
        return response()->json($msg);      
        //--- Redirect Section Ends            
    }

    //*** GET Request Delete
    public function destroy($id)
    {
        $data = MenuSetting::findOrFail($id);
        
        $data->delete();
        //--- Redirect Section     
        $msg = 'Data Deleted Successfully.';
        return response()->json($msg);      
        //--- Redirect Section Ends     
    }
}
