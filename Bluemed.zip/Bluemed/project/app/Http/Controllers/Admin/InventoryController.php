<?php

namespace App\Http\Controllers\Admin;

use Datatables;
use App\Models\inventory;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Input;
use Validator;

class InventoryController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:admin');
        $this->middleware('user_permissions');
    }

    //*** JSON Request
    public function datatables()
    {
        //   $datas = \DB::table('inventory')->get();
             $datas = inventory::orderBy('id','desc')->get();
         //--- Integrating This Collection Into Datatables
         return Datatables::of($datas)
                            ->editColumn('attribute_id', function(inventory $data){
                                    $name = \DB::table('attribute_masters')->where('id',$data->attribute_id)->first();
                                    if(!is_null($name)){
                                        return $name->name_en;
                                    }else{
                                        return null;
                                    } 
                            })
                            ->addColumn('units', function(inventory $data){
                                    $units = \DB::table('attribute_masters')->where('id',$data->attribute_id)->first();
                                    return $units->units;
                            })
                            ->addColumn('action', function(inventory $data) {
                                     return '<div class="action-list"><a data-href="' . route('admin-inv-edit',$data->id) . '" class="edit" data-toggle="modal" data-target="#modal1"> <i class="fas fa-edit"></i>Edit</a><a href="javascript:;" data-href="' . route('admin-inv-delete',$data->id) . '" data-toggle="modal" data-target="#confirm-delete" class="delete"><i class="fas fa-trash-alt"></i></a></div>';
                             }) 
                            ->rawColumns(['action'])
                            ->toJson(); //--- Returning Json Data To Client Side
    }

    //*** GET Request
    public function index()
    {
        return view('admin.inventory.index');
    }

    //*** GET Request
    public function create()
    {
        return view('admin.inventory.create');
    }

    //*** POST Request
    public function store(Request $request)
    {
       

        //--- Logic Section
        
        $input = $request->all();
        
        $rules = [
                'attribute_id'   => 'required|unique:inventories',
            ];
        $validator = Validator::make(Input::all(), $rules);
        
        if ($validator->fails()) {
            return response()->json(array('errors' => $validator->getMessageBag()->toArray()));
        }else{
            echo "<pre>"; print_r($input); exit;
            $data = new inventory();
            $data->fill($input)->save();
            //--- Logic Section Ends
    
            //--- Redirect Section        
            $msg = 'New Data Added Successfully.';
            return response()->json($msg);      
            //--- Redirect Section Ends       
        }
    }

    //*** GET Request
    public function edit($id)
    {
        $data = inventory::findOrFail($id);
        return view('admin.inventory.edit',compact('data'));
    }

    //*** POST Request
    public function update(Request $request, $id)
    {
        //--- Validation Section
        $rules = [
        	'photo' => 'mimes:jpeg,jpg,png,svg',
        	'slug' => 'unique:categories,slug,'.$id.'|regex:/^[a-zA-Z0-9\s-]+$/'
        		 ];
        $customs = [
        	'photo.mimes' => 'Image Type is Invalid.',
        	'slug.unique' => 'This slug has already been taken.',
            'slug.regex' => 'Slug Must Not Have Any Special Characters.'
        		   ];
        $validator = Validator::make(Input::all(), $rules, $customs);
        
        if ($validator->fails()) {
          return response()->json(array('errors' => $validator->getMessageBag()->toArray()));
        }
        //--- Validation Section Ends

        //--- Logic Section
        $data = Inventory::findOrFail($id);
        $input = $request->all();
           
        $data->update($input);
        //--- Logic Section Ends

        //--- Redirect Section     
        $msg = 'Data Updated Successfully.';
        return response()->json($msg);      
        //--- Redirect Section Ends            
    }

      //*** GET Request Status
      public function status($id1,$id2)
        {
            $data = Inventory::findOrFail($id1);
            $data->status = $id2;
            $data->update();
        }


    //*** GET Request Delete
    public function destroy($id)
    {
        $data = Inventory::findOrFail($id);

       
        // if($data->products->count()>0)
        // {
        // //--- Redirect Section     
        // $msg = 'Remove the products first !!!!';
        // return response()->json($msg);      
        // //--- Redirect Section Ends    
        // }

        $data->delete();
        //--- Redirect Section     
        $msg = 'Data Deleted Successfully.';
        return response()->json($msg);      
        //--- Redirect Section Ends     
    }
}
