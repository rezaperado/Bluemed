<?php

namespace App\Http\Controllers\Admin;

use Datatables;
use App\Models\Childcategory;
use App\Models\Subcategory;
use Carbon\Carbon;
use App\Models\Product;
use App\Models\Category;
use App\Models\Currency;
use App\Models\Gallery;
use App\Models\Brand;
use App\Models\Collection;
use App\Models\PracticeField;
use App\Models\User;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Input;
use Validator;
use Image;
use App\Models\attribute_masters;
use DB;
use File;
use App\Models\Color;
class CatalogController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:admin');
        $this->middleware('user_permissions');
       

        
    }

    //*** JSON Request
    public function datatables(Request $request)
    {
         $datas = Product::where('product_type','=','normal')->orderBy('id','desc');
		
         if (request()->has('category_id') || request()->has('sub_category')) {

            $category_id = request()->get('category_id');
            $sub_category = request()->get('sub_category');
            if (!empty($category_id) && empty($sub_category)) {
                $datas->where('category_id', $category_id);
            }
            else if (!empty($category_id) && !empty($sub_category)) {
                $datas->where('category_id', $category_id)->where('subcategory_id', $sub_category);
            }
        }
        if (request()->has('stock') && !empty(request()->get('stock'))) 
        {
            $stock = request()->get('stock');
            $datas->where('stock','>=', $stock);
            //echo $datas->toSql();exit;
        }
		if (request()->has('vendor') && !empty(request()->get('vendor'))) 
        {
            $vendor = request()->get('vendor');
            $datas->where('user_id','=', $vendor);
        }
        if (request()->has('brand')) 
        {
            $brand = request()->get('brand');
            if($brand != 0)
            {
                $datas->where('brand_id','=', $brand);    
            }
            else if($brand == 0 && $brand != '')
            {
                $datas->where('brand_id','=', 0)->orWhereNull('brand_id');       
            }
        }
        if (request()->has('sort')) 
        {
            $sort = request()->get('sort');
            if($sort == 'asc')
            {
                $datas->orderBy('name','asc');
            }
            else if($sort == 'desc')
            {
                $datas->orderBy('name','desc');   
            }
            else if($sort == 'price-asc')
            {
                $datas->orderBy('price','asc');   
            }
            else if($sort == 'price-desc')
            {
                $datas->orderBy('price','desc');   
            }
        }
        $datas = $datas->get();
         //--- Integrating This Collection Into Datatables
         return Datatables::of($datas)
                            ->addColumn('checkbox', function(Product $data) {
                                return '<input type="checkbox" class="chk_product" name="chk_product" id="chk_product" value="'.$data->id.'">';
                            })
                            ->editColumn('sku', function(Product $data) {
                                return $data->sku;
                            })
                            ->editColumn('name', function(Product $data) {
                                $name = strlen(strip_tags($data->name)) > 30 ? substr(strip_tags($data->name),0,30).'...' : strip_tags($data->name);
                                $id = '<small>Product ID: <a href="'.route('front.product', $data->slug).'" target="_blank">'.sprintf("%'.08d",$data->id).'</a></small>';
                                return  $name.'<br>'.$id;
                            })
                            ->editColumn('price', function(Product $data) {
                                $sign = Currency::where('is_default','=',1)->first();
                                $price = $sign->sign." ".number_format($data->price,3);
                                return  $price;
                            })
                            ->editColumn('stock', function(Product $data) {
                                $stck = (string)$data->stock;
                                if($stck == "0")
                                return "Out Of Stock";
                                elseif($stck == null)
                                return "Unlimited";
                                else
                                return $data->stock;
                            })
                            ->addColumn('status', function(Product $data) {
                                $class = $data->status == 1 ? 'drop-success' : 'drop-danger';
                                $s = $data->status == 1 ? 'selected' : '';
                                $ns = $data->status == 0 ? 'selected' : '';
                                return '<div class="action-list"><select class="process select droplinks '.$class.'"><option data-val="1" value="'. route('admin-prod-status',['id1' => $data->id, 'id2' => 1]).'" '.$s.'>Activated</option><<option data-val="0" value="'. route('admin-prod-status',['id1' => $data->id, 'id2' => 0]).'" '.$ns.'>Deactivated</option>/select></div>';
                            })                             
                            ->addColumn('action', function(Product $data) {
                                 return '<div class="dropdown"><button class="dropbtn">Actions <i style="font-size: 10px;" class="fa fa-chevron-down "></i></button><div class="dropdown-content"><a href="' . route('admin-prod-edit',$data->id) . '"> <i class="fas fa-edit"></i>Edit</a><a href="javascript" class="set-gallery" data-toggle="modal" data-target="#setgallery"><input type="hidden" value="'.$data->id.'"><i class="fas fa-eye"></i> View Gallery</a><a data-href="' . route('admin-prod-feature',$data->id) . '" class="feature" data-toggle="modal" data-target="#modal2"> <i class="fas fa-star"></i>Highlight</a><a href="javascript:;" data-href="' . route('admin-prod-delete',$data->id) . '" data-toggle="modal" data-target="#confirm-delete" class="delete"><i class="fas fa-trash-alt"></i> Delete</a></div></div></div><div class="action-list00"></div>';
                                /*return '<div class="action-list"><a href="' . route('admin-prod-edit',$data->id) . '"> <i class="fas fa-edit"></i>Edit</a><a href="javascript" class="set-gallery" data-toggle="modal" data-target="#setgallery"><input type="hidden" value="'.$data->id.'"><i class="fas fa-eye"></i> View Gallery</a><a data-href="' . route('admin-prod-feature',$data->id) . '" class="feature" data-toggle="modal" data-target="#modal2"> <i class="fas fa-star"></i>Highlight</a><a href="javascript:;" data-href="' . route('admin-prod-delete',$data->id) . '" data-toggle="modal" data-target="#confirm-delete" class="delete"><i class="fas fa-trash-alt"></i></a></div>';*/
                            }) 
                            ->rawColumns(['checkbox','name', 'status', 'action'])
                            ->toJson(); //--- Returning Json Data To Client Side
    }

    //*** JSON Request
    public function deactivedatatables()
    {
         $datas = Product::where('status','=',0)->orderBy('id','desc')->get();
         
         //--- Integrating This Collection Into Datatables
         return Datatables::of($datas)
                            ->editColumn('name', function(Product $data) {
                                $name = strlen(strip_tags($data->name)) > 50 ? substr(strip_tags($data->name),0,50).'...' : strip_tags($data->name);
                                $id = '<small>Product ID: <a href="'.route('front.product', $data->slug).'" target="_blank">'.sprintf("%'.08d",$data->id).'</a></small>';
                                return  $name.'<br>'.$id;
                            })
                            ->editColumn('price', function(Product $data) {
                                $sign = Currency::where('is_default','=',1)->first();
                                $price = $sign->sign.$data->price;
                                return  $price;
                            })
                            ->editColumn('stock', function(Product $data) {
                                $stck = (string)$data->stock;
                                if($stck == "0")
                                return "Out Of Stock";
                                elseif($stck == null)
                                return "Unlimited";
                                else
                                return $data->stock;
                            })
                            ->addColumn('status', function(Product $data) {
                                $class = $data->status == 1 ? 'drop-success' : 'drop-danger';
                                $s = $data->status == 1 ? 'selected' : '';
                                $ns = $data->status == 0 ? 'selected' : '';
                                return '<div class="action-list"><select class="process select droplinks '.$class.'"><option data-val="1" value="'. route('admin-prod-status',['id1' => $data->id, 'id2' => 1]).'" '.$s.'>Activated</option><<option data-val="0" value="'. route('admin-prod-status',['id1' => $data->id, 'id2' => 0]).'" '.$ns.'>Deactivated</option>/select></div>';
                            })                             
                            ->addColumn('action', function(Product $data) {
                                return '<div class="action-list"><a href="' . route('admin-prod-edit',$data->id) . '"> <i class="fas fa-edit"></i>Edit</a><a href="javascript" class="set-gallery" data-toggle="modal" data-target="#setgallery"><input type="hidden" value="'.$data->id.'"><i class="fas fa-eye"></i> View Gallery</a><a data-href="' . route('admin-prod-feature',$data->id) . '" class="feature" data-toggle="modal" data-target="#modal2"> <i class="fas fa-star"></i>Highlight</a><a href="javascript:;" data-href="' . route('admin-prod-delete',$data->id) . '" data-toggle="modal" data-target="#confirm-delete" class="delete"><i class="fas fa-trash-alt"></i></a></div>';
                            }) 
                            ->rawColumns(['name', 'status', 'action'])
                            ->toJson(); //--- Returning Json Data To Client Side
    }
    
    
    public function product_attributes(){
         return view('admin.attributes.index');
    }
    
     public function inventory(){
         return view('admin.inventory.index');
    }
    public function getsubcat(Request $request)
    {
        $category_id = $request->category_id;
        $sub_cats = Subcategory::where('category_id', $category_id)->orderBy('name','asc')->get();
        $sub_cat_html = '';
        foreach($sub_cats as $cat)
        {
            $sub_cat_html .= '<option value="'.$cat->id.'">'.$cat->name.'</option>';
        }
        echo $sub_cat_html;exit;
    }
    //*** GET Request
    public function index()
    {
        $category = Category::where('status',1)->orderBy('name','asc')->get();
		$vendor_role_id = DB::table('roles')->select('id')->where('name','Vendor')->get()->first();
		$vendor_role_id = $vendor_role_id->id;
		$vendor = User::where('is_vendor','=',2)->where('role_id','=',DB::raw("'$vendor_role_id'"))->orderBy('id','desc')->get();
		
        $brands = Brand::select('brands.id','brands.name')->join('products','products.brand_id','=','brands.id')->orderBy('brands.name','asc')->distinct()->get();
        //print_r($brands);exit;
        $products = Product::where('product_type','!=','affiliate')->orderBy('name','asc')->get();
        $productsData = array();
        foreach($products as $key => $product)
        {
        	$productsData[$key]['item_code'] = isset($product->sku) ? $product->sku : '';
        	$productsData[$key]['name_en'] = isset($product->name) ? $product->name : '';
        	$productsData[$key]['name_ar'] = isset($product->name_ar) ? $product->name_ar : '';
        	$category_data = getCategoryName($product->category_id);
        	$productsData[$key]['category'] = isset($category_data->name) ? $category_data->name : '';
        	$sub_category = getSubCategoryName($product->subcategory_id);
        	$productsData[$key]['sub_category'] = isset($sub_category->name) ? $sub_category->name : '';
        	$child_category = getChildCategory($product->childcategory_id);
        	$productsData[$key]['child_category'] = isset($child_category->name) ? $child_category->name : '';
        	$brand = getBrandName($product->id);
        	$productsData[$key]['brand'] = $brand;
        	$variations = DB::table('product_variations')->where('product_id', $product->id)->get();
        	$attr_master = $datas = attribute_masters::orderBy('id','desc')->get()->toArray();
        	$attributes_arr = array();
        	foreach($attr_master as $attr)
        	{
        		$attributes_arr[] = $attr['name_en'];
        	}
        	
        	if($variations->count() > 0)
        	{
        		$attr_arr = array();
        		$variation_arr = array();
        		foreach($variations as $variation)
        		{
        			$attributes = (array)json_decode($variation->json_attributes);
        			$index = 0;
        			
        			foreach($attributes_arr as $attrkey => $val)
    				{
    					if(isset($attributes[$val]) && !empty($attributes[$val]))
    					{
    						$attr_arr[$val] = $attributes[$val];	
    					}
    					else
    					{
    						$attr_arr[$val] = '';		
    					}
    				}
    				$attr_arr['Sku'] = $variation->sku;
    				$attr_arr['Qty'] = $variation->qty;
    				$attr_arr['Price'] = $variation->price;
    				$attr_string = urldecode(str_replace('=',':',str_replace('&',',',http_build_query($attr_arr))));
	        		array_push($variation_arr, $attr_string);
        		}
        		$productsData[$key]['attributes'] = $variation_arr;
        	}
        	$productsData[$key]['price'] = $product->price;
        	$productsData[$key]['stock'] = $product->stock;
        	$productsData[$key]['description_en'] = $product->details;
        	$productsData[$key]['description_ar'] = $product->details_ar;
        }
        // echo "<pre>";
        // print_r($productsData);exit;
        return view('admin.product.index',compact('category','brands','productsData','vendor'));
    }

    //*** GET Request
    public function deactive()
    {
        return view('admin.product.deactive');
    }

    //*** GET Request
    public function types()
    {
        return view('admin.product.types');
    }

    //*** GET Request
    public function createPhysical()    
    {   
        $cats = Category::all();    
        $sign = Currency::where('is_default','=',1)->first();   
        $brands = Brand::orderBy('name','ASC')->get();
        $collection = Collection::orderBy('name','ASC')->get();
        $practice_field = PracticeField::orderBy('name','ASC')->get();
        $colors = Color::orderBy('color_id','desc')->get(); 
		$vendor_role_id = DB::table('roles')->select('id')->where('name','Vendor')->get()->first();
		$vendor_role_id = $vendor_role_id->id;
		$vendor = User::where('is_vendor','=',2)->where('role_id','=',DB::raw("'$vendor_role_id'"))->orderBy('id','desc')->get();
        $color_data = array();  
        foreach($colors as $key => $color)  
        {   
            $color_data[$key]['id'] = $key; 
            $color_data[$key]['name'] = $color->color_name; 
            $color_data[$key]['code'] = $color->color_code; 
        }   
        $color_data = json_encode($color_data); 
        return view('admin.product.create.physical',compact('cats','sign','brands','color_data','vendor','collection','practice_field'));  
    }

    //*** GET Request
    public function createDigital()
    {
        $cats = Category::all();
        $sign = Currency::where('is_default','=',1)->first();
        return view('admin.product.create.digital',compact('cats','sign'));
    }

    //*** GET Request
    public function createLicense()
    {
        $cats = Category::all();
        $sign = Currency::where('is_default','=',1)->first();
        return view('admin.product.create.license',compact('cats','sign'));
    }

    //*** GET Request
    public function status($id1,$id2)
    {
        $data = Product::findOrFail($id1);
        $data->status = $id2;
        $data->update();
    }

    //*** POST Request
    public function uploadUpdate(Request $request,$id)
    {
        //--- Validation Section
        $rules = [
          'image' => 'required',
        ];
        $validator = Validator::make($request->all(), $rules);
        if ($validator->fails()) {
          return response()->json(array('errors' => $validator->getMessageBag()->toArray()));
        }

        $data = Product::findOrFail($id);

        //--- Validation Section Ends
        $image = $request->image;
        list($type, $image) = explode(';', $image);
        list(, $image)      = explode(',', $image);
        $image = base64_decode($image);
        $image_name = time().str_random(8).'.png';
        $path = 'assets/images/products/'.$image_name;
        file_put_contents($path, $image);
                if($data->photo != null)
                {
                    if (file_exists(public_path().'/assets/images/products/'.$data->photo)) {
                        unlink(public_path().'/assets/images/products/'.$data->photo);
                    }
                } 
                        $input['photo'] = $image_name;
         $data->update($input);
                if($data->thumbnail != null)
                {
                    if (file_exists(public_path().'/assets/images/thumbnails/'.$data->thumbnail)) {
                        unlink(public_path().'/assets/images/thumbnails/'.$data->thumbnail);
                    }
                } 

        $img = Image::make(public_path().'/assets/images/products/'.$data->photo)->resize(285, 285);
        $thumbnail = time().str_random(8).'.jpg';
        $img->save(public_path().'/assets/images/thumbnails/'.$thumbnail);
        $data->thumbnail  = $thumbnail;   
        $data->update();
        return response()->json(['status'=>true,'file_name' => $image_name]);
    }

    //*** POST Request
    public function store(Request $request)
    {
        //--- Validation Section
        /*$rules = [
            'photo'      => 'required',
            'file'       => 'mimes:zip',
            'sku' => 'unique:products,sku'
        ];

        $validator = Validator::make(Input::all(), $rules);

        if ($validator->fails()) {
            return response()->json(array('errors' => $validator->getMessageBag()->toArray()));
        }*/
        //--- Validation Section Ends

        //--- Logic Section  
        //check sku is available
        $input = $request->all();
        
        //print_r($input['collection_id']);die();
        $coll_id=implode(",",$input['collection_id']);
        
        $prd = Product::where('sku',$input['sku'])->get()->count();
        if($prd > 0)
        {
            echo "SKU already exist";exit;
        }
       

        $data = new Product;
        $sign = Currency::where('is_default','=',1)->first();
         $input = $request->all();  
        $color_images = $input['color_images']; 
        $color_names = $input['product_colors'];
        //print_r($input);exit;
        $attributes = isset($input['attr'])? $input['attr'] : '';
        // Check File
        if ($file = $request->file('file'))
        {
            $name = time().$file->getClientOriginalName();
            $name = str_replace(' ', '', $name);
            $file->move('assets/files',$name);
            $input['file'] = $name;
        }
        $attachmentArr = array();
        if (!empty($request->file('attachment')))
        {
            $files = $request->file('attachment');
            foreach($files as $key => $file)
            {
                $name = time().$file->getClientOriginalName();
                $name = str_replace(' ', '', $name);
                $file->move('assets/files',$name);
                $attachmentArr[] = $name;
            }
        }
        $attachmentArr = implode(",", $attachmentArr);
        $input['attachment'] = $attachmentArr;
        $image = $input['photo'];
        // list($type, $image) = explode(';', $image);
        // list(, $image)      = explode(',', $image);
		if(!empty($image))
        {
            $image_parts = explode(";base64,", $image);
            $image_type_aux = explode("image/", $image_parts[0]);
            $image_type = $image_type_aux[1];
            $image_base64 = base64_decode($image_parts[1]);
            $image_name = time().str_random(8) . '.'.$image_type;
            $file = 'assets/images/products/' . $image_name;
            file_put_contents($file, $image_base64);
            $input['photo'] = $image_name;
        }
        else
        {
            $input['photo'] = 'default.png';
        }
		
        // Check Physical
        if($request->type == "Physical")
        {
            
            if(!is_null($input['size'])){
                  $size = implode(',', $input['size']);
            }else{
                $size= null;
            }
            
             if(!is_null($input['size_qty'])){
                  $sizeqty = implode(',', $input['size_qty']);
            }else{
                $sizeqty= null;
            }
            
             if(!is_null($input['size_price'])){
                  $sizeprice = implode(',', $input['size_price']);
            }else{
                $sizeprice= null;
            }
            
                  
            $price = ($input['price'] / $sign->value);  
            if(isset($input['is_multiple_products']))
            {
                $input['is_multiple_products'] = 1;
            } 
            else
            {
                $input['is_multiple_products'] = 0;
            }    
                    
            $insertProductValues = \DB::table("products")->insertGetID(['user_id'=>$input['vendor_id'], 'category_id'=>$input['category_id'],'subcategory_id'=>$input['subcategory_id'], 'name'=>$input['name'],'name_ar'=>$input['name_ar'],'photo'=>$input['photo'],'size'=>$size,'size_qty'=>$sizeqty,'size_price'=>$sizeprice,'price'=>$price, 'details'=>$input['details'],'details_ar'=>$input['details_ar'],'policy_ar'=>$input['policy_ar'],'weight'=>$input['weight'],'stock'=>$input['stock'],'policy'=>$input['policy'],'youtube'=>$input['youtube'],'sku'=>$input['sku'],'type'=>$input['type'],'meta_description'=>$input['meta_description'],'brand_id'=>$input['brand_id'],'collection_id'=>$coll_id,'practice_field_id'=>$input['practice_field_id'],'product_info'=>$input['product_info'],'is_multiple_products' => $input['is_multiple_products'], 'attachment' => $attachmentArr]);
            //print_r($insertProductValues);exit;
            $id = $insertProductValues;


        }
        //save color image  
        if(!empty($color_images))   
        {   
                
            foreach($color_images as $key => $image)    
            {   
                DB::table('product_color_images')->insert(array('product_id' => $id, 'color_name' => $color_names[$key], 'image' => $image));   
            }   
        }
        
         if (isset($input['attr_name_en']) && !is_null($input['attr_name_en'])) {
            //  echo "<pre>"; print_r($input); exit;
            //  $input['attribute_id'] = implode(',',$input['attr_name_en']); 
             $check = \DB::table('product_attributes')->where('product_id',$id)->get();
              if(!is_null($check)){
                    $check = \DB::table('product_attributes')->where('product_id',$id)->delete();
                    foreach($input['attr_name_en'] as $key=>$value){
                        $checkattr = \DB::table('product_attributes')->where('product_id',$id)->where('attribute_id',$value)->get();
                        if(!is_null($checkattr)){
                         $update = \DB::table("product_attributes")->where('product_id',$id)->where('attribute_id',$value)->update(['qty'=>$input['attr_qty'][$key]]);
                        }else{
                          $insert = \DB::table("product_attributes")->insertGetId(['product_id'=>$id,'attribute_id'=>$value,'qty'=>$input['attr_qty'][$key]]); 
                        }
                    }
                    
              }else{
                    foreach($input['attr_name_en'] as $key=>$value){
                         $insert = \DB::table("product_attributes")->insertGetId(['product_id'=>$id,'attribute_id'=>$value,'qty'=>$input['attr_qty'][$key]]);
                    }
              }
                 
                // $input['attr_units'] = implode(',', $input['attr_units']); 
             
         }
               
       
      if($input['sleeve'][0]!=null && isset($input['sleeve'][0])){
        $check2 = \DB::table('product_sleeves')->where('product_id',$id)->get();
              if(!is_null($check2)){
                    $check3 = \DB::table('product_sleeves')->where('product_id',$id)->delete();
              }  
            foreach($input['sleeve'] as $s){
                $insertSleeves = \DB::table("product_sleeves")->insertGetID(['product_id'=>$id,'sleeve_type'=>$s]);
            }
        }

        // Conert Price According to Currency
        // $input['price'] = ($input['price'] / $sign->value);
        // $input['previous_price'] = ($input['previous_price'] / $sign->value);

        // Save Data
        // $data->fill($input)->save();

        // Set SLug
        // echo $id; exit;
        $prod = Product::find($id);
        $prod->slug = str_slug($input['name'],'-').'-'.strtolower(str_random(3).$id.str_random(3));
        // Set Thumbnail
        /* $img = Image::make(public_path().'/assets/images/products/'.$prod->photo)->resize(285, 285);
        $thumbnail = time().str_random(8).'.jpg';
        $img->save(public_path().'/assets/images/thumbnails/'.$thumbnail);
        $prod->thumbnail  = $thumbnail;
        $prod->update(); */

        // Add To Gallery If any
        $lastid = $id;
        if ($files = $request->file('gallery')){
            foreach ($files as  $key => $file){
                if(in_array($key, $request->galval))
                {
                    $gallery = new Gallery;
                    $name = time().$file->getClientOriginalName();
                    $file->move('assets/images/galleries',$name);
                    $gallery['photo'] = $name;
                    $gallery['product_id'] = $lastid;
                    $gallery->save();
                }
            }
        }
        //logic Section Ends

        //store product attr
        if(!empty($attributes))
        {
            $attr_arr = array();
            $attr_val_arr = array();
            $attr_json_arr = array();
            $attribute_names = array();
            if(!empty($attributes))
            {
                $alt_arr = $attributes;
                foreach($alt_arr as $key=>$val)
                {
                    foreach($val as $val_key => $inner_val)
                    {
                        if(empty($inner_val))
                        {
                            unset($attributes[$key][$val_key]);
                        }
                        else
                        {
                            //echo $val_key;exit;
                            array_push($attribute_names, $val_key);
                        }
                    }
                }
                
                $attr_arr = array();
                $attribute_names = array_unique($attribute_names);
                $imploted_attr = $attribute_names;
                //print_r($attributes);exit;
                /*if (($key = array_search('price', $imploted_attr)) !== false) {
                    unset($imploted_attr[$key]);
                }
                if (($key = array_search('sku', $imploted_attr)) !== false) {
                    unset($imploted_attr[$key]);
                }
                if (($key = array_search('qty', $imploted_attr)) !== false) {
                    unset($imploted_attr[$key]);
                }*/
                //print_r($imploted_attr);exit;
                foreach ($attributes as $attrkey => $attribute) {
                    $imploted_attr = array_keys($attribute);
                    if (($key = array_search('price', $imploted_attr)) !== false) {
                        unset($imploted_attr[$key]);
                    }
                    if (($key = array_search('sku', $imploted_attr)) !== false) {
                        unset($imploted_attr[$key]);
                    }
                    if (($key = array_search('qty', $imploted_attr)) !== false) {
                        unset($imploted_attr[$key]);
                    }
                    foreach ($attribute as $key => $value) {
                        $attr_arr[$attrkey]['product_id'] = $lastid;

                        $attr_arr[$attrkey]['attribute_names'] = implode('-', $imploted_attr);
                        $excluded_key = array('price','sku','qty');
                        //echo $key;exit;
                        if(!in_array($key,$excluded_key))
                        {
                            $first_val = isset($attr_arr[$attrkey]['attribute_values']) ? $attr_arr[$attrkey]['attribute_values'] : '';
                            if(empty($first_val))
                            {
                                $attr_arr[$attrkey]['attribute_values'] = $value;
                                array_push($attr_val_arr, $value);
                            }
                            else
                            {
                                $attr_arr[$attrkey]['attribute_values'] = $first_val.'-'.$value;
                                array_push($attr_val_arr,$value);
                            }

                        }
                        else
                        {
                            
                            $attr_arr[$attrkey]['sku'] = $attributes[$attrkey]['sku'];
                            $attr_arr[$attrkey]['qty'] = $attributes[$attrkey]['qty'];
                            $attr_arr[$attrkey]['price'] = $attributes[$attrkey]['price'];
                        }
                        $attr_arr[$attrkey]['created_at'] = date('Y-m-d H:i:s');
                        $attr_arr[$attrkey]['updated_at'] = date('Y-m-d H:i:s');

                        continue;
                    }
                }
                //$attr_val_arr = array_filter($attr_val_arr);
                //print_r($attr_arr);exit;
                if(count($attr_val_arr) > 0)
                {
                    foreach($attr_arr as $key => $attr)
                    {
                        $attr_names[$key] = explode('-', $attr['attribute_names']);
                        $attr_values[$key] = explode('-', $attr['attribute_values']);
                    }
                    $attr_json_arr = array();
                    foreach ($attr_names as $key => $name) {
                        foreach ($name as $namekey => $value) {
                            $vals = '';
                            if(isset($attr_values[$key][$namekey]))
                                $vals = $attr_values[$key][$namekey];
                            $attr_json_arr[$key][$value] = $vals;
                        }
                    }

                    foreach($attr_json_arr as $key => $val)
                    {
                        $attr_arr[$key]['json_attributes'] = json_encode($val);
                    }
                    DB::table('product_variations')->where('product_id', $lastid)->delete();
                    DB::table('product_variations')->insert($attr_arr);
                }
            }
        }

        //--- Redirect Section        
             $msg = 'Product Added Successfully.<a href="'.route('admin-prod-index').'">View Product Lists.</a>';
        return response()->json($msg); 
        // return view('admin.product.index');
        //--- Redirect Section Ends 
        
        return Redirect::to('admin.product.index');
    }

    //*** POST Request
    public function import(){

        $cats = Category::all();
        $sign = Currency::where('is_default','=',1)->first();
        return view('admin.product.productcsv',compact('cats','sign'));
    }

    public function importSubmit(Request $request)
    {
          $params = $request->all();
        $excel_data = isset($params['excel_data']) ? $params['excel_data'] : '';
        $excel_data = json_decode($excel_data);
        unset($excel_data[0]);
        $imagesNotFound = array();
        $datas = "";
        $log = '';
        $i=1;
        $sign = Currency::where('is_default','=',1)->first();
        foreach($excel_data as $line)
        {
            $line[0] = strval($line[0]);
            $product_exist = DB::select("select id from products where sku = '".$line[0]."'");
            $product_exist = isset($product_exist[0]->id) ? $product_exist[0]->id : '';
            $id = $product_exist;
            if (!$product_exist || $product_exist)
            {
                $input['type'] = 'Physical';
                $input['sku'] = $line[0];
                $input['category_id'] = 0;
                $input['subcategory_id'] = 0;
                $input['childcategory_id'] = 0;
                $input['brand_id'] = 0;
                $mcat = DB::select("select id from categories where lower(name)='".strtolower($line[1])."'");
                $mcat = isset($mcat[0]->id) ? $mcat[0]->id : '';
                //$brand = Brand::where(DB::raw('lower(name)'), strtolower($line[4]));
                $brandTEmp = DB::select("select id from brands where lower(name) = '".strtolower(trim($line[4]))."'");
                // print_r($brandTEmp);
                $brand = isset($brandTEmp[0]->id) ? $brandTEmp[0]->id : '';
               /* echo "==".$brand."==";
                die;*/
                if(!empty($brand)){
                    $input['brand_id'] = $brand;
                }
                
                
                  if(!empty($line[25]))
                        {
                           $coll=explode(',',$line[25]);
                           $new_coll=array();
                           
                           for($ccc=0;$ccc<count($coll);$ccc++)
                           {
                            
                            $ch=Collection::where('name','=',$coll[$ccc])->count();
                            if($ch==0)
                            {
                    
                        $log .= "<br>SKU: ".$line[0]." - No Collection Found (".$coll[$ccc].")!<br>";
                  
                            }
                            
                            else
                            {
                                $ch=Collection::where('name','=',$coll[$ccc])->get();
                                foreach($ch as $c)
                                {
                                     $new_coll[]= $c->id;
                                }
                            }
                            
                            
                           }
                           $input['collection_id'] = implode(',',$new_coll); 
                            
                            
                        }
                        else
                        {
                            $input['collection_id'] =0;
                        }
                        
                        
                           if(!empty($line[26]))
                        {
                           
                            
                            $ch=PracticeField::where('name','=',$line[26])->count();
                            if($ch==0)
                            {
                    
                        $log .= "<br>SKU: ".$line[0]." - No Practice Field Found!<br>";
                   
                            }else
                            {
                                $ch=PracticeField::where('name','=',$line[26])->get();
                                foreach($ch as $c)
                                {
                                     $input['practice_field_id'] = $c->id;
                                }
                            }
                        }
                        
                        else
                        {
                             $input['practice_field_id']=0;
                        }
                        
                        
                        
                        
                          if(!empty($line[27]))
                        {
                           
                            
                            $ch=User::where('shop_name','=',$line[27])->count();
                            if($ch==0)
                            {
                    
                        $log .= "<br>SKU: ".$line[0]." - No User Field Found!<br>";
                   
                            }else
                            {
                                $ch=User::where('shop_name','=',$line[27])->get();
                                foreach($ch as $c)
                                {
                                     $input['user_id'] = $c->id;
                                }
                            }
                        }
                        
                        else
                        
                        {
                          $input['user_id'] =0;  
                        }
                        
                        
                if(!empty($mcat))
                {
                    $input['category_id'] = $mcat;

                    if($line[2] != ""){
                        $scat = DB::select("select id from subcategories where category_id = ".$mcat." and status=1 and lower(name) = '".strtolower($line[2])."'");
                        $scat = isset($scat[0]->id) ? $scat[0]->id : '';
                        if(!empty($scat)) {
                            $input['subcategory_id'] = $scat;
                        }
                    }
                    if($line[3] != ""){
                        $chcat = DB::select("select id from childcategories where lower(name) = '".strtolower($line[3])."'");
                        $chcat = isset($chcat[0]->id) ? $chcat[0]->id : '';
                        if(!empty($chcat)) {
                            $input['childcategory_id'] = $chcat;
                        }
                    }

                    $input['photo'] = mb_convert_encoding(strtolower($line[7]), 'UTF-8', 'UTF-8');
                    $input['name'] = mb_convert_encoding($line[5], 'UTF-8', 'UTF-8');
                    $input['name_ar'] = mb_convert_encoding($line[6], 'UTF-8', 'UTF-8');
                    $input['details'] = mb_convert_encoding($line[10], 'UTF-8', 'UTF-8');
                    $input['details_ar'] = mb_convert_encoding($line[11], 'UTF-8', 'UTF-8');
                    $input['product_info'] = mb_convert_encoding($line[12], 'UTF-8', 'UTF-8');
                    $input['color'] = mb_convert_encoding($line[17], 'UTF-8', 'UTF-8');
                    $input['price'] = mb_convert_encoding($line[13], 'UTF-8', 'UTF-8');
                    $input['previous_price'] = mb_convert_encoding($line[14], 'UTF-8', 'UTF-8');
                    $input['weight'] = !empty($line[15]) ? $line[15] : 0;
                    $input['stock'] = $line[16];
                    $input['youtube'] = mb_convert_encoding($line[19], 'UTF-8', 'UTF-8');
                    $input['policy'] = mb_convert_encoding($line[20], 'UTF-8', 'UTF-8');
                    $input['policy_ar'] = mb_convert_encoding($line[21], 'UTF-8', 'UTF-8');
                    $input['meta_tag'] = mb_convert_encoding($line[22], 'UTF-8', 'UTF-8');
                    $input['meta_description'] = mb_convert_encoding($line[23], 'UTF-8', 'UTF-8');
                    $input['tags'] = mb_convert_encoding($line[18], 'UTF-8',
                    'UTF-8');
                    $input['product_type'] = 'normal';
                    // Conert Price According to Currency
                    $input['price'] = ($input['price'] / $sign->value);
                    $input['previous_price'] = ($input['previous_price'] / $sign->value);
                    $input['is_multiple_products'] = !empty($line[9]) ? 1 : 0;
                    // Save Data
                    if($product_exist)
                    {
                        //DB::table('products')->where('sku',                         )->update($input);
                       // $prod = DB::select("select id, name, slug from products where sku='".$line[0]."'");
                       // $prod = $prod[0];
                    }
                    else
                    {
                       // DB::table('products')->insert($input);
                       // $prod = DB::select("select id, name, slug from products where sku='".$line[0]."'");                        
                        //$prod = $prod[0];  
                        //echo "test2";exit;   
                    }
                   // $slug = str_slug($prod->name,'-').'-'.strtolower(str_random(3).$prod->id.str_random(3));
                    $thumbnail = '';
                    // Set Thumbnail
                    if(!empty($line[7]))
                    {
                        if(file_exists(public_path('assets/images/galleries/'.$line[7])))
                        {
                            $move = File::copy(public_path('assets/images/galleries/'.$line[7]), public_path('assets/images/products/'.$line[7]));
                            $img = Image::make('assets/images/galleries/'.$line[7])->resize(285, 285);
                            $thumbnail = time().str_random(8).'.jpg';
                            $img->save(public_path().'/assets/images/thumbnails/'.$thumbnail);
                            ///$prod->thumbnail  = $thumbnail;
                        }
                        else
                        {
                            // echo "Please first upload product images - ".$line[7];exit;
                            $imagesNotFound[][$line[0]]['image'] = $line[7];
                        }
                    }
                   // DB::statement("update products set slug='".$slug."', thumbnail='".$thumbnail."' where sku='".$line[0]."'");
                   
                    //add gallary
                    if(!empty($line[8]))
                    {
                        //DB::table('galleries')->where('product_id',$prod->id)->delete();
                        $gallary_imgages = explode(',',$line[8]);
                        foreach($gallary_imgages as $image)
                        {
                            if(file_exists(public_path('assets/images/galleries/'.$image)))
                            {
                                $image = strtolower(trim($image));
                            
                                /*$gallery = new Gallery;
                                $gallery['photo'] = $image;
                                $gallery['product_id'] = $prod->id;
                                $gallery->save();*/
                                
                                //DB::statement("insert into galleries(photo,product_id) values('".$image."',".$prod->id.")");
                                if($image){
                                    //$move = File::copy(public_path('assets/import/images/'.$image), public_path('assets/images/galleries/'.$image));
                                }
                                
                            }
                            else
                            {
                                // echo "Please first upload product images - ".$image;exit;
                                $image = strtolower(trim($image));
                                //DB::statement("insert into galleries(photo,product_id) values('".$image."',".$prod->id.")");
                               // $imagesNotFound[][$line[0]]['image'] = $image;
                            }
                        }
                    }

                   if(!empty($line[24]))
                    {
                        // WHITE:AMIT02_1.jpg,AMIT02_2.jpg;RED:AMIT02_1.jpg,AMIT02_2.jpg,AMIT02_3.jpg;GREEN:AMIT02_3.jpg;
                        $line[24] = trim($line[24],";");
                        $colorArrA = explode(';',$line[24]);


                        //DB::table('product_color_images')->where('product_id', $prod->id)->delete();
                        for($imgCtr=0;$imgCtr<count($colorArrA);$imgCtr++)
                        {
                            $colorArrAColonBreak = explode(':',$colorArrA[$imgCtr]);
                            $colName = trim($colorArrAColonBreak[0]);
                            $colImages = isset($colorArrAColonBreak[1]) ? $colorArrAColonBreak[1] : "" ;
                            $imageAttr = '';
                            if($colImages!="")
                            {
                                $colImagesCommaBreak = explode(',',$colImages);
                                for($cicb=0;$cicb<count($colImagesCommaBreak);$cicb++)
                                {
                                
                                    $imageAttr.= isset($colImagesCommaBreak[$cicb]) ? url('/assets/images/galleries')."/".strtolower($colImagesCommaBreak[$cicb])."," : "" ;

                                }

                                $imageAttr = trim($imageAttr,",");

                            }

                           // DB::table('product_color_images')->insert(array('product_id' => $prod->id, 'color_name' => $colName , 'image' => $imageAttr));
                        }
                    }
                    
                    //add variations
                    $attributes = explode(';',$line[9]);
                    //DB::table('product_variations')->where('product_id',$prod->id)->delete();
                    foreach($attributes as $key => $attr)
                    {
                        //print_r($attr);exit;
                        $attr_name_arr = array();
                        $attr_val_arr = array();
                        $attr_json_arr = array();
                        $exploded_attr = explode(',', $attr);
                        $sku = '';$qty = 0;$price = 0;
                        foreach($exploded_attr as $e_key => $e_attr)
                        {
                            $exp_attr = explode(':', $e_attr);
                            //print_r($exp_attr);exit;
                            if($exp_attr[0] == 'Sku')
                            {
                                $sku = $exp_attr[1];
                            }
                            if($exp_attr[0] == 'Qty')
                            {
                                $qty = $exp_attr[1];
                            }
                            if($exp_attr[0] == 'Price')
                            {
                                $price = $exp_attr[1];
                            }
                            if(!empty($exp_attr[1]))
                            {
                                array_push($attr_name_arr, $exp_attr[0]);
                                array_push($attr_val_arr, $exp_attr[1]);
                                $attr_json_arr[$exp_attr[0]] = $exp_attr[1];
                            }
                        }   
                        //print_r($attr_val_arr);exit;
                        if (($key = array_search('Price', $attr_name_arr)) !== false) {
                            unset($attr_name_arr[$key]);
                        }
                        if (($key = array_search('Sku', $attr_name_arr)) !== false) {
                            unset($attr_name_arr[$key]);
                        }
                        if (($key = array_search('Qty', $attr_name_arr)) !== false) {
                            unset($attr_name_arr[$key]);
                        }

                        unset($attr_json_arr['Sku']);
                        unset($attr_json_arr['Qty']);
                        unset($attr_json_arr['Price']);
                        array_splice($attr_val_arr, count($attr_val_arr) - 3, 3);
                        

                        //DB::table('product_variations')->insert(array('product_id' => $prod->id,'sku'=>$sku,'attribute_names' => implode('-', $attr_name_arr),'attribute_values'=> implode('-', $attr_val_arr),'qty'=>$qty,'price'=>$price,'created_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s'),'json_attributes'=>json_encode($attr_json_arr)));
                    }
                }
                else
                {
                    $log .= "<br>Sku: ".$line[0]." - No Category Found!<br>";
                }
            }
            else
            {
                $log .= "<br>Sku: ".$line[0]." - Duplicate Product Code!<br>";
            }
        }
        $imagesNotFoundHtml = '';
        //--- Redirect Section
        if(count($imagesNotFound) > 0)
        {
            $imagesNotFoundHtml = 'Please upload following product images :- <br> Item Code - Image';
             for($imgC=0;$imgC<sizeof($imagesNotFound);$imgC++)
            {
                // print_r($imagesNotFound[$imgC]);
                foreach($imagesNotFound[$imgC] as $keyy=>$vall)
                {
                    $imagesNotFoundHtml = $imagesNotFoundHtml." ".$keyy." - ".$vall['image']."<br>";
                }
            }
        }
        $msg = $log;
        
         
      if($log!='')
        return response()->json($msg);
        
         $msg = $msg.'<br>'.$imagesNotFoundHtml;
         
        if($imagesNotFoundHtml!='')
        return response()->json($msg);
        
        
        
        
        
         $log = '';
        $sign = Currency::where('is_default','=',1)->first();
        foreach($excel_data as $line)
        {
            $line[0] = strval($line[0]);
            $product_exist = DB::select("select id from products where sku = '".$line[0]."'");
            $product_exist = isset($product_exist[0]->id) ? $product_exist[0]->id : '';
            $id = $product_exist;
            if (!$product_exist || $product_exist)
            {
                $input['type'] = 'Physical';
                $input['sku'] = $line[0];
                $input['category_id'] = 0;
                $input['subcategory_id'] = 0;
                $input['childcategory_id'] = 0;
                $input['brand_id'] = 0;
                $mcat = DB::select("select id from categories where lower(name)='".strtolower($line[1])."'");
                $mcat = isset($mcat[0]->id) ? $mcat[0]->id : '';
                //$brand = Brand::where(DB::raw('lower(name)'), strtolower($line[4]));
                $brandTEmp = DB::select("select id from brands where lower(name) = '".strtolower(trim($line[4]))."'");
                // print_r($brandTEmp);
                $brand = isset($brandTEmp[0]->id) ? $brandTEmp[0]->id : '';
               /* echo "==".$brand."==";
                die;*/
                if(!empty($brand)){
                    $input['brand_id'] = $brand;
                }
                
                
                  if(!empty($line[25]))
                        {
                           $coll=explode(',',$line[25]);
                           $new_coll=array();
                           
                           for($ccc=0;$ccc<count($coll);$ccc++)
                           {
                            
                            $ch=Collection::where('name','=',$coll[$ccc])->count();
                            if($ch==0)
                            {
                    
                        $log .= "<br>SKU: ".$line[0]." - No Collection Found (".$coll[$ccc].")!<br>";
                  
                            }
                            
                            else
                            {
                                $ch=Collection::where('name','=',$coll[$ccc])->get();
                                foreach($ch as $c)
                                {
                                     $new_coll[]= $c->id;
                                }
                            }
                            
                            
                           }
                           $input['collection_id'] = implode(',',$new_coll); 
                            
                            
                        }
                        else
                        {
                            $input['collection_id'] =0;
                        }
                        
                        
                           if(!empty($line[26]))
                        {
                           
                            
                            $ch=PracticeField::where('name','=',$line[26])->count();
                            if($ch==0)
                            {
                    
                        $log .= "<br>SKU: ".$line[0]." - No Practice Field Found!<br>";
                   
                            }else
                            {
                                $ch=PracticeField::where('name','=',$line[26])->get();
                                foreach($ch as $c)
                                {
                                     $input['practice_field_id'] = $c->id;
                                }
                            }
                        }
                        
                        else
                        {
                             $input['practice_field_id']=0;
                        }
                        
                        
                        
                        
                          if(!empty($line[27]))
                        {
                           
                            
                            $ch=User::where('shop_name','=',$line[27])->count();
                            if($ch==0)
                            {
                    
                        $log .= "<br>SKU: ".$line[0]." - No User Field Found!<br>";
                   
                            }else
                            {
                                $ch=User::where('shop_name','=',$line[27])->get();
                                foreach($ch as $c)
                                {
                                     $input['user_id'] = $c->id;
                                }
                            }
                        }
                        
                        else
                        
                        {
                          $input['user_id'] =0;  
                        }
                        
                        
                if(!empty($mcat))
                {
                    $input['category_id'] = $mcat;

                    if($line[2] != ""){
                        $scat = DB::select("select id from subcategories where category_id = ".$mcat." and status=1 and lower(name) = '".strtolower($line[2])."'");
                        $scat = isset($scat[0]->id) ? $scat[0]->id : '';
                        if(!empty($scat)) {
                            $input['subcategory_id'] = $scat;
                        }
                    }
                    if($line[3] != ""){
                        $chcat = DB::select("select id from childcategories where lower(name) = '".strtolower($line[3])."'");
                        $chcat = isset($chcat[0]->id) ? $chcat[0]->id : '';
                        if(!empty($chcat)) {
                            $input['childcategory_id'] = $chcat;
                        }
                    }

                    $input['photo'] = mb_convert_encoding(strtolower($line[7]), 'UTF-8', 'UTF-8');
                    $input['name'] = mb_convert_encoding($line[5], 'UTF-8', 'UTF-8');
                    $input['name_ar'] = mb_convert_encoding($line[6], 'UTF-8', 'UTF-8');
                    $input['details'] = mb_convert_encoding($line[10], 'UTF-8', 'UTF-8');
                    $input['details_ar'] = mb_convert_encoding($line[11], 'UTF-8', 'UTF-8');
                    $input['product_info'] = mb_convert_encoding($line[12], 'UTF-8', 'UTF-8');
                    $input['color'] = mb_convert_encoding($line[17], 'UTF-8', 'UTF-8');
                    $input['price'] = mb_convert_encoding($line[13], 'UTF-8', 'UTF-8');
                    $input['previous_price'] = mb_convert_encoding($line[14], 'UTF-8', 'UTF-8');
                    $input['weight'] = !empty($line[15]) ? $line[15] : 0;
                    $input['stock'] = $line[16];
                    $input['youtube'] = mb_convert_encoding($line[19], 'UTF-8', 'UTF-8');
                    $input['policy'] = mb_convert_encoding($line[20], 'UTF-8', 'UTF-8');
                    $input['policy_ar'] = mb_convert_encoding($line[21], 'UTF-8', 'UTF-8');
                    $input['meta_tag'] = mb_convert_encoding($line[22], 'UTF-8', 'UTF-8');
                    $input['meta_description'] = mb_convert_encoding($line[23], 'UTF-8', 'UTF-8');
                    $input['tags'] = mb_convert_encoding($line[18], 'UTF-8', 'UTF-8');
                    $input['product_type'] = 'normal';
                    // Conert Price According to Currency
                    $input['price'] = ($input['price'] / $sign->value);
                    $input['previous_price'] = ($input['previous_price'] / $sign->value);
                    $input['is_multiple_products'] = !empty($line[9]) ? 1 : 0;
                    // Save Data
                    if($product_exist)
                    {
                        DB::table('products')->where('sku', $line[0])->update($input);
                        $prod = DB::select("select id, name, slug from products where sku='".$line[0]."'");
                        $prod = $prod[0];
                    }
                    else
                    {
                        DB::table('products')->insert($input);
                        $prod = DB::select("select id, name, slug from products where sku='".$line[0]."'");                        
                        $prod = $prod[0];  
                        //echo "test2";exit;   
                    }
                    $slug = str_slug($prod->name,'-').'-'.strtolower(str_random(3).$prod->id.str_random(3));
                    $thumbnail = '';
                    // Set Thumbnail
                    if(!empty($line[7]))
                    {
                        if(file_exists(public_path('assets/images/galleries/'.$line[7])))
                        {
                            $move = File::copy(public_path('assets/images/galleries/'.$line[7]), public_path('assets/images/products/'.strtolower($line[7])));
                            $img = Image::make('assets/images/galleries/'.$line[7])->resize(285, 285);
                            $thumbnail = time().str_random(8).'.jpg';
                            $img->save(public_path().'/assets/images/thumbnails/'.$thumbnail);
                            ///$prod->thumbnail  = $thumbnail;
                        }
                        else
                        {
                            // echo "Please first upload product images - ".$line[7];exit;
                            $imagesNotFound[][$line[0]]['image'] = $line[7];
                        }
                    }
                    DB::statement("update products set slug='".$slug."', thumbnail='".$thumbnail."' where sku='".$line[0]."'");
                   
                    //add gallary
                    if(!empty($line[8]))
                    {
                        DB::table('galleries')->where('product_id',$prod->id)->delete();
                        $gallary_imgages = explode(',',$line[8]);
                        foreach($gallary_imgages as $image)
                        {
                            if(file_exists(public_path('assets/images/galleries/'.$image)))
                            {
                                //$image = strtolower(trim($image));
                            
                                /*$gallery = new Gallery;
                                $gallery['photo'] = $image;
                                $gallery['product_id'] = $prod->id;
                                $gallery->save();*/
                                
                                DB::statement("insert into galleries(photo,product_id) values('".$image."',".$prod->id.")");
                                if($image){
                                    //$move = File::copy(public_path('assets/import/images/'.$image), public_path('assets/images/galleries/'.$image));
                                }
                                
                            }
                            else
                            {
                                // echo "Please first upload product images - ".$image;exit;
                                //$image = strtolower(trim($image));
                                DB::statement("insert into galleries(photo,product_id) values('".$image."',".$prod->id.")");
                                $imagesNotFound[][$line[0]]['image'] = $image;
                            }
                        }
                    }

                   if(!empty($line[24]))
                    {
                        // WHITE:AMIT02_1.jpg,AMIT02_2.jpg;RED:AMIT02_1.jpg,AMIT02_2.jpg,AMIT02_3.jpg;GREEN:AMIT02_3.jpg;
                        $line[24] = trim($line[24],";");
                        $colorArrA = explode(';',$line[24]);


                        DB::table('product_color_images')->where('product_id', $prod->id)->delete();
                        for($imgCtr=0;$imgCtr<count($colorArrA);$imgCtr++)
                        {
                            $colorArrAColonBreak = explode(':',$colorArrA[$imgCtr]);
                            $colName = trim($colorArrAColonBreak[0]);
                            $colImages = isset($colorArrAColonBreak[1]) ? $colorArrAColonBreak[1] : "" ;
                            $imageAttr = '';
                            if($colImages!="")
                            {
                                $colImagesCommaBreak = explode(',',$colImages);
                                for($cicb=0;$cicb<count($colImagesCommaBreak);$cicb++)
                                {
                                
                                    $imageAttr.= isset($colImagesCommaBreak[$cicb]) ? url('/assets/images/galleries')."/".strtolower($colImagesCommaBreak[$cicb])."," : "" ;

                                }

                                $imageAttr = trim($imageAttr,",");

                            }

                            DB::table('product_color_images')->insert(array('product_id' => $prod->id, 'color_name' => $colName , 'image' => $imageAttr));
                        }
                    }
                    
                    //add variations
                    $attributes = explode(';',$line[9]);
                    DB::table('product_variations')->where('product_id','=',$prod->id)->delete();
                    foreach($attributes as $key => $attr)
                    {
                        //print_r($attr);exit;
                        $attr_name_arr = array();
                        $attr_val_arr = array();
                        $attr_json_arr = array();
                        $exploded_attr = explode(',', $attr);
                        $sku = '';$qty = 0;$price = 0;
                        foreach($exploded_attr as $e_key => $e_attr)
                        {
                            $exp_attr = explode(':', $e_attr);
                            //print_r($exp_attr);exit;
                            if($exp_attr[0] == 'Sku')
                            {
                                $sku = $exp_attr[1];
                            }
                            if($exp_attr[0] == 'Qty')
                            {
                                $qty = $exp_attr[1];
                            }
                            if($exp_attr[0] == 'Price')
                            {
                                $price = $exp_attr[1];
                            }
                            if(!empty($exp_attr[1]))
                            {
                                array_push($attr_name_arr, $exp_attr[0]);
                                array_push($attr_val_arr, $exp_attr[1]);
                                $attr_json_arr[$exp_attr[0]] = $exp_attr[1];
                            }
                        }   
                        //print_r($attr_val_arr);exit;
                        if (($key = array_search('Price', $attr_name_arr)) !== false) {
                            unset($attr_name_arr[$key]);
                        }
                        if (($key = array_search('Sku', $attr_name_arr)) !== false) {
                            unset($attr_name_arr[$key]);
                        }
                        if (($key = array_search('Qty', $attr_name_arr)) !== false) {
                            unset($attr_name_arr[$key]);
                        }

                        unset($attr_json_arr['Sku']);
                        unset($attr_json_arr['Qty']);
                        unset($attr_json_arr['Price']);
                        //array_splice($attr_val_arr, count($attr_val_arr) - 3, 3);
                        

                        DB::table('product_variations')->insert(array('product_id' => $prod->id,'sku'=>$sku,'attribute_names' => implode('-', $attr_name_arr),'attribute_values'=> implode('-', $attr_val_arr),'qty'=>$qty,'price'=>$price,'created_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s'),'json_attributes'=>json_encode($attr_json_arr)));
                    }
                }
                else
                {
                    $log .= "<br>Sku: ".$line[0]." - No Category Found!<br>";
                }
            }
            else
            {
                $log .= "<br>Sku: ".$line[0]." - Duplicate Product Code!<br>";
            }
        }
        $imagesNotFoundHtml = '';
        //--- Redirect Section
        if(count($imagesNotFound) > 0)
        {
            $imagesNotFoundHtml = 'Please upload following product images :- <br> Item Code - Image';
             for($imgC=0;$imgC<sizeof($imagesNotFound);$imgC++)
            {
                // print_r($imagesNotFound[$imgC]);
                foreach($imagesNotFound[$imgC] as $keyy=>$vall)
                {
                    $imagesNotFoundHtml = $imagesNotFoundHtml." ".$keyy." - ".$vall['image']."<br>";
                }
            }
        }
        $msg = 'Bulk Product File Imported Successfully.<a href="'.route('admin-prod-index').'">View Product Lists.</a>'.$log;
        $msg = $msg.'<br>'.$imagesNotFoundHtml;
        return response()->json($msg);
    }


    //*** GET Request
    public function edit($id)   
    {   
    
        $cats = Category::all();    
        $sub_cats = Subcategory::all(); 
        $child_categories = Childcategory::where('status',1)->get();    
        $data = Product::findOrFail($id);   
        $sign = Currency::where('is_default','=',1)->first();   
        $collection = Collection::orderBy('name','ASC')->get();
        $practice_field = PracticeField::orderBy('name','ASC')->get();
        $product_attributes = DB::table('product_variations')->where('product_id', $id)->orderBy('id','ASC')->get();    
        $brands = Brand::orderBy('name','ASC')->get();  
        $colors = Color::orderBy('color_id','desc')->get(); 
        $color_data = array();  
        $product_color_data = DB::table('product_color_images')->where('product_id', $id)->get();   
        $selected_color_arr = array();  
        $gallery_images = Gallery::where('product_id', $id)->get(); 
        $gallery_images_arr = array(); 
		$vendor_role_id = DB::table('roles')->select('id')->where('name','Vendor')->get()->first();
		$vendor_role_id = $vendor_role_id->id;
		$vendor = User::where('is_vendor','=',2)->where('role_id','=',DB::raw("'$vendor_role_id'"))->orderBy('id','desc')->get();
        foreach($gallery_images as $image)  
        {   
            $gallery_images_arr[] = URL('/assets/images/galleries/'.$image->photo); 
        }   
        foreach($product_color_data as $key => $color)  
        {   
            $selected_color_arr[$key]['name'] = $color->color_name;     
            $selected_color_arr[$key]['code'] = Color::where('color_name','=',$color->color_name)->value('color_code');       
        }   
        $selected_color_arr = json_encode($selected_color_arr); 
        foreach($colors as $key => $color)  
        {   
            $color_data[$key]['id'] = $key; 
            $color_data[$key]['name'] = $color->color_name; 
            $color_data[$key]['code'] = $color->color_code; 
        }   
        $color_data = json_encode($color_data); 
        if($data->type == 'Digital')    
            return view('admin.product.edit.digital',compact('cats','data','sign'));    
        elseif($data->type == 'License')    
            return view('admin.product.edit.license',compact('cats','data','sign'));    
        else    
            return view('admin.product.edit.physical',compact('cats','data','sign','product_attributes','brands','sub_cats','child_categories','color_data','product_color_data','selected_color_arr','gallery_images_arr','vendor','practice_field','collection'));   
    } 
	
	
	//*** show product
    public function show($id)   
    {   
        $cats = Category::all();    
        $sub_cats = Subcategory::all(); 
        $child_categories = Childcategory::where('status',1)->get();    
        $data = Product::findOrFail($id);   
        $sign = Currency::where('is_default','=',1)->first();   
        $product_attributes = DB::table('product_variations')->where('product_id', $id)->orderBy('id','ASC')->get();    
        $brands = Brand::orderBy('name','ASC')->get();  
        $colors = Color::orderBy('color_id','desc')->get(); 
        $color_data = array();  
        $product_color_data = DB::table('product_color_images')->where('product_id', $id)->get();   
        $selected_color_arr = array();  
        $gallery_images = Gallery::where('product_id', $id)->get(); 
        $gallery_images_arr = array(); 
		$vendor_role_id = DB::table('roles')->select('id')->where('name','Vendor')->get()->first();
		$vendor_role_id = $vendor_role_id->id;
		$vendor = User::where('is_vendor','=',2)->where('role_id','=',DB::raw("'$vendor_role_id'"))->orderBy('id','desc')->get();
        foreach($gallery_images as $image)  
        {   
            $gallery_images_arr[] = URL('/assets/images/galleries/'.$image->photo); 
        }   
        foreach($product_color_data as $key => $color)  
        {   
            $selected_color_arr[$key]['name'] = $color->color_name;     
            $selected_color_arr[$key]['code'] = Color::where('color_name','=',$color->color_name)->value('color_code');
        }   
        $selected_color_arr = json_encode($selected_color_arr); 
        foreach($colors as $key => $color)  
        {   
            $color_data[$key]['id'] = $key; 
            $color_data[$key]['name'] = $color->color_name; 
            $color_data[$key]['code'] = $color->color_code; 
        }   
        $color_data = json_encode($color_data); 
        if($data->type == 'Digital')    
            return view('admin.product.view.digital',compact('cats','data','sign'));    
        elseif($data->type == 'License')    
            return view('admin.product.view.license',compact('cats','data','sign'));    
        else    
            return view('admin.product.view.physical',compact('cats','data','sign','product_attributes','brands','sub_cats','child_categories','color_data','product_color_data','selected_color_arr','gallery_images_arr','vendor'));   
    }

    //*** POST Request
    public function update(Request $request, $id)
    {
		

        //--- Validation Section
        $rules = [
               'file'       => 'mimes:zip'
                ];

        $validator = Validator::make(Input::all(), $rules);
        
        if ($validator->fails()) {
          return response()->json(array('errors' => $validator->getMessageBag()->toArray()));
        }
        //--- Validation Section Ends


        //-- Logic Section
        $data = Product::findOrFail($id);
        $sign = Currency::where('is_default','=',1)->first();
        $input = $request->all();
        
        $input['collection_id'] = implode(',', $request->collection_id);
        
        $color_images = isset($input['color_images']) ? $input['color_images'] : '';    
$color_names = isset($input['product_colors']) ? $input['product_colors'] : '';
        $attachmentArr = array();
        if (!empty($request->file('attachment')))
        {
            $files = $request->file('attachment');
            foreach($files as $key => $file)
            {
                $name = time().$file->getClientOriginalName();
                $name = str_replace(' ', '', $name);
                $file->move('assets/files',$name);
                $attachmentArr[] = $name;
            }
        }
        $hidden_attachment = isset($input['hidden_attachment']) ? $input['hidden_attachment'] : array();
        $final_attachment = array_merge($attachmentArr, $hidden_attachment);
        $final_attachment = array_unique($final_attachment);
        $final_attachment = array_filter($final_attachment);
        $final_attachment = implode(",", $final_attachment);
        $input['attachment'] = $final_attachment;
// echo "<pre>"; print_r($input); exit;
            //Check Types 
            if($request->type_check == 1)
            {
                $input['link'] = null;           
            }
            else
            {
                if($data->file!=null){
                        if (file_exists(public_path().'/assets/files/'.$data->file)) {
                        unlink(public_path().'/assets/files/'.$data->file);
                    }
                }
                $input['file'] = null;            
            }
            //update color image    
            //save color image  
            if(!empty($color_images))   
            {   
                DB::table('product_color_images')->where('product_id', $id)->delete();  
                foreach($color_images as $key => $image)    
                {   
                    DB::table('product_color_images')->insert(array('product_id' => $id, 'color_name' => $color_names[$key], 'image' => $image));   
                }   
            }
 
            // Check Physical
            if($data->type == "Physical")
            {

                        // Check Condition
                        if ($request->product_condition_check == ""){
                            $input['product_condition'] = 0;
                        }

                        // Check Shipping Time
                        if ($request->shipping_time_check == ""){
                            $input['ship'] = null;
                        } 

                        // Check Size

                        if(empty($request->size_check ))
                        {
                            $input['size'] = null;
                            $input['size_qty'] = null;
                            $input['size_price'] = null;
                            //  $input['size_length'] = null;
                        }
                        else{
                                if(in_array(null, $request->size) || in_array(null, $request->size_qty) || in_array(null, $request->size_price))
                                {
                                    $input['size'] = null;
                                    $input['size_qty'] = null;
                                    $input['size_price'] = null;
                                    // $input['size_length'] = null;
                                }
                                else 
                                {             
                                    
                                      $length_check = \DB::table('product_lengths')->where('product_id',$id)->get();
                                    //   echo count($length_check); exit;
                                    // echo "<pre>"; print_r($input); exit;
                                    if(count($length_check) > 0){
                                          $check = \DB::table('product_lengths')->where('product_id',$id)->delete();
                                          
                                             foreach($input['size_length'] as $parent_key=>$parent_length){
                                            foreach($parent_length as $k=>$v){
                                                if($v!=null){
                                                // echo 'product_size=>'.$input['size'][$parent_key].' product_length=>'.$v.'<br>';
                                                 $insert = \DB::table("product_lengths")->insertGetId(['product_id'=>$id,'product_size'=>$input['size'][$parent_key],'product_length'=>$v]);
                                            }
                                            }
                                            
                                        }
                                        
                                    }else{
                                        // echo "<pre>"; print_r($input['size']); exit;
                                        foreach($input['size_length'] as $parent_key=>$parent_length){
                                            foreach($parent_length as $k=>$v){
                                                if($v!=null){
                                                // echo 'product_size=>'.$input['size'][$parent_key].' product_length=>'.$v.'<br>';
                                                 $insert = \DB::table("product_lengths")->insertGetId(['product_id'=>$id,'product_size'=>$input['size'][$parent_key],'product_length'=>$v]);
                                            }
                                            }
                                            
                                        }
                                        
                                        // exit;
                                        
                                    }
                                    
                                    $input['size'] = implode(',', $input['size']); 
                                    $input['size_qty'] = implode(',', $request->size_qty);
                                    $input['size_price'] = implode(',', $request->size_price); 
                                    
                                  
                                    //  $input['size_length'] = implode(',', $request->size_price); 
                                }
                        }


            //  echo "<pre>"; print_r($input); exit;
                        // Check Whole Sale
            if(empty($request->whole_check ))
            {
                $input['whole_sell_qty'] = null;
                $input['whole_sell_discount'] = null;
            }
            else{
                if(in_array(null, $request->whole_sell_qty) || in_array(null, $request->whole_sell_discount))
                {
                $input['whole_sell_qty'] = null;
                $input['whole_sell_discount'] = null;
                }
                else
                {
                    $input['whole_sell_qty'] = implode(',', $request->whole_sell_qty);
                    $input['whole_sell_discount'] = implode(',', $request->whole_sell_discount);
                }
            }

                        // Check Color
                        if(empty($request->color_check ))
                        {
                            $input['color'] = null;
                        }
                        else{
                            if (!empty($request->color)) 
                             {
                                $input['color'] = implode(',', $request->color);       
                             }  
                            if (empty($request->color)) 
                             {
                                $input['color'] = null;       
                             }  
                        }

                        // Check Measure
                    if ($request->measure_check == "") 
                     {
                        $input['measure'] = null;    
                     } 
            }
            
              

        
            // Check Seo
        if (empty($request->seo_check)) 
         {
            $input['meta_tag'] = null;
            $input['meta_description'] = null;         
         }  
         else {
        if (!empty($request->meta_tag)) 
         {
            $input['meta_tag'] = implode(',', $request->meta_tag);       
         }              
         }
          if(isset($input['is_multiple_products']))
        {
            $input['is_multiple_products'] = 1;
        } 
        else
        {
            $input['is_multiple_products'] = 0;
        }
 

        // Check License
        if($data->type == "License")
        {

        if(!in_array(null, $request->license) && !in_array(null, $request->license_qty))
        {             
            $input['license'] = implode(',,', $request->license);  
            $input['license_qty'] = implode(',', $request->license_qty);                 
        }
        else
        {
            if(in_array(null, $request->license) || in_array(null, $request->license_qty))
            {
                $input['license'] = null;  
                $input['license_qty'] = null;
            }
            else
            {
                $license = explode(',,', $prod->license);
                $license_qty = explode(',', $prod->license_qty);
                $input['license'] = implode(',,', $license);  
                $input['license_qty'] = implode(',', $license_qty);
            }
        }  

        }
            // Check Features
            if(!in_array(null, $request->features) && !in_array(null, $request->colors))
            {             
                    $input['features'] = implode(',', str_replace(',',' ',$request->features));  
                    $input['colors'] = implode(',', str_replace(',',' ',$request->colors));                 
            }
            else
            {
                if(in_array(null, $request->features) || in_array(null, $request->colors))
                {
                    $input['features'] = null;  
                    $input['colors'] = null;
                }
                else
                {
                    $features = explode(',', $data->features);
                    $colors = explode(',', $data->colors);
                    $input['features'] = implode(',', $features);  
                    $input['colors'] = implode(',', $colors);
                }
            }  

        //Product Tags 
        if (!empty($request->tags)) 
         {
            $input['tags'] = implode(',', $request->tags);       
         }  
        if (empty($request->tags)) 
         {
            $input['tags'] = null;       
         }
         
       
    //   $input['length'] = implode(',', str_replace(',',' ',$request->length)); 
        if (empty($request->tags)) {
            
        }
        
     
        
         if (!empty($input['attr_name_en'])) {
            //  echo "<pre>"; print_r($input); exit;
            //  $input['attribute_id'] = implode(',',$input['attr_name_en']); 
             $check = \DB::table('product_attributes')->where('product_id',$id)->get();
              if(count($check) > 0){
                    $check = \DB::table('product_attributes')->where('product_id',$id)->delete();
                    foreach($input['attr_name_en'] as $key=>$value){
                        $checkattr = \DB::table('product_attributes')->where('product_id',$id)->where('attribute_id',$value)->get();
                        if(count($checkattr) > 0){
                         $update = \DB::table("product_attributes")->where('product_id',$id)->where('attribute_id',$value)->update(['qty'=>$input['attr_qty'][$key]]);
                        }else{
                           $insert = \DB::table("product_attributes")->insertGetId(['product_id'=>$id,'attribute_id'=>$value,'qty'=>$input['attr_qty'][$key]]); 
                        }
                    }
                    
              }else{
                  foreach($input['attr_name_en'] as $key=>$value){
                         $insert = \DB::table("product_attributes")->insertGetId(['product_id'=>$id,'attribute_id'=>$value,'qty'=>$input['attr_qty'][$key]]);
                    }
              }
                 
                // $input['attr_units'] = implode(',', $input['attr_units']); 
             
         }
               

        /*if(!empty($input['sleeve'])){
            $check = \DB::table('product_sleeves')->where('product_id',$id)->get();
                      if(count($check) > 0){
                            $check = \DB::table('product_sleeves')->where('product_id',$id)->delete();
                      }  
                    foreach($input['sleeve'] as $s){
                        $insertSleeves = \DB::table("product_sleeves")->insertGetID(['product_id'=>$id,'sleeve_type'=>$s]);
                    }
        }*/
       
         $input['price'] = $input['price'] / $sign->value;
         $input['previous_price'] = $input['previous_price'] / $sign->value; 
//  echo "<pre>"; print_r($input); exit;
         
         $data->update($input);
        //-- Logic Section Ends
        //store product attr
        $attributes= $input['attr'];
        $attr_values = array();
        //print_r($attributes);exit;
        $lastid = $id;
        if(!empty($attributes))
        {
            $attr_arr = array();
            $attr_val_arr = array();
            $attr_json_arr = array();
            $attribute_names = array();
            if(!empty($attributes))
            {
                $alt_arr = $attributes;
                foreach($alt_arr as $key=>$val)
                {
                    foreach($val as $val_key => $inner_val)
                    {
                        if(empty($inner_val))
                        {
                            unset($attributes[$key][$val_key]);
                        }
                        else
                        {
                            //echo $val_key;exit;
                            array_push($attribute_names, $val_key);
                        }
                    }
                }
                
                $attr_arr = array();
                $attribute_names = array_unique($attribute_names);
                $imploted_attr = $attribute_names;
                //print_r($attributes);exit;
                /*if (($key = array_search('price', $imploted_attr)) !== false) {
                    unset($imploted_attr[$key]);
                }
                if (($key = array_search('sku', $imploted_attr)) !== false) {
                    unset($imploted_attr[$key]);
                }
                if (($key = array_search('qty', $imploted_attr)) !== false) {
                    unset($imploted_attr[$key]);
                }*/
                //print_r($imploted_attr);exit;
                foreach ($attributes as $attrkey => $attribute) {
                    $imploted_attr = array_keys($attribute);
                    if (($key = array_search('price', $imploted_attr)) !== false) {
                        unset($imploted_attr[$key]);
                    }
                    if (($key = array_search('sku', $imploted_attr)) !== false) {
                        unset($imploted_attr[$key]);
                    }
                    if (($key = array_search('qty', $imploted_attr)) !== false) {
                        unset($imploted_attr[$key]);
                    }
                    foreach ($attribute as $key => $value) {
                        $attr_arr[$attrkey]['product_id'] = $lastid;

                        $attr_arr[$attrkey]['attribute_names'] = implode('-', $imploted_attr);
                        $excluded_key = array('price','sku','qty');
                        //echo $key;exit;
                        if(!in_array($key,$excluded_key))
                        {
                            $first_val = isset($attr_arr[$attrkey]['attribute_values']) ? $attr_arr[$attrkey]['attribute_values'] : '';
                            if(empty($first_val))
                            {
                                $attr_arr[$attrkey]['attribute_values'] = $value;
                                array_push($attr_val_arr, $value);
                            }
                            else
                            {
                                $attr_arr[$attrkey]['attribute_values'] = $first_val.'-'.$value;
                                array_push($attr_val_arr,$value);
                            }

                        }
                        else
                        {
                            
     if(isset($attributes[$attrkey]['sku']))
       $attr_arr[$attrkey]['sku'] = $attributes[$attrkey]['sku'];
       else
        $attr_arr[$attrkey]['sku'] = '';
       
        if(isset($attributes[$attrkey]['qty']))
      $attr_arr[$attrkey]['qty'] = $attributes[$attrkey]['qty'];
      else
      $attr_arr[$attrkey]['qty'] = 0;
      
       if(isset($attributes[$attrkey]['price']))
       $attr_arr[$attrkey]['price'] = $attributes[$attrkey]['price'];
       else
       $attr_arr[$attrkey]['price'] = 0;
       
                        }
                        $attr_arr[$attrkey]['created_at'] = date('Y-m-d H:i:s');
                        $attr_arr[$attrkey]['updated_at'] = date('Y-m-d H:i:s');

                        continue;
                    }
                }
                //$attr_val_arr = array_filter($attr_val_arr);
                //print_r($attr_arr);exit;
                if(count($attr_val_arr) > 0)
                {
                    foreach($attr_arr as $key => $attr)
                    {
                        $attr_names[$key] = explode('-', $attr['attribute_names']);
                        $attr_values[$key] = explode('-', $attr['attribute_values']);
                    }
                    $attr_json_arr = array();
                    foreach ($attr_names as $key => $name) {
                        foreach ($name as $namekey => $value) {
                            $vals = '';
                            if(isset($attr_values[$key][$namekey]))
                                $vals = $attr_values[$key][$namekey];
                            $attr_json_arr[$key][$value] = $vals;
                        }
                    }

                    foreach($attr_json_arr as $key => $val)
                    {
                        $attr_arr[$key]['json_attributes'] = json_encode($val);
                    }

                    DB::table('product_variations')->where('product_id', $lastid)->delete();
                    DB::table('product_variations')->insert($attr_arr);
                }
            }
        }
        //--- Redirect Section        
        $msg = 'Product Updated Successfully.<a href="'.route('admin-prod-index').'">View Product Lists.</a>';
        return response()->json($msg);      
        //--- Redirect Section Ends    
    }


    //*** GET Request
    public function feature($id)
    {
            $data = Product::findOrFail($id);
            return view('admin.product.highlight',compact('data'));
    }

    //*** POST Request
    public function featuresubmit(Request $request, $id)
    {
        //-- Logic Section
            $data = Product::findOrFail($id);
            $input = $request->all(); 
            if($request->featured == "")
            {
                $input['featured'] = 0;
            }
            if($request->hot == "")
            {
                $input['hot'] = 0;
            }
            if($request->best == "")
            {
                $input['best'] = 0;
            }
            if($request->top == "")
            {
                $input['top'] = 0;
            }
            if($request->latest == "")
            {
                $input['latest'] = 0;
            }
            if($request->big == "")
            {
                $input['big'] = 0;
            } 
            if($request->trending == "")
            {
                $input['trending'] = 0;
            }    
            if($request->sale == "")
            {
                $input['sale'] = 0;
            }   
            if($request->is_discount == "")
            {
                $input['is_discount'] = 0;
                $input['discount_date'] = null;               
            }  
            if($request->promotional == "")
            {
                $input['promotional'] = 0;
            }
            if($request->offer_product == "")
            {
                $input['offer_product'] = 0;
            }
            if($request->best_value == "")
            {
                $input['best_value'] = 0;
            } 
			var_dump($input);exit;
            $data->update($input);
        //-- Logic Section Ends

        //--- Redirect Section        
        $msg = 'Highlight Updated Successfully.';
        return response()->json($msg);      
        //--- Redirect Section Ends    

    }

    //*** GET Request
    public function destroy($id)
    {

        $data = Product::findOrFail($id);
        if($data->galleries->count() > 0)
        {
            foreach ($data->galleries as $gal) {
                    if (file_exists(public_path().'/assets/images/galleries/'.$gal->photo)) {
                       // unlink(public_path().'/assets/images/galleries/'.$gal->photo);
                    }
                $gal->delete();
            }

        }

        if($data->reports->count() > 0)
        {
            foreach ($data->reports as $gal) {
                $gal->delete();
            }
        }

        if($data->ratings->count() > 0)
        {
            foreach ($data->ratings  as $gal) {
                $gal->delete();
            }
        }
        if($data->wishlists->count() > 0)
        {
            foreach ($data->wishlists as $gal) {
                $gal->delete();
            }
        }
        if($data->clicks->count() > 0)
        {
            foreach ($data->clicks as $gal) {
                $gal->delete();
            }
        }
        if($data->comments->count() > 0)
        {
            foreach ($data->comments as $gal) {
            if($gal->replies->count() > 0)
            {
                foreach ($gal->replies as $key) {
                    $key->delete();
                }
            }
                $gal->delete();
            }
        }


        if (!filter_var($data->photo,FILTER_VALIDATE_URL)){
            if (file_exists(public_path().'/assets/images/products/'.$data->photo)) {
               // unlink(public_path().'/assets/images/products/'.$data->photo);
            }
        }

        if (file_exists(public_path().'/assets/images/thumbnails/'.$data->thumbnail) && $data->thumbnail != "") {
           // unlink(public_path().'/assets/images/thumbnails/'.$data->thumbnail);
        }

        if($data->file != null){
            if (file_exists(public_path().'/assets/files/'.$data->file)) {
               // unlink(public_path().'/assets/files/'.$data->file);
            }
        }
        $data->delete();
        //--- Redirect Section     
        $msg = 'Product Deleted Successfully.';
        return response()->json($msg);      
        //--- Redirect Section Ends    

// PRODUCT DELETE ENDS  
    }
    public function bulkdelete(Request $request)
    {
        $params = $request->post();
        $product_ids = isset($params['product_ids']) ? $params['product_ids'] : '';
        if (strpos($product_ids, ',') !== false) {
            $product_ids = explode(',', $product_ids);
        } else {
            $product_ids = array($product_ids);
        }
        foreach($product_ids as $product_id)
        {
            Product::where('id',$product_id)->delete();
        }
        echo json_encode(array('status' => true));exit;
    }
    public function bulkstatus(Request $request)
    {
         $params = $request->post();
        $product_ids = isset($params['product_ids']) ? $params['product_ids'] : '';
        $status = isset($params['status']) ? $params['status'] : '';
        if (strpos($product_ids, ',') !== false) {
            $product_ids = explode(',', $product_ids);
        } else {
            $product_ids = array($product_ids);
        }
        foreach($product_ids as $product_id)
        {
            Product::where('id',$product_id)->update(array('status' => $status));
        }
        echo json_encode(array('status' => true));exit;
    }
}
