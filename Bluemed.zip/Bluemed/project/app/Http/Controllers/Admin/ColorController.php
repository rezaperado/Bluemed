<?php



namespace App\Http\Controllers\Admin;



use Datatables;

use App\Models\Color;

use Illuminate\Http\Request;

use App\Http\Controllers\Controller;

use Illuminate\Support\Facades\Input;

use Validator;



class ColorController extends Controller

{

    public function __construct()

    {

        $this->middleware('auth:admin');
        $this->middleware('user_permissions');

    }




    //*** GET Request

    public function index()

    {

        return view('admin.color.index');

    }


      //*** JSON Request

    public function datatables()

    {

         $datas = Color::orderBy('color_id','desc')->get();

         //--- Integrating This Collection Into Datatables

         return Datatables::of($datas)

                           /* ->editColumn('photo', function(color $data) {

                                $photo = $data->photo ? url('assets/images/brands/'.$data->photo):url('assets/images/noimage.png');

                                return '<img src="' . $photo . '" alt="Image">';

                            })*/
                            ->editColumn('color_code', function(color $data){
                                $color = "background:".$data->color_code.";padding: 0px 8px;border: 5px solid #ddd;margin: 0 10px;";
                                return $data->color_code . "<span style='".$color."'>&nbsp;</span>";
                            })
                            ->addColumn('action', function(color $data) {

                                return '<div class="action-list"><a data-href="' . route('admin-color-edit',$data->color_id) . '" class="edit" data-toggle="modal" data-target="#modal1"> <i class="fas fa-edit"></i>Edit</a><a href="javascript:;" data-href="' . route('admin-color-delete',$data->color_id) . '" data-toggle="modal" data-target="#confirm-delete" class="delete"><i class="fas fa-trash-alt"></i></a></div>';

                            }) 

                            ->rawColumns(['color_code','action'])

                            ->toJson(); //--- Returning Json Data To Client Side

    }


    //*** GET Request

    public function create()

    {

         return view('admin.color.create');

    }



    //*** POST Request

    public function store(Request $request)

    {
 //--- Validation Section

        $rules = [

               'color_name' => 'required',
               'color_code' => 'required',
               'color_name_ar' => 'required'
                ];



        $validator = Validator::make(Input::all(), $rules);

        

        if ($validator->fails()) {

          return response()->json(array('errors' => $validator->getMessageBag()->toArray()));

        }

        //--- Validation Section Ends



        //--- Logic Section

        $data = new Color();

        $input = $request->all();

        $data->fill($input)->save();

        //--- Logic Section Ends



        //--- Redirect Section        

        $msg = 'New Data Added Successfully.';

        return response()->json($msg);      

        //--- Redirect Section Ends    

    }



    //*** GET Request

    public function edit($id)

    {
          $data = color::findOrFail($id);

        return view('admin.color.edit',compact('data'));
    }



    //*** POST Request

    public function update(Request $request, $id)

    {



        //--- Validation Section

        $rules = [

               
               'color_name' => 'required',
               'color_code' => 'required',
               'color_name_ar' => 'required'
                ];



        $validator = Validator::make(Input::all(), $rules);

        

        if ($validator->fails()) {

          return response()->json(array('errors' => $validator->getMessageBag()->toArray()));

        }

        //--- Validation Section Ends



        //--- Logic Section

        $data = Color::findOrFail($id);

        $input = $request->all();

        $data->update($input);

        //--- Logic Section Ends



        //--- Redirect Section     

        $msg = 'Data Updated Successfully.';

        return response()->json($msg);      

        //--- Redirect Section Ends            

    

    }

     //*** GET Request Delete

    public function destroy($id)

    {

        $data = Color::findOrFail($id);


        $data->delete();

        //--- Redirect Section     

        $msg = 'Data Deleted Successfully.';

        return response()->json($msg);      

        //--- Redirect Section Ends     

    }


}

