<?php

namespace App\Http\Controllers\Admin;

use App\Classes\GeniusMailer;
use App\Http\Controllers\Controller;
use App\Models\Generalsetting;
use App\Models\Order;
use Illuminate\Support\Facades\Storage;
use App\Models\OrderTrack;
use Datatables;
use App\Models\User;
use Illuminate\Http\Request;
use DB;
class OrderController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:admin');
        $this->middleware('user_permissions');
    }
    
    public function allorders(Request $request)
    {
         
         if (request()->ajax()) {
             $datas = Order::select('orders.*',DB::raw("CONCAT(users.first_name,' ',users.last_name) as fullname"),"users.email")->join('users', 'users.id', '=', 'orders.user_id')->orderBy('orders.created_at','desc'); 
          
            if (request()->has('user_name')) {

                $user_name = request()->get('user_name');

                if (!empty($user_name)) {

                    $datas->where('user_id', $user_name);

                }

            }
            
            if (request()->has('order_type')) {

                $order_type = request()->get('order_type');

                if (!empty($order_type)) {

                    $datas->where('orders.status', $order_type);

                }

            }
            
            // filter_delivery_status
            
            if (request()->has('filter_delivery_status')) {

                $filter_delivery_status = request()->get('filter_delivery_status');

                if (!empty($filter_delivery_status)) {

                    $datas->where('orders.status', $filter_delivery_status);

                }

            }
            
            
              /*if (request()->has('filter_country')) {

                $filter_country = request()->get('filter_country');
                    
                    if($filter_country == 0){
                        $datas->where('customer_country', DB::raw("'Kuwait'"));
                    }else{
                         $datas->where('customer_country', '!=' , DB::raw("'Kuwait'"));
                    }

                   

            }*/
            
            
             if (!empty(request()->start_date) && !empty(request()->end_date)) {

                $start = request()->start_date;

                $end =  request()->end_date;

                $datas->whereDate('orders.created_at', '>=', DB::raw("'$start'"))

                            ->whereDate('orders.created_at', '<=', DB::raw("'$end'"));

            }
            
            $datas = $datas->get();
            
           return Datatables::of($datas)
                            ->editColumn('id', function(Order $data) {
                                $id = '<a href="'.route('admin-order-invoice',$data->id).'">'.$data->order_number.'</a>';
                                return $id;
                            })
                              ->editColumn('order_date', function(Order $data) {
                                return $data->created_at;
                            })
                            ->editColumn('city', function(Order $data) {
                                return $data->customer_city;
                            })
                             ->editColumn('country', function(Order $data) {
                                return $data->customer_country;
                            })
                            ->editColumn('pay_amount', function(Order $data) {
                                return $data->currency_sign ." ".round($data->pay_amount * $data->currency_value , 2);
                            })
                            ->editColumn('AWB_number', function(Order $data) {
                                 $getShipdtls = \DB::table("order_shipping_details")->where("order_number",$data->order_number)->first();
                                 if(isset($getShipdtls)){
                                    return $getShipdtls->AWB_number;
                                 }else{
                                     return null;
                                 }
                            })
                            ->addColumn('action', function(Order $data) {
                               if($data->status == 'completed'){
                                    $orders = '<a href="javascript:;" data-href="'. route('admin-order-edit',$data->id) .'" class="delivery" data-toggle="modal" data-target="#modal1" data-toggle="tooltip" title="Delivery Status"><i class="fas fa-dollar-sign"></i></a>';
                                    
                                    return '<div class="action-list"><a href="' . route('admin-order-show',$data->id) . '" data-toggle="tooltip" title="Details"> <i class="fas fa-eye"></i> </a><a href="javascript:;" class="send" data-email="'. $data->customer_email .'" data-toggle="modal" data-target="#vendorform" data-toggle="tooltip" title="Send"><i class="fas fa-envelope"></i></a><a href="javascript:;" data-href="'. route('admin-order-track',$data->id) .'" class="track" data-toggle="modal" data-target="#modal1" data-toggle="tooltip" title="Track Order"><i class="fas fa-truck"></i></a>'.$orders.'<a href="' . route('admin-order-return',$data->id) . '" data-toggle="tooltip" title="Return"> <i class="fas fa-undo"></i> </a><a href="' . route('admin-order-delete',$data->id) . '" data-toggle="tooltip" title="Delete"> <i class="fas fa-trash"></i> </a></div>';
                                }else{
                                    $orders = '<a href="javascript:;" data-href="'. route('admin-order-edit',$data->id) .'" class="delivery" data-toggle="modal" data-target="#modal1" data-toggle="tooltip" title="Delivey Status"><i class="fas fa-dollar-sign"></i></a>';
                                  
                                     return '<div class="action-list"><a href="' . route('admin-order-show',$data->id) . '" data-toggle="tooltip" title="Details"> <i class="fas fa-eye"></i> </a><a href="javascript:;" class="send" data-email="'. $data->customer_email .'" data-toggle="modal" data-target="#vendorform" data-toggle="tooltip" title="Send"><i class="fas fa-envelope"></i></a><a href="javascript:;" data-href="'. route('admin-order-track',$data->id) .'" class="track" data-toggle="modal" data-target="#modal1" data-toggle="tooltip" title="Track Order"><i class="fas fa-truck"></i></a><a href="' . route('admin-order-delete',$data->id) . '" data-toggle="tooltip" title="Delete"> <i class="fas fa-trash"></i> </a>'.$orders.'</div>';
                                
                                }
                               
                               
                                 }) 
                            ->rawColumns(['id','order_date','city','country','action','pay_amount','AWB_number'])
                            ->toJson();  //--- Returning Json Data To Client Side
                            
         }
        
    }

      public function allDashboardOrders(Request $request)
    {
        
         if (request()->ajax()) {
             $datas = Order::orderBy('created_at','desc'); 
          
         
            
            if (request()->has('order_type')) {

                $order_type = request()->get('order_type');

                if (!empty($order_type)) {

                    $datas->where('status', $order_type);

                }

            }
            
            
              if (request()->has('filter_country')) {

                $filter_country = request()->get('filter_country');
                    
                    if($filter_country == 0){
                        $datas->where('customer_country', 'Kuwait');
                    }else{
                         $datas->where('customer_country', '!=' , 'Kuwait');
                    }

                   

            }
            
            // filter_delivery_status
            
            if (request()->has('filter_delivery_status')) {

                $filter_delivery_status = request()->get('filter_delivery_status');

                if (!empty($filter_delivery_status)) {

                    $datas->where('status', $filter_delivery_status);

                }

            }
            
            
          
          
            $datas = $datas->get();
            
           return Datatables::of($datas)
                            ->editColumn('id', function(Order $data) {
                                $id = '<a href="'.route('admin-order-invoice',$data->id).'">'.$data->order_number.'</a>';
                                return $id;
                            })
                              ->editColumn('order_date', function(Order $data) {
                                return $data->created_at;
                            })
                            ->editColumn('city', function(Order $data) {
                                return $data->customer_city;
                            })
                             ->editColumn('country', function(Order $data) {
                                return $data->customer_country;
                            })
                            ->editColumn('pay_amount', function(Order $data) {
                                return $data->currency_sign ." ".round($data->pay_amount * $data->currency_value , 2);
                            })
                            ->editColumn('AWB_number', function(Order $data) {
                                 $getShipdtls = \DB::table("order_shipping_details")->where("order_number",$data->order_number)->first();
                                 if(isset($getShipdtls)){
                                    return $getShipdtls->AWB_number;
                                 }else{
                                     return null;
                                 }
                            })
                            ->addColumn('action', function(Order $data) {
                               if($data->status == 'completed'){
                                    $orders = '<a href="javascript:;" data-href="'. route('admin-order-edit',$data->id) .'" class="delivery" data-toggle="modal" data-target="#modal1" data-toggle="tooltip" title="Delivery Status"><i class="fas fa-dollar-sign"></i></a>';
                                    $getShipdtls = \DB::table("order_shipping_details")->where("order_number",$data->order_number)->first();
                                    
                                    if(!isset($getShipdtls)){
                                       $shipment_details = '<a href="javascript:void(0)" onclick="getshipment('.$data->id.')" data-toggle="tooltip" title="Add Shipments"> <i class="fas fa-truck"></i></a>';
                                        $bill = '<a href="' . route('admin-order-shipment_details',$data->id) . '"  data-toggle="tooltip" title="Download Airway_bill" style="display:none" id="air_way_bill"> <i class="fas fa-download"></i></a>';
                              
                                    }else{
                                      $shipment_details = '<a href="javascript:void(0)" onclick="getshipment('.$data->id.')" data-toggle="tooltip" title="Add Shipments" style="display:none"> <i class="fas fa-truck"></i></a>';
                                       
                                       $bill = '<a href="' . route('admin-order-shipment_details',$data->id) . '"  data-toggle="tooltip" title="Download Airway_bill" id="air_way_bill"> <i class="fas fa-download"></i></a>';
                                    }
                                    
                                    return '<div class="action-list"><a href="' . route('admin-order-show',$data->id) . '" data-toggle="tooltip" title="Details"> <i class="fas fa-eye"></i> </a><a href="javascript:;" class="send" data-email="'. $data->customer_email .'" data-toggle="modal" data-target="#vendorform" data-toggle="tooltip" title="Send"><i class="fas fa-envelope"></i></a><a href="javascript:;" data-href="'. route('admin-order-track',$data->id) .'" class="track" data-toggle="modal" data-target="#modal1" data-toggle="tooltip" title="Track Order"><i class="fas fa-truck"></i></a>'.$orders.'<a href="' . route('admin-order-return',$data->id) . '" data-toggle="tooltip" title="Return"> <i class="fas fa-undo"></i> </a>'.$shipment_details.$bill.'</div>';
                                }else{
                                    $orders = '<a href="javascript:;" data-href="'. route('admin-order-edit',$data->id) .'" class="delivery" data-toggle="modal" data-target="#modal1" data-toggle="tooltip" title="Delivey Status"><i class="fas fa-dollar-sign"></i></a>';
                                    $getShipdtls = \DB::table("order_shipping_details")->where("order_number",$data->order_number)->first();
                                    
                                       if(!isset($getShipdtls)){
                                       $shipment_details = '<a href="javascript:void(0)" onclick="getshipment('.$data->id.')" data-toggle="tooltip" title="Add Shipments"> <i class="fas fa-truck"></i></a>';
                                        $bill = '<a href="' . route('admin-order-shipment_details',$data->id) . '"  data-toggle="tooltip" title="Download Airway_bill" style="display:none" id="air_way_bill"> <i class="fas fa-download"></i></a>';
                              
                                    }else{
                                      $shipment_details = '<a href="javascript:void(0)" onclick="getshipment('.$data->id.')" data-toggle="tooltip" title="Add Shipments" style="display:none"> <i class="fas fa-truck"></i></a>';
                                       
                                       $bill = '<a href="' . route('admin-order-shipment_details',$data->id) . '"  data-toggle="tooltip" title="Download Airway_bill" id="air_way_bill"> <i class="fas fa-download"></i></a>';
                                    }
                                     return '<div class="action-list"><a href="' . route('admin-order-show',$data->id) . '" data-toggle="tooltip" title="Details"> <i class="fas fa-eye"></i> </a><a href="javascript:;" class="send" data-email="'. $data->customer_email .'" data-toggle="modal" data-target="#vendorform" data-toggle="tooltip" title="Send"><i class="fas fa-envelope"></i></a><a href="javascript:;" data-href="'. route('admin-order-track',$data->id) .'" class="track" data-toggle="modal" data-target="#modal1" data-toggle="tooltip" title="Track Order"><i class="fas fa-truck"></i></a>'.$orders.$shipment_details.$bill.'</div>';
                                
                                }
                               
                               
                                 }) 
                            ->rawColumns(['id','order_date','city','country','action','pay_amount','AWB_number'])
                            ->toJson();  //--- Returning Json Data To Client Side
                            
         }
        
    }
    
    
    
    public function index()
    {
        
        return view('admin.order.index');
    }

    public function edit($id)
    {
        $data = Order::find($id);
        return view('admin.order.delivery',compact('data'));
    }
    



    //*** POST Request
    public function update(Request $request, $id)
    {

        //--- Logic Section
        $data = Order::findOrFail($id);

        $input = $request->all();
        if ($data->status == "completed"){

        // Then Save Without Changing it.
            $input['status'] = "completed";
            $data->update($input);
            //--- Logic Section Ends
    

        //--- Redirect Section          
        $msg = 'Status Updated Successfully.';
        return response()->json($msg);    
        //--- Redirect Section Ends     

    
            }else{
            if ($input['status'] == "completed"){
    
                $gs = Generalsetting::findOrFail(1);
                if($gs->is_smtp == 1)
                {
                    $maildata = [
                        'to' => $data->customer_email,
                        'subject' => 'Your order '.$data->order_number.' is Confirmed!',
                        'body' => "Hello ".$data->customer_name.","."\n Thank you for shopping with us. We are looking forward to your next visit.",
                    ];
    
                    $mailer = new GeniusMailer();
                    $mailer->sendCustomMail($maildata);                
                }
                else
                {
                   $to = $data->customer_email;
                   $subject = 'Your order '.$data->order_number.' is Confirmed!';
                   $msg = "Hello ".$data->customer_name.","."\n Thank you for shopping with us. We are looking forward to your next visit.";
                $headers = "From: ".$gs->from_name."<".$gs->from_email.">";
                   mail($to,$subject,$msg,$headers);                
                }
            }
            if ($input['status'] == "declined"){
                $gs = Generalsetting::findOrFail(1);
                if($gs->is_smtp == 1)
                {
                    $maildata = [
                        'to' => $data->customer_email,
                        'subject' => 'Your order '.$data->order_number.' is Declined!',
                        'body' => "Hello ".$data->customer_name.","."\n We are sorry for the inconvenience caused. We are looking forward to your next visit.",
                    ];
                $mailer = new GeniusMailer();
                $mailer->sendCustomMail($maildata);
                }
                else
                {
                   $to = $data->customer_email;
                   $subject = 'Your order '.$data->order_number.' is Declined!';
                   $msg = "Hello ".$data->customer_name.","."\n We are sorry for the inconvenience caused. We are looking forward to your next visit.";
                   $headers = "From: ".$gs->from_name."<".$gs->from_email.">";
                   mail($to,$subject,$msg,$headers);
                }
    
            }

            $data->update($input);

            // if($request->track_text)
            // {
                    $title = ucwords($request->status);
                    $ck = OrderTrack::where('order_id','=',$id)->where('title','=',$title)->first();
                    if($ck){
                        $ck->order_id = $id;
                        $ck->title = $title;
                        $ck->text = $request->track_text;
                        $ck->update();  
                    }
                    else {
                        $data = new OrderTrack;
                        $data->order_id = $id;
                        $data->title = $title;
                        $data->text = $request->track_text;
                        $data->save();            
                    }
    
    
            // } 


         //--- Redirect Section          
         $msg = 'Status Updated Successfully.';
         return response()->json($msg);    
         //--- Redirect Section Ends    
    
            }



        //--- Redirect Section          
        $msg = 'Status Updated Successfully.';
        return response()->json($msg);    
        //--- Redirect Section Ends  


    }

    public function return($id){
        $updateOrder = \DB::table("orders")->where('id',$id)->update(['status'=>'returned','pay_amount'=>0]);
         $order = Order::findOrFail($id);
         
        // $cart = unserialize(bzdecompress(utf8_decode($order->cart)));
        return view('admin.order.return',compact('order'));
    }
    
    
    public function pending()
    {
        return view('admin.order.pending');
    }
    public function processing()
    {
        return view('admin.order.processing');
    }
    public function completed()
    {
        return view('admin.order.completed');
    }
    public function declined()
    {
        return view('admin.order.declined');
    }
     public function returned()
    {
        return view('admin.order.returned');
    }
    public function delete($id)
    {
      $order = Order::where('id',$id)->delete();
      return redirect()->back()->with('success', 'Order deleted successfully!');
    }
    public function show($id)
    {
        $order = Order::findOrFail($id);
        $cart = unserialize(bzdecompress(utf8_decode($order->cart)));
        $user_id = $order->user_id;
        $user = User::findOrFail($user_id);
        // echo "<pre>"; print_r($cart); exit;
        return view('admin.order.details',compact('order','cart','user'));
    }
    public function invoice($id)
    {
        $order = Order::findOrFail($id);
        $user_id = $order->user_id;
        $user = User::findOrFail($user_id);
        $cart = unserialize(bzdecompress(utf8_decode($order->cart)));
        return view('admin.order.invoice',compact('order','cart','user'));
    }
    public function emailsub(Request $request)
    {
        $gs = Generalsetting::findOrFail(1);
        if($gs->is_smtp == 1)
        {
            $data = [
                    'to' => $request->to,
                    'subject' => $request->subject,
                    'body' => $request->message,
            ];

            $mailer = new GeniusMailer();
            $mailer->sendCustomMail($data);                
        }
        else
        {
            $data = 0;
            $headers = "From: ".$gs->from_name."<".$gs->from_email.">";
            $mail = mail($request->to,$request->subject,$request->message,$headers);
            if($mail) {   
                $data = 1;
            }
        }

        return response()->json($data);
    }

    public function printpage($id)
    {
        $order = Order::findOrFail($id);
        $cart = unserialize(bzdecompress(utf8_decode($order->cart)));
        $user_id = $order->user_id;
        $user = User::findOrFail($user_id);
        return view('admin.order.print',compact('order','cart','user'));
    }

    public function license(Request $request, $id)
    {
        $order = Order::findOrFail($id);
        $cart = unserialize(bzdecompress(utf8_decode($order->cart)));
        $cart->items[$request->license_key]['license'] = $request->license;
        $order->cart = utf8_encode(bzcompress(serialize($cart), 9));
        $order->update();       
        $msg = 'Successfully Changed The License Key.';
        return response()->json($msg);
    }

    public function status($id,$status)
    {
        $mainorder = Order::findOrFail($id);

    }
    
        
   public function shipment_details($id){
       
       $mainorder = Order::findOrFail($id);
       
        $order = \DB::table("order_shipping_details")->where("order_number",$mainorder->order_number)->first();
         $response = $this->getFedExResponse(null,$order);
         $file = public_path()."/".$order->AWB_number.'_AIR_WAYBILL.pdf';
        //  echo $file; exit;

if(!file_exists($file)){ // file does not exist
    die('file not found');
} else {
    header("Cache-Control: public");
    header("Content-Description: File Transfer");
    header("Content-Disposition: attachment; filename=$file");
    header("Content-Type: application/zip");
    header("Content-Transfer-Encoding: binary");

    // read the file from disk
    readfile($file);
}
exit;

        // $response = $this->getFedExResponse(null,$order);
     
             if (file_exists($file)) {
                    header('Content-Description: File Transfer');
                    header('Content-Type: application/octet-stream');
                    header('Content-Disposition: attachment; filename="'.basename($file).'"');
                    header('Expires: 0');
                    header('Cache-Control: must-revalidate');
                    header('Pragma: public');
                    header('Content-Length: ' . filesize($file));
                    readfile($file);
                    exit;
                }
         
           
            
            
   }
     public function shipment($id){
         $order = Order::findOrFail($id);
         $data = null;
        // echo $id; exit;
         $response = $this->getFedExResponse($data,$order);
         if($response == 0){
             return 0;
         }else{
             return json_encode($response);
         }
    }
    
    
      private function getFedExResponse($data,$order){
        
        $xml = '<SOAP-ENV:Envelope xmlns:SOAP-ENV="http://schemas.xmlsoap.org/soap/envelope/" xmlns:SOAP-ENC="http://schemas.xmlsoap.org/soap/encoding/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:m0="http://fedex.com/ws/ship/v23">
   <SOAP-ENV:Body>
      <ProcessShipmentRequest xmlns="http://fedex.com/ws/ship/v23">
         <WebAuthenticationDetail>
            <ParentCredential>
               <Key>fggkognwYOTIwftP</Key>
               <Password>vRAB8LPkhKuT9BfQMZBz8poty</Password>
            </ParentCredential>
            <UserCredential>
               <Key>fggkognwYOTIwftP</Key>
               <Password>vRAB8LPkhKuT9BfQMZBz8poty</Password>
            </UserCredential>
         </WebAuthenticationDetail>
         <ClientDetail>
            <AccountNumber>510087160</AccountNumber>
            <MeterNumber>114019609</MeterNumber>
         </ClientDetail>
         <TransactionDetail>
            <CustomerTransactionId>IE_v17_Ship</CustomerTransactionId>
         </TransactionDetail>
         <Version>
            <ServiceId>ship</ServiceId>
            <Major>23</Major>
            <Intermediate>0</Intermediate>
            <Minor>0</Minor>
         </Version>
         <RequestedShipment>
            <ShipTimestamp>2019-11-19T12:00:56-06:00</ShipTimestamp>
            <DropoffType>REGULAR_PICKUP</DropoffType>
            <ServiceType>INTERNATIONAL_PRIORITY</ServiceType>
            <PackagingType>YOUR_PACKAGING</PackagingType>
            <Shipper>
               <Contact>
                  <PersonName>SYED</PersonName>
                  <CompanyName>FOUZ BOUTIQUE</CompanyName>
                  <PhoneNumber>123456789</PhoneNumber>
                  <EMailAddress>TEST@TEST.COM</EMailAddress>
               </Contact>
               <Address>
                  <StreetLines>AVNU21 BLD 1, MEZANNAINE FLR</StreetLines>
                  <StreetLines>BLK 12 ABUGAR ALGHAFARI STREET</StreetLines>
                  <City>SALMIYA</City>
                  <StateOrProvinceCode></StateOrProvinceCode>
                  <PostalCode></PostalCode>
                  <CountryCode>KW</CountryCode>
               </Address>
            </Shipper>
            <Recipient>
               <Contact>
                  <PersonName>TST NAME</PersonName>
                  <CompanyName>TST COMPANY</CompanyName>
                  <PhoneNumber>123456789</PhoneNumber>
                  <EMailAddress>TEST@TEST.COM</EMailAddress>
               </Contact>
               <Address>
                  <StreetLines>ADDRESS LINE 1</StreetLines>
                  <StreetLines>ADDRESS LINE 2</StreetLines>
                  <City>DUBAI CITY</City>
                  <StateOrProvinceCode></StateOrProvinceCode>
                  <PostalCode></PostalCode>
                  <CountryCode>AE</CountryCode>
               </Address>
            </Recipient>
            <ShippingChargesPayment>
               <PaymentType>SENDER</PaymentType>
               <Payor>
                  <ResponsibleParty>
                     <AccountNumber>510087160</AccountNumber>
                     <Contact>
                        <ContactId>12345</ContactId>
                        <PersonName>INPUT YOUR INFORMATION</PersonName>
                     </Contact>
                  </ResponsibleParty>
               </Payor>
            </ShippingChargesPayment>
            <SpecialServicesRequested>
               <SpecialServiceTypes>ELECTRONIC_TRADE_DOCUMENTS</SpecialServiceTypes>
            </SpecialServicesRequested>
            <CustomsClearanceDetail>
               <DutiesPayment>
                  <PaymentType>RECIPIENT</PaymentType>
               </DutiesPayment>
               <DocumentContent>NON_DOCUMENTS</DocumentContent>
               <CustomsValue>
                  <Currency>USD</Currency>
                  <Amount>100.00</Amount>
               </CustomsValue>
               <Commodities>
                  <NumberOfPieces>1</NumberOfPieces>
                  <Description>ABCD</Description>
                  <CountryOfManufacture>US</CountryOfManufacture>
                  <Weight>
                     <Units>KG</Units>
                     <Value>1.0</Value>
                  </Weight>
                  <Quantity>1</Quantity>
                  <QuantityUnits>cm</QuantityUnits>
                  <UnitPrice>
                     <Currency>USD</Currency>
                     <Amount>1.000000</Amount>
                  </UnitPrice>
                  <CustomsValue>
                     <Currency>USD</Currency>
                     <Amount>100.000000</Amount>
                  </CustomsValue>
               </Commodities>
               <ExportDetail>
                  <ExportComplianceStatement>30.37(f)</ExportComplianceStatement>
               </ExportDetail>
            </CustomsClearanceDetail>
            <LabelSpecification>
               <LabelFormatType>COMMON2D</LabelFormatType>
               <ImageType>PDF</ImageType>
               <LabelStockType>PAPER_8.5X11_TOP_HALF_LABEL</LabelStockType>
            </LabelSpecification>
            <ShippingDocumentSpecification>
               <ShippingDocumentTypes>COMMERCIAL_INVOICE</ShippingDocumentTypes>
               <CommercialInvoiceDetail>
                  <Format>
                     <ImageType>PDF</ImageType>
                     <StockType>PAPER_LETTER</StockType>
                     <ProvideInstructions>1</ProvideInstructions>
                  </Format>
                  <CustomerImageUsages>
                     <Type>LETTER_HEAD</Type>
                     <Id>IMAGE_1</Id>
                  </CustomerImageUsages>
                  <CustomerImageUsages>
                     <Type>SIGNATURE</Type>
                     <Id>IMAGE_2</Id>
                  </CustomerImageUsages>
               </CommercialInvoiceDetail>
            </ShippingDocumentSpecification>
            <RateRequestTypes>LIST</RateRequestTypes>
            <PackageCount>1</PackageCount>
            <RequestedPackageLineItems>
               <SequenceNumber>1</SequenceNumber>
               <Weight>
                  <Units>KG</Units>
                  <Value>20.0</Value>
               </Weight>
               <Dimensions>
                  <Length>12</Length>
                  <Width>12</Width>
                  <Height>12</Height>
                  <Units>CM</Units>
               </Dimensions>
               <CustomerReferences>
                  <CustomerReferenceType>CUSTOMER_REFERENCE</CustomerReferenceType>
                  <Value>TC001_01_PT1_ST01_PK01_SNDUS_RCPCA_POS</Value>
               </CustomerReferences>
            </RequestedPackageLineItems>
         </RequestedShipment>
      </ProcessShipmentRequest>
   </SOAP-ENV:Body>
</SOAP-ENV:Envelope>';
        
   


    
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL,'https://wsbeta.fedex.com:443/web-services');
        curl_setopt($curl, CURLOPT_POST, 1);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($curl, CURLOPT_POSTFIELDS, $xml);
        $result_xml = curl_exec($curl);
        if (curl_errno($curl)) {
            $error_msg = curl_error($curl);
        }
        curl_close($curl);
        
        if (isset($error_msg)) {
            // TODO - Handle cURL error accordingly
            print_r($error_msg);
            return 0;
        }else{
       
            // $response = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $result_xml);
            $response = str_replace('xmlns="http//fedex.com/ws/ship/v23"', '', $result_xml);
            $response = str_replace('xmlns:SOAP-ENV="http://schemas.xmlsoap.org/soap/envelope/"', '', $result_xml);
            // $response = $this->delete_all_between('<Image>', '</Image>', $response);
           
            libxml_use_internal_errors(true);
            $Data = simplexml_load_string($response) or die("ghvgh");
            if (false === $Data) {
                echo "Failed loading XML\n";
                foreach(libxml_get_errors() as $error) {
                    echo "\t", $error->message;
                }
            }
            
                // echo "<pre>"; print_r($Data);  exit;
                $Data = $this->xml2array($Data);
                if(isset($Data['SOAP-ENV:Body']['ProcessShipmentReply']['CompletedShipmentDetail']['CompletedPackageDetails']['Label']['Parts'])){
                    $base64 = $Data['SOAP-ENV:Body']['ProcessShipmentReply']['CompletedShipmentDetail']['CompletedPackageDetails']['Label']['Parts']['Image'];
                    
                    $awb_number =  $Data['SOAP-ENV:Body']['ProcessShipmentReply']['CompletedShipmentDetail']['MasterTrackingId']['TrackingNumber'];
                    
                $decoded = base64_decode($base64);
                
                 $saveAWB = \DB::table("order_shipping_details")->insertGetid(['order_number'=>$order->order_number,'AWB_number'=>$awb_number,'AWB_image'=>$decoded]);
                
                if ( base64_encode(base64_decode($base64, true)) === $base64){
    echo 'is valid';
} else {
    echo 'is NOT valid';
}
exit;
                 echo $decoded; exit;
                $file = $awb_number.'_AIR_WAYBILL.pdf';
                
                $order_shipment = [
                        'order_number' => $order->order_number,
                        'AWB_number' => $awb_number
                    ];
                    
                     file_put_contents($file, $decoded);
      
               
                return 0;
                // if (file_exists($file)) {
                //     header('Content-Description: File Transfer');
                //     header('Content-Type: application/octet-stream');
                //     header('Content-Disposition: attachment; filename="'.basename($file).'"');
                //     header('Expires: 0');
                //     header('Cache-Control: must-revalidate');
                //     header('Pragma: public');
                //     header('Content-Length: ' . filesize($file));
                //     readfile($file);
                //     exit;
                // }
      
                $saveAWB = \DB::table("order_shipping_details")->insertGetid(['order_number'=>$order->order_number,'AWB_number'=>$awb_number]);
                return $order_shipment;
            
            
                
        }else{
            return 0;
        }

         }
    }
    
    function xml2array ( $xmlObj, $output = array () )
       {      
       foreach ( (array) $xmlObj as $index => $node )
       {
        $output[$index] = (is_object($node)) ? $this->xml2array($node): $node;
       }
      return $output;
    }
    
}