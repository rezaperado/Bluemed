<?php

namespace App\Http\Controllers\User;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Wishlist;
use App\Models\Product;
use Auth;
use Illuminate\Support\Facades\Session;
use App\Models\Currency;
class WishlistController extends Controller
{
    public function __construct()
    {
       // $this->middleware('auth');
    }

    public function wishlists(Request $request)
    {
        $user = Auth::user();
        if(empty($user))
        {
            return redirect('/user/login');
        }
        $sort = '';
        $user = Auth::guard('web')->user();

        // Search By Sort
        if (Session::has('currency')) 
        {
            $curr = Currency::find(Session::get('currency'));
        }
        else
        {
            $curr = Currency::where('is_default','=',1)->first();
        }
        $wishes = Wishlist::where('user_id','=',$user->id)->pluck('product_id');
        $wishlists = Product::where('status','=',1)->whereIn('id',$wishes)->orderBy('id','desc')->paginate(8);
        if($request->ajax())
        {
            return view('front.pagination.wishlist',compact('user','wishlists','sort'));            
        }
        return view('user.wishlist',compact('user','wishlists','sort','curr'));
    }
    
    public function addwishlist(Request $request)
    {      
        $user = Auth::guard('web')->user();
        if(!empty($user))
        {
            $data = 0;
            $product_id = $request->product_id;
            $ck = Wishlist::where('user_id','=',$user->id)->where('product_id','=',$product_id)->get()->count();
            if($ck > 0)
            {
                return response()->json(['status'=>false]); 
            }
            $wish = new Wishlist();
            $wish->user_id = $user->id;
            $wish->product_id = $product_id;
            $wish->save();
            $ck = Wishlist::where('user_id','=',$user->id)->get()->count();
            $data = 1; 
            return response()->json(['status'=>'1','total_count'=>$ck]);
        }
        else
        {
            return response()->json(['status'=>'2']);
        }   
    }
    public function addwish($id)
    {      
        $user = Auth::guard('web')->user();
        $data = 0;
        $ck = Wishlist::where('user_id','=',$user->id)->where('product_id','=',$id)->get()->count();
        if($ck > 0)
        {
            return response()->json(['status'=>false]); 
        }
        $wish = new Wishlist();
        $wish->user_id = $user->id;
        $wish->product_id = $id;
        $wish->save();
        $data = 1; 
        return response()->json(['status'=>true]);      
    }

    public function removewish($id)
    {
        $wish = Wishlist::findOrFail($id);
        $wish->delete();        
        $data = 1; 
        return response()->json($data);      
    }
    
    public function getWish()
    {
        $user = Auth::guard('web')->user();
        $ck = Wishlist::where('user_id','=',$user->id)->get()->count();
        if(empty($ck)){
            $data = 0;
        }else{
            $data = $ck;
        }
        return response()->json($data);      
    }

}
