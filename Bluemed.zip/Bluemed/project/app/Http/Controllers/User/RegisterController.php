<?php

namespace App\Http\Controllers\User;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Generalsetting;
use App\Models\User;
use App\Classes\GeniusMailer;
use App\Models\Notification;
use App\Models\EmailTemplate;
use Auth;
use Illuminate\Support\Facades\Input;
use Validator;
use Mail;
use App\Mail\RegisterReminder;


class RegisterController extends Controller
{

    public function register(Request $request)
    {

    	$params = $request->post();
    	$gs = Generalsetting::findOrFail(1);

    	if($gs->is_capcha == 1)
    	{
	        $value = session('captcha_string');
	        if ($request->codes != $value){
	            return response()->json(array('errors' => [ 0 => 'Please enter Correct Capcha Code.' ]));    
	        }    		
    	}
        $rules = [
		        'email'   => 'required|email|unique:users',
		        'password' => 'min:5|required_with:confirm_password|same:confirm_password',
				'confirm_password' => 'min:5'
                ];
        $validator = Validator::make(Input::all(), $rules);
        
        if ($validator->fails()) {
          //return response()->json(array('errors' => $validator->getMessageBag()->toArray()));
          return redirect()->back()
                        ->withErrors($validator)
                        ->withInput();
        }
        $user = new User;
        $input = $request->except(['_token','confirm_password','register']);     
        $input['password'] = bcrypt($request['password']);
        $token = md5(time().$request->email);
        $input['verification_link'] = $token;
        $user->fill($input)->save();
        //send signup email
    	$data = [
            'to' => $request->email,
            'type' => "new_registration",
            'name' => $request->first_name."  ".$request->last_name,
            'token' => $token,
            'verify_link' => url('user/register/verify/'.$token),
            'is_verification_email' => $gs->is_verification_email 
        ];

        $mailer = new GeniusMailer();
        $this->sendRegistrationMail($data);
		if($gs->is_verification_email == 1)
        {

	        $to = $request->email;
	        /*$subject = 'Verify your email address.';
	        
	        $message = "Dear Customer,\nSimply click the link below or copy paste in your browser to verify your email address.".url('user/register/verify/'.$token);

	        $msg = "Dear Customer\nWe noticed that you need to verify your email address". url('user/register/verify/'.$token)."Simply click here to verify";
	        $data  = array('to' => $to , 'subject' => $subject , 'msg' => $msg); 
	       
	        $data = [
	            'to' => $to,
	            'subject' => $subject,
	            'body' => $msg,
	        ];
	        
	        $to = $to;
            $subject = $subject;
            $txt = $message;

            $headers = "From: ".$gs->from_name."<".$gs->from_email.">";
            //echo $to."   ".$headers."   ".$subject."  ".$txt;exit;
            try{
                mail($to,$subject,$txt,$headers);    
            }
            catch(Exception $e)
            {
                
            }*/
      		return redirect()->back()->with('success', 'We need to verify your email address. We have sent an email to '.$to.' to verify your email address. Please click link in that email to continue.');
        }
        else {
            $user->email_verified = 'Yes';
            $user->update();
	        $notification = new Notification;
	        $notification->user_id = $user->id;
	        $notification->save();
            Auth::guard('web')->login($user); 
          	return redirect()->route('user-profile');
        }
        
    }
    public function sendRegistrationMail($maildata)
    {
    	$email_template = EmailTemplate::where('email_type', $maildata['type'])->first()->toArray();
    	$email_body = $email_template['email_body'];
    	$email_sub = $email_template['email_subject'];
    	$is_verification_email = $maildata['is_verification_email'];
    	$verification_link = $maildata['verify_link'];
    	$setup = Generalsetting::find(1);
    	$logo = "<img src='".public_path('/theme/assets/upload/'.$setup->logo)."'>";
    	
    	$body = str_replace("{customer_name}", $maildata['name'] ,$email_body);
    	$body = str_replace("{website_title}", $setup->title ,$body);
    	
    	
    	$exloded_body = explode('.',$body);
    	$exloded_body[3] = '<a href="'.$verification_link.'">'.$verification_link.'</a>';
    	$email_body = implode('. ',$exloded_body);
    	$data = [
            'email_body' => $email_body
        ];
        $objDemo = new \stdClass();
        $objDemo->to = $maildata['to'];
        $objDemo->from = $setup->from_email;
        $objDemo->title = $setup->from_name;
        $objDemo->subject = $email_sub;

        try{
            Mail::send('emails.mailbody',$data, function ($message) use ($objDemo) {
                $message->from($objDemo->from,$objDemo->title);
                $message->to($objDemo->to);
                $message->subject($objDemo->subject);
            });
        }
        catch (\Exception $e){
            die($e->getMessage());
        }
    }
    public function token($token)
    {
        $gs = Generalsetting::findOrFail(1);

        if($gs->is_verification_email == 1)
        {    	
            $user = User::where('verification_link','=',$token)->first();
            if(isset($user))
            {

                $user->email_verified = 'Yes';
                $user->update();
    	        $notification = new Notification;
    	        $notification->user_id = $user->id;
    	        $notification->save();
                Auth::guard('web')->login($user); 
                return redirect()->route('edit-profile')->with('success','Email Verified Successfully');
            }
		}
		else {
    		return redirect()->back();	
		}
    }
}
