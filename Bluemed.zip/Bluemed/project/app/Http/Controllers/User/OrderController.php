<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use Auth;
use App\Models\Order;
use App\Models\Product;
use App\Models\OrderTrack;
use Illuminate\Http\Request;
use App\Models\Generalsetting;
use View;
use Session;
use App\Models\Currency;
class OrderController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth');
    }

    public function orders()
    {
        $user = Auth::guard('web')->user();
        $orders = Order::where('user_id','=',$user->id)->orderBy('id','desc')->get();
        return view('user.order.index',compact('user','orders'));
    }
    public function view($id)
    {
        $order = Order::where('id',$id)->get()->first();
        if (Session::has('currency')) 
        {
            $curr = Currency::find(Session::get('currency'));
        }
        else
        {
            $curr = Currency::where('is_default','=',1)->first();
        }
        $user = Auth::user();
        $product_data = Product::select('products.*')->join('ordered_product_details','ordered_product_details.product_id','=','products.id')->where('ordered_product_details.order_number',$order->order_number)->get();
       //return $order->cart;
       $cart = unserialize(bzdecompress(utf8_decode($order->cart)));
        return view('user.order-view',compact('order','user','curr','product_data','cart'));
    }
    public function vieworder(Request $request)
    {
        $order_id = $request->order_id;
        $order = Order::where('id',$order_id)->get()->first();
        if (Session::has('currency')) 
        {
            $curr = Currency::find(Session::get('currency'));
        }
        else
        {
            $curr = Currency::where('is_default','=',1)->first();
        }
        $product_data = Product::select('products.*')->join('ordered_product_details','ordered_product_details.product_id','=','products.id')->where('ordered_product_details.order_number',$order->order_number)->get();
        $html =  View::make('user.order-view',compact('user','curr','product_data','order'));
        echo $html;exit;
    }
    public function trackorder(Request $request)
    {
        $order_id = $request->order_id;
        $order = Order::where('id','=',$order_id)->first();

        $order_track_data = OrderTrack::where('order_id',$order->id)->orderBy('created_at','desc')->get();

        $datas = array('Pending','Processing','On Delivery','Completed');
        //$html = view('user.order-track',compact('user','orders'));
        $html =  View::make('user.order-track',compact('user','order','order_track_data'));
        echo $html;exit;
    }
    public function ordertrack()
    {
        $user = Auth::guard('web')->user();
        $orders = Order::where('user_id','=',$user->id)->orderBy('id','desc')->get();
        return view('user.order-track',compact('user','orders'));
    }

    public function trackload($id)
    {
        $order = Order::where('order_number','=',$id)->first();
        $order_track_data = OrderTrack::where('order_id',$order->id)->orderBy('created_at','desc')->get();
        $datas = array('Pending','Processing','On Delivery','Completed');
        return view('load.track-load',compact('order','datas','order_track_data'));

    }


    public function order($id)
    {
        $user = Auth::guard('web')->user();
        $order = Order::findOrfail($id);
        $cart = unserialize(bzdecompress(utf8_decode($order->cart)));
        return view('user.order.details',compact('user','order','cart'));
    }

    public function orderdownload($slug,$id)
    {
        $user = Auth::guard('web')->user();
        $order = Order::where('order_number','=',$slug)->first();
        $prod = Product::findOrFail($id);
        if(!isset($order) || $prod->type == 'Physical' || $order->user_id != $user->id)
        {
            return redirect()->back();
        }
        return response()->download(public_path('assets/files/'.$prod->file));
    }

    public function orderprint($id)
    {
        $user = Auth::user();
        $name = $user->first_name." ".$user->last_name;
        $order = Order::findOrfail($id);
        $cart = unserialize(bzdecompress(utf8_decode($order->cart)));
        $gs = Generalsetting::findOrFail(1);
        return view('user.order.print',compact('user','name','order','cart','gs'));
    }

    public function trans()
    {
        $id = $_GET['id'];
        $trans = $_GET['tin'];
        $order = Order::findOrFail($id);
        $order->txnid = $trans;
        $order->update();
        $data = $order->txnid;
        return response()->json($data);            
    }  

}
