<?php

namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Input;
use App\Models\Cart;
use Illuminate\Http\Request;
use App\Models\Product;
use App\Models\Currency;
use App\Models\Coupon;
use App\Models\Generalsetting;
use Session;
use DB;

class CartController extends Controller
{

    public function cart()
    {
        $this->code_image();
        if (!Session::has('cart')) {
            return view('front.cart');
        }
        if (Session::has('already')) {
            Session::forget('already');
        }
        if (Session::has('coupon')) {
            Session::forget('coupon');
        }
        if (Session::has('coupon_total')) {
            Session::forget('coupon_total');
        }
        if (Session::has('coupon_total1')) {
            Session::forget('coupon_total1');
        }
        if (Session::has('coupon_percentage')) {
            Session::forget('coupon_percentage');
        }
        $gs = Generalsetting::findOrFail(1);
        $oldCart = Session::get('cart');
        
        $cart = new Cart($oldCart);
        $products = $cart->items;
        $totalPrice = $cart->totalPrice;
        $mainTotal = $totalPrice;
        $shipping_data  = DB::table('shippings')->where('user_id','=',0)->get()->first();
        $tx = $gs->tax;
        if($tx != 0)
        {
            $tax = ($totalPrice / 100) * $tx;
            $mainTotal = $totalPrice + $tax;
        }
        if (Session::has('currency')) 
        {
            $curr = Currency::find(Session::get('currency'));
        }
        else
        {
            $curr = Currency::where('is_default','=',1)->first();
        }
        $curr = $curr->sign;

        return view('front.cart', compact('products','totalPrice','mainTotal','tx','curr','shipping_data')); 
    }
    public function updatecartqty(Request $request)
    {
        $params = $request->post();
        $product_id = isset($params['product_id']) ? $params['product_id'] : '';
        $qty = isset($params['qty']) ? $params['qty'] : '';
        $price = isset($params['price']) ? $params['price'] : '';
        $stock = isset($params['stock']) ? $params['stock'] : '';
        $sub_total_price = $price * $qty;
        $cart = Session::get('cart');
        $variations = (array)$cart['items'][$product_id]['variations'];
        
        $prod = Product::where('id','=',$product_id)->first();
        $cart->updateqty($prod, $prod->id,$variations, $stock,$qty);
        if($cart->items[$product_id]['dp'] == 1)
        {
            return response()->json(['status' => 0]);
        }
        if(($cart->items[$product_id]['stock'] != '') && $cart->items[$product_id]['stock'] < 0)
        {
            return response()->json(['status' => 0]);
        }
        if(!empty($cart->items[$product_id]['size_qty']))
        {
            if($cart->items[$product_id]['qty'] > $cart->items[$product_id]['size_qty'])
            {
                return response()->json(['status' => 1, 'msg' => 'Successfully added into cart']);
            }           
        }
        $cart->totalPrice = 0;
        $total_price = 0;$shipping_charge = 0.00;$sub_total = 0;
        foreach($cart->items as $data)
        {
            $cart->totalPrice += $data['price'];
            $sub_total += $data['price'];
        }
        $total_price  = $sub_total + $shipping_charge;
        $formData['productn_ame'] = $prod->name;
        $formData['weight'] = $prod->weight;
        Session::put('cartValues',$formData);
        Session::put('cart',$cart);
        return response()->json(['status' => 1,'prod_sub_total'=>number_format($sub_total_price,2),'sub_total'=>number_format($sub_total,2),'total_price'=>number_format($total_price,2),'shipping_charge'=>0.00, 'msg' => 'Successfully added into cart']);
    }
    public function cartview()
    {
        return view('load.cart'); 
    }
    
    public function submitcart(Request $request){
        try{
            $formData = Input::all();
            $variations = isset($formData['attr']) ? $formData['attr'] : '';
            $attr_id = isset($formData['attr_id']) ? $formData['attr_id'] : '';
            $total_stock = isset($formData['total_stock']) ? $formData['total_stock'] : 0;
            $id = $formData['product_id'];
            $quantity = isset($formData['quantity']) ? $formData['quantity'] : 0;
            
            $prod = Product::where('id','=',$id)->first();
            $oldCart = Session::has('cart') ? Session::get('cart') : null;

            $cart = new Cart($oldCart);
            $cart->add($prod, $prod->id,$variations, $total_stock,$quantity,$attr_id);
            
           
            if($cart->items[$id]['dp'] == 1)
            {
                return response()->json(['status' => 0]);
            }
            if(($cart->items[$id]['stock'] != '') && $cart->items[$id]['stock'] < 0)
            {
                return response()->json(['status' => 0]);
            }
            if(!empty($cart->items[$id]['size_qty']))
            {
                if($cart->items[$id]['qty'] > $cart->items[$id]['size_qty'])
                {
                    return response()->json(['status' => 1, 'msg' => 'Successfully added into cart']);
                }           
            }

            $cart->totalPrice = 0;
            foreach($cart->items as $data)
            $cart->totalPrice += $data['price'];
              $formData['productn_ame'] = $prod->name;
                $formData['weight'] = $prod->weight;
             Session::put('cartValues',$formData);
            Session::put('cart',$cart);
            return response()->json(['status' => 1, 'msg' => 'Successfully added into cart']); 
        }catch(\Exception $e){
            echo $e->getMessage();exit;
            return response()->json(['status' => 0, 'msg' => $e->getMessage()]); 
        }
    }
    
    
    
     public function addincart(Request $request){
        // // echo "<pre>"; print_r(Input::all()); exit;
        $formData = Input::all();
        $id = $formData['product_id'];
         $prod = Product::where('id','=',$id)->first(['id','user_id','slug','name','photo','size','length','size_qty','size_price','color','price','stock','type','file','link','license','license_qty','measure','whole_sell_qty','whole_sell_discount']);
        if(!empty($prod->license_qty))
        {
        $lcheck = 1;
            foreach($prod->license_qty as $ttl => $dtl)
            {
                if($dtl < 1)
                {
                    $lcheck = 0;
                }
                else
                {
                    $lcheck = 1;
                    break;
                }                    
            }
                if($lcheck == 0)
                {
                    return 0;            
                }
        }
        $size = '';
        if(!empty($formData['size']))
        { 
        $size = $formData['size'];
        } 
        
         $length = '';
        if(!empty($formData['lengths']))
        { 
        $length = $formData['lengths'];
        }  

        $oldCart = Session::has('cart') ? Session::get('cart') : null;
        $cart = new Cart($oldCart);

        $cart->add($prod, $prod->id,$size,$length);
        // if($cart->items[$id.$size]['dp'] == 1)
        // {
        //     return redirect()->route('front.cart');
        // }
        // if($cart->items[$id.$size]['stock'] < 0)
        // {
        //     return redirect()->route('front.cart');
        // }
        // if(!empty($cart->items[$id.$size]['size_qty']))
        // {
        //     if($cart->items[$id.$size]['qty'] > $cart->items[$id.$size]['size_qty'])
        //     {
        //         // return redirect()->route('front.cart');
        //     }           
        // }

        $cart->totalPrice = 0;
        foreach($cart->items as $data)
        $cart->totalPrice += $data['price'];
        Session::put('cart',$cart);
         return 'hiiii';
         
         
    }

   public function addtocart($id)
    {
        $prod = Product::where('id','=',$id)->first(['id','user_id','slug','name','photo','size','length','size_qty','size_price','color','price','stock','type','file','link','license','license_qty','measure','whole_sell_qty','whole_sell_discount']);
        
        //   echo "<pre>"; print_r($prod); exit;
        if(!empty($prod->license_qty))
        {
        $lcheck = 1;
            foreach($prod->license_qty as $ttl => $dtl)
            {
                if($dtl < 1)
                {
                    $lcheck = 0;
                }
                else
                {
                    $lcheck = 1;
                    break;
                }                    
            }
                if($lcheck == 0)
                {
                    return 0;            
                }
        }
        $size = '';
        if(!empty($prod->size))
        { 
        $size = $prod->size[0];
        } 
        
         $length = '';
        if(!empty($prod->length))
        { 
        $length = $prod->length;
        }  

        $oldCart = Session::has('cart') ? Session::get('cart') : null;
        $cart = new Cart($oldCart);

        $cart->add($prod, $prod->id,$size,$length);
        if($cart->items[$id.$size]['dp'] == 1)
        {
            return redirect()->route('front.cart');
        }
        if($cart->items[$id.$size]['stock'] < 0)
        {
            return redirect()->route('front.cart');
        }
        if(!empty($cart->items[$id.$size]['size_qty']))
        {
            if($cart->items[$id.$size]['qty'] > $cart->items[$id.$size]['size_qty'])
            {
                return redirect()->route('front.cart');
            }           
        }

        $cart->totalPrice = 0;
        foreach($cart->items as $data)
        $cart->totalPrice += $data['price'];
        Session::put('cart',$cart);
         return redirect()->route('front.cart');
    }  

   public function addcart($id)
    {
        $prod = Product::where('id','=',$id)->first(['id','user_id','slug','name','photo','size','size_qty','size_price','color','price','stock','type','file','link','license','license_qty','measure','whole_sell_qty','whole_sell_discount']);
      
        
        if(!empty($prod->license_qty))
        {
        $lcheck = 1;
            foreach($prod->license_qty as $ttl => $dtl)
            {
                if($dtl < 1)
                {
                    $lcheck = 0;
                }
                else
                {
                    $lcheck = 1;
                    break;
                }                    
            }
                if($lcheck == 0)
                {
                    return 0;            
                }
        }
        $size = '';
        if(!empty($prod->size))
        { 
        $size = $prod->size[0];
        }  

        $oldCart = Session::has('cart') ? Session::get('cart') : null;
        $cart = new Cart($oldCart);

        $cart->add($prod, $prod->id,$size);
        if($cart->items[$id.$size]['dp'] == 1)
        {
            return 'digital';
        }
        if($cart->items[$id.$size]['stock'] < 0)
        {
            return 0;
        }
        if(!empty($cart->items[$id.$size]['size_qty']))
        {
	        if($cart->items[$id.$size]['qty'] > $cart->items[$id.$size]['size_qty'])
	        {
	            return 0;
	        }        	
        }


        $cart->totalPrice = 0;
        foreach($cart->items as $data)
        $cart->totalPrice += $data['price'];
        Session::put('cart',$cart);
        $data[0] = count($cart->items);        
        return response()->json($data);           
    }  

    public function addnumcart()
    {
        $id = $_GET['id'];
        $qty = $_GET['qty'];
        $price = $_GET['price'];
        $prod = Product::where('id','=',$id)->first(['id','user_id','slug','name','photo','size','size_qty','size_price','color','price','stock','type','file','link','license','license_qty','measure','whole_sell_qty','whole_sell_discount']);

        $oldCart = Session::has('cart') ? Session::get('cart') : null;
        $cart = new Cart($oldCart);
        $cart->addnum($prod, $prod->id, $qty, $price);
        
        if($cart->items[$id]['stock'] < 0)
        {
            return 0;
        }

        $cart->totalPrice = 0;
        foreach($cart->items as $data)
        $cart->totalPrice += $data['price'];        
        Session::put('cart',$cart);
        $data[0] = count($cart->items);   
        return response()->json($data);        
    }  

    public function addbyone()
    {
        if (Session::has('coupon')) {
            Session::forget('coupon');
        }
        $gs = Generalsetting::findOrFail(1);
        if (Session::has('currency')) 
        {
            $curr = Currency::find(Session::get('currency'));
        }
        else
        {
            $curr = Currency::where('is_default','=',1)->first();
        }
        $id = $_GET['id'];
        $itemid = $_GET['itemid'];
        $size_qty = $_GET['size_qty'];
        $size_price = $_GET['size_price'];
        $prod = Product::where('id','=',$id)->first(['id','user_id','slug','name','photo','size','size_qty','size_price','color','price','stock','type','file','link','license','license_qty','measure','whole_sell_qty','whole_sell_discount']);

        if(!empty($prod->license_qty))
        {
        $lcheck = 1;
            foreach($prod->license_qty as $ttl => $dtl)
            {
                if($dtl < 1)
                {
                    $lcheck = 0;
                }
                else
                {
                    $lcheck = 1;
                    break;
                }                    
            }
                if($lcheck == 0)
                {
                    return 0;            
                }
        }
        $oldCart = Session::has('cart') ? Session::get('cart') : null;
        $cart = new Cart($oldCart);
        $cart->adding($prod, $itemid,$size_qty,$size_price);
        if($cart->items[$itemid]['stock'] < 0)
        {
            return 0;
        }
        if(!empty($size_qty))
        {
            if($cart->items[$itemid]['qty'] > $cart->items[$itemid]['size_qty'])
            {
                return 0;
            }            
        }
        $cart->totalPrice = 0;
        foreach($cart->items as $data)
        $cart->totalPrice += $data['price'];        
        Session::put('cart',$cart);
        $data[0] = $cart->totalPrice;

        $data[3] = $data[0];
        $tx = $gs->tax;
        if($tx != 0)
        {
            $tax = ($data[0] / 100) * $tx;
            $data[3] = $data[0] + $tax;
        }  

        $data[1] = $cart->items[$itemid]['qty']; 
        $data[2] = $cart->items[$itemid]['price'];
        $data[0] = round($data[0] * $curr->value,2);
        $data[2] = round($data[2] * $curr->value,2);
        if($gs->currency_format == 0){
            $data[0] = $curr->sign.$data[0];
            $data[2] = $curr->sign.$data[2];
            $data[3] = $curr->sign.$data[3];
        }
        else{
            $data[0] = $data[0].$curr->sign;
            $data[2] = $data[2].$curr->sign;
            $data[3] = $data[3].$curr->sign;
        }     
        return response()->json($data);          
    }  

    public function reducebyone()
    {
        if (Session::has('coupon')) {
            Session::forget('coupon');
        }
        $gs = Generalsetting::findOrFail(1);
        if (Session::has('currency')) 
        {
            $curr = Currency::find(Session::get('currency'));
        }
        else
        {
            $curr = Currency::where('is_default','=',1)->first();
        }
        $id = $_GET['id'];
        $itemid = $_GET['itemid'];
        $size_qty = $_GET['size_qty'];
        $size_price = $_GET['size_price'];
        $prod = Product::where('id','=',$id)->first(['id','user_id','slug','name','photo','size','size_qty','size_price','color','price','stock','type','file','link','license','license_qty','measure','whole_sell_qty','whole_sell_discount']);

        if(!empty($prod->license_qty))
        {
        $lcheck = 1;
            foreach($prod->license_qty as $ttl => $dtl)
            {
                if($dtl < 1)
                {
                    $lcheck = 0;
                }
                else
                {
                    $lcheck = 1;
                    break;
                }                    
            }
                if($lcheck == 0)
                {
                    return 0;            
                }
        }
        $oldCart = Session::has('cart') ? Session::get('cart') : null;
        $cart = new Cart($oldCart);
        $cart->reducing($prod, $itemid,$size_qty,$size_price);
        $cart->totalPrice = 0;
        foreach($cart->items as $data)
        $cart->totalPrice += $data['price'];    
        
        Session::put('cart',$cart);
        $data[0] = $cart->totalPrice;

        $data[3] = $data[0];
        $tx = $gs->tax;
        if($tx != 0)
        {
            $tax = ($data[0] / 100) * $tx;
            $data[3] = $data[0] + $tax;
        }  

        $data[1] = $cart->items[$itemid]['qty']; 
        $data[2] = $cart->items[$itemid]['price'];
        $data[0] = round($data[0] * $curr->value,2);
        $data[2] = round($data[2] * $curr->value,2);
        if($gs->currency_format == 0){
            $data[0] = $curr->sign.$data[0];
            $data[2] = $curr->sign.$data[2];
            $data[3] = $curr->sign.$data[3];
        }
        else{
            $data[0] = $data[0].$curr->sign;
            $data[2] = $data[2].$curr->sign;
            $data[3] = $data[3].$curr->sign;
        }       
        return response()->json($data);        
    }  

    public function upcolor()
    {
         $id = $_GET['id'];
         $color = $_GET['color'];
        $prod = Product::where('id','=',$id)->first(['id','user_id','slug','name','photo','size','size_qty','size_price','color','price','stock','type','file','link','license','license_qty','measure','whole_sell_qty','whole_sell_discount']);
         $oldCart = Session::has('cart') ? Session::get('cart') : null;
         $cart = new Cart($oldCart);
         $cart->updateColor($prod,$id,$color);  
         Session::put('cart',$cart);
    } 


    public function removecart($id)
    {
        $gs = Generalsetting::findOrFail(1);
        if (Session::has('currency')) 
        {
            $curr = Currency::find(Session::get('currency'));
        }
        else
        {
            $curr = Currency::where('is_default','=',1)->first();
        }
        $oldCart = Session::has('cart') ? Session::get('cart') : null;
        $cart = new Cart($oldCart);

        $cart->removeItem($id);
        if (count($cart->items) > 0) {
            Session::put('cart', $cart);
                $data['sub_total'] = $cart->totalPrice;
                $data['total_price'] = $data['sub_total'];
                    $tx = $gs->tax;
                    if($tx != 0)
                    {
                        $tax = ($data['sub_total'] / 100) * $tx;
                        $data['total_price'] = $data['sub_total'] + $tax;
                    } 

                if($gs->currency_format == 0){
                    $data['sub_total'] = number_format($data['sub_total'] * $curr->value,2);
                    $data['total_price'] = number_format($data['total_price'] * $curr->value,2);
                }
                else{
                    $data['sub_total'] = number_format($data['sub_total'] * $curr->value,2);
                    $data['total_price'] = number_format($data['total_price'] * $curr->value,2);
                }
            
            $data[1] = count($cart->items);
            //return response()->json($data);  
            return response()->json(['status' => 1,'data'=>$data]);
        } else {
            Session::forget('cart');
            Session::forget('already');
            Session::forget('coupon');
            Session::forget('coupon_total');
            Session::forget('coupon_total1');
            Session::forget('coupon_percentage');

            $data = 0;
            return response()->json(['status' => 0,'data'=>$data]); 
        }          
    } 

    public function coupon()
    {
        $gs = Generalsetting::findOrFail(1);
        $code = $_GET['code'];
        $total = (float)preg_replace('/[^0-9\.]/ui','',$_GET['total']);;
        $fnd = Coupon::where('code','=',$code)->get()->count();
        if($fnd < 1)
        {
        return response()->json(0);              
        }
        else{
        $coupon = Coupon::where('code','=',$code)->first();
            if (Session::has('currency')) 
            {
              $curr = Currency::find(Session::get('currency'));
            }
            else
            {
                $curr = Currency::where('is_default','=',1)->first();
            }
        if($coupon->times != null)
        {
            if($coupon->times == "0")
            {
                return response()->json(0);                
            }
        }
        $today = date('Y-m-d');
        $from = date('Y-m-d',strtotime($coupon->start_date));
        $to = date('Y-m-d',strtotime($coupon->end_date));
        if($from <= $today && $to >= $today)
        {
            if($coupon->status == 1)
            {
                $oldCart = Session::has('cart') ? Session::get('cart') : null;
                $val = Session::has('already') ? Session::get('already') : null;
                if($val == $code)
                {
                    return response()->json(2); 
                }
                $cart = new Cart($oldCart);
                if($coupon->type == 0)
                {
                    Session::put('already', $code);
                    $coupon->price = (int)$coupon->price;
                    $val = $total / 100;
                    $sub = $val * $coupon->price;
                    $total = $total - $sub;
                    $data[0] = round($total,2);
                    if($gs->currency_format == 0){
                        $data[0] = $curr->sign.$data[0];
                    }
                    else{
                        $data[0] = $data[0].$curr->sign;
                    }
                    $data[1] = $code;      
                    $data[2] = round($sub, 2);
                    Session::put('coupon', $data[2]);
                    Session::put('coupon_code', $code);
                    Session::put('coupon_id', $coupon->id);
                    Session::put('coupon_total', $data[0]);
                    $data[3] = $coupon->id;
                    $data[4] = $coupon->price."%";
                    $data[5] = 1;

                    Session::put('coupon_percentage', $data[4]);

                    return response()->json($data);   
                }
                else{
                    Session::put('already', $code);
                    $total = $total - round($coupon->price * $curr->value, 2);
                    $data[0] = round($total,2);
                    $data[1] = $code;
                    $data[2] = round($coupon->price * $curr->value, 2);
                    Session::put('coupon', $data[2]);
                    Session::put('coupon_code', $code);
                    Session::put('coupon_id', $coupon->id);
                    Session::put('coupon_total', $data[0]);
                    $data[3] = $coupon->id;
                if($gs->currency_format == 0){
                    $data[4] = $curr->sign.$data[2];
                    $data[0] = $curr->sign.$data[0];
                }
                else{
                    $data[4] = $data[2].$curr->sign;
                    $data[0] = $data[0].$curr->sign;
                }
                    

                    Session::put('coupon_percentage', 0);

                    $data[5] = 1;
                    return response()->json($data);              
                }
            }
            else{
                    return response()->json(0);   
            }              
        }
        else{
        return response()->json(0);             
        }
        }         
    } 

    public function couponcheck(Request $request)
    {
        $gs = Generalsetting::findOrFail(1);
        $params= $request->post();
        $code = $params['code'];
        $total = $params['total'];
        $fnd = Coupon::where('code','=',$code)->get()->count();
        if($fnd < 1)
        {
            return response()->json(0);              
        }
        else{
            $coupon = Coupon::where('code','=',$code)->first();
            if (Session::has('currency')) 
            {
              $curr = Currency::find(Session::get('currency'));
            }
            else
            {
                $curr = Currency::where('is_default','=',1)->first();
            }
            if($coupon->times != null)
            {
                if($coupon->times == "0")
                {
                    return response()->json(0);                
                }
            }
            $today = date('Y-m-d');
            $from = date('Y-m-d',strtotime($coupon->start_date));
            $to = date('Y-m-d',strtotime($coupon->end_date));
            if($from <= $today && $to >= $today)
            {
                if($coupon->status == 1)
                {
                    $oldCart = Session::has('cart') ? Session::get('cart') : null;
                    $val = Session::has('already') ? Session::get('already') : null;
                    if($val == $code)
                    {
                        return response()->json(2); 
                    }
                    $cart = new Cart($oldCart);
                    if($coupon->type == 0)
                    {
                        Session::put('already', $code);
                        $coupon->price = (int)$coupon->price;

                        $oldCart = Session::get('cart');
                        $cart = new Cart($oldCart);

                        $total = $total - $params['shipping_cost'];
                        $total = $total - $params['tax'];

                        $val = $total / 100;
                        $sub = $val * $coupon->price;
                        $total = $total - $sub;
                        $total = $total + $params['shipping_cost'];
                        $total = $total + $params['tax'];
                        $data[0] = round($total,2);
                        $data[1] = $code;      
                        $data[2] = round($sub, 2);
                        if($gs->currency_format == 0){
                            $data[0] = $curr->sign.$data[0];
                        }
                        else{
                            $data[0] = $data[0].$curr->sign;
                        }
                        Session::put('coupon', $data[2]);
                        Session::put('coupon_code', $code);
                        Session::put('coupon_id', $coupon->id);
                        Session::put('coupon_total1', $data[0]);
                        Session::forget('coupon_total');
                        Session::save();
                        $data[0] = round($total,2);
                        $data[1] = $code;      
                        $data[2] = round($sub, 2);
                        $data[3] = $coupon->id;
                        $data[4] = $coupon->price."%";
                        $data[5] = 1;

                        Session::put('coupon_percentage', $data[4]);
                        Session::save();

                        return response()->json($data);   
                    }
                    else{
                        Session::put('already', $code);
                        $total = $total - round($coupon->price * $curr->value, 2);
                        $data[0] = round($total,2);
                        $data[1] = $code;
                        $data[2] = round($coupon->price * $curr->value, 2);
                        $data[3] = $coupon->id;
                        if($gs->currency_format == 0){
                            $data[4] = 0;
                            $data[0] = $curr->sign.$data[0];
                        }
                        else{
                            $data[4] = 0;
                            $data[0] = $data[0].$curr->sign;
                        }
                        Session::put('coupon', $data[2]);
                        Session::put('coupon_code', $code);
                        Session::put('coupon_id', $coupon->id);
                        Session::put('coupon_total1', $data[0]);
                        Session::forget('coupon_total');
                        $data[0] = round($total,2);
                        $data[1] = $code;
                        $data[2] = round($coupon->price * $curr->value, 2);
                        $data[3] = $coupon->id;                  
                        $data[5] = 1;

                        Session::put('coupon_percentage', $data[4]);
                        Session::save();
                        return response()->json($data);              
                    }
                }
                else{
                        return response()->json(0);   
                }              
            }
            else{
                return response()->json(0);             
            }
        }         
    } 


    // Capcha Code Image
    private function  code_image()
    {
        $actual_path = str_replace('project','',base_path());
        $image = imagecreatetruecolor(200, 50);
        $background_color = imagecolorallocate($image, 255, 255, 255);
        imagefilledrectangle($image,0,0,200,50,$background_color);

        $pixel = imagecolorallocate($image, 0,0,255);
        for($i=0;$i<500;$i++)
        {
            imagesetpixel($image,rand()%200,rand()%50,$pixel);
        }

        $font = $actual_path.'assets/front/fonts/NotoSans-Bold.ttf';
        $allowed_letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        $length = strlen($allowed_letters);
        $letter = $allowed_letters[rand(0, $length-1)];
        $word='';
        //$text_color = imagecolorallocate($image, 8, 186, 239);
        $text_color = imagecolorallocate($image, 0, 0, 0);
        $cap_length=6;// No. of character in image
        for ($i = 0; $i< $cap_length;$i++)
        {
            $letter = $allowed_letters[rand(0, $length-1)];
            imagettftext($image, 25, 1, 35+($i*25), 35, $text_color, $font, $letter);
            $word.=$letter;
        }
        $pixels = imagecolorallocate($image, 8, 186, 239);
        for($i=0;$i<500;$i++)
        {
            imagesetpixel($image,rand()%200,rand()%50,$pixels);
        }
        session(['captcha_string' => $word]);
        imagepng($image, $actual_path."assets/images/capcha_code.png");
    }
    public function refreshcart(Request $request)
    {
        $total_item= 0;
        if(!empty(Session::get('cart')))
        {
            if (Session::has('currency')) 
            {
                $curr = Currency::find(Session::get('currency'));
            }
            else
            {
                $curr = Currency::where('is_default','=',1)->first();
            }
            $total_item = count(Session::get('cart')->items);
            $cart_items = Session::get('cart')->items;
            $view=view('front.refreshcart',compact('curr'));
            $view=$view->render();
            $response['status'] = 1;
            $response['total_item'] = $total_item;
            $response['data'] = $view;
        }
        else
        {
            $total_item = 0;
            $view=view('front.refreshcart',compact('curr'));
            $view=$view->render();
            $response['status']= false;
            $response['total_item'] = $total_item;
            $response['data'] = $view;
        }
        echo json_encode($response);exit;
    }
}
