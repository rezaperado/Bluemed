<?php

namespace App\Http\Controllers\Front;

use App\Classes\GeniusMailer;
use App\Http\Controllers\Controller;
use Redirect;
use App\Models\Cart;
use App\Models\Coupon;
use App\Models\Currency;
use App\Models\Generalsetting;
use App\Models\Notification;
use App\Models\Order;
use App\Models\OrderTrack;
use App\Models\PaymentGateway;
use App\Models\Pickup;
use Mail;
use App\Models\User;
use App\Models\EmailTemplate;
use App\Models\Product;
use Auth;
use DB;
use SoapClient;
use Illuminate\Http\Request;
use Session;
use SimpleXMLElement;
use App\Models\DeliveryTime;

class CheckoutController extends Controller
{
    
    
    function test_email()
    {
          $mailer = new GeniusMailer();
                    $this->sendAutoOrderMail($data,$order->id,$order->order_number); 
    }
    
    function online_failed()
    {
        return redirect('/checkout');
    }
    public function loadpayment($slug1,$slug2)
    {
        
        // echo $slug1; exit;
        if (Session::has('currency')) {
            $curr = Currency::find(Session::get('currency'));
        }
        else {
            $curr = Currency::where('is_default','=',1)->first();
        }
        $payment = $slug1;
        $pay_id = $slug2;
        $gateway = '';
        if($pay_id != 0) {
            $gateway = PaymentGateway::findOrFail($pay_id);
        }
        return view('load.payment',compact('payment','pay_id','gateway','curr'));
    }
    
    
    
        public function placeorder(Request $request)
    {
    	$params = $request->all();
    	Session::put('request_data',$params);
        Session::save();
        
        $request_data = Session::get('request_data');
        $gs = Generalsetting::findOrFail(1);
		$ord_inc_id = $gs->order_increment_id;
		if(empty($ord_inc_id))
		{
		    $ord_inc_id = '100001';
		}
		else
		{
		    $ord_inc_id = (int)$ord_inc_id+1;
		}
		$ordernumber = 'ORD'.(string)$ord_inc_id;
		$total_price=0;$index = 0;
		$oldCart = Session::get('cart');
		$cart = new Cart($oldCart);
		foreach($cart->items as $key => $value){
		    $total_price += number_format($value['unit_price']*$value['qty'],3);
		    $prdItemArr[$index]['ItemName'] = $value['item']['name'];
		    $prdItemArr[$index]['Quantity'] = $value['qty'];
		    $prdItemArr[$index]['UnitPrice'] = number_format($value['unit_price'],3);
		    $index++;
		}
		$prdItemArr = json_encode($prdItemArr);
		
		
		
		  $shipping_cost = isset($request_data['shipping_cost']) ? $request_data['shipping_cost'] : 0;
                $tax = isset($request_data['tax']) ? $request_data['tax']: 0;
                $coupon_code = isset($request_data['code']) ? $request_data['coupon_code'] : '';
                $coupon_discount = isset($request_data['coupon_discount']) ? $request_data['coupon_discount'] : '';
               
                if (Session::has('currency')) 
            {
              $curr = Currency::find(Session::get('currency'));
            }
            else
            {
                $curr = Currency::where('is_default','=',1)->first();
            }
            
                $coupon = Session::has('coupon') ? Session::get('coupon') : 0;
                $oldCart = Session::get('cart');
                $cart = new Cart($oldCart);
                $total = $total_price;
                if($gs->tax != 0)
                {
                    $tax = ($total / 100) * $gs->tax;
                    $total = $total + $tax;
                }
                if(!empty($shipping_cost))
                {
                    $total = $total + $shipping_cost;
                }
                if(!Session::has('coupon_total1'))
                {
                    $total = $total - $coupon;     
                    $total = $total + 0;               
                }
                else {
                    
                    $total = Session::get('coupon_total1'); 
                    $total = str_replace('KD', '', $total);
                    $total = (float)$total + round(0 * (float)$curr->value, 2); 
                }
                $ord_inc_id = $gs->order_increment_id;
                if(empty($ord_inc_id))
                {
                    $ord_inc_id = '100001';
                }
                else
                {
                    $ord_inc_id = (int)$ord_inc_id+1;
                }
                
                if($coupon_discount=='')
                $coupon_discount=0;
            
             $tdata =round($total_price / $curr->value, 2) + $shipping_cost + $tax - $coupon_discount;
                
                
		if(isset($request->payment_method) && $request->payment_method == 'KNET')
		{
		    
	
                        
		   $fields = array(
'merchant_id'=>'1201',
 'username' => 'test',
'password'=>stripslashes('test'), 'api_key'=>'jtest123', // in sandbox request
 //'api_key' =>password_hash('API_KEY',PASSWORD_BCRYPT), //In production mode, please pass API_KEY with

'order_id'=>time(), // MIN 30 characters with strong unique function (like hashing function with time)
'total_price'=>$tdata,
'CurrencyCode'=>'KWD',//only works in production mode
'CstFName'=>$request_data['billing_first_name'] .' '.$request_data['billing_last_name'],
'CstEmail'=>$request_data['billing_email'],
'CstMobile'=>$request_data['billing_phone'],
'success_url'=>'http://bluemed.me/test/checkout/payment/success', 
'error_url'=>'http://bluemed.me/test/checkout/payment/failed',
'test_mode'=>1, // test mode enabled
'whitelabled'=>true, // only accept in live credentials (it will not work in test)
'payment_gateway'=>'knet',// only works in production mode
'ProductName'=>'',
'ProductQty'=>'',
'ProductPrice'=>'',
'reference'=>'Ref00001'
);
$fields_string = http_build_query($fields);
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL,"https://api.upayments.com/test-payment");
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS,$fields_string);
// receive server response ...
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$server_output = curl_exec($ch);
curl_close($ch);
  $server_output = json_decode($server_output,true);
 
 if($server_output['status']=='success')
return  redirect($server_output['paymentURL']);
else
return redirect()->back();

		}
    }
    
    
    public function placeorder_old(Request $request)
    {
    	$params = $request->all();
    	Session::put('request_data',$params);
        Session::save();
        $gs = Generalsetting::findOrFail(1);
		$ord_inc_id = $gs->order_increment_id;
		if(empty($ord_inc_id))
		{
		    $ord_inc_id = '100001';
		}
		else
		{
		    $ord_inc_id = (int)$ord_inc_id+1;
		}
		$ordernumber = 'ORD'.(string)$ord_inc_id;
		$total_price=0;$index = 0;
		$oldCart = Session::get('cart');
		$cart = new Cart($oldCart);
		foreach($cart->items as $key => $value){
		    $total_price += number_format($value['unit_price']*$value['qty'],3);
		    $prdItemArr[$index]['ItemName'] = $value['item']['name'];
		    $prdItemArr[$index]['Quantity'] = $value['qty'];
		    $prdItemArr[$index]['UnitPrice'] = number_format($value['unit_price'],3);
		    $index++;
		}
		$prdItemArr = json_encode($prdItemArr);
		if(isset($request->payment_method) && $request->payment_method == 'KNET')
		{
		    $t= time();
		    //$token ="7Fs7eBv21F5xAocdPvvJ-sCqEyNHq4cygJrQUFvFiWEexBUPs4AkeLQxH4pzsUrY3Rays7GVA6SojFCz2DMLXSJVqk8NG-plK-cZJetwWjgwLPub_9tQQohWLgJ0q2invJ5C5Imt2ket_-JAlBYLLcnqp_WmOfZkBEWuURsBVirpNQecvpedgeCx4VaFae4qWDI_uKRV1829KCBEH84u6LYUxh8W_BYqkzXJYt99OlHTXHegd91PLT-tawBwuIly46nwbAs5Nt7HFOozxkyPp8BW9URlQW1fE4R_40BXzEuVkzK3WAOdpR92IkV94K_rDZCPltGSvWXtqJbnCpUB6iUIn1V-Ki15FAwh_nsfSmt_NQZ3rQuvyQ9B3yLCQ1ZO_MGSYDYVO26dyXbElspKxQwuNRot9hi3FIbXylV3iN40-nCPH4YQzKjo5p_fuaKhvRh7H8oFjRXtPtLQQUIDxk-jMbOp7gXIsdz02DrCfQIihT4evZuWA6YShl6g8fnAqCy8qRBf_eLDnA9w-nBh4Bq53b1kdhnExz0CMyUjQ43UO3uhMkBomJTXbmfAAHP8dZZao6W8a34OktNQmPTbOHXrtxf6DS-oKOu3l79uX_ihbL8ELT40VjIW3MJeZ_-auCPOjpE3Ax4dzUkSDLCljitmzMagH2X8jN8-AYLl46KcfkBV"; #token value to be placed here;
		    $token = $gs->myfatoorah_api_key;
		    $basURL = "https://apitest.myfatoorah.com";
		    $CallBackUrl = URL('/checkout/payment/return');
		    $errorUrl = URL('/checkout/payment/error');
		    $language = '';
		    if(app()->getLocale() == 'ar')
		    {
		        $language = 'ar';
		    }
		    else
		    {
		        $language = 'en';
		    }
		    $post_string = '{
		        "NotificationOption": "ALL",
		        "CustomerName": "'.$request->billing_first_name.' '.$request->billing_last_name.'",
		        "DisplayCurrencyIso" : "KWD",
		        "MobileCountryCode" : "+965",
		        "CustomerMobile" : "'.$request->billing_phone.'",
		        "CustomerEmail" : "'.$request->billing_email.'",
		        "InvoiceValue" : "'.round($total_price,3).'",
		        "CallBackUrl" : "'.$CallBackUrl.'",
		        "ErrorUrl" : "'.$errorUrl.'",
		        "Language": "'.$language.'",
		        "CustomerReference" : "'.$t.'",
		        "CustomerCivilId" : "12345678",
		        "ExpireDate": "",
		        "CustomerAddress" :{
		              "Block":"'.$request->billing_block.'",
		              "Street":"'.$request->billing_street.'",
		              "HouseBuildingNo":"",
		              "Address":"",
		              "AddressInstructions":""
		          },                 
		        "InvoiceItems" : '.$prdItemArr.'
		      }';
		     //echo $post_string;exit;
		      //Session::put('online_payment_order',$order);
		      Session::put('online_payment',$cart);
		      Session::save();
		      //echo $post_string;exit;
		      $curl = curl_init();
		      curl_setopt_array($curl, array(
		      CURLOPT_URL => "$basURL/v2/SendPayment",
		      CURLOPT_CUSTOMREQUEST => "POST",
		      CURLOPT_POSTFIELDS => $post_string,
		          CURLOPT_HTTPHEADER => array("Authorization: Bearer $token","Content-Type: application/json"),
		      ));
		      curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		      $response = curl_exec($curl);
		      $info = curl_getinfo($curl);
		      //print_r($info);exit;
		      $err = curl_error($curl);
		      curl_close($curl);
		      if ($err) {
		          echo "cURL Error #:" . $err;exit;
		      } else {
		          $response = json_decode($response);
		          //print_r($response);exit;
		          //echo $response->Data->InvoiceURL;exit;
		          $RedirectUrl= isset($response->Data->InvoiceURL) ? $response->Data->InvoiceURL : '';
		         
		          echo json_encode(array('status'=>true,'payment_method'=>'myfatoorah','order_id'=>'','redirect_url'=>$RedirectUrl));exit;
		      }
		}
    }
    public function sendAutoOrderMail(array $mailData,$id,$order_number)
    {
        $setup = Generalsetting::find(1);
        $orderdata = Order::select('*')->where('id',$id)->get()->first();
        $order_number = $orderdata->order_number;
        $datas = array();
        if(!empty($orderdata))
        {
            $order =  Order::select('*')->leftjoin('ordered_product_details','ordered_product_details.order_number','=','orders.order_number')
            ->select('ordered_product_details.product_id','ordered_product_details.product_name','orders.totalQty','orders.pay_amount')
            ->where('orders.id','=',DB::raw("$id"))->where('user_id', DB::raw("$orderdata->user_id"))->get();
            /*$order_status_info = array(
                                    'order_placed' => false,
                                    'on_review' => false,
                                    'on_delivery' => false,
                                    'delivered' => false
                                );

            if($order->status == "pending") 
                $order_status_info['order_placed'] = true;

            if($order->status == "processing")
                $order_status_info['on_review'] = true;

            if($order->status == "on delivery") 
                $order_status_info['on_delivery'] = true;

            if($order->status == "completed")
                $order_status_info['delivered'] = true;*/

            $payment_info = array(
                                'order_id' => isset($orderdata->order_number) ? $orderdata->order_number : '',
                                'total_products' => isset($orderdata->totalQty) ? $orderdata->totalQty : '',
                                'total_cost' => isset($orderdata->pay_amount) ? 'KD'.$orderdata->pay_amount : '',
                                'ordered_date' => isset($orderdata->created_at) ? date('Y-m-d H:i:s', strtotime($orderdata->created_at)) : '',
                                'payment_method' => isset($orderdata->method) ? $orderdata->method : '',
                                'transaction_id' => isset($orderdata->txnid) ? $orderdata->txnid : '',
                                'payment_status' => ($orderdata->payment_status == 'Pending') ? 'Unpaid' : 'Paid'
                            );
            $userData = User::find($orderdata->user_id);
            $billing_info = array(
                                'name' => $userData->first_name.' '.$userData->last_name,
                                'email' => isset($userData->email) ? $userData->email : '',
                                'phone' => isset($userData->mobile) ? $userData->mobile : '',
                                'area' => isset($userData->area) ? $userData->area : '',
                                'block' => isset($userData->block) ? $userData->block : '',
                                'street' => isset($userData->street) ? $userData->street : '',
                                'country' => isset($userData->country) ? getcountry($userData->country) : '',
                                'city' => isset($userData->city) ? $userData->city : '',
                                'postal_code' => isset($userData->zip) ? $userData->zip : ''
                            );
            $billing_name = $userData->first_name.' '.$userData->last_name;
            $shipping_name = $userData->shipping_first_name.' '.$userData->shipping_last_name;
            $billing_email = isset($userData->email) ? $userData->email : '';
            $shipping_email = isset($userData->shipping_email) ? $userData->shipping_email : '';

            $shiping_info = array(
                                'name' => !empty($shipping_name) ? $shipping_name : $billing_name,
                                'email' => !empty($shipping_email) ? $shipping_email : $billing_email,
                                'phone' => !empty($userData->shipping_phone) ? $userData->shipping_phone : $userData->phone,
                                'area' => !empty($userData->shipping_area) ? $userData->shipping_area : $userData->area,
                                'block' => !empty($userData->shipping_block) ? $userData->shipping_block : $userData->block,
                                'street' => !empty($userData->shipping_street) ? $userData->shipping_street : $userData->street,
                                'country' => !empty($userData->shipping_country) ? getcountry($userData->shipping_country) : getcountry($userData->country),
                                'city' => !empty($userData->shipping_city) ? $userData->shipping_city : $userData->city,
                                'postal_code' => !empty($userData->shipping_zip) ? $userData->shipping_zip : $userData->zip
                            );

            $order_products = array();

            foreach($order as $key => $product)
            {
                $order_products[$key]['product_id'] = isset($product->product_id) ? $product->product_id : '';
                $order_products[$key]['product_name'] = isset($product->product_name) ? $product->product_name : '';
                $order_products[$key]['product_name'] = isset($product->product_name) ? $product->product_name : '';
                //$order_products[$key]['product_brand'] = isset($product->product_brand) ? $product->product_brand : '';
                //$order_products[$key]['product_category'] = isset($product->product_category) ? $product->product_category : '';
                $order_products[$key]['product_type'] = isset($product->product_type) ? $product->product_type : '';
                $order_products[$key]['total_qty'] = isset($product->totalQty) ? $product->totalQty : '';
                $order_products[$key]['pay_amount'] = isset($product->pay_amount) ? $product->pay_amount : '';
            }

            $datas =  array('payment_data' => $payment_info, 'billing_address' => $billing_info, 'shipping_address' => $shiping_info, 'products_data' => $order_products);
        }
        $billing_info_html = '<p style="margin:2px 0px;">'.$datas['billing_address']['name'].'</p>';
        $billing_info_html.= '<p style="margin:2px 0px;">'.$datas['billing_address']['area'].', '.$datas['billing_address']['area'].', '.$datas['billing_address']['street'].'</p>';
        $billing_info_html.= '<p style="margin:2px 0px;">'.$datas['billing_address']['city'].', '.$datas['billing_address']['postal_code'].'</p>';
        $billing_info_html.= '<p style="margin:2px 0px;">'.$datas['billing_address']['country'].'</p>';

        $shipping_info_html = '<p style="margin:2px 0px;">'.$datas['shipping_address']['name'].'</p>';
        $shipping_info_html.= '<p style="margin:2px 0px;">'.$datas['shipping_address']['area'].', '.$datas['shipping_address']['area'].', '.$datas['shipping_address']['street'].'</p>';
        $shipping_info_html.= '<p style="margin:2px 0px;">'.$datas['shipping_address']['city'].', '.$datas['shipping_address']['postal_code'].'</p>';
        $shipping_info_html.= '<p style="margin:2px 0px;">'.$datas['shipping_address']['country'].'</p>';
        $payment_method =$datas['payment_data']['payment_method'];
        $order_items_html = '';
        $order_items_html.= '<table border="0" cellpadding="0" cellspacing="0" width="100%">';
        $order_items_html.= '<tr style="height: 21px;">
                            <td align="left" bgcolor="#D2C7BA" width="50%" style="padding: 12px; font-size: 16px; line-height: 24px;">&nbsp;Item</td>
                            <td align="left" bgcolor="#D2C7BA" width="25%" style="padding: 12px; font-size: 16px; line-height: 24px;">Qty</td>
                            <td align="left" bgcolor="#D2C7BA" width="25%" style="padding: 12px;  font-size: 16px; line-height: 24px;">Price</td>
                            </tr>';
        foreach ($datas['products_data'] as $key => $value) {
            $order_items_html.= '<tr style="height: 21px;">';
            $order_items_html.= '<td align="left" width="50%" style="padding: 6px 12px;font-size: 16px; line-height: 24px;">'.$value['product_name'].'</td>';
            $order_items_html.= '<td align="left" width="25%" style="padding: 6px 12px;font-size: 16px; line-height: 24px;">'.$value['total_qty'].'</td>';
            $order_items_html.= '<td align="left" width="25%" style="padding: 6px 12px; font-size: 16px; line-height: 24px;">'.$value['pay_amount'].'</td>';
            $order_items_html.= '</tr>';
        }
        $order_items_html.= '<tr style="height: 21px;">';
        $order_items_html.= '<td align="left" width="25%" style="padding: 6px 12px; font-size: 16px; line-height: 24px;" colspan="2" >Total</td>';
        $order_items_html.= '<td align="left" width="25%" style="padding: 6px 12px; font-size: 16px; line-height: 24px;">'.$datas['payment_data']['total_cost'].'</td>';
        $order_items_html.= '</tr>';
        $order_items_html.='</table>';

        $temp = EmailTemplate::where('email_type','=',$mailData['type'])->first();

        $body = preg_replace("/{customer_name}/", $mailData['cname'] ,$temp->email_body);
        // $body = preg_replace("@logo@", $setup->logo ,$body);
        $body = preg_replace("/{order_amount}/", $mailData['oamount'] ,$body);
        $body = preg_replace("/{admin_name}/", $mailData['aname'] ,$body);
        $body = preg_replace("/{admin_email}/", $mailData['aemail'] ,$body);
        $body = preg_replace("/{order_number}/", $order_number ,$body);
        $body = preg_replace("/{website_title}/", $setup->title ,$body);
        $subject = preg_replace("/{order_number}/", $order_number ,$temp->email_subject);
        $body = str_replace("{order_date}", date('M d, Y H:i:s', strtotime($orderdata->created_at)) ,$body);
        $body = str_replace("{billing_info}", $billing_info_html,$body);
        $body = str_replace("{shipping_info}", $shipping_info_html ,$body);
        $body = str_replace("{payment_method}", $payment_method ,$body);
        $body = str_replace("{order_items}", $order_items_html ,$body);
        $data = [
            'email_body' => $body
        ];


        $objDemo = new \stdClass();
        $objDemo->to = $mailData['to'];
        $objDemo->from = $setup->from_email;
        $objDemo->title = $setup->from_name;
        $objDemo->subject = $subject;

        try{
            Mail::send('admin.email.mailbody',$data, function ($message) use ($objDemo,$id) {
                $message->from($objDemo->from,$objDemo->title);
                $message->to($objDemo->to);
                $message->subject($objDemo->subject);
        $order = Order::findOrFail($id);
        $cart = unserialize(bzdecompress(utf8_decode($order->cart)));
        


            });

        }
        catch (\Exception $e){
            //die("Not Sent!");
        }

        $files = glob('assets/prints/*'); //get all file names
        foreach($files as $file){
            if(is_file($file))
            unlink($file); //delete file
        }
        

    }
    public function orderreceived($id)
    {
        $order = Order::where('id',$id)->get()->first();
        if (Session::has('currency')) 
        {
            $curr = Currency::find(Session::get('currency'));
        }
        else
        {
            $curr = Currency::where('is_default','=',1)->first();
        }
        $product_data = Product::select('products.*')->join('ordered_product_details','ordered_product_details.product_id','=','products.id')->where('ordered_product_details.order_number',$order->order_number)->get();
        $gs = Generalsetting::findOrFail(1);
        $user = Auth::user();
        return view('front.orderreceived',compact('order','curr','product_data','gs','user'));
    }
    public function getShippingRate(Request $request){
        $req_data = $request->all(); 
        
        if($req_data->country == 114){
            $currency = 0;
        }else{
        $getCountryCode = \DB::table("country")->where("id",$req_data->country)->first();
        
        $oldCart = Session::get('cart');
        $qty = 0; $weight = 0;
        foreach($oldCart->items as $k=>$v){
            $qty = $qty + $v['qty'];
        }
        
        foreach($oldCart->items as $k=>$v){
             foreach($v->item as $w){
                $weight = $weight + $w['weight'];
             }
        }
        $data = [
            'rcv_name' => $req_data['name'],
            'rcv_address' => $req_data['rec_address'],
            'rcv_phone' => $req_data['rec_phone'],
            'rcv_zip' => $req_data['zip'],
            'rcv_countrycode' => $getCountryCode->iso,
            'rcv_city' => 'KL',
            'product_items' => count($oldCart['items']),
            'product_qty' => $qty,
            'product_weight' => $weight
            
            ];
         $shippingCharges = $this->getFedExRequest($data);
         $currency = getCurrency($shippingCharges);
        }
         return $currency;
    }

    public function checkout()
    {
        $this->code_image();
        if (!Session::has('cart')) {
            return redirect()->route('front.cart')->with('success',"You don't have any product to checkout.");
        }
        $gs = Generalsetting::findOrFail(1);
        $deliveryTime = DeliveryTime::orderBy('id')->get();
        $dp = 1;
        $vendor_shipping_id = 0;
        $user = Auth::user();
        $vendor_packing_id = 0;
            if (Session::has('currency')) 
            {
              $curr = Currency::find(Session::get('currency'));
            }
            else
            {
                $curr = Currency::where('is_default','=',1)->first();
            }
            
            $country = DB::table('countries')->get();
            
// If a user is Authenticated then there is no problm user can go for checkout
        $tx = $gs->tax;
        if(Auth::guard('web')->check())
        {
                $gateways =  PaymentGateway::where('status','=',1)->get();

                $pickups = Pickup::all();
                $oldCart = Session::get('cart');
                $cart = new Cart($oldCart);
                $products = $cart->items;

                // Shipping Method
                $shipping_data  = DB::table('shippings')->where('user_id','=',0)->get();

                // Packaging
                $package_data  = DB::table('packages')->where('user_id','=',0)->get();

                foreach ($products as $prod) {
                    if($prod['item']['type'] == 'Physical')
                    {
                        $dp = 0;
                        break;
                    }
                }
                $total = $cart->totalPrice;
                $coupon = Session::has('coupon') ? Session::get('coupon') : 0;
                if($gs->tax != 0)
                {
                    $tax = ($total / 100) * $gs->tax;
                    $total = $total + $tax;
                }
                if(!Session::has('coupon_total'))
                {
                $total = $total - $coupon;     
                $total = $total + 0;               
                }
                else {
                $total = Session::get('coupon_total');  
                $total = $total + round(0 * $curr->value, 2); 
                }
        return view('front.checkout', ['country' => $country,'products' => $cart->items, 'totalPrice' => $total, 'pickups' => $pickups, 'totalQty' => $cart->totalQty, 'gateways' => $gateways, 'shipping_cost' => 0, 'digital' => $dp, 'curr' => $curr,'shipping_data' => $shipping_data,'package_data' => $package_data, 'vendor_shipping_id' => $vendor_shipping_id, 'vendor_packing_id' => $vendor_packing_id,'user'=>$user,'tx'=>$tx,'deliveryTime' => $deliveryTime]);             
        }

        else

        {
// If guest checkout is activated then user can go for checkout
           	if($gs->guest_checkout == 1)
              {
                $gateways =  PaymentGateway::where('status','=',1)->get();
                $pickups = Pickup::all();
                $oldCart = Session::get('cart');
                $cart = new Cart($oldCart);
                $products = $cart->items;

                // Shipping Method
                $shipping_data  = DB::table('shippings')->where('user_id','=',0)->get();

                // Packaging
                $package_data  = DB::table('packages')->where('user_id','=',0)->get();

                foreach ($products as $prod) {
                    if($prod['item']['type'] == 'Physical')
                    {
                        $dp = 0;
                        break;
                    }
                }
                $total = $cart->totalPrice;
                $coupon = Session::has('coupon') ? Session::get('coupon') : 0;
                if($gs->tax != 0)
                {
                    $tax = ($total / 100) * $gs->tax;
                    $total = $total + $tax;
                }
                if(!Session::has('coupon_total'))
                {
                $total = $total - $coupon;     
                $total = $total + 0;               
                }
                else {
                $total = Session::get('coupon_total');  
                $total =  str_replace($curr->sign,'',$total) + round(0 * $curr->value, 2); 
                }
                foreach ($products as $prod) {
                    if($prod['item']['type'] != 'Physical')
                    {
                        if(!Auth::guard('web')->check())
                        {
                $ck = 1;
        return view('front.checkout', ['country' => $country,'products' => $cart->items, 'totalPrice' => $total, 'pickups' => $pickups, 'totalQty' => $cart->totalQty, 'gateways' => $gateways, 'shipping_cost' => 0, 'checked' => $ck, 'digital' => $dp, 'curr' => $curr,'shipping_data' => $shipping_data,'package_data' => $package_data, 'vendor_shipping_id' => $vendor_shipping_id, 'vendor_packing_id' => $vendor_packing_id,'user'=>$user,'tx'=>$tx ,'deliveryTime'=>$deliveryTime]);  
                        }
                    }
                }
        return view('front.checkout', ['country' => $country,'products' => $cart->items, 'totalPrice' => $total, 'pickups' => $pickups, 'totalQty' => $cart->totalQty, 'gateways' => $gateways, 'shipping_cost' => 0, 'digital' => $dp, 'curr' => $curr,'shipping_data' => $shipping_data,'package_data' => $package_data, 'vendor_shipping_id' => $vendor_shipping_id, 'vendor_packing_id' => $vendor_packing_id,'user'=>$user,'tx'=>$tx, 'deliveryTime' => $deliveryTime]);                 
               }

// If guest checkout is Deactivated then display pop up form with proper error message

                    else{
                $gateways =  PaymentGateway::where('status','=',1)->get();
                $pickups = Pickup::all();
                $oldCart = Session::get('cart');
                $cart = new Cart($oldCart);
                $products = $cart->items;

                // Shipping Method
                $shipping_data  = DB::table('shippings')->where('user_id','=',0)->get();

                // Packaging
                $package_data  = DB::table('packages')->where('user_id','=',0)->get();



                $total = $cart->totalPrice;
                $coupon = Session::has('coupon') ? Session::get('coupon') : 0;
                if($gs->tax != 0)
                {
                    $tax = ($total / 100) * $gs->tax;
                    $total = $total + $tax;
                }
                if(!Session::has('coupon_total'))
                {
                $total = $total - $coupon;     
                $total = $total + 0;               
                }
                else {
                $total = Session::get('coupon_total');  
                $total = $total + round(0 * $curr->value, 2); 
                }
                $ck = 1;
        return view('front.checkout', ['country' => $country,'products' => $cart->items, 'totalPrice' => $total, 'pickups' => $pickups, 'totalQty' => $cart->totalQty, 'gateways' => $gateways, 'shipping_cost' => 0, 'checked' => $ck, 'digital' => $dp, 'curr' => $curr,'shipping_data' => $shipping_data,'package_data' => $package_data, 'vendor_shipping_id' => $vendor_shipping_id, 'vendor_packing_id' => $vendor_packing_id,'user'=>$user,'tx'=>$tx,'deliveryTime'=>$deliveryTime]);                 
                    }
        }

    }



   public function online_payment(Request $request){
       //return $_GET['PaymentID'];
              $request_data = Session::get('request_data');
              /*echo "<pre>";
              print_r($request_data);exit;*/
              if($request->createaccount) {
                    $users = User::where('email','=',$request_data['billing_email'])->get();
                    
                    if($users->count() < 1) {
                        $user = new User;
                        $user->first_name = $request_data['billing_first_name'];
                        $user->last_name = $request_data['billing_last_name'];
                        $user->area = $request_data['billing_area'];
                        $user->block = $request_data['billing_block'];
                        $user->street = $request_data['billing_street'];
                        $user->city = $request_data['billing_city'];
                        $user->zip = $request_data['billing_zip'];
                        $user->country = $request_data['country'];
                        $user->phone = $request_data['billing_phone'];
                        $user->email = $request_data['billing_email'];
                        $user->password = bcrypt($request_data['password']);
                        $token = md5(time().$request_data['personal_name'].$request_data['personal_email']);
                        $user->verification_link = $token;
                        $user->save();
                        Auth::guard('web')->login($user);
                        if($gs->is_verification_email == 1)
                        {
                             $to = $request_data['billing_email'];
                                $subject = 'Verify your email address.';
                                
                                $message = "Dear Customer,\nSimply click the link below or copy paste in your browser to verify your email address.".url('user/register/verify/'.$token);

                                $msg = "Dear Customer\nWe noticed that you need to verify your email address". url('user/register/verify/'.$token)."Simply click here to verify";
                                $data  = array('to' => $to , 'subject' => $subject , 'msg' => $msg); 
                               
                                $data = [
                                    'to' => $to,
                                    'subject' => $subject,
                                    'body' => $msg,
                                ];
                                
                                $to = $to;
                                $subject = $subject;
                                $txt = $message;

                                $headers = "From: ".$gs->from_name."<".$gs->from_email.">";
                                //echo $to."   ".$headers."   ".$subject."  ".$txt;exit;
                                try{
                                    mail($to,$subject,$txt,$headers);    
                                }
                                catch(Exception $e)
                                {
                                    
                                }
                        }
                    }
                    else
                    {
                        echo json_encode(array('status'=>false,'message'=>'Email is already exist.'));exit;
                    }
                }
                $user = User::find(Auth::id());
                $user->first_name = $request_data['billing_first_name'];
                $user->last_name = $request_data['billing_last_name'];
                $user->area = $request_data['billing_area'];
                $user->block = $request_data['billing_block'];
                $user->street = $request_data['billing_street'];
                $user->city = $request_data['billing_city'];
                $user->zip = $request_data['billing_zip'];
                $user->country = $request_data['billing_country'];
                $user->phone = $request_data['billing_phone'];
                $user->email = $request_data['billing_email'];
                $user->shipping_first_name = isset($request_data['shipping_first_name']) ? $request_data['shipping_first_name'] : '';
                $user->shipping_last_name = isset($request_data['shipping_last_name']) ? $request_data['shipping_last_name'] : '';
                $user->shipping_area = isset($request_data['shipping_area']) ? $request_data['shipping_area'] : '';
                $user->shipping_block = isset($request_data['shipping_block']) ? $request_data['shipping_block'] : '';
                $user->shipping_street = isset($request_data['shipping_street']) ? $request_data['shipping_street'] : '';
                $user->shipping_city = isset($request_data['shipping_city']) ? $request_data['shipping_city'] : '';
                $user->shipping_zip = isset($request_data['shipping_zip']) ? $request_data['shipping_zip'] : '';
                $user->shipping_country = isset($request_data['shipping_country']) ? $request_data['shipping_country'] : '';
                $user->shipping_phone = isset($request_data['shipping_phone']) ? $request_data['shipping_phone'] : '';
                $user->shipping_email = isset($request_data['shipping_email']) ? $request_data['shipping_email'] : '';
                $user->shipping_first_name = isset($request_data['shipping_first_name']) ? $request_data['shipping_first_name'] : '';
                $user->save();
                if (!Session::has('cart')) {
                    return redirect(URL('/carts'));
                }
                if (Session::has('currency')) 
                {
                  $curr = Currency::find(Session::get('currency'));
                }
                else
                {
                    $curr = Currency::where('is_default','=',1)->first();
                }
                $gs = Generalsetting::findOrFail(1);
                $oldCart = Session::get('cart');
                $cart = new Cart($oldCart);
                $pid = "";
                $totalQty = 0;$total_price=0;
                $prdItemArr = array();
                $index = 0;
                $attr_id = 0;
                $prd_for_api = array();
                foreach($cart->items as $key => $value){
                    
                   $pd=Product::find($value['item']['id']);
                    $st=$pd->stock-$value['qty'];
                  Product::where('id','=',$value['item']['id'])->update(['stock'=>$st]);
                   //return  Product::find($value['item']['id']);
                    $variations = $value['variations'];
                    $attr_id = $value['attr_id'];
                    $pid .= ','.$value['item']['id'];
                    $totalQty++;
                    $total_price += number_format($value['unit_price']*$value['qty'],3);
                    $prdItemArr[$index]['ItemName'] = $value['item']['name'];
                    $prdItemArr[$index]['Quantity'] = $value['qty'];
                    $prdItemArr[$index]['Variations'] = $value['variations'];
                    $prdItemArr[$index]['UnitPrice'] = number_format($value['unit_price'],3);
                    $prd_for_api[$index]['ProductCode'] = $value['item']['sku'];
                    $prd_for_api[$index]['Unit_Name'] = 'PCS';
                    $prd_for_api[$index]['Quantity'] = $value['qty'];
                    $prd_for_api[$index]['Rate'] = $value['unit_price'];
                    $prd_for_api[$index]['Gross'] = $value['unit_price'];
                    $index++;
                }
                $prdItemArr = json_encode($prdItemArr);
                
                if(isset($request_data['ship_to_different_address']))
                {
                    if($request_data['ship_to_different_address']==1)
                    {
                          $shipping='shipto'; 
                    }
                    
                    else
                    {
                          $shipping='shipto'; 
                          
                          
                          $request_data['shipping_first_name'] = isset($request_data['billing_first_name']) ? $request_data['billing_first_name'] : '';
               $request_data['shipping_last_name'] = isset($request_data['billing_last_name']) ? $request_data['billing_last_name'] : '';
               $request_data['shipping_area'] = isset($request_data['billing_area']) ? $request_data['billing_area'] : '';
               $request_data['shipping_block'] = isset($request_data['billing_block']) ? $request_data['billing_block'] : '';
               $request_data['shipping_street'] = isset($request_data['billing_street']) ? $request_data['billing_street'] : '';
               $request_data['shipping_city'] = isset($request_data['billing_city']) ? $request_data['billing_city'] : '';
               $request_data['shipping_zip'] = isset($request_data['billing_zip']) ? $request_data['billing_zip'] : '';
               $request_data['shipping_country'] = isset($request_data['billing_country']) ? $request_data['billing_country'] : '';
               $request_data['shipping_phone'] = isset($request_data['billing_phone']) ? $request_data['billing_phone'] : '';
               $request_data['shipping_email'] = isset($request_data['billing_email']) ? $request_data['billing_email'] : '';
               
               
                    }
                }
                else
                {
                   $shipping='shipto'; 
                   
                   $request_data['shipping_first_name'] = isset($request_data['billing_first_name']) ? $request_data['billing_first_name'] : '';
               $request_data['shipping_last_name'] = isset($request_data['billing_last_name']) ? $request_data['billing_last_name'] : '';
               $request_data['shipping_area'] = isset($request_data['billing_area']) ? $request_data['billing_area'] : '';
               $request_data['shipping_block'] = isset($request_data['billing_block']) ? $request_data['billing_block'] : '';
               $request_data['shipping_street'] = isset($request_data['billing_street']) ? $request_data['billing_street'] : '';
               $request_data['shipping_city'] = isset($request_data['billing_city']) ? $request_data['billing_city'] : '';
               $request_data['shipping_zip'] = isset($request_data['billing_zip']) ? $request_data['billing_zip'] : '';
               $request_data['shipping_country'] = isset($request_data['billing_country']) ? $request_data['billing_country'] : '';
               $request_data['shipping_phone'] = isset($request_data['billing_phone']) ? $request_data['billing_phone'] : '';
               $request_data['shipping_email'] = isset($request_data['billing_email']) ? $request_data['billing_email'] : '';
               
                }
               
                $shipping_cost = isset($request_data['shipping_cost']) ? $request_data['shipping_cost'] : 0;
                $tax = isset($request_data['tax']) ? $request_data['tax']: 0;
                $coupon_code = isset($request_data['code']) ? $request_data['coupon_code'] : '';
                $coupon_discount = isset($request_data['coupon_discount']) ? $request_data['coupon_discount'] : '';
                $str = ltrim($pid, ',');
                $coupon = Session::has('coupon') ? Session::get('coupon') : 0;
                $oldCart = Session::get('cart');
                $cart = new Cart($oldCart);
                $total = $total_price;
                if($gs->tax != 0)
                {
                    $tax = ($total / 100) * $gs->tax;
                    $total = $total + $tax;
                }
                if(!empty($shipping_cost))
                {
                    $total = $total + $shipping_cost;
                }
                if(!Session::has('coupon_total1'))
                {
                    $total = $total - $coupon;     
                    $total = $total + 0;               
                }
                else {
                    
                    $total = Session::get('coupon_total1'); 
                    $total = str_replace('KD', '', $total);
                    $total = (float)$total + round(0 * (float)$curr->value, 2); 
                }
                $ord_inc_id = $gs->order_increment_id;
                if(empty($ord_inc_id))
                {
                    $ord_inc_id = '100001';
                }
                else
                {
                    $ord_inc_id = (int)$ord_inc_id+1;
                }
                $ordernumber = 'ORD'.(string)$ord_inc_id;
                $order = new Order;
                $success_url = action('Front\PaymentController@payreturn');
                $item_name = $gs->title." Order";
                $item_number = str_random(4).time();
                $order['user_id'] = Auth::id();
                $order['cart'] = utf8_encode(bzcompress(serialize($cart), 9)); 
                $order['totalQty'] = $totalQty;
                $order['product_id'] = $str;
                $order['pay_amount'] = round($total_price / $curr->value, 2) + $shipping_cost + $tax - $coupon_discount;
                $order['method'] = 'KNET';
                $order['shipping'] = $shipping;
                $order['shipping_cost'] = $shipping_cost;
                $order['packing_cost'] = 0;
                $order['tax'] = $tax;
                
                if(isset($_GET['PaymentID']))
                 $order['txnid'] = $_GET['PaymentID'];
                $order['order_number'] = $ordernumber;
                $order['order_note'] = $request_data['order_comments'];
                $order['coupon_code'] = $coupon_code;
                $order['coupon_discount'] = $coupon_discount;
                $order['dp'] = isset($request_data['dp']) ? $request_data['dp'] : 0;
                $order['payment_status'] = "Completed";
                $order['currency_sign'] = $curr->sign;
                $order['currency_value'] = $curr->value;
                $order['delivery_time'] = '';
                
                
                $order['shipping_first_name'] = isset($request_data['shipping_first_name']) ? $request_data['shipping_first_name'] : '';
                $order['shipping_last_name'] = isset($request_data['shipping_last_name']) ? $request_data['shipping_last_name'] : '';
                $order['shipping_area'] = isset($request_data['shipping_area']) ? $request_data['shipping_area'] : '';
                $order['shipping_block'] = isset($request_data['shipping_block']) ? $request_data['shipping_block'] : '';
                $order['shipping_street'] = isset($request_data['shipping_street']) ? $request_data['shipping_street'] : '';
                $order['shipping_city'] = isset($request_data['shipping_city']) ? $request_data['shipping_city'] : '';
                $order['shipping_zip'] = isset($request_data['shipping_zip']) ? $request_data['shipping_zip'] : '';
                $order['shipping_country'] = isset($request_data['shipping_country']) ? $request_data['shipping_country'] : '';
                $order['shipping_phone'] = isset($request_data['shipping_phone']) ? $request_data['shipping_phone'] : '';
                $order['shipping_email'] = isset($request_data['shipping_email']) ? $request_data['shipping_email'] : '';
                
                
                $order->save();
                
                Generalsetting::where('id',1)->update(array('order_increment_id'=>$ord_inc_id));
                $orderupdate = \DB::table("orders")->where('id',$order->id)->update(['order_number'=>$ordernumber]);
                $cartValues = Session::get('cartValues');
                foreach($cart->items as $v){
                    $insertOrderedProductDetails = \DB::table("ordered_product_details")->insertGetID(['order_number'=>$ordernumber,'product_id'=>$v['item']['id']
                        ,'product_name'=>$v['item']['name']]);
                }
                $track = new OrderTrack;
                $track->title = 'Pending';
                $track->text = 'You have successfully placed your order.';
                $track->order_id = $order->id;
                $track->save();

                $notification = new Notification;
                $notification->order_id = $order->id;
                $notification->save();
                if(isset($request_data['coupon_id']) && $request_data['coupon_id'] != "")
                {
                   $coupon = Coupon::findOrFail($request_data['coupon_id']);
                   $coupon->used++;
                   if($coupon->times != null)
                   {
                        $i = (int)$coupon->times;
                        $i--;
                        $coupon->times = (string)$i;
                   }
                    $coupon->update();
                }
                foreach($cart->items as $prod)
                {
                    $x = (string)$prod['stock'];
                    if($x != null)
                    {
                        $product = Product::findOrFail($prod['item']['id']);
                        $product->stock =  $prod['stock'];
                        //$product->update();  
                        $attr_stock = DB::table('product_variations')->select('qty')->where('id', $prod['attr_id'])->first();
                        if(isset($attr_stock->qt))
                        {
                            $stock = $attr_stock->qty;
                            DB::table('product_variations')->where('id', $prod['attr_id'])->update(array('qty'=>($stock-1)));    
                        }
                        
                        if($product->stock <= 5)
                        {
                            $notification = new Notification;
                            $notification->product_id = $product->id;
                            $notification->save();                    
                        }              
                    }
                }
                if($gs->is_smtp == 1)
                {
                    $data = [
                        'to' => $request_data['billing_email'],
                        'type' => "new_order",
                        'cname' => $request_data['billing_first_name']." ".$request_data['billing_last_name'],
                        'oamount' => "KD ".$order->pay_amount,
                        'aname' => "",
                        'aemail' => "",
                        'wtitle' => "",
                        'onumber' => $ordernumber,
                    ];

                    $mailer = new GeniusMailer();
                    $this->sendAutoOrderMail($data,$order->id,$order->order_number);            
                }
                else
                {
                   $to = $request_data['billing_email'];
                   $subject = "Your Order Placed!!";
                   $msg = "Hello ".$request_data['billing_name']."!\nYou have placed a new order.\nYour order number is ".$ordernumber.".Please wait for your delivery. \nThank you.";
                    $headers = "From: ".$gs->from_name."<".$gs->from_email.">";
                   mail($to,$subject,$msg,$headers);            
                }
                //Sending Email To Admin
                if($gs->is_smtp == 1)
                {
                    $data = [
                        'to' => $gs->email,
                        'subject' => "New Order Recieved!!",
                        'body' => "Hello Admin!<br>Your store has received a new order.<br>Order Number is ".$ordernumber.".Please login to your panel to check. <br>Thank you.",
                    ];

                    $mailer = new GeniusMailer();
                   $mailer->sendCustomMail($data);            
                }
                else
                {
                   $to = $gs->email;
                   $subject = "New Order Recieved!!";
                   $msg = "Hello Admin!\nYour store has recieved a new order.\nOrder Number is ".$ordernumber.".Please login to your panel to check. \nThank you.";
                    $headers = "From: ".$gs->from_name."<".$gs->from_email.">";
                   mail($to,$subject,$msg,$headers);
                }
              //Session::forget('cart');
              //$order_data = Session::get('online_payment_order');
              $online_payment = Session::get('online_payment');

              
              $user = Auth::user();
              $transaction_id = '';
              //$order = Order::where('id',$order_data->id)->first();
              $prd_for_api = array();
              $index = 0;
             // foreach($online_payment->items as $key => $value){
               // $prd_for_api[$index]['ProductCode'] = $value['item']['sku'];
               // $prd_for_api[$index]['Unit_Name'] = 'PCS';
               // $prd_for_api[$index]['Quantity'] = $value['qty'];
               // $prd_for_api[$index]['Rate'] = $value['unit_price'];
               // $prd_for_api[$index]['Gross'] = $value['unit_price'];
               // $index++;
             // }
               //save order api start
                $url = "http://168.187.178.135/Marafie/api/Focus/PostInv";
                $curl = curl_init();
                curl_setopt($curl, CURLOPT_URL,$url);
                curl_setopt($curl, CURLOPT_POST, 1);
                curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query(array('SInvHeaderDetails' => array('OrderNo'=>$order->order_number,'OrderDate'=>date('Y-m-d'),'Narration'=>'Test Narration','PaymentMode'=>'Knet'),'SInvBodyDetails'=>$prd_for_api)));
                $result = curl_exec($curl);
                $info = curl_getinfo($curl);
                curl_close($curl);
                $json = json_decode($result, true);
                //print_r($json);exit;
              //save order api end
              //if(empty($order->txnid)){
                //echo "test ".$transaction_id;exit;
                /*$order_save = Order::find($order_data->id);
                $order_save->payment_status = 'Completed';
                $order_save->timestamps = false;
                $order_save->txnid = $transaction_id;
                $order_save->save();*/
                /*echo "<pre>";
                print_r($order);exit;
                DB::table('orders')->where('id', $order->id)->update(array('payment_status' => 'Completed', 'txnid' => $transaction_id));*/
              //}
                //sleep(30);
              if (Session::has('currency')) 
                {
                    $curr = Currency::find(Session::get('currency'));
                }
                else
                {
                    $curr = Currency::where('is_default','=',1)->first();
                }
              $order_product = DB::table('ordered_product_details')->where('order_number',$order->order_number)->get();
              $tempcart = Session::get('online_payment');
              $product_data = Product::select('products.*')->join('ordered_product_details','ordered_product_details.product_id','=','products.id')->where('ordered_product_details.order_number',$order->order_number)->get();
                Session::forget('cart');
                Session::forget('already');
                Session::forget('coupon');
                Session::forget('coupon_total');
                Session::forget('coupon_total1');
                Session::forget('coupon_percentage');
                Session::save();
                
                   $order = Order::where('id',$order->id)->first();
            
      
         $cart = unserialize(bzdecompress(utf8_decode($order->cart)));
       
             return view('front.success',compact('order','tempcart','order_product','product_data','curr','gs','user','cart'));
        
        if(Session::has('tempcart')){
            $oldCart = Session::get('tempcart');
            $tempcart = new Cart($oldCart);
            $order_data = Session::get('temporder');
            $order = Order::where('id',$order_data->id)->first();
            
      
         $cart = unserialize(bzdecompress(utf8_decode($order->cart)));
        
            $order_product = DB::table('ordered_product_details')->where('order_number',$order->order_number)->get();
            return view('front.success',compact('tempcart','order','order_product','cart'));
            
        }
        else{
            $tempcart = '';
            return redirect()->back();
        }
     }





   public function cashondelivery(Request $request){
        $this->code_image();
     $params = $request->all();
        Session::put('request_data',$params);
        Session::save();
              $request_data = Session::get('request_data');
              /*echo "<pre>";
              print_r($request_data);exit;*/
              if($request->createaccount) {
                    $users = User::where('email','=',$request_data['billing_email'])->get();
                    
                    if($users->count() < 1) {
                        $user = new User;
                        $user->first_name = $request_data['billing_first_name'];
                        $user->last_name = $request_data['billing_last_name'];
                        $user->area = $request_data['billing_area'];
                        $user->block = $request_data['billing_block'];
                        $user->street = $request_data['billing_street'];
                        $user->city = $request_data['billing_city'];
                        $user->zip = $request_data['billing_zip'];
                        $user->country = $request_data['country'];
                        $user->phone = $request_data['billing_phone'];
                        $user->email = $request_data['billing_email'];
                        $user->password = bcrypt($request_data['password']);
                        $token = md5(time().$request_data['personal_name'].$request_data['personal_email']);
                        $user->verification_link = $token;
                        $user->save();
                        Auth::guard('web')->login($user);
                        if($gs->is_verification_email == 1)
                        {
                             $to = $request_data['billing_email'];
                                $subject = 'Verify your email address.';
                                
                                $message = "Dear Customer,\nSimply click the link below or copy paste in your browser to verify your email address.".url('user/register/verify/'.$token);

                                $msg = "Dear Customer\nWe noticed that you need to verify your email address". url('user/register/verify/'.$token)."Simply click here to verify";
                                $data  = array('to' => $to , 'subject' => $subject , 'msg' => $msg); 
                               
                                $data = [
                                    'to' => $to,
                                    'subject' => $subject,
                                    'body' => $msg,
                                ];
                                
                                $to = $to;
                                $subject = $subject;
                                $txt = $message;

                                $headers = "From: ".$gs->from_name."<".$gs->from_email.">";
                                //echo $to."   ".$headers."   ".$subject."  ".$txt;exit;
                                try{
                                    mail($to,$subject,$txt,$headers);    
                                }
                                catch(Exception $e)
                                {
                                    
                                }
                        }
                    }
                    else
                    {
                        echo json_encode(array('status'=>false,'message'=>'Email is already exist.'));exit;
                    }
                }
                $user = User::find(Auth::id());
                $user->first_name = $request_data['billing_first_name'];
                $user->last_name = $request_data['billing_last_name'];
                $user->area = $request_data['billing_area'];
                $user->block = $request_data['billing_block'];
                $user->street = $request_data['billing_street'];
                $user->city = $request_data['billing_city'];
                $user->zip = $request_data['billing_zip'];
                $user->country = $request_data['billing_country'];
                $user->phone = $request_data['billing_phone'];
                $user->email = $request_data['billing_email'];
                $user->shipping_first_name = isset($request_data['shipping_first_name']) ? $request_data['shipping_first_name'] : '';
                $user->shipping_last_name = isset($request_data['shipping_last_name']) ? $request_data['shipping_last_name'] : '';
                $user->shipping_area = isset($request_data['shipping_area']) ? $request_data['shipping_area'] : '';
                $user->shipping_block = isset($request_data['shipping_block']) ? $request_data['shipping_block'] : '';
                $user->shipping_street = isset($request_data['shipping_street']) ? $request_data['shipping_street'] : '';
                $user->shipping_city = isset($request_data['shipping_city']) ? $request_data['shipping_city'] : '';
                $user->shipping_zip = isset($request_data['shipping_zip']) ? $request_data['shipping_zip'] : '';
                $user->shipping_country = isset($request_data['shipping_country']) ? $request_data['shipping_country'] : '';
                $user->shipping_phone = isset($request_data['shipping_phone']) ? $request_data['shipping_phone'] : '';
                $user->shipping_email = isset($request_data['shipping_email']) ? $request_data['shipping_email'] : '';
                $user->shipping_first_name = isset($request_data['shipping_first_name']) ? $request_data['shipping_first_name'] : '';
                $user->save();
                if (!Session::has('cart')) {
                    return redirect(URL('/carts'));
                }
                if (Session::has('currency')) 
                {
                  $curr = Currency::find(Session::get('currency'));
                }
                else
                {
                    $curr = Currency::where('is_default','=',1)->first();
                }
                $gs = Generalsetting::findOrFail(1);
                $oldCart = Session::get('cart');
                $cart = new Cart($oldCart);
                $pid = "";
                $totalQty = 0;$total_price=0;
                $prdItemArr = array();
                $index = 0;
                $attr_id = 0;
                $prd_for_api = array();
                foreach($cart->items as $key => $value){
                    
                   $pd=Product::find($value['item']['id']);
                    $st=$pd->stock-$value['qty'];
                  Product::where('id','=',$value['item']['id'])->update(['stock'=>$st]);
                   //return  Product::find($value['item']['id']);
                    $variations = $value['variations'];
                    $attr_id = $value['attr_id'];
                    $pid .= ','.$value['item']['id'];
                    $totalQty++;
                    $total_price += number_format($value['unit_price']*$value['qty'],3);
                    $prdItemArr[$index]['ItemName'] = $value['item']['name'];
                    $prdItemArr[$index]['Quantity'] = $value['qty'];
                    $prdItemArr[$index]['UnitPrice'] = number_format($value['unit_price'],3);
                    $prd_for_api[$index]['ProductCode'] = $value['item']['sku'];
                    $prd_for_api[$index]['Unit_Name'] = 'PCS';
                    $prd_for_api[$index]['Quantity'] = $value['qty'];
                    $prd_for_api[$index]['Rate'] = $value['unit_price'];
                    $prd_for_api[$index]['Gross'] = $value['unit_price'];
                    $index++;
                }
                $prdItemArr = json_encode($prdItemArr);
                
                if(isset($request_data['ship_to_different_address']))
                {
                    if($request_data['ship_to_different_address']==1)
                    {
                          $shipping='shipto'; 
                    }
                    
                    else
                    {
                          $shipping='shipto'; 
                          
                          
                          $request_data['shipping_first_name'] = isset($request_data['billing_first_name']) ? $request_data['billing_first_name'] : '';
               $request_data['shipping_last_name'] = isset($request_data['billing_last_name']) ? $request_data['billing_last_name'] : '';
               $request_data['shipping_area'] = isset($request_data['billing_area']) ? $request_data['billing_area'] : '';
               $request_data['shipping_block'] = isset($request_data['billing_block']) ? $request_data['billing_block'] : '';
               $request_data['shipping_street'] = isset($request_data['billing_street']) ? $request_data['billing_street'] : '';
               $request_data['shipping_city'] = isset($request_data['billing_city']) ? $request_data['billing_city'] : '';
               $request_data['shipping_zip'] = isset($request_data['billing_zip']) ? $request_data['billing_zip'] : '';
               $request_data['shipping_country'] = isset($request_data['billing_country']) ? $request_data['billing_country'] : '';
               $request_data['shipping_phone'] = isset($request_data['billing_phone']) ? $request_data['billing_phone'] : '';
               $request_data['shipping_email'] = isset($request_data['billing_email']) ? $request_data['billing_email'] : '';
               
               
                    }
                }
                else
                {
                   $shipping='shipto'; 
                   
                   $request_data['shipping_first_name'] = isset($request_data['billing_first_name']) ? $request_data['billing_first_name'] : '';
               $request_data['shipping_last_name'] = isset($request_data['billing_last_name']) ? $request_data['billing_last_name'] : '';
               $request_data['shipping_area'] = isset($request_data['billing_area']) ? $request_data['billing_area'] : '';
               $request_data['shipping_block'] = isset($request_data['billing_block']) ? $request_data['billing_block'] : '';
               $request_data['shipping_street'] = isset($request_data['billing_street']) ? $request_data['billing_street'] : '';
               $request_data['shipping_city'] = isset($request_data['billing_city']) ? $request_data['billing_city'] : '';
               $request_data['shipping_zip'] = isset($request_data['billing_zip']) ? $request_data['billing_zip'] : '';
               $request_data['shipping_country'] = isset($request_data['billing_country']) ? $request_data['billing_country'] : '';
               $request_data['shipping_phone'] = isset($request_data['billing_phone']) ? $request_data['billing_phone'] : '';
               $request_data['shipping_email'] = isset($request_data['billing_email']) ? $request_data['billing_email'] : '';
               
                }
               
                $shipping_cost = isset($request_data['shipping_cost']) ? $request_data['shipping_cost'] : 0;
                $tax = isset($request_data['tax']) ? $request_data['tax']: 0;
                $coupon_code = isset($request_data['code']) ? $request_data['coupon_code'] : '';
                $coupon_discount = isset($request_data['coupon_discount']) ? $request_data['coupon_discount'] : '';
                $str = ltrim($pid, ',');
                $coupon = Session::has('coupon') ? Session::get('coupon') : 0;
                $oldCart = Session::get('cart');
                $cart = new Cart($oldCart);
                $total = $total_price;
                if($gs->tax != 0)
                {
                    $tax = ($total / 100) * $gs->tax;
                    $total = $total + $tax;
                }
                if(!empty($shipping_cost))
                {
                    $total = $total + $shipping_cost;
                }
                if(!Session::has('coupon_total1'))
                {
                    $total = $total - $coupon;     
                    $total = $total + 0;               
                }
                else {
                    
                    $total = Session::get('coupon_total1'); 
                    $total = str_replace('KD', '', $total);
                    $total = (float)$total + round(0 * (float)$curr->value, 2); 
                }
                $ord_inc_id = $gs->order_increment_id;
                if(empty($ord_inc_id))
                {
                    $ord_inc_id = '100001';
                }
                else
                {
                    $ord_inc_id = (int)$ord_inc_id+1;
                }
                $ordernumber = 'ORD'.(string)$ord_inc_id;
                $order = new Order;
                $success_url = action('Front\PaymentController@payreturn');
                $item_name = $gs->title." Order";
                $item_number = str_random(4).time();
                $order['user_id'] = Auth::id();
                $order['cart'] = utf8_encode(bzcompress(serialize($cart), 9)); 
                $order['totalQty'] = $totalQty;
                $order['product_id'] = $str;
                $order['pay_amount'] = round($total_price / $curr->value, 2) + $shipping_cost + $tax - $coupon_discount;
                $order['method'] = $request_data['payment_method'];
                $order['shipping'] = $shipping;
                $order['shipping_cost'] = $shipping_cost;
                $order['packing_cost'] = 0;
                $order['tax'] = $tax;
                $order['order_number'] = $ordernumber;
                $order['order_note'] = $request_data['order_comments'];
                $order['coupon_code'] = $coupon_code;
                $order['coupon_discount'] = $coupon_discount;
                $order['dp'] = isset($request_data['dp']) ? $request_data['dp'] : 0;
                $order['payment_status'] = "Pending";
                $order['currency_sign'] = $curr->sign;
                $order['currency_value'] = $curr->value;
                $order['delivery_time'] = '';
                
                
                $order['shipping_first_name'] = isset($request_data['shipping_first_name']) ? $request_data['shipping_first_name'] : '';
                $order['shipping_last_name'] = isset($request_data['shipping_last_name']) ? $request_data['shipping_last_name'] : '';
                $order['shipping_area'] = isset($request_data['shipping_area']) ? $request_data['shipping_area'] : '';
                $order['shipping_block'] = isset($request_data['shipping_block']) ? $request_data['shipping_block'] : '';
                $order['shipping_street'] = isset($request_data['shipping_street']) ? $request_data['shipping_street'] : '';
                $order['shipping_city'] = isset($request_data['shipping_city']) ? $request_data['shipping_city'] : '';
                $order['shipping_zip'] = isset($request_data['shipping_zip']) ? $request_data['shipping_zip'] : '';
                $order['shipping_country'] = isset($request_data['shipping_country']) ? $request_data['shipping_country'] : '';
                $order['shipping_phone'] = isset($request_data['shipping_phone']) ? $request_data['shipping_phone'] : '';
                $order['shipping_email'] = isset($request_data['shipping_email']) ? $request_data['shipping_email'] : '';
                
                
                $order->save();
                
                Generalsetting::where('id',1)->update(array('order_increment_id'=>$ord_inc_id));
                $orderupdate = \DB::table("orders")->where('id',$order->id)->update(['order_number'=>$ordernumber]);
                $cartValues = Session::get('cartValues');
                foreach($cart->items as $v){
                    $insertOrderedProductDetails = \DB::table("ordered_product_details")->insertGetID(['order_number'=>$ordernumber,'product_id'=>$v['item']['id']
                        ,'product_name'=>$v['item']['name']]);
                }
                $track = new OrderTrack;
                $track->title = 'Pending';
                $track->text = 'You have successfully placed your order.';
                $track->order_id = $order->id;
                $track->save();

                $notification = new Notification;
                $notification->order_id = $order->id;
                $notification->save();
                if(isset($request_data['coupon_id']) && $request_data['coupon_id'] != "")
                {
                   $coupon = Coupon::findOrFail($request_data['coupon_id']);
                   $coupon->used++;
                   if($coupon->times != null)
                   {
                        $i = (int)$coupon->times;
                        $i--;
                        $coupon->times = (string)$i;
                   }
                    $coupon->update();
                }
                foreach($cart->items as $prod)
                {
                    $x = (string)$prod['stock'];
                    if($x != null)
                    {
                        $product = Product::findOrFail($prod['item']['id']);
                        $product->stock =  $prod['stock'];
                        //$product->update();  
                        $attr_stock = DB::table('product_variations')->select('qty')->where('id', $prod['attr_id'])->first();
                        if(isset($attr_stock->qt))
                        {
                            $stock = $attr_stock->qty;
                            DB::table('product_variations')->where('id', $prod['attr_id'])->update(array('qty'=>($stock-1)));    
                        }
                        
                        if($product->stock <= 5)
                        {
                            $notification = new Notification;
                            $notification->product_id = $product->id;
                            $notification->save();                    
                        }              
                    }
                }
                if($gs->is_smtp == 1)
                {
                    $data = [
                        'to' => $request_data['billing_email'],
                        'type' => "new_order",
                        'cname' => $request_data['billing_first_name']." ".$request_data['billing_last_name'],
                        'oamount' => "KD ".$order->pay_amount,
                        'aname' => "",
                        'aemail' => "",
                        'wtitle' => "",
                        'onumber' => $ordernumber,
                    ];

                    $mailer = new GeniusMailer();
                    $this->sendAutoOrderMail($data,$order->id,$order->order_number);            
                }
                else
                {
                   $to = $request_data['billing_email'];
                   $subject = "Your Order Placed!!";
                   $msg = "Hello ".$request_data['billing_name']."!\nYou have placed a new order.\nYour order number is ".$ordernumber.".Please wait for your delivery. \nThank you.";
                    $headers = "From: ".$gs->from_name."<".$gs->from_email.">";
                   mail($to,$subject,$msg,$headers);            
                }
                //Sending Email To Admin
                if($gs->is_smtp == 1)
                {
                    $data = [
                        'to' => $gs->email,
                        'subject' => "New Order Recieved!!",
                        'body' => "Hello Admin!<br>Your store has received a new order.<br>Order Number is ".$ordernumber.".Please login to your panel to check. <br>Thank you.",
                    ];

                    $mailer = new GeniusMailer();
                   $mailer->sendCustomMail($data);            
                }
                else
                {
                   $to = $gs->email;
                   $subject = "New Order Recieved!!";
                   $msg = "Hello Admin!\nYour store has recieved a new order.\nOrder Number is ".$ordernumber.".Please login to your panel to check. \nThank you.";
                    $headers = "From: ".$gs->from_name."<".$gs->from_email.">";
                   mail($to,$subject,$msg,$headers);
                }
              //Session::forget('cart');
              //$order_data = Session::get('online_payment_order');
              $online_payment = Session::get('online_payment');

              
              $user = Auth::user();
              $transaction_id = '';
              //$order = Order::where('id',$order_data->id)->first();
              $prd_for_api = array();
              $index = 0;
             // foreach($online_payment->items as $key => $value){
               // $prd_for_api[$index]['ProductCode'] = $value['item']['sku'];
               // $prd_for_api[$index]['Unit_Name'] = 'PCS';
               // $prd_for_api[$index]['Quantity'] = $value['qty'];
               // $prd_for_api[$index]['Rate'] = $value['unit_price'];
               // $prd_for_api[$index]['Gross'] = $value['unit_price'];
               // $index++;
             // }
               //save order api start
                $url = "http://168.187.178.135/Marafie/api/Focus/PostInv";
                $curl = curl_init();
                curl_setopt($curl, CURLOPT_URL,$url);
                curl_setopt($curl, CURLOPT_POST, 1);
                curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query(array('SInvHeaderDetails' => array('OrderNo'=>$order->order_number,'OrderDate'=>date('Y-m-d'),'Narration'=>'Test Narration','PaymentMode'=>'Knet'),'SInvBodyDetails'=>$prd_for_api)));
                $result = curl_exec($curl);
                $info = curl_getinfo($curl);
                curl_close($curl);
                $json = json_decode($result, true);
                //print_r($json);exit;
              //save order api end
              //if(empty($order->txnid)){
                //echo "test ".$transaction_id;exit;
                /*$order_save = Order::find($order_data->id);
                $order_save->payment_status = 'Completed';
                $order_save->timestamps = false;
                $order_save->txnid = $transaction_id;
                $order_save->save();*/
                /*echo "<pre>";
                print_r($order);exit;
                DB::table('orders')->where('id', $order->id)->update(array('payment_status' => 'Completed', 'txnid' => $transaction_id));*/
              //}
                //sleep(30);
              if (Session::has('currency')) 
                {
                    $curr = Currency::find(Session::get('currency'));
                }
                else
                {
                    $curr = Currency::where('is_default','=',1)->first();
                }
              $order_product = DB::table('ordered_product_details')->where('order_number',$order->order_number)->get();
              $tempcart = Session::get('online_payment');
              $product_data = Product::select('products.*')->join('ordered_product_details','ordered_product_details.product_id','=','products.id')->where('ordered_product_details.order_number',$order->order_number)->get();
                Session::forget('cart');
                Session::forget('already');
                Session::forget('coupon');
                Session::forget('coupon_total');
                Session::forget('coupon_total1');
                Session::forget('coupon_percentage');
                Session::save();
                
                   $order = Order::where('id',$order->id)->first();
            
      
         $cart = unserialize(bzdecompress(utf8_decode($order->cart)));
       
             return view('front.success',compact('order','tempcart','order_product','product_data','curr','gs','user','cart'));
        
        if(Session::has('tempcart')){
            $oldCart = Session::get('tempcart');
            $tempcart = new Cart($oldCart);
            $order_data = Session::get('temporder');
            $order = Order::where('id',$order_data->id)->first();
            
      
         $cart = unserialize(bzdecompress(utf8_decode($order->cart)));
        
            $order_product = DB::table('ordered_product_details')->where('order_number',$order->order_number)->get();
            return view('front.success',compact('tempcart','order','order_product','cart'));
            
        }
        else{
            $tempcart = '';
            return redirect()->back();
        }
     }


    public function gateway(Request $request)
    {
        
        // echo "<pre>"; print_r($request->all()); dd();
        // print_r($request->all()); exit;
        $req_data = $request->all();
      
          if (Session::has('currency')) 
            {
              $curr = Currency::find(Session::get('currency'));
            }
            else
            {
                $curr = Currency::where('is_default','=',1)->first();
            }
        $gs = Generalsetting::findOrFail(1);
        $oldCart = Session::get('cart');
        
        // echo "<pre>"; print_r($oldCart); exit;
        $cart = new Cart($oldCart);
        foreach($cart->items as $key => $prod)
        {
        if(!empty($prod['item']['license']) && !empty($prod['item']['license_qty']))
        {
                foreach($prod['item']['license_qty']as $ttl => $dtl)
                {
                    if($dtl != 0)
                    {
                        $dtl--;
                        $produc = Product::findOrFail($prod['item']['id']);
                        $temp = $produc->license_qty;
                        $temp[$ttl] = $dtl;
                        $final = implode(',', $temp);
                        $produc->license_qty = $final;
                        $produc->update();
                        $temp =  $produc->license;
                        $license = $temp[$ttl];
                         $oldCart = Session::has('cart') ? Session::get('cart') : null;
                         $cart = new Cart($oldCart);
                         $cart->updateLicense($prod['item']['id'],$license);  
                         Session::put('cart',$cart);
                        break;
                    }                    
                }
        }
        }
        
        // echo "<pre>"; print_r($cart); exit;
        $pid = "";
        foreach($cart->items as $value){
            
            $pid .= ','.$value['item']['id'];
            
        }
        $str = ltrim($pid, ',');
        
        $country = \DB::table("countries")->where('id',$request->customer_country)->first();
        
          // //billing Details 
        $user_data = User::find($request->user_id);
        
        $user_data->city = $request->city;
        $user_data->phone = $request->phone;
        $user_data->address = $request->address;
        $user_data->address2 = $request->address2;
        $user_data->country = $request->customer_country;
        $user_data->zip = $request->zip;
        $user_data->block = $request->block;
        $user_data->street = $request->street;
        $user_data->area = $request->area;
        $user_data->avenue = $request->avenue;
        $user_data->house_number = $request->house_number;
        $user_data->save();
        
        $order = new Order;
        $success_url = action('Front\PaymentController@payreturn');
        $item_name = $gs->title." Order";
        $item_number = str_random(4).time();
        $order['user_id'] = $request->user_id;
        $order['cart'] = utf8_encode(bzcompress(serialize($cart), 9)); 
        $order['totalQty'] = $request->totalQty;
        $order['product_id'] = $str;
        $order['pay_amount'] = round($request->total / $curr->value, 2) + $request->shipping_cost + $request->packing_cost;
        $order['method'] = $request->method;
        $order['shipping'] = $request->shipping;
        $order['pickup_location'] = $request->pickup_location;
        $order['customer_email'] = $request->email;
        $order['customer_name'] = $request->name;
        $order['shipping_cost'] = $request->shipping_cost;
        $order['packing_cost'] = $request->packing_cost;
        $order['tax'] = $request->tax;
        $order['customer_phone'] = $request->phone;
        $order['order_number'] = str_random(4).time();
        $order['customer_address'] = $request->address;
        $order['customer_country'] = $country->country_name;
        $order['customer_city'] = $request->city;
        $order['customer_zip'] = $request->zip;
        $order['shipping_email'] = $request->shipping_email;
        $order['shipping_name'] = $request->shipping_name;
        $order['shipping_phone'] = $request->shipping_phone;
        $order['shipping_address'] = $request->shipping_address;
        $order['shipping_country'] = $request->shipping_country;
        $order['shipping_city'] = $request->shipping_city;
        $order['shipping_zip'] = $request->shipping_zip;
        $order['order_note'] = $request->order_notes;
        $order['coupon_code'] = $request->coupon_code;
        $order['coupon_discount'] = $request->coupon_discount;
        $order['dp'] = $request->dp;
        $order['payment_status'] = "Pending";
        $order['currency_sign'] = $curr->sign;
        $order['currency_value'] = $curr->value;
        $order['vendor_shipping_id'] = $request->vendor_shipping_id;
        $order['vendor_packing_id'] = $request->vendor_packing_id;

            if (Session::has('affilate')) 
            {
                $val = $request->total / 100;
                $sub = $val * $gs->affilate_charge;
                $user = User::findOrFail(Session::get('affilate'));
                $user->affilate_income += $sub;
                $user->update();
                $order['affilate_user'] = $user->name;
                $order['affilate_charge'] = $sub;
            }
        $order->save();
        
        $ordernumber = 'ORD'.sprintf("%05d", $order->id);
        // echo $ordernumber; exit;
        $orderupdate = \DB::table("orders")->where('id',$order->id)->update(['order_number'=>$ordernumber]);
        
        $cartValues = Session::get('cartValues');
        $sleeve = isset($cartValues['sleeve_list']) ?  $cartValues['sleeve_list'] : 'full';
         foreach($cart->items as $v){
                $insertOrderedProductDetails = \DB::table("ordered_product_details")->insertGetID(['order_number'=>$ordernumber,'product_id'=>$v['item']['id']
                ,'product_name'=>$v['item']['name'],'product_length'=>$cartValues['length_list'],'product_size'=>$cartValues['size'],'product_sleeve'=>$sleeve]);
         }
        
        $track = new OrderTrack;
        $track->title = 'Pending';
        $track->text = 'You have successfully placed your order.';
        $track->order_id = $order->id;
        $track->save();
        
      
        /*************** order saved*********************/
        $getCountry = \DB::table("countries")->where('id',$req_data['customer_country'])->first();
        // echo "<pre>"; print_r($getCountry); exit;
        $req_data['country_code'] = $getCountry->country_code;
        // if($req_data['customer_country'] != 119){
        //     $shippingCharges = $this->getFedExRequest($request->all());
        // }else{
             $shippingCharges = 0;
        // }
        
        $updateShippingCharge = \DB::table("orders")->where("order_number",$ordernumber)->update(['shipping_cost'=>$shippingCharges]);
      
    //   $final_payment = $request['total'] + $shippingCharges;
      
    //   echo $final_payment; exit;
      $username='apiaccount@myfatoorah.com';
      $password='api12345*';
      
    //   echo $username; exit;
      $curl = curl_init();
      curl_setopt($curl, CURLOPT_URL,'https://apidemo.myfatoorah.com/Token');
      curl_setopt($curl, CURLOPT_POST, 1);
      curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
      curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
      curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
      curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query(array('grant_type' => 'password','username' => $username,'password' =>$password)));
      $result = curl_exec($curl);
      $info = curl_getinfo($curl);
      curl_close($curl);
      $json = json_decode($result, true);
      if(isset($json['access_token']) && !empty($json['access_token'])){
          $access_token= $json['access_token'];
      }else{
        $access_token='';
      }
      if(isset($json['token_type']) && !empty($json['token_type'])){
      $token_type= $json['token_type'];
        }else{
            $token_type='';
        }
    //  echo $access_token; exit;

      if(isset($json['access_token']) && !empty($json['access_token']))
      {
        // echo "Token Generated Successfully.<br>";
         Session::put('online_payment_order',$order);
         Session::put('online_payment',$cart);
        $t= time();
        $name = "Demo Name";
        $post_string = '{
            "InvoiceValue": "10",
            "CustomerName": "'.$request->name.'",
            "CustomerBlock": "Block",
            "CustomerStreet": "Street",
            "CustomerHouseBuildingNo": "Building no",
            "CustomerCivilId": "123456789124",
            "CustomerAddress": "'.$request->address.'",
            "CustomerReference": "'.$t.'",
            "DisplayCurrencyIsoAlpha": "KWD",
            "CountryCodeId": "+965",
            "CustomerMobile": "'.$request->phone.'",
            "CustomerEmail": "'.$request->email.'",
            "DisplayCurrencyId": 3,
            "SendInvoiceOption": 1,
            "InvoiceItemsCreate": [
              {
                "ProductId": null,
                "ProductName": "Product01",
                "Quantity": 1,
                "UnitPrice": 10
              }
            ],
           "CallBackUrl":  "http://ecommercedemo.q8jit.com/checkout/payment/return",
            "Language": 2,
             "ExpireDate": "2022-12-31T13:30:17.812Z",
  "ApiCustomFileds": "weight=10,size=L,lenght=170",
  "ErrorUrl": "http://ecommercedemo.q8jit.com"
          }';
          
        //   print_r($post_string); exit;
        $soap_do     = curl_init();
       curl_setopt($soap_do, CURLOPT_URL, "https://apidemo.myfatoorah.com/ApiInvoices/CreateInvoiceIso");
       curl_setopt($soap_do, CURLOPT_CONNECTTIMEOUT, 10);
       curl_setopt($soap_do, CURLOPT_TIMEOUT, 10);
       curl_setopt($soap_do, CURLOPT_RETURNTRANSFER, true);
       curl_setopt($soap_do, CURLOPT_SSL_VERIFYPEER, false);
       curl_setopt($soap_do, CURLOPT_SSL_VERIFYHOST, false);
       curl_setopt($soap_do, CURLOPT_POST, true);
       curl_setopt($soap_do, CURLOPT_POSTFIELDS, $post_string);
       curl_setopt($soap_do, CURLOPT_HTTPHEADER, array('Content-Type: application/json; charset=utf-8','Content-Length: ' . strlen($post_string),  'Accept: application/json','Authorization: Bearer '.$access_token));
       $result1 = curl_exec($soap_do);
    //   echo "<pre>";print_r($result1);exit;
       $err    = curl_error($soap_do);
      $json1= json_decode($result1,true);
      $RedirectUrl= $json1['RedirectUrl'];
      
    //   echo $RedirectUrl; exit;
    //   $ref_Ex=explode('/',$RedirectUrl);
    //   $referenceId =  $ref_Ex[4];
       curl_close($soap_do);
      return Redirect::to($RedirectUrl);
      }else{
        //print_r($json);
      print_r("Error: ".$json['error']."<br>Description: ".$json['error_description']);
      }

    

      //call back to same index page after payment page redirect
      if(isset($_GET['paymentId'])){
         $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL,'https://apidemo.myfatoorah.com/Token');
        curl_setopt($curl, CURLOPT_POST, 1);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query(array('grant_type' => 'password','username' => 'apiaccount@myfatoorah.com','password' => 'api12345*')));
        $result = curl_exec($curl);
        $error= curl_error($curl);
        $info = curl_getinfo($curl);
        curl_close($curl);
        $json = json_decode($result, true);
        $access_token= $json['access_token'];
        $token_type= $json['token_type'];
       if(isset($_GET['paymentId']))
        {
            $id=$_GET['paymentId'];
        }
        $password= 'api12345*';
        $url = 'https://apidemo.myfatoorah.com/ApiInvoices/Transaction/'.$id;
        $soap_do1 = curl_init();
        curl_setopt($soap_do1, CURLOPT_URL,$url );
        curl_setopt($soap_do1, CURLOPT_CONNECTTIMEOUT, 10);
        curl_setopt($soap_do1, CURLOPT_TIMEOUT, 10);
        curl_setopt($soap_do1, CURLOPT_RETURNTRANSFER, true );
        curl_setopt($soap_do1, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($soap_do1, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($soap_do1, CURLOPT_POST, false );
        curl_setopt($soap_do1, CURLOPT_POST, 0);
        curl_setopt($soap_do1, CURLOPT_HTTPGET, 1);
        curl_setopt($soap_do1, CURLOPT_HTTPHEADER, array('Content-Type: application/json; charset=utf-8', 'Accept: application/json','Authorization: Bearer '.$access_token));
        $result_in = curl_exec($soap_do1);
        $err_in = curl_error($soap_do1);
        $file_contents = htmlspecialchars(curl_exec($soap_do1));
        curl_close($soap_do1);
        $getRecorById = json_decode($result_in, true);
        echo'<div class="form-group "><label class="control-label" for="name">
        Invoice id : '.$getRecorById['InvoiceId'].'
         </label><br>';
         echo'<div class="form-group "><label class="control-label" for="name">
         InvoiceReference : '.$getRecorById['InvoiceReference'].'
          </label><br>';
        echo'<div class="form-group "><label class="control-label" for="name">
          CreatedDate : '.$getRecorById['CreatedDate'].'
           </label><br>';
        echo'<div class="form-group "><label class="control-label" for="name">
             ExpireDate : '.$getRecorById['ExpireDate'].'
              </label><br>';
      echo'<div class="form-group "><label class="control-label" for="name">
                   InvoiceValue : '.$getRecorById['InvoiceValue'].'
                    </label><br>';
  echo'<div class="form-group "><label class="control-label" for="name">
  Comments : '.$getRecorById['Comments'].'</label><br>';
  echo'<div class="form-group "><label class="control-label" for="name">
  CustomerName : '.$getRecorById['CustomerName'].'</label><br>';
  echo'<div class="form-group "><label class="control-label" for="name">
  CustomerMobile : '.$getRecorById['CustomerMobile'].'</label><br>';
  echo'<div class="form-group "><label class="control-label" for="name">
  CustomerEmail : '.$getRecorById['CustomerEmail'].'</label><br>';
  echo'<div class="form-group "><label class="control-label" for="name">
  TransactionDate : '.$getRecorById['TransactionDate'].'</label><br>';
  echo'<div class="form-group "><label class="control-label" for="name">
  TransactionDate : '.$getRecorById['TransactionDate'].'</label><br>';
  echo'<div class="form-group "><label class="control-label" for="name">
  PaymentGateway : '.$getRecorById['PaymentGateway'].'</label><br>';
  echo'<div class="form-group "><label class="control-label" for="name">
  ReferenceId : '.$getRecorById['ReferenceId'].'</label><br>';
  echo'<div class="form-group "><label class="control-label" for="name">
  TrackId : '.$getRecorById['TrackId'].'</label><br>';
  echo'<div class="form-group "><label class="control-label" for="name">
  TransactionId : '.$getRecorById['TransactionId'].'</label><br>';
  echo'<div class="form-group "><label class="control-label" for="name">
  PaymentId : '.$getRecorById['PaymentId'].'</label><br>';
  echo'<div class="form-group "><label class="control-label" for="name">
  AuthorizationId : '.$getRecorById['AuthorizationId'].'</label><br>';
  echo'<div class="form-group "><label class="control-label" for="name">
  OrderId : '.$getRecorById['OrderId'].'</label><br>';
  echo'<div class="form-group "><label class="control-label" for="name">
  TransactionStatus : '.$getRecorById['TransactionStatus'].'</label><br>';
  echo'<div class="form-group "><label class="control-label" for="name">
  Error : '.$getRecorById['Error'].'</label><br>';
  echo'<div class="form-group "><label class="control-label" for="name">
  PaidCurrency : '.$getRecorById['PaidCurrency'].'</label><br>';
  echo'<div class="form-group "><label class="control-label" for="name">
  PaidCurrencyValue : '.$getRecorById['PaidCurrencyValue'].'</label><br>';
  echo'<div class="form-group "><label class="control-label" for="name">
  TransationValue : '.$getRecorById['TransationValue'].'</label><br>';
  echo'<div class="form-group "><label class="control-label" for="name">
  CustomerServiceCharge : '.$getRecorById['CustomerServiceCharge'].'</label><br>';
  echo'<div class="form-group "><label class="control-label" for="name">
  DueValue : '.$getRecorById['DueValue'].'</label><br>';
  echo'<div class="form-group "><label class="control-label" for="name">
  Currency : '.$getRecorById['Currency'].'</label><br>';
    

    }
}

    // Capcha Code Image
    private function  code_image()
    {
        $actual_path = str_replace('project','',base_path());
        $image = imagecreatetruecolor(200, 50);
        $background_color = imagecolorallocate($image, 255, 255, 255);
        imagefilledrectangle($image,0,0,200,50,$background_color);

        $pixel = imagecolorallocate($image, 0,0,255);
        for($i=0;$i<500;$i++)
        {
            imagesetpixel($image,rand()%200,rand()%50,$pixel);
        }

        $font = $actual_path.'assets/front/fonts/NotoSans-Bold.ttf';
        $allowed_letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        $length = strlen($allowed_letters);
        $letter = $allowed_letters[rand(0, $length-1)];
        $word='';
        //$text_color = imagecolorallocate($image, 8, 186, 239);
        $text_color = imagecolorallocate($image, 0, 0, 0);
        $cap_length=6;// No. of character in image
        for ($i = 0; $i< $cap_length;$i++)
        {
            $letter = $allowed_letters[rand(0, $length-1)];
            imagettftext($image, 25, 1, 35+($i*25), 35, $text_color, $font, $letter);
            $word.=$letter;
        }
        $pixels = imagecolorallocate($image, 8, 186, 239);
        for($i=0;$i<500;$i++)
        {
            imagesetpixel($image,rand()%200,rand()%50,$pixels);
        }
        session(['captcha_string' => $word]);
        imagepng($image, $actual_path."assets/images/capcha_code.png");
    }
    
    function delete_all_between($beginning, $end, $string) {
      $beginningPos = strpos($string, $beginning);
      $endPos = strpos($string, $end);
      if ($beginningPos === false || $endPos === false) {
        return $string;
      }
    
      $textToDelete = substr($string, $beginningPos, ($endPos + strlen($end)) - $beginningPos);
    
      return $this->delete_all_between($beginning, $end, str_replace($textToDelete, '', $string)); // recursion to ensure all occurrences are replaced
    }
    
    private function getFedExRequest($data){
        
        $xml = '<SOAP-ENV:Envelope xmlns:SOAP-ENV="http://schemas.xmlsoap.org/soap/envelope/" xmlns:SOAP-ENC="http://schemas.xmlsoap.org/soap/encoding/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns="http://fedex.com/ws/rate/v26">
   <SOAP-ENV:Body>
      <RateRequest>
         <WebAuthenticationDetail>
            <ParentCredential>
               <Key>H3gAFjxaodAAv7Au</Key>
               <Password>qr0DykXOut56KrId8EkMzx7TN</Password>
            </ParentCredential>
            <UserCredential>
               <Key>H3gAFjxaodAAv7Au</Key>
               <Password>qr0DykXOut56KrId8EkMzx7TN</Password>
            </UserCredential>
         </WebAuthenticationDetail>
         <ClientDetail>
            <AccountNumber>767676506</AccountNumber>
            <MeterNumber>250669912</MeterNumber>
         </ClientDetail>
         <TransactionDetail>
            <CustomerTransactionId>International Priority with Payment type_SENDER</CustomerTransactionId>
         </TransactionDetail>
         <Version>
            <ServiceId>crs</ServiceId>
            <Major>26</Major>
            <Intermediate>0</Intermediate>
            <Minor>0</Minor>
         </Version>
         <RequestedShipment>
            <ShipTimestamp>2020-04-22T09:34:56-06:00</ShipTimestamp>
            <DropoffType>REGULAR_PICKUP</DropoffType>
            <ServiceType>INTERNATIONAL_PRIORITY</ServiceType>
            <PackagingType>YOUR_PACKAGING</PackagingType>
            <PreferredCurrency>USD</PreferredCurrency>
            <Shipper>
               <Contact>
                  <PersonName>MANISHA</PersonName>
                  <CompanyName>FOUZ BOUTIQUE</CompanyName>
                  <PhoneNumber>123456789</PhoneNumber>
                  <EMailAddress/>
               </Contact>
               <Address>
                  <StreetLines>BLOCK 12, SALMIYA</StreetLines>
                  <StreetLines>BLDG 10, SALMIYA</StreetLines>
                  <City>SALMIYA</City>
                  <StateOrProvinceCode/>
                  <PostalCode/>
                  <CountryCode>KW</CountryCode>
               </Address>
            </Shipper>
            <Recipient>
               <Contact>
                  <PersonName>.$data["rcv_name"].</PersonName>
                  <CompanyName>FDX INDIA</CompanyName>
                  <PhoneNumber>.$data["rcv_phone"].</PhoneNumber>
                  <EMailAddress/>
               </Contact>
               <Address>
                  <StreetLines>.$data["rcv_address"].</StreetLines>
                  <StreetLines>.$data["rcv_address"].</StreetLines>
                  <City>.$data["rcv_city"].</City>
                  <StateOrProvinceCode>.$data["rcv_statecode"].</StateOrProvinceCode>
                  <PostalCode>.$data["rcv_zip"].</PostalCode>
                  <CountryCode>.$data["rcv_countrycode"].</CountryCode>
               </Address>
            </Recipient>
            <ShippingChargesPayment>
               <PaymentType>SENDER</PaymentType>
               <Payor>
                  <ResponsibleParty>
                     <AccountNumber>767676506</AccountNumber>
                  </ResponsibleParty>
               </Payor>
            </ShippingChargesPayment>
            <CustomsClearanceDetail>
               <DutiesPayment>
                  <PaymentType>SENDER</PaymentType>
                  <Payor>
                     <ResponsibleParty>
                        <AccountNumber>620155977</AccountNumber>
                     </ResponsibleParty>
                  </Payor>
               </DutiesPayment>
               <DocumentContent>NON_DOCUMENTS</DocumentContent>
               <CustomsValue>
                  <Currency>USD</Currency>
                  <Amount>100.00</Amount>
               </CustomsValue>
               <CommercialInvoice>
                  <TermsOfSale>FOB_OR_FCA</TermsOfSale>
               </CommercialInvoice>
               <Commodities>
                  <NumberOfPieces>.$data["product_items"].</NumberOfPieces>
                  <Description>.$data["product_description"].</Description>
                  <CountryOfManufacture>KW</CountryOfManufacture>
                  <Weight>
                     <Units>KG</Units>
                     <Value>.$data["product_weight"].</Value>
                  </Weight>
                  <Quantity>.$data["product_qty"].</Quantity>
                  <QuantityUnits>cm</QuantityUnits>
                  <UnitPrice>
                     <Currency>USD</Currency>
                     <Amount>1.000000</Amount>
                  </UnitPrice>
                  <CustomsValue>
                     <Currency>USD</Currency>
                     <Amount>100.000000</Amount>
                  </CustomsValue>
               </Commodities>
               <ExportDetail>
                  <ExportComplianceStatement>30.37(f)</ExportComplianceStatement>
               </ExportDetail>
            </CustomsClearanceDetail>
            <RateRequestTypes>NONE</RateRequestTypes>
            <PackageCount>2</PackageCount>
            <RequestedPackageLineItems>
               <SequenceNumber>1</SequenceNumber>
               <GroupNumber>1</GroupNumber>
               <GroupPackageCount>1</GroupPackageCount>
               <Weight>
                  <Units>KG</Units>
                  <Value>0.50</Value>
               </Weight>
               <Dimensions>
                  <Length>12</Length>
                  <Width>12</Width>
                  <Height>12</Height>
                  <Units>CM</Units>
               </Dimensions>
               <CustomerReferences>
                  <CustomerReferenceType>CUSTOMER_REFERENCE</CustomerReferenceType>
                  <Value>TC001_01_PT1_ST01_PK01_SNDUS_RCPCA_POS</Value>
               </CustomerReferences>
            </RequestedPackageLineItems>
            <RequestedPackageLineItems>
               <SequenceNumber>2</SequenceNumber>
               <GroupNumber>1</GroupNumber>
               <GroupPackageCount>1</GroupPackageCount>
               <Weight>
                  <Units>KG</Units>
                  <Value>0.50</Value>
               </Weight>
               <Dimensions>
                  <Length>12</Length>
                  <Width>12</Width>
                  <Height>12</Height>
                  <Units>CM</Units>
               </Dimensions>
               <CustomerReferences>
                  <CustomerReferenceType>CUSTOMER_REFERENCE</CustomerReferenceType>
                  <Value>TC001_01_PT1_ST01_PK01_SNDUS_RCPCA_POS</Value>
               </CustomerReferences>
            </RequestedPackageLineItems>
         </RequestedShipment>
      </RateRequest>
   </SOAP-ENV:Body>
</SOAP-ENV:Envelope>';
  
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL,'https://ws.fedex.com:443/web-services');
        curl_setopt($curl, CURLOPT_POST, 1);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($curl, CURLOPT_POSTFIELDS, $xml);
        $result_xml = curl_exec($curl);
      
        if (curl_errno($curl)) {
            $error_msg = curl_error($curl);
        }
        curl_close($curl);
        
        if (isset($error_msg)) {
         
            // TODO - Handle cURL error accordingly
            print_r($error_msg);
            return 0;
        }else{
            $response = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $result_xml);
            $response = str_replace('xmlns="http://fedex.com/ws/rate/v26"', '', $result_xml);
            $response = str_replace('xmlns:SOAP-ENV="http://schemas.xmlsoap.org/soap/envelope/"', '', $result_xml);
            $response = $this->delete_all_between('<Image>', '</Image>', $response);
            
            libxml_use_internal_errors(true);
            $Data = simplexml_load_string($response) or die("ghvgh");
            if (false === $Data) {
                echo "Failed loading XML\n";
                foreach(libxml_get_errors() as $error) {
                    echo "\t", $error->message;
                }
            }
            $Data = $this->xml2array($Data);
            echo "<pre>"; print_r($Data); exit;
            if(isset($Data['SOAP-ENV:Body']['ProcessShipmentReply']['CompletedShipmentDetail']['ShipmentRating']['ShipmentRateDetails']['0'])){
                $amount = $this->xml2array($Data['SOAP-ENV:Body']['ProcessShipmentReply']['CompletedShipmentDetail']['ShipmentRating']['ShipmentRateDetails']['0']);
                return $amount['TotalNetCharge']['Amount'];
            }
            return 0;
        }
    }
    
    function xml2array ( $xmlObj, $output = array () )
       {      
       foreach ( (array) $xmlObj as $index => $node )
       {
        $output[$index] = (is_object($node)) ? $this->xml2array($node): $node;
       }
      return $output;
    }
    
    
    public function checkoutLogin(Request $request){
        if($request->ajax()){
            $users = User::where('email','=',$request->email)->first();
            if(!empty($users)) {
                if (Auth::attempt(['email' => $request->email, 'password' => $request->password])) {
                    Auth::guard('web')->login($users);    
                    return response()->json(['status' => 1,'data' => $users]);
                }else{
                     return response()->json(['status' => 0,'msg' => 'Password wrong,Try again.']);
                }
            }else{
                return response()->json(['status' => 0,'msg' => 'Incorrect credentials, please try again.']);
            }   
        }
    }
}
