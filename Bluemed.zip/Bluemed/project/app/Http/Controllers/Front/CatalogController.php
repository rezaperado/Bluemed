<?php

namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\Childcategory;
use App\Models\Comment;
use App\Models\Currency;
use App\Models\Order;
use App\Models\Product;
use App\Models\ProductClick;
use App\Models\Rating;
use App\Models\Reply;
use App\Models\Report;
use App\Models\Subcategory;
use Auth;
use App\Models\Gallery;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Collection;
use Session;
use Illuminate\Support\Facades\Input;
use Validator;
use DB;
use App\Models\PracticeField;
use App\Models\Brand;
use App\Models\Collection as Coll; 
use App\Models\CategoryBanner;  
use App\Models\attribute_masters;   
use File;   
use Image;
class CatalogController extends Controller
{

// CATEGORIES SECTOPN

public function categories()
{
    return view('front.categories');
}


public function collection()
    {
        
         $collection=Coll::get();
        return view('front.collection',compact('collection'));
        
    }
    
    public function practice_field()
    {
        
         $practice =PracticeField::get();
        return view('front.practice',compact('practice'));
        
    }
    
    
// CATEGORIES SECTION ENDS


// -------------------------------- CATEGORY SECTION ----------------------------------------

    public function category(Request $request,$slug)
    {
        
        $filtered_cat=array();
        $arabic_attr = DB::table('attribute_masters')->select('name_en','name_ar')->get()->toArray();
        $this->code_image();
        $filters = isset($request->attr) ? $request->attr : array();
        $sort = "date";
        if (Session::has('currency')) 
        {
            $curr = Currency::find(Session::get('currency'));
        }
        else
        {
            $curr = Currency::where('is_default','=',1)->first();
        }
        $curr = $curr->sign;
        $cat = Category::where('slug','=',$slug)->first();
        $categories = Category::where('status',1)->get();
        $subcategory = Subcategory::where('category_id',$cat->id)->where('status',1)->get();
        $product_variations = DB::table('product_variations')->select('product_variations.id','attribute_names','attribute_values')->join('products', 'products.id', '=', 'product_variations.product_id')->where('status',1)->where('category_id',$cat->id)->where('products.status',1)->get();
        $attr_arr = array();
        foreach ($product_variations as $key => $attribute) {
            /*echo "<pre>";
            print_r($attribute);exit;*/
            $attribute_names = explode('-', $attribute->attribute_names);
            $attribute_values = explode('-', $attribute->attribute_values);
            foreach ($attribute_names as $attrkey => $attrvalue) {
               //echo $attrvalue."---".$attribute_values[$attrkey]."<br>";
                $vals = '';
                if(isset($attribute_values[$attrkey]))
                    $vals = $attribute_values[$attrkey];
                $attr_arr[$attrvalue][$key] = $vals;
            }
            //print_r($attribute_values);exit;
        }
        $min_max_price = DB::table('product_variations')->select(DB::raw("min(product_variations.price) as min_price"),DB::raw("max(product_variations.price) as max_price"))->join('products', 'products.id', '=', 'product_variations.product_id')->where('status',1)->where('category_id',$cat->id)->get()->first();

        $min_price = $min_max_price->min_price;
        $max_price = $min_max_price->max_price;
        $latest_products = Product::where('latest','=',1)->where('status','=',1)->where('category_id',$cat->id)->take(18)->get();
        $oldcats = $cat->products()->where('status','=',1)->orderBy('id','desc')->get();
        $layout_type = !empty(request()->query('layout')) ? request()->query('layout') : 'grid';
        $page_length = isset($request->pagesize) ? $request->pagesize : 20;
        if(isset($request->pagesize) && $request->pagesize == 'all')
        {
            $cats = (new Collection(Product::filterProducts($oldcats)))->paginate($oldcats->count())->appends(request()->query());
        }
        else
        {
            $page_length = isset($request->pagesize) ? $request->pagesize : 20;
            $cats = (new Collection(Product::filterProducts($oldcats)))->paginate($page_length)->appends(request()->query());
        }
        // Search By Price
        if(!isset($request->filter_clear) && ($request->filter_clear != 'true'))
        {
            if(!empty($request->price_filter) || (isset($request->attr) && !empty($request->attr)) || (isset($request->category_id) && !empty($request->category_id)))
            {
                $price_filter = explode('-', $request->price_filter);

                $min = trim($price_filter[0]);
                $max = trim($price_filter[1]);

                $data = DB::table('product_variations')->select('product_id')->whereBetween('price', [$min, $max])->get();
                $prd_ids = array();$product_ids = array();
                foreach($data as $prd)
                {
                    array_push($prd_ids, $prd->product_id);
                }
                if(isset($request->attr) && !empty($request->attr))
                {
                    $filters = $request->attr;
                    
                    foreach($filters as $key => $filter)
                    {
                        foreach($filter as $val)
                        {
                            //echo $val;
                            $data = DB::table('product_variations')->select('product_id')->where('json_attributes','like', DB::raw("'%".$val."%'"))->get();
                            foreach($data as $prdId)
                            {
                                array_push($product_ids, $prdId->product_id);
                            }
                        }
                    }
                    $product_ids = array_unique($product_ids);
                    $product_ids = array_filter($product_ids);
                }

                $oldcats = $cat->products()->where('status','=',1)->where(function($query) use ($min,$max,$prd_ids) {
                        $query->orWhereBetween('price', [$min, $max])
                              ->orWhereIn('products.id', $prd_ids);
                });
                if(!empty($product_ids))
                {
                    $oldcats = $oldcats->whereIn('products.id',$product_ids);    
                }
                if((isset($request->category_id) && !empty($request->category_id)))
                {
                    $filtered_cat = $request->category_id;
                    $oldcats = $oldcats->whereIn('products.category_id',$request->category_id)->orWhereIn('products.subcategory_id',$request->category_id);
                    //echo $oldcats->toSql();exit;
                }
                $oldcats = $oldcats->orderBy('price','asc')->get();
                //$oldcats = $cat->products()->where('status','=',1)->whereBetween('price', [$min, $max])->orderBy('price','asc')->get();
                if(isset($request->pagesize) && $request->pagesize == 'all')
                {
                    $cats = (new Collection(Product::filterProducts($oldcats)))->sortBy('price')->paginate($oldcats->count())->appends(request()->query());
                }
                else
                {
                    $page_length = isset($request->pagesize) ? $request->pagesize : 20;
                    $cats = (new Collection(Product::filterProducts($oldcats)))->sortBy('price')->paginate($page_length)->appends(request()->query());
                }
                if($request->ajax()){
                    return view('front.pagination.category',compact('cat','cats','sort','min','max','curr'));
                }
                //return view('front.category',compact('cat','sort','cats','curr','layout_type','page_length','categories','latest_products','attr_arr','min_price','max_price'));
            }
        }
        
        /*if(isset($request->attr) && !empty($request->attr))
        {
            $filters = $request->attr;
            $product_ids = array();
            foreach($filters as $key => $filter)
            {
                foreach($filter as $val)
                {
                    //echo $val;
                    $data = DB::table('product_variations')->select('product_id')->where('json_attributes','like', DB::raw("'%".$val."%'"))->get();
                    foreach($data as $prdId)
                    {
                        array_push($product_ids, $prdId->product_id);
                    }
                }
            }
            $product_ids = array_unique($product_ids);
            $product_ids = array_filter($product_ids);
            $oldcats = $cat->products()->whereIn('id',$product_ids)->orderBy('id','desc')->get();
            if(isset($request->pagesize) && $request->pagesize == 'all')
            {
                $cats = (new Collection(Product::filterProducts($oldcats)))->paginate($oldcats->count())->appends(request()->query());
            }
            else
            {
                $page_length = isset($request->pagesize) ? $request->pagesize : 20;
                $cats = (new Collection(Product::filterProducts($oldcats)))->paginate($page_length)->appends(request()->query());
            }
        }*/
        // Search By Sort
        if( !empty($request->sort))
        {
            $sort = $request->sort;
            if($sort == 'date')
            {
                $oldcats = $cat->products()->where('status','=',1)->orderBy('id','desc')->get();
                if(isset($request->pagesize) && $request->pagesize == 'all')
                {
                    $cats = (new Collection(Product::filterProducts($oldcats)))->paginate($oldcats->count())->appends(request()->query());
                }
                else
                {
                    $page_length = isset($request->pagesize) ? $request->pagesize : 20;
                    $cats = (new Collection(Product::filterProducts($oldcats)))->paginate($page_length)->appends(request()->query());
                }
            }
            else if($sort == 'alphabet')
            {
                $oldcats = $cat->products()->where('status','=',1)->orderBy('name','asc')->get();
                if(isset($request->pagesize) && $request->pagesize == 'all')
                {
                    $cats = (new Collection(Product::filterProducts($oldcats)))->paginate($oldcats->count())->appends(request()->query());
                }
                else
                {
                    $page_length = isset($request->pagesize) ? $request->pagesize : 20;
                    $cats = (new Collection(Product::filterProducts($oldcats)))->paginate($page_length)->appends(request()->query());
                }
            }
            else if($sort == 'featured')
            {
                $oldcats = $cat->products()->where('status','=',1)->orderBy('featured','desc')->get();
                if(isset($request->pagesize) && $request->pagesize == 'all')
                {
                    $cats = (new Collection(Product::filterProducts($oldcats)))->paginate($oldcats->count())->appends(request()->query());
                }
                else
                {
                    $page_length = isset($request->pagesize) ? $request->pagesize : 20;
                    $cats = (new Collection(Product::filterProducts($oldcats)))->paginate($page_length)->appends(request()->query());
                }
            }
            else if($sort == 'promotional')
            {
                $oldcats = $cat->products()->where('status','=',1)->orderBy('promotional','desc')->get();
                if(isset($request->pagesize) && $request->pagesize == 'all')
                {
                    $cats = (new Collection(Product::filterProducts($oldcats)))->paginate($oldcats->count())->appends(request()->query());
                }
                else
                {
                    $page_length = isset($request->pagesize) ? $request->pagesize : 20;
                    $cats = (new Collection(Product::filterProducts($oldcats)))->paginate($page_length)->appends(request()->query());
                }
            }
            else if($sort == "rating")
            {
                $oldcats = $cat->products()->where('status','=',1)->leftJoin('ratings', 'products.id', '=', 'ratings.product_id')->addSelect(DB::raw('AVG(ratings.rating) as average_rating'))->groupBy('products.id')->orderBy('average_rating', 'desc')->get();
                
                if(isset($request->pagesize) && $request->pagesize == 'all')
                {
                    $cats = (new Collection(Product::filterProducts($oldcats)))->paginate($oldcats->count())->appends(request()->query());
                }
                else
                {
                    $page_length = isset($request->pagesize) ? $request->pagesize : 20;
                    $cats = (new Collection(Product::filterProducts($oldcats)))->paginate($page_length)->appends(request()->query());
                }
                if(isset($request->pagesize) && $request->pagesize == 'all')
                {
                    $cats = (new Collection(Product::filterProducts($oldcats)))->paginate($oldcats->count())->appends(request()->query());
                }
                else
                {
                    $page_length = isset($request->pagesize) ? $request->pagesize : 20;
                    $cats = (new Collection(Product::filterProducts($oldcats)))->paginate($page_length)->appends(request()->query());
                }
            }
            else if($sort == "popularity")
            {
                $oldcats = $cat->products()->where('status','=',1)->leftJoin('ratings', 'products.id', '=', 'ratings.product_id')->addSelect(DB::raw('AVG(ratings.rating) as average_rating'))->groupBy('products.id')->orderBy('average_rating', 'desc')->get();
                
                if(isset($request->pagesize) && $request->pagesize == 'all')
                {
                    $cats = (new Collection(Product::filterProducts($oldcats)))->paginate($oldcats->count())->appends(request()->query());
                }
                else
                {
                    $page_length = isset($request->pagesize) ? $request->pagesize : 20;
                    $cats = (new Collection(Product::filterProducts($oldcats)))->paginate($page_length)->appends(request()->query());
                }
                $oldcats = $cat->products()->where('status','=',1)->orderBy('id','desc')->get();
                if(isset($request->pagesize) && $request->pagesize == 'all')
                {
                    $cats = (new Collection(Product::filterProducts($oldcats)))->paginate($oldcats->count())->appends(request()->query());
                }
                else
                {

                    $page_length = isset($request->pagesize) ? $request->pagesize : 20;
                    $cats = (new Collection(Product::filterProducts($oldcats)))->paginate($page_length)->appends(request()->query());
                }
            }
            else if($sort == 'price')
            {
                $oldcats = $cat->products()->where('status','=',1)->orderBy('price','asc')->get();
                if(isset($request->pagesize) && $request->pagesize == 'all')
                {
                    $cats = (new Collection(Product::filterProducts($oldcats)))->sortBy('price')->paginate($oldcats->count())->appends(request()->query());
                }
                else
                {
                    $page_length = isset($request->pagesize) ? $request->pagesize : 20;
                    $cats = (new Collection(Product::filterProducts($oldcats)))->sortBy('price')->paginate($page_length)->appends(request()->query());
                }
            }
            else if($sort == 'price-desc')
            {
                $oldcats = $cat->products()->where('status','=',1)->orderBy('price','desc')->get();
                
                if(isset($request->pagesize) && $request->pagesize == 'all')
                {
                    $cats = (new Collection(Product::filterProducts($oldcats)))->sortByDesc('price')->paginate($oldcats->count())->appends(request()->query());
                }
                else
                {
                    $page_length = isset($request->pagesize) ? $request->pagesize : 20;
                    $cats = (new Collection(Product::filterProducts($oldcats)))->sortByDesc('price')->paginate($page_length)->appends(request()->query());
                }
            }
            if($request->ajax()){
                return view('front.pagination.category',compact('cat','cats','sort'));
            }
            if($subcategory->count() > 0)
            {
                return view('front.categories',compact('cat','sort','cats','curr','layout_type','page_length','categories','latest_products','attr_arr','min_price','max_price','filters','subcategory','arabic_attr'));
            }
            else
            {
                return view('front.categories',compact('cat','sort','cats','curr','layout_type','page_length','categories','latest_products','attr_arr','min_price','max_price','filters','subcategory','arabic_attr'));
            }
        }
        // Otherwise Go To Category
        if($request->ajax()){
            return view('front.pagination.category',compact('cat','sort','cats'));
        }    
        if($subcategory->count() > 0)
        {
            return view('front.categories',compact('cat','sort','cats','curr','layout_type','page_length','categories','latest_products','attr_arr','min_price','max_price','filters','subcategory','arabic_attr','filtered_cat'));
        }
        else
        {
            return view('front.categories',compact('cat','sort','cats','curr','layout_type','page_length','categories','latest_products','attr_arr','min_price','max_price','filters','subcategory','arabic_attr','filtered_cat'));
        }
    }

    public function subcategory(Request $request,$slug1,$slug2)
    {
        
        $filters=array();
        $min='';
        $max='';
        $minprice='';
        $maxprice='';

        $this->code_image();
        $sort = "date";
        if (Session::has('currency')) 
        {
            $curr = Currency::find(Session::get('currency'));
        }
        else
        {
            $curr = Currency::where('is_default','=',1)->first();
        }
        $curr = $curr->sign;
        $subcat = Subcategory::where('slug','=',$slug2)->first();
        $cat = Category::where('status',1)->where('slug','=',$slug1)->get()->first();
        $categories = Category::where('status',1)->where('slug','!=',$slug1)->get();
        $parent_cat_id = Category::select('id')->where('slug',$slug1)->get()->first();
        $parent_cat_id = $parent_cat_id->id;
        $sub_cat_id = isset($subcat->id) ? $subcat->id : '';
        
        $cate_pr=DB::table('products')->where('status',1)->where('category_id',$cat->id)->where('subcategory_id',$sub_cat_id)->get();
        
        $latest_products = Product::where('latest','=',1)->where('status','=',1)->where('category_id',$parent_cat_id)->where('subcategory_id',$sub_cat_id)->take(18)->get();
        $oldcats = $subcat->products()->where('status','=',1)->orderBy('id','desc')->get();
        $layout_type = !empty(request()->query('layout')) ? request()->query('layout') : 'grid';
        $product_variations = DB::table('product_variations')->select('attribute_names','attribute_values')->join('products', 'products.id', '=', 'product_variations.product_id')->where('status',1)->where('category_id',$cat->id)->get();
        $attr_arr = array();
        foreach ($product_variations as $key => $attribute) {
            $attribute_names = explode('-', $attribute->attribute_names);
            $attribute_values = explode('-', $attribute->attribute_values);
            foreach ($attribute_names as $attrkey => $attrvalue) {
               //echo $attrvalue."---".$attribute_values[$attrkey]."<br>";
                if(!empty($attribute_values[$attrkey]))
                $attr_arr[$attrvalue][$key] = $attribute_values[$attrkey];
            }
            //print_r($attribute_values);exit;
        }
        $filtered_cat = $request->category_id;
        $filtered_sub_cat = $request->sub_category_id;
        $min_max_price = DB::table('product_variations')->select(DB::raw("min(product_variations.price) as min_price"),DB::raw("max(product_variations.price) as max_price"))->join('products', 'products.id', '=', 'product_variations.product_id')->where('status',1)->where('category_id',$cat->id)->get()->first();

        $default_min_max_price = DB::table('products')->select(DB::raw("min(products.price) as min_price"),DB::raw("max(products.price) as max_price"))->where('status',1)->where('category_id',$cat->id)->get()->first();
        $default_min = $default_min_max_price->min_price;
        $default_max = $default_min_max_price->max_price;

        $min_price = min(array($min_max_price->min_price,$default_min));
        $max_price = max(array($min_max_price->max_price, $default_max));
        $page_length = isset($request->pagesize) ? $request->pagesize : 20;

        if(isset($request->pagesize) && $request->pagesize == 'all')
        {
            $cats = (new Collection(Product::filterProducts($oldcats)))->paginate($oldcats->count())->appends(request()->query());
        }
        else 
        {
            $page_length = isset($request->pagesize) ? $request->pagesize : 20;
            $cats = (new Collection(Product::filterProducts($oldcats)))->paginate($page_length)->appends(request()->query());
        }
        // Search By Price
        // Search By Price
        if(!isset($request->filter_clear) && ($request->filter_clear != 'true'))
        {
            if(!empty($request->price_filter) || isset($request->attr) && !empty($request->attr))
            {
                $price_filter = explode('-', $request->price_filter);

                $minprice = trim($price_filter[0]);
                $maxprice = trim($price_filter[1]);
                $data = DB::table('product_variations')->select('product_id')->whereBetween('price', [$minprice, $maxprice])->get();
                $prd_ids = array();$product_ids = array();
                foreach($data as $prd)
                {
                    array_push($prd_ids, $prd->product_id);
                }
                if(isset($request->attr) && !empty($request->attr))
                {
                    $filters = $request->attr;
                    
                    foreach($filters as $key => $filter)
                    {
                        foreach($filter as $val)
                        {
                            //echo $val;
                            $data = DB::table('product_variations')->select('product_id')->where('json_attributes','like', DB::raw("'%".$val."%'"))->get();
                            foreach($data as $prdId)
                            {
                                array_push($product_ids, $prdId->product_id);
                            }
                        }
                    }
                    $product_ids = array_unique($product_ids);
                    $product_ids = array_filter($product_ids);
                }

                $oldcats = $cat->products()->where('status','=',1)->where(function($query) use ($minprice,$maxprice,$prd_ids) {
                        $query->orWhereBetween('price', [$minprice, $maxprice])
                              ->orWhereIn('products.id', $prd_ids);
                });
                if(!empty($product_ids))
                {
                    $oldcats = $oldcats->whereIn('products.id',$product_ids);    
                }
                $oldcats = $oldcats->where('subcategory_id',$sub_cat_id)->orderBy('price','asc')->get();
                //$oldcats = $cat->products()->where('status','=',1)->whereBetween('price', [$min, $max])->orderBy('price','asc')->get();
                if(isset($request->pagesize) && $request->pagesize == 'all')
                {
                    $cats = (new Collection(Product::filterProducts($oldcats)))->sortBy('price')->paginate($oldcats->count())->appends(request()->query());
                }
                else
                {
                    $page_length = isset($request->pagesize) ? $request->pagesize : 20;
                    $cats = (new Collection(Product::filterProducts($oldcats)))->sortBy('price')->paginate($page_length)->appends(request()->query());
                }
            }
        }
        
        /*if(isset($request->attr) && !empty($request->attr))
        {
            $filters = $request->attr;
            $product_ids = array();
            foreach($filters as $key => $filter)
            {
                foreach($filter as $val)
                {
                    //echo $val;
                    $data = DB::table('product_variations')->select('product_id')->where('json_attributes','like', DB::raw("'%".$val."%'"))->get();
                    foreach($data as $prdId)
                    {
                        array_push($product_ids, $prdId->product_id);
                    }
                }
            }
            $product_ids = array_unique($product_ids);
            $product_ids = array_filter($product_ids);
            $oldcats = $cat->products()->whereIn('id',$product_ids)->orderBy('id','desc')->get();
            if(isset($request->pagesize) && $request->pagesize == 'all')
            {
                $cats = (new Collection(Product::filterProducts($oldcats)))->paginate($oldcats->count())->appends(request()->query());
            }
            else
            {
                $page_length = isset($request->pagesize) ? $request->pagesize : 20;
                $cats = (new Collection(Product::filterProducts($oldcats)))->paginate($page_length)->appends(request()->query());
            }
        }*/
        if(!empty($request->min) || !empty($request->max))
        {
            $min = $request->min;
            $max = $request->max;
            $oldcats = $subcat->products()->where('status','=',1)->whereBetween('price', [$min, $max])->orderBy('price','asc')->get();
            $cats = (new Collection(Product::filterProducts($oldcats)))->sortBy('price')->paginate(9);
            /*if($request->ajax()){
                return view('front.pagination.category',compact('subcat','cats','sort','min','max'));
            }*/
            return view('front.subcategory',compact('subcat','cats','sort','min','max','filtered_cat','filtered_sub_cat','cate_pr'));
        }
        
        // Search By Sort
        if( !empty($request->sort) )
        {
            $sort = $request->sort;
            if($sort == 'date')
            {
                $oldcats = $subcat->products()->where('status','=',1)->orderBy('id','desc')->get();
                if(isset($request->pagesize) && $request->pagesize == 'all')
                {
                    $cats = (new Collection(Product::filterProducts($oldcats)))->paginate($oldcats->count())->appends(request()->query());
                }
                else
                {
                    $page_length = isset($request->pagesize) ? $request->pagesize : 20;
                    $cats = (new Collection(Product::filterProducts($oldcats)))->paginate($page_length)->appends(request()->query());
                }
            }
            else if($sort == 'alphabet')
            {
                $oldcats = $cat->products()->where('status','=',1)->orderBy('name','asc')->get();
                if(isset($request->pagesize) && $request->pagesize == 'all')
                {
                    $cats = (new Collection(Product::filterProducts($oldcats)))->paginate($oldcats->count())->appends(request()->query());
                }
                else
                {
                    $page_length = isset($request->pagesize) ? $request->pagesize : 20;
                    $cats = (new Collection(Product::filterProducts($oldcats)))->paginate($page_length)->appends(request()->query());
                }
            }
            else if($sort == 'alphabet-desc')
            {
                $oldcats = $cat->products()->where('status','=',1)->orderBy('name','desc')->get();
                if(isset($request->pagesize) && $request->pagesize == 'all')
                {
                    $cats = (new Collection(Product::filterProducts($oldcats)))->paginate($oldcats->count())->appends(request()->query());
                }
                else
                {
                    $page_length = isset($request->pagesize) ? $request->pagesize : 20;
                    $cats = (new Collection(Product::filterProducts($oldcats)))->paginate($page_length)->appends(request()->query());
                }
            }
            else if($sort == 'featured')
            {
                $oldcats = $cat->products()->where('status','=',1)->orderBy('featured','desc')->get();
                if(isset($request->pagesize) && $request->pagesize == 'all')
                {
                    $cats = (new Collection(Product::filterProducts($oldcats)))->paginate($oldcats->count())->appends(request()->query());
                }
                else
                {
                    $page_length = isset($request->pagesize) ? $request->pagesize : 20;
                    $cats = (new Collection(Product::filterProducts($oldcats)))->paginate($page_length)->appends(request()->query());
                }
            }
            else if($sort == 'promotional')
            {
                $oldcats = $cat->products()->where('status','=',1)->orderBy('promotional','desc')->get();
                if(isset($request->pagesize) && $request->pagesize == 'all')
                {
                    $cats = (new Collection(Product::filterProducts($oldcats)))->paginate($oldcats->count())->appends(request()->query());
                }
                else
                {
                    $page_length = isset($request->pagesize) ? $request->pagesize : 20;
                    $cats = (new Collection(Product::filterProducts($oldcats)))->paginate($page_length)->appends(request()->query());
                }
            }
            else if($sort == "rating")
            {
                $oldcats = $subcat->products()->where('status','=',1)->leftJoin('ratings', 'products.id', '=', 'ratings.product_id')->addSelect(DB::raw('AVG(ratings.rating) as average_rating'))->groupBy('products.id')->orderBy('average_rating', 'desc')->get();
                
                if(isset($request->pagesize) && $request->pagesize == 'all')
                {
                    $cats = (new Collection(Product::filterProducts($oldcats)))->paginate($oldcats->count())->appends(request()->query());
                }
                else
                {
                    $page_length = isset($request->pagesize) ? $request->pagesize : 20;
                    $cats = (new Collection(Product::filterProducts($oldcats)))->paginate($page_length)->appends(request()->query());
                }
                if(isset($request->pagesize) && $request->pagesize == 'all')
                {
                    $cats = (new Collection(Product::filterProducts($oldcats)))->paginate($oldcats->count())->appends(request()->query());
                }
                else
                {
                    $page_length = isset($request->pagesize) ? $request->pagesize : 20;
                    $cats = (new Collection(Product::filterProducts($oldcats)))->paginate($page_length)->appends(request()->query());
                }
            }
            else if($sort == "popularity")
            {
                $oldcats = $subcat->products()->where('status','=',1)->leftJoin('ratings', 'products.id', '=', 'ratings.product_id')->addSelect(DB::raw('AVG(ratings.rating) as average_rating'))->groupBy('products.id')->orderBy('average_rating', 'desc')->get();
                
                if(isset($request->pagesize) && $request->pagesize == 'all')
                {
                    $cats = (new Collection(Product::filterProducts($oldcats)))->paginate($oldcats->count())->appends(request()->query());
                }
                else
                {
                    $page_length = isset($request->pagesize) ? $request->pagesize : 20;
                    $cats = (new Collection(Product::filterProducts($oldcats)))->paginate($page_length)->appends(request()->query());
                }
                $oldcats = $cat->products()->where('status','=',1)->orderBy('id','desc')->get();
                if(isset($request->pagesize) && $request->pagesize == 'all')
                {
                    $cats = (new Collection(Product::filterProducts($oldcats)))->paginate($oldcats->count())->appends(request()->query());
                }
                else
                {

                    $page_length = isset($request->pagesize) ? $request->pagesize : 20;
                    $cats = (new Collection(Product::filterProducts($oldcats)))->paginate($page_length)->appends(request()->query());
                }
            }
            else if($sort == 'price')
            {
                $oldcats = $subcat->products()->where('status','=',1)->orderBy('price','asc')->get();
                if(isset($request->pagesize) && $request->pagesize == 'all')
                {
                    $cats = (new Collection(Product::filterProducts($oldcats)))->sortBy('price')->paginate($oldcats->count())->appends(request()->query());
                }
                else
                {
                    $page_length = isset($request->pagesize) ? $request->pagesize : 20;
                    $cats = (new Collection(Product::filterProducts($oldcats)))->sortBy('price')->paginate($page_length)->appends(request()->query());
                }
            }
            else if($sort == 'price-desc')
            {
                $oldcats = $subcat->products()->where('status','=',1)->orderBy('price','desc')->get();
                
                if(isset($request->pagesize) && $request->pagesize == 'all')
                {
                    $cats = (new Collection(Product::filterProducts($oldcats)))->sortByDesc('price')->paginate($oldcats->count())->appends(request()->query());
                }
                else
                {
                    $page_length = isset($request->pagesize) ? $request->pagesize : 20;
                    $cats = (new Collection(Product::filterProducts($oldcats)))->sortByDesc('price')->paginate($page_length)->appends(request()->query());
                }
            }
            /*if($request->ajax()){
                return view('front.pagination.category',compact('subcat','cats','sort'));
            }*/
            if($min_price == $max_price)
                $min_price = 0;

            return view('front.subcategory',compact('cat','sort','cats','curr','layout_type','page_length','categories','latest_products','attr_arr','min_price','max_price','filters','subcategory','subcat','filtered_cat','filtered_sub_cat','minprice','maxprice','cate_pr'));
        }
        // Otherwise Go To Category
        /*if($request->ajax()){
            return view('front.pagination.category',compact('subcat','sort','cats'));
        }    */
        if($min_price == $max_price)
                $min_price = 0;
                
                //return $cats;
        return view('front.subcategory',compact('cat','sort','cats','curr','layout_type','page_length','categories','latest_products','attr_arr','min_price','max_price','filters','min','max','subcat','filtered_cat','filtered_sub_cat','minprice','maxprice','cate_pr'));
    }

    public function childcategory(Request $request,$slug1,$slug2,$slug3)
    {
        $this->code_image();
        $sort = "";
        $childcat = Childcategory::where('slug','=',$slug3)->first();
        $oldcats = $childcat->products()->where('status','=',1)->orderBy('id','desc')->get();
        $cats = (new Collection(Product::filterProducts($oldcats)))->paginate(9);

        // Search By Price

    if(!empty($request->min) || !empty($request->max))
    {
        $min = $request->min;
        $max = $request->max;
        $oldcats = $childcat->products()->where('status','=',1)->whereBetween('price', [$min, $max])->orderBy('price','asc')->get();
        $cats = (new Collection(Product::filterProducts($oldcats)))->sortBy('price')->paginate(9);
        if($request->ajax()){
            return view('front.pagination.category',compact('childcat','cats','sort','min','max'));
        }
        return view('front.category',compact('childcat','cats','sort','min','max'));
    }

        // Search By Sort

    if( !empty($request->sort) )
    {
        $sort = $request->sort;
        if($sort == "new")
        {
        $oldcats = $childcat->products()->where('status','=',1)->orderBy('id','desc')->get();
        $cats = (new Collection(Product::filterProducts($oldcats)))->paginate(9);
        }
        else if($sort == "old")
        {
        $oldcats = $childcat->products()->where('status','=',1)->get();
        $cats = (new Collection(Product::filterProducts($oldcats)))->paginate(9);
        }
        else if($sort == "low")
        {
        $oldcats = $childcat->products()->where('status','=',1)->orderBy('price','asc')->get();
        $cats = (new Collection(Product::filterProducts($oldcats)))->sortBy('price')->paginate(9);
        }
        else if($sort == "high")
        {
        $oldcats = $childcat->products()->where('status','=',1)->orderBy('price','desc')->get();
        $cats = (new Collection(Product::filterProducts($oldcats)))->sortByDesc('price')->paginate(9);
        }
        if($request->ajax()){
            return view('front.pagination.category',compact('childcat','cats','sort'));
        }
        
        return view('front.category',compact('childcat','cats','sort'));
    }

        // Otherwise Go To Category

        if($request->ajax()){
            return view('front.pagination.category',compact('childcat','sort','cats'));
        }    
        return view('front.category',compact('childcat','sort','cats'));
        }



    public function tag(Request $request, $tag)
    {
        $this->code_image();
       $tags = $tag;
       $sort = '';
       $oldcats = Product::where('tags', 'like', '%' . $tags . '%')->where('status','=',1)->orderBy('id','desc')->get();
       $products = (new Collection(Product::filterProducts($oldcats)))->paginate(9);

        // Search By Price

    if(!empty($request->min) || !empty($request->max))
    {
        $min = $request->min;
        $max = $request->max;
       $oldcats = Product::where('tags', 'like', '%' . $tags . '%')->where('status','=',1)->whereBetween('price', [$min, $max])->orderBy('price','asc')->get();
       $products = (new Collection(Product::filterProducts($oldcats)))->sortBy('price')->paginate(9);
        if($request->ajax()){
            return view('front.pagination.tags',compact('products','tags','sort','min','max'));
        }
        return view('front.tags',compact('products','tags','sort','min','max'));
    }

        // Search By Sort

    if( !empty($request->sort) )
    {
        $sort = $request->sort;
        if($sort == "new")
        {
        $oldcats = Product::where('tags', 'like', '%' . $tags . '%')->where('status','=',1)->orderBy('id','desc')->get();
        $products = (new Collection(Product::filterProducts($oldcats)))->paginate(9);
        }
        else if($sort == "old")
        {
        $oldcats = Product::where('tags', 'like', '%' . $tags . '%')->where('status','=',1)->get();
        $products = (new Collection(Product::filterProducts($oldcats)))->paginate(9);
        }
        else if($sort == "low")
        {
        $oldcats = Product::where('tags', 'like', '%' . $tags . '%')->where('status','=',1)->orderBy('price','asc')->get();
        $products = (new Collection(Product::filterProducts($oldcats)))->sortBy('price')->paginate(9);
        }
        else if($sort == "high")
        {
        $oldcats = Product::where('tags', 'like', '%' . $tags . '%')->where('status','=',1)->orderBy('price','desc')->get();
        $products = (new Collection(Product::filterProducts($oldcats)))->sortByDesc('price')->paginate(9);
        }
        if($request->ajax()){
            return view('front.pagination.tags',compact('products','tags','sort'));
        }
        
        return view('front.tags',compact('products','tags','sort'));
    }

        // Otherwise Go To Tags

        if($request->ajax()){
            return view('front.pagination.tags',compact('products','tags','sort'));
        }   
       return view('front.tags', compact('products','tags','sort'));
    }


    public function search(Request $request)
    {
        
        $min=0;
        $max=0;
        $this->code_image();
        if (Session::has('currency')) 
        {
            $curr = Currency::find(Session::get('currency'));
        }
        else
        {
            $curr = Currency::where('is_default','=',1)->first();
        }
        $curr = $curr->sign;
        $search = $request->search;
        $layout_type = !empty(request()->query('layout')) ? request()->query('layout') : 'grid';
         $min_max_price = DB::table('product_variations')->select(DB::raw("min(product_variations.price) as min_price"),DB::raw("max(product_variations.price) as max_price"))->join('products', 'products.id', '=', 'product_variations.product_id')->where('status',1)->get()->first();

        $default_min_max_price = DB::table('products')->select(DB::raw("min(products.price) as min_price"),DB::raw("max(products.price) as max_price"))->where('status',1)->get()->first();
        $default_min = $default_min_max_price->min_price;
        $default_max = $default_min_max_price->max_price;

        $min_price = min(array($min_max_price->min_price,$default_min));
        $max_price = max(array($min_max_price->max_price, $default_max));
        $page_length = isset($request->pagesize) ? $request->pagesize : 20;
        $collection_id = $request->collection_id;
        if(!empty($request->collection_id))
        {
            // *********************** CATALOG SEARCH SECTION ******************
           $cat_id = $request->collection_id;
           $sort = '';
            // Search By Sort
            if( !empty($request->sort) )
            {
                $min = $request->min;
                $max = $request->max;
                $sort = $request->sort;
                if($sort == 'date')
                {
                   $oldcats = Product::where('collection_id',  $collection_id)->where('status','=',1)->orderBy('id','desc')->get();
                    if(isset($request->pagesize) && $request->pagesize == 'all')
                    {
                        $products = (new Collection(Product::filterProducts($oldcats)))->paginate($oldcats->count())->appends(request()->query());
                    }
                    else
                    {
                        $page_length = isset($request->pagesize) ? $request->pagesize : 20;
                        $products = (new Collection(Product::filterProducts($oldcats)))->paginate($page_length)->appends(request()->query());
                    }
                }
                else if($sort == 'alphabet')
                {
                    $oldcats = Product::where('collection_id',  $collection_id)->where('status','=',1)->orderBy('name','asc')->get();
                    if(isset($request->pagesize) && $request->pagesize == 'all')
                    {
                        $products = (new Collection(Product::filterProducts($oldcats)))->paginate($oldcats->count())->appends(request()->query());
                    }
                    else
                    {
                        $page_length = isset($request->pagesize) ? $request->pagesize : 20;
                        $products = (new Collection(Product::filterProducts($oldcats)))->paginate($page_length)->appends(request()->query());
                    }
                }
                else if($sort == 'featured')
                {
                    $oldcats = Product::where('collection_id',  $collection_id)->where('status','=',1)->orderBy('featured','desc')->get();
                    if(isset($request->pagesize) && $request->pagesize == 'all')
                    {
                        $products = (new Collection(Product::filterProducts($oldcats)))->paginate($oldcats->count())->appends(request()->query());
                    }
                    else
                    {
                        $page_length = isset($request->pagesize) ? $request->pagesize : 20;
                        $products = (new Collection(Product::filterProducts($oldcats)))->paginate($page_length)->appends(request()->query());
                    }
                }
                else if($sort == 'promotional')
                {
                    $oldcats = Product::where('collection_id',  $collection_id)->where('status','=',1)->orderBy('promotional','desc')->get();
                    if(isset($request->pagesize) && $request->pagesize == 'all')
                    {
                        $products = (new Collection(Product::filterProducts($oldcats)))->paginate($oldcats->count())->appends(request()->query());
                    }
                    else
                    {
                        $page_length = isset($request->pagesize) ? $request->pagesize : 20;
                        $products = (new Collection(Product::filterProducts($oldcats)))->paginate($page_length)->appends(request()->query());
                    }
                }
                else if($sort == "rating")
                {
                    $oldcats = Product::where('collection_id',  $collection_id)->where('status','=',1)->leftJoin('ratings', 'products.id', '=', 'ratings.product_id')->addSelect(DB::raw('AVG(ratings.rating) as average_rating'))->groupBy('products.id')->orderBy('average_rating', 'desc')->get();
                    if(isset($request->pagesize) && $request->pagesize == 'all')
                    {
                        $products = (new Collection(Product::filterProducts($oldcats)))->paginate($oldcats->count())->appends(request()->query());
                    }
                    else
                    {
                        $page_length = isset($request->pagesize) ? $request->pagesize : 20;
                        $products = (new Collection(Product::filterProducts($oldcats)))->paginate($page_length)->appends(request()->query());
                    }
                    if(isset($request->pagesize) && $request->pagesize == 'all')
                    {
                        $products = (new Collection(Product::filterProducts($oldcats)))->paginate($oldcats->count())->appends(request()->query());
                    }
                    else
                    {
                        $page_length = isset($request->pagesize) ? $request->pagesize : 20;
                        $products = (new Collection(Product::filterProducts($oldcats)))->paginate($page_length)->appends(request()->query());
                    }
                }
                else if($sort == "popularity")
                {
                    $oldcats = Product::where('collection_id',  $collection_id)->where('status','=',1)->leftJoin('ratings', 'products.id', '=', 'ratings.product_id')->addSelect(DB::raw('AVG(ratings.rating) as average_rating'))->groupBy('products.id')->orderBy('average_rating', 'desc')->get();
                    
                    if(isset($request->pagesize) && $request->pagesize == 'all')
                    {
                        $products = (new Collection(Product::filterProducts($oldcats)))->paginate($oldcats->count())->appends(request()->query());
                    }
                    else
                    {
                        $page_length = isset($request->pagesize) ? $request->pagesize : 20;
                        $products = (new Collection(Product::filterProducts($oldcats)))->paginate($page_length)->appends(request()->query());
                    }
                    $oldcats = Product::where('collection_id',  $collection_id)->where('status','=',1)->orderBy('id','desc')->get();
                    if(isset($request->pagesize) && $request->pagesize == 'all')
                    {
                        $products = (new Collection(Product::filterProducts($oldcats)))->paginate($oldcats->count())->appends(request()->query());
                    }
                    else
                    {

                        $page_length = isset($request->pagesize) ? $request->pagesize : 20;
                        $products = (new Collection(Product::filterProducts($oldcats)))->paginate($page_length)->appends(request()->query());
                    }
                }
                else if($sort == 'price')
                {
                    $oldcats = Product::where('collection_id',  $collection_id)->where('status','=',1)->orderBy('price','asc')->get();
                    if(isset($request->pagesize) && $request->pagesize == 'all')
                    {
                        $products = (new Collection(Product::filterProducts($oldcats)))->sortBy('price')->paginate($oldcats->count())->appends(request()->query());
                    }
                    else
                    {
                        $page_length = isset($request->pagesize) ? $request->pagesize : 20;
                        $products = (new Collection(Product::filterProducts($oldcats)))->sortBy('price')->paginate($page_length)->appends(request()->query());
                    }
                }
                else if($sort == 'price-desc')
                {
                    $oldcats = Product::where('collection_id',  $collection_id)->orderBy('price','desc')->get();
                    
                    if(isset($request->pagesize) && $request->pagesize == 'all')
                    {
                        $products = (new Collection(Product::filterProducts($oldcats)))->sortByDesc('price')->paginate($oldcats->count())->appends(request()->query());
                    }
                    else
                    {
                        $page_length = isset($request->pagesize) ? $request->pagesize : 20;
                        $products = (new Collection(Product::filterProducts($oldcats)))->sortByDesc('price')->paginate($page_length)->appends(request()->query());
                    }
                }
                
                return view('front.search',compact('products','search','collection_id','sort','min','max','layout_type','page_length','curr'));
            }
            // Search By Price

            // Otherwise Go To Tags
            if($request->ajax()){
                return view('front.pagination.search',compact('products','cat_id','sort'));
            }   
            $oldcats = Product::where('name', 'like', '%' . $search . '%')->where('status','=',1)->where('collection_id','like', '%' . $collection_id . '%')->orderBy('price','desc')->get();
            $products = (new Collection(Product::filterProducts($oldcats)))->sortByDesc('price')->paginate($page_length);
            
         
            return view('front.search',compact('products','search','cat_id','sort','min','max','layout_type','page_length','curr'));
            // *********************** CATALOG SEARCH SECTION ENDS ******************
        }
        else 
        {
            
            //return 1;
            // *********************** NORMAL SEARCH SECTION ******************
            $sort='';
            $collection_id = $request->collection_id; 
            $search = $request->search;
            if($collection_id == 0) {
                // SORT SEARCH
                if( !empty($request->sort) )
                {
                    $sort = $request->sort;
                    if($sort == 'date')
                    {
                       $oldcats = Product::where('name', 'like', '%' . $search . '%')->where('status','=',1)->orderBy('id','desc')->get();
                        if(isset($request->pagesize) && $request->pagesize == 'all')
                        {
                            $products = (new Collection(Product::filterProducts($oldcats)))->paginate($oldcats->count())->appends(request()->query());
                        }
                        else
                        {
                            $page_length = isset($request->pagesize) ? $request->pagesize : 20;
                            $products = (new Collection(Product::filterProducts($oldcats)))->paginate($page_length)->appends(request()->query());
                        }
                    }
                    else if($sort == 'alphabet')
                    {
                        $oldcats = Product::where('name', 'like', '%' . $search . '%')->where('status','=',1)->orderBy('name','asc')->get();
                        if(isset($request->pagesize) && $request->pagesize == 'all')
                        {
                            $products = (new Collection(Product::filterProducts($oldcats)))->paginate($oldcats->count())->appends(request()->query());
                        }
                        else
                        {
                            $page_length = isset($request->pagesize) ? $request->pagesize : 20;
                            $products = (new Collection(Product::filterProducts($oldcats)))->paginate($page_length)->appends(request()->query());
                        }
                    }
                    else if($sort == 'featured')
                    {
                        $oldcats = Product::where('name', 'like', '%' . $search . '%')->where('status','=',1)->orderBy('featured','desc')->get();
                        if(isset($request->pagesize) && $request->pagesize == 'all')
                        {
                            $products = (new Collection(Product::filterProducts($oldcats)))->paginate($oldcats->count())->appends(request()->query());
                        }
                        else
                        {
                            $page_length = isset($request->pagesize) ? $request->pagesize : 20;
                            $products = (new Collection(Product::filterProducts($oldcats)))->paginate($page_length)->appends(request()->query());
                        }
                    }
                    else if($sort == 'promotional')
                    {
                        $oldcats = Product::where('name', 'like', '%' . $search . '%')->where('status','=',1)->orderBy('promotional','desc')->get();
                        if(isset($request->pagesize) && $request->pagesize == 'all')
                        {
                            $products = (new Collection(Product::filterProducts($oldcats)))->paginate($oldcats->count())->appends(request()->query());
                        }
                        else
                        {
                            $page_length = isset($request->pagesize) ? $request->pagesize : 20;
                            $products = (new Collection(Product::filterProducts($oldcats)))->paginate($page_length)->appends(request()->query());
                        }
                    }
                    else if($sort == "rating")
                    {
                        $oldcats = Product::where('name', 'like', '%' . $search . '%')->where('status','=',1)->leftJoin('ratings', 'products.id', '=', 'ratings.product_id')->addSelect(DB::raw('AVG(ratings.rating) as average_rating'))->groupBy('products.id')->orderBy('average_rating', 'desc')->get();
                        if(isset($request->pagesize) && $request->pagesize == 'all')
                        {
                            $products = (new Collection(Product::filterProducts($oldcats)))->paginate($oldcats->count())->appends(request()->query());
                        }
                        else
                        {
                            $page_length = isset($request->pagesize) ? $request->pagesize : 20;
                            $products = (new Collection(Product::filterProducts($oldcats)))->paginate($page_length)->appends(request()->query());
                        }
                        if(isset($request->pagesize) && $request->pagesize == 'all')
                        {
                            $products = (new Collection(Product::filterProducts($oldcats)))->paginate($oldcats->count())->appends(request()->query());
                        }
                        else
                        {
                            $page_length = isset($request->pagesize) ? $request->pagesize : 20;
                            $products = (new Collection(Product::filterProducts($oldcats)))->paginate($page_length)->appends(request()->query());
                        }
                    }
                    else if($sort == "popularity")
                    {
                        $oldcats = Product::where('name', 'like', '%' . $search . '%')->where('status','=',1)->leftJoin('ratings', 'products.id', '=', 'ratings.product_id')->addSelect(DB::raw('AVG(ratings.rating) as average_rating'))->groupBy('products.id')->orderBy('average_rating', 'desc')->get();
                        
                        if(isset($request->pagesize) && $request->pagesize == 'all')
                        {
                            $products = (new Collection(Product::filterProducts($oldcats)))->paginate($oldcats->count())->appends(request()->query());
                        }
                        else
                        {
                            $page_length = isset($request->pagesize) ? $request->pagesize : 20;
                            $products = (new Collection(Product::filterProducts($oldcats)))->paginate($page_length)->appends(request()->query());
                        }
                        $oldcats = Product::where('name', 'like', '%' . $search . '%')->where('status','=',1)->orderBy('id','desc')->get();
                        if(isset($request->pagesize) && $request->pagesize == 'all')
                        {
                            $products = (new Collection(Product::filterProducts($oldcats)))->paginate($oldcats->count())->appends(request()->query());
                        }
                        else
                        {

                            $page_length = isset($request->pagesize) ? $request->pagesize : 20;
                            $products = (new Collection(Product::filterProducts($oldcats)))->paginate($page_length)->appends(request()->query());
                        }
                    }
                    else if($sort == 'price')
                    {
                        $oldcats = Product::where('name', 'like', '%' . $search . '%')->where('status','=',1)->orderBy('price','asc')->get();
                        if(isset($request->pagesize) && $request->pagesize == 'all')
                        {
                            $products = (new Collection(Product::filterProducts($oldcats)))->sortBy('price')->paginate($oldcats->count())->appends(request()->query());
                        }
                        else
                        {
                            $page_length = isset($request->pagesize) ? $request->pagesize : 20;
                            $products = (new Collection(Product::filterProducts($oldcats)))->sortBy('price')->paginate($page_length)->appends(request()->query());
                        }
                    }
                    else if($sort == 'price-desc')
                    {
                        $oldcats = Product::where('name', 'like', '%' . $search . '%')->orderBy('price','desc')->get();
                        
                        if(isset($request->pagesize) && $request->pagesize == 'all')
                        {
                            $products = (new Collection(Product::filterProducts($oldcats)))->sortByDesc('price')->paginate($oldcats->count())->appends(request()->query());
                        }
                        else
                        {
                            $page_length = isset($request->pagesize) ? $request->pagesize : 20;
                            $products = (new Collection(Product::filterProducts($oldcats)))->sortByDesc('price')->paginate($page_length)->appends(request()->query());
                        }
                    }
                     
                    return view('front.search',compact('products','search','collection_id','sort','min','max','layout_type','page_length','curr'));
                }
               
                // SORT SEARCH ENDS
                //$oldcats = Product::where('status','=',1)->whereRaw('MATCH (name) AGAINST (? IN BOOLEAN MODE)' , array($search))->orWhereRaw('MATCH (sku) AGAINST (? IN BOOLEAN MODE)' , array($search))->get();
                $oldcats = Product::where('name', 'like', '%' . $search . '%')->orWhere('sku', 'like', '%' . $search . '%')->where('status','=',1)->orderBy('id','desc')->get();
                $products = (new Collection(Product::filterProducts($oldcats)))->paginate($page_length);
                if($request->ajax()){
                    return view('front.pagination.search',compact('products','search','collection_id','sort'));
                }   
                
              
               return view('front.search',compact('products','search','collection_id','sort','layout_type','page_length','curr'));    
            }
            else 
            {
                
                 
                // SORT SEARCH
                if( !empty($request->sort) )
                {
                    $sort = $request->sort;
                    if($sort == "new")
                    {
                        $oldcats = Product::where('collection_id', 'like', '%' . $collection_id . '%')->where('name', 'like', '%' . $search . '%')->where('status','=',1)->orderBy('id','desc')->get();
                        $products = (new Collection(Product::filterProducts($oldcats)))->paginate($page_length);
                    }
                    else if($sort == "old")
                    {
                        $oldcats = Product::where('collection_id', 'like', '%' . $collection_id . '%')->where('name', 'like', '%' . $search . '%')->where('status','=',1)->get();
                        $products = (new Collection(Product::filterProducts($oldcats)))->paginate($page_length);
                    }
                    else if($sort == "low")
                    {
                        $oldcats = Product::where('collection_id', 'like', '%' . $collection_id . '%')->where('name', 'like', '%' . $search . '%')->where('status','=',1)->orderBy('price','asc')->get();
                        $products = (new Collection(Product::filterProducts($oldcats)))->sortBy('price')->paginate($page_length);
                    }
                    else if($sort == "high")
                    {
                        $oldcats =Product::where('collection_id', 'like', '%' . $collection_id . '%')->where('name', 'like', '%' . $search . '%')->where('status','=',1)->orderBy('price','desc')->get();
                        $products = (new Collection(Product::filterProducts($oldcats)))->sortByDesc('price')->paginate($page_length);
                    }
                    if($request->ajax()){
                        return view('front.pagination.search',compact('products','search','collection_id','sort','layout_type'));
                    }
                 
                    return view('front.search',compact('products','search','collection_id','sort','layout_type','page_length','curr'));
                }
                // SORT SEARCH ENDS

                $oldcats = Product::where('collection_id', 'like', '%' . $collection_id . '%')->where('name', 'like', '%' . $search . '%')->where('status','=',1)->orderBy('id','desc')->get();
                $products = (new Collection(Product::filterProducts($oldcats)))->paginate($page_length);
                if($request->ajax()){
                    return view('front.pagination.search',compact('products','search','collection_id','sort'));
                }   

                return view('front.search',compact('products','search','collection_id','sort','layout_type','page_length','curr'));   
            }
        }
        return view('errors.404');         
    }


// -------------------------------- CATEGORY SECTION ENDS----------------------------------------


// -------------------------------- PRODUCT DETAILS SECTION ----------------------------------------
 public function product($id)
    {
        //echo $id; exit;
        $arabic_attr = DB::table('attribute_masters')->select('name_en','name_ar')->get()->toArray();
        $this->code_image();
        $product = Product::where('id',$id)->first(); 
        if(empty($product))
        {
            return view('errors.404');
        }  
        $product->views+=1;
        $product->update(); 
        
        if (Session::has('currency')) 
        {
            $curr = Currency::find(Session::get('currency'));
        }
        else
        {
            $curr = Currency::where('is_default','=',1)->first();
        }
        $product_variations = DB::table('product_variations')->where('product_id', $id)->orderBy("id")->get();
	//print_r($product_variations);
        // echo "i am here". $product->id; 
        $product_click =  new ProductClick;
        $product_click->product_id = $product->id;
        $product_click->date = Carbon::now()->format('Y-m-d');
        // $product_click->save();  
        if(!$product_click->save()){
            // echo "not saved";
        }        
        else
        {
            // echo "saved";
        }
        $vendors = Product::where('user_id','=',0)->inRandomOrder()->take(9)->get();
        $gallary = Gallery::where('product_id', $id)->get();
        $prodClickIds = ProductClick::select('product_id')->where('product_id',"!=",$product->id)->distinct()->orderBy("date","desc")->take(8)->get();
        // print_r($prodClickIds->toArray());
        $recently_viewed = Product::whereIn("id",$prodClickIds)->where("status",1)->get();
        // $recently_viewed = ProductClick::join('products', 'products.id', '=', 'product_clicks.product_id')->where('products.id','!=',$product->id)->where('products.status',1)->orderBy("date","desc")->take(8)->get();
        // echo "<pre>"; print_r($recently_viewed);    die;
        $brands = Brand::orderBy('name','asc')->get();
        $reviews = DB::table('ratings')->select('ratings.*','users.first_name','users.last_name')->join('users', 'users.id', '=', 'ratings.user_id')->join('products', 'products.id', '=', 'ratings.product_id')->where('ratings.product_id',$id)->get();
        $review_count = DB::table('ratings')->select('ratings.*','users.first_name','users.last_name')->join('users', 'users.id', '=', 'ratings.user_id')->join('products', 'products.id', '=', 'ratings.product_id')->where('ratings.product_id',$id)->get()->count();
        $five_star_rating = DB::table('ratings')->select('ratings.*','users.first_name','users.last_name')->join('users', 'users.id', '=', 'ratings.user_id')->join('products', 'products.id', '=', 'ratings.product_id')->where('ratings.product_id',$id)->where('rating','=',5)->get()->count();
        $four_star_rating = DB::table('ratings')->select('ratings.*','users.first_name','users.last_name')->join('users', 'users.id', '=', 'ratings.user_id')->join('products', 'products.id', '=', 'ratings.product_id')->where('ratings.product_id',$id)->where('rating','=',4)->get()->count();
        $three_star_rating = DB::table('ratings')->select('ratings.*','users.first_name','users.last_name')->join('users', 'users.id', '=', 'ratings.user_id')->join('products', 'products.id', '=', 'ratings.product_id')->where('ratings.product_id',$id)->where('rating','=',3)->get()->count();
        $two_star_rating = DB::table('ratings')->select('ratings.*','users.first_name','users.last_name')->join('users', 'users.id', '=', 'ratings.user_id')->join('products', 'products.id', '=', 'ratings.product_id')->where('ratings.product_id',$id)->where('rating','=',2)->get()->count();
        $one_star_rating = DB::table('ratings')->select('ratings.*','users.first_name','users.last_name')->join('users', 'users.id', '=', 'ratings.user_id')->join('products', 'products.id', '=', 'ratings.product_id')->where('ratings.product_id',$id)->where('rating','=',1)->get()->count();
        $average_rating = DB::table('ratings')->select(DB::raw('avg(rating) as average_rating'))->join('users', 'users.id', '=', 'ratings.user_id')->join('products', 'products.id', '=', 'ratings.product_id')->where('ratings.product_id',DB::raw("$id"))->first();
        $average_rating= $average_rating->average_rating;
        return view('front.product',compact('product','brands','curr','vendors','product_variations','gallary','recently_viewed','reviews','review_count','five_star_rating','four_star_rating','three_star_rating','two_star_rating','one_star_rating','average_rating','id','arabic_attr'));

    }
    
// -------------------------------- PRODUCT DETAILS SECTION ----------------------------------------


    public function writereview(Request $request)
    {
        $product_id = $request->product_id;
        $rating = isset($request->rating) ? $request->rating : 0;
        $comment = $request->comment;
        $name= $request->name;
        $email = $request->email;
        $user = Auth::user();
        if(empty($user))
        {
            return response()->json(['status'=>false,'message'=>'Please login to write review']);
        }
        else
        {
            DB::table('ratings')->insert(array('user_id'=>$user->id,'product_id'=>$product_id,'review'=>$comment,'rating'=>$rating,'review_date'=>date('Y-m-d H:i:s')));
            return response()->json(['status'=>true,'message'=>'Review saved successfully']);
        }
    }
// -------------------------------- PRODUCT DETAILS SECTION ----------------------------------------

    public function report(Request $request)
    {

        //--- Validation Section
            $rules = [
                   'note' => 'max:400',
                    ];
            $customs = [
                   'note.max' => 'Note Must Be Less Than 400 Characters.',
                       ];
            $validator = Validator::make(Input::all(), $rules, $customs);
            if ($validator->fails()) {
              return response()->json(array('errors' => $validator->getMessageBag()->toArray()));
            }
        //--- Validation Section Ends

        //--- Logic Section
        $data = new Report;
        $input = $request->all();
        $data->fill($input)->save();
        //--- Logic Section Ends

        //--- Redirect Section  
        $msg = 'New Data Added Successfully.';
        return response()->json($msg);      
        //--- Redirect Section Ends  

    }

    public function affProductRedirect($id)
    {
        $product = Product::where('id','=',$id)->first();
//        $product->views+=1;
//        $product->update();


        return redirect($product->affiliate_link);

    }

    public function quick($id)
    {
        $product = Product::findOrFail($id);   
        if (Session::has('currency')) 
        {
            $curr = Currency::find(Session::get('currency'));
        }
        else
        {
            $curr = Currency::where('is_default','=',1)->first();
        }       
        return view('load.quick',compact('product','curr'));

    }

// -------------------------------- PRODUCT DETAILS SECTION ENDS----------------------------------------

// -------------------------------- PRODUCT COMMENT SECTION ----------------------------------------

    public function comment(Request $request)
    {
        $comment = new Comment;
        $input = $request->all();
        $comment->fill($input)->save();
        $comments = Comment::where('product_id','=',$request->product_id)->get()->count();
        $data[0] = $comment->user->photo ? url('assets/images/users/'.$comment->user->photo):url('assets/images/noimage.png');
        $data[1] = $comment->user->name;
        $data[2] = $comment->created_at->diffForHumans();
        $data[3] = $comment->text;
        $data[4] = $comments;
        $data[5] = route('product.comment.delete',$comment->id);
        $data[6] = route('product.comment.edit',$comment->id);
        $data[7] = route('product.reply',$comment->id);
        $data[8] = $comment->user->id;
        return response()->json($data);
    }

    public function commentedit(Request $request,$id)
    {
        $comment =Comment::findOrFail($id);
        $comment->text = $request->text;
        $comment->update();
        return response()->json($comment->text);
    } 

    public function commentdelete($id)
    {
        $comment =Comment::findOrFail($id);
        if($comment->replies->count() > 0)
        {
            foreach ($comment->replies as $reply) {
                $reply->delete();
            }
        }
        $comment->delete();
    }     

// -------------------------------- PRODUCT COMMENT SECTION ENDS ----------------------------------------

// -------------------------------- PRODUCT REPLY SECTION ----------------------------------------

    public function reply(Request $request,$id)
    {
        $reply = new Reply;
        $input = $request->all();
        $input['comment_id'] = $id;
        $reply->fill($input)->save();
        $data[0] = $reply->user->photo ? url('assets/images/users/'.$reply->user->photo):url('assets/images/noimage.png');
        $data[1] = $reply->user->name;
        $data[2] = $reply->created_at->diffForHumans();
        $data[3] = $reply->text;
        $data[4] = route('product.reply.delete',$reply->id);
        $data[5] = route('product.reply.edit',$reply->id);
        return response()->json($data);
    } 

    public function replyedit(Request $request,$id)
    {
        $reply = Reply::findOrFail($id);
        $reply->text = $request->text;
        $reply->update();
        return response()->json($reply->text);
    } 

    public function replydelete($id)
    {
        $reply =Reply::findOrFail($id);
        $reply->delete();
    } 

// -------------------------------- PRODUCT REPLY SECTION ENDS----------------------------------------


// ------------------ Rating SECTION --------------------

    public function reviewsubmit(Request $request)
    {
        $ck = 0;
$orders = Order::where('user_id','=',$request->user_id)->where('status','=','completed')->get();

        foreach($orders as $order)
        {
        $cart = unserialize(bzdecompress(utf8_decode($order->cart)));
            foreach($cart->items as $product)
            {
                if($request->product_id == $product['item']['id'])
                {
                    $ck = 1;
                    break;
                }
            }
        }
        if($ck == 1)
        {
            $user = Auth::guard('web')->user();
            $prev = Rating::where('product_id','=',$request->product_id)->where('user_id','=',$user->id)->get();
            if(count($prev) > 0)
            {
            return response()->json(array('errors' => [ 0 => 'You Have Reviewed Already.' ]));                
            }         
            $Rating = new Rating;
            $Rating->fill($request->all());
            $Rating['review_date'] = date('Y-m-d H:i:s');
            $Rating->save();
            $data[0] = 'Your Rating Submitted Successfully.';
            $data[1] = Rating::rating($request->product_id);
            $data[2] = Rating::where('product_id','=',$request->product_id)->count();
            return response()->json($data);  
        }
        else{
            return response()->json(array('errors' => [ 0 => 'Buy This Product First' ]));
        }
    }


    public function reviews($id){
        $productt = Product::find($id);   
        return view('load.reviews',compact('productt','id'));

    }

// ------------------ Rating SECTION ENDS --------------------



    // Capcha Code Image
    private function  code_image()
    {
        $actual_path = str_replace('project','',base_path());
        $image = imagecreatetruecolor(200, 50);
        $background_color = imagecolorallocate($image, 255, 255, 255);
        imagefilledrectangle($image,0,0,200,50,$background_color);

        $pixel = imagecolorallocate($image, 0,0,255);
        for($i=0;$i<500;$i++)
        {
            imagesetpixel($image,rand()%200,rand()%50,$pixel);
        }

        $font = $actual_path.'assets/front/fonts/NotoSans-Bold.ttf';
        $allowed_letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        $length = strlen($allowed_letters);
        $letter = $allowed_letters[rand(0, $length-1)];
        $word='';
        //$text_color = imagecolorallocate($image, 8, 186, 239);
        $text_color = imagecolorallocate($image, 0, 0, 0);
        $cap_length=6;// No. of character in image
        for ($i = 0; $i< $cap_length;$i++)
        {
            $letter = $allowed_letters[rand(0, $length-1)];
            imagettftext($image, 25, 1, 35+($i*25), 35, $text_color, $font, $letter);
            $word.=$letter;
        }
        $pixels = imagecolorallocate($image, 8, 186, 239);
        for($i=0;$i<500;$i++)
        {
            imagesetpixel($image,rand()%200,rand()%50,$pixels);
        }
        session(['captcha_string' => $word]);
        imagepng($image, $actual_path."assets/images/capcha_code.png");
    }
    public function getAttributeCombination(Request $request)
    {
        $params = $request->post();
        $selected_attr = isset($params['selected_attr']) ? $params['selected_attr'] : '';
        $selected_val = isset($params['selected_attr_val']) ? $params['selected_attr_val'] : '';
        $attributes = json_decode($params['attr_data']);
        $final_attr_arr = array();
        $attr_arr = array();
        foreach ($attributes as $key => $attribute) {
            foreach ($attribute as $attrkey => $attrvalue) {
                //echo $attrkey;
                //print_r($attribute);exit;
                if($selected_val == $attrvalue)
                {
                    foreach ($attributes[$key] as $attr_key => $attr_value) {
                        if(!in_array($attr_value, $attr_arr) && !empty($attr_value))
                        $final_attr_arr[$attr_key][] = $attr_value;
                        array_push($attr_arr, $attr_value);
                    }
                    //$final_attr_arr[]
                }
            }
        }
        echo json_encode($final_attr_arr);exit;
    }
    public function getcolorimage(Request $request) 
    {   
        $product_id = $request->product_id; 
        $color = $request->selected_color;  
        $image = DB::table('product_color_images')->select('image')->where('product_id', $product_id)->where('color_name', $color)->first();    
        //print_r($image);exit; 
        $flag = false;  
        if(!empty($image))  
        {   
            $images = isset($image->image) ? $image->image : '';    
            $images = explode(",",$images); 
            $top_images = '';$bottom_images = '';   
            foreach($images as $key => $image){ 
                if($key == 0)   
                {   
                    $top_images .= '<a href="'.$image.'" class="fancybox"><img style="border:1px solid #e8e8e6;" id="zoom_03" class="" src="'.$image.'" data-zoom-image="'.$image.'" width="411"  /></a><a href="'.$image.'" class="btn-zoom-image fancybox"><i class="fa fa-search"></i></a><div class="clearfix"></div>   
                        <div class="clearfix"></div>';  
                }   
            }   
            $top_images .= '<div id="gallery_01" style="width:500px;float:left; ">';    
            foreach($images as $key => $image){ 
                $class = ($key ==0)?'active':'';    
                $top_images .= '<a  href="#" class="elevatezoom-gallery '.$class.'" data-update="" data-image="'.$image.'"  
                            data-zoom-image="'.$image.'">   
                                <img src="'.$image.'" width="100" />    
                            </a>';  
            }   
            $top_images .= '</div>';    
            /*foreach($images as $key => $image){   
                $class = ($key ==0)?'active_slide':'';  
                $bottom_images .= '<div class="item">   
                            <img src="'.$image.'" class="img-fluid prd-zoom-img" id="product_featured_image" alt="">    
                        </div>';    
            }*/ 
            $response['status'] = true; 
            $response['top_images'] = $top_images;  
            //$response['bottom_images'] = $bottom_images;  
        }   
        else    
        {   
            $response['status'] = false;    
            $response['top_images'] = '';   
            $response['bottom_images'] = '';    
        }   
            
        echo json_encode($response);exit;   
    }
    public function getbase64image(Request $request)    
    {   
        /*$image = $request->file('file');  
        $new_name = rand() . '.' . $image->getClientOriginalExtension();    
        $image->move(public_path('assets/images/galleries/'), $new_name);   
        echo public_path('assets/images/galleries/').$new_name;exit;*/  
        $image = $request->image;   
        $path = ''; 
        if(!empty($image))  
        {   
            $image_parts = explode(";base64,", $image); 
            $image_type_aux = explode("image/", $image_parts[0]);   
            $image_type = $image_type_aux[1];   
            $image_base64 = base64_decode($image_parts[1]); 
            $image_name = time().str_random(8) . '.'.$image_type;   
            $file = 'assets/images/products/' . $image_name;    
            file_put_contents($file, $image_base64);    
            $path  = $image_name;   
        }   
        echo $path;exit;    
    }
    public function bulkupload(Request $request)    
    {   
        $params = $request->all();  
        $excel_data = isset($params['excel_data']) ? $params['excel_data'] : '';    
        $excel_data = json_decode($excel_data); 
        unset($excel_data[0]);  
        $imagesNotFound = array();  
        $datas = "";    
        $log = '';  
        $sign = Currency::where('is_default','=',1)->first();   
        foreach($excel_data as $line)   
        {   
            $line[0] = strval($line[0]);    
            $product_exist = DB::select("select id from products where sku = '".$line[0]."'");  
            $product_exist = isset($product_exist[0]->id) ? $product_exist[0]->id : ''; 
            $id = $product_exist;   
            if (!$product_exist || $product_exist)  
            {   
                $input['type'] = 'Physical';    
                $input['sku'] = $line[0];   
                $input['category_id'] = 0;  
                $input['subcategory_id'] = 0;   
                $input['childcategory_id'] = 0; 
                $input['brand_id'] = 0; 
                $mcat = DB::select("select id from categories where lower(name)='".strtolower($line[1])."'");   
                $mcat = isset($mcat[0]->id) ? $mcat[0]->id : '';    
                //$brand = Brand::where(DB::raw('lower(name)'), strtolower($line[4]));  
                $brandTEmp = DB::select("select id from brands where lower(name) = '".strtolower(trim($line[4]))."'");  
                // print_r($brandTEmp); 
                $brand = isset($brandTEmp[0]->id) ? $brandTEmp[0]->id : ''; 
               /* echo "==".$brand."==";    
                die;*/  
                if(!empty($brand)){ 
                    $input['brand_id'] = $brand;    
                }   
                if(!empty($mcat))   
                {   
                    $input['category_id'] = $mcat;  
                    if($line[2] != ""){ 
                        $scat = DB::select("select id from subcategories where category_id = ".$mcat." and status=1 and lower(name) = '".strtolower($line[2])."'"); 
                        $scat = isset($scat[0]->id) ? $scat[0]->id : '';    
                        if(!empty($scat)) { 
                            $input['subcategory_id'] = $scat;   
                        }   
                    }   
                    if($line[3] != ""){ 
                        $chcat = DB::select("select id from childcategories where lower(name) = '".strtolower($line[3])."'");   
                        $chcat = isset($chcat[0]->id) ? $chcat[0]->id : ''; 
                        if(!empty($chcat)) {    
                            $input['childcategory_id'] = $chcat;    
                        }   
                    }   
                    $input['photo'] = mb_convert_encoding(strtolower($line[7]), 'UTF-8', 'UTF-8');  
                    $input['name'] = mb_convert_encoding($line[5], 'UTF-8', 'UTF-8');   
                    $input['name_ar'] = mb_convert_encoding($line[6], 'UTF-8', 'UTF-8');    
                    $input['details'] = mb_convert_encoding($line[10], 'UTF-8', 'UTF-8');   
                    $input['details_ar'] = mb_convert_encoding($line[11], 'UTF-8', 'UTF-8');    
                    $input['product_info'] = mb_convert_encoding($line[12], 'UTF-8', 'UTF-8');  
                    $input['color'] = mb_convert_encoding($line[17], 'UTF-8', 'UTF-8'); 
                    $input['price'] = mb_convert_encoding($line[13], 'UTF-8', 'UTF-8'); 
                    $input['previous_price'] = mb_convert_encoding($line[14], 'UTF-8', 'UTF-8');    
                    $input['weight'] = !empty($line[15]) ? $line[15] : 0;   
                    $input['stock'] = $line[16];    
                    $input['youtube'] = mb_convert_encoding($line[19], 'UTF-8', 'UTF-8');   
                    $input['policy'] = mb_convert_encoding($line[20], 'UTF-8', 'UTF-8');    
                    $input['policy_ar'] = mb_convert_encoding($line[21], 'UTF-8', 'UTF-8'); 
                    $input['meta_tag'] = mb_convert_encoding($line[22], 'UTF-8', 'UTF-8');  
                    $input['meta_description'] = mb_convert_encoding($line[23], 'UTF-8', 'UTF-8');  
                    $input['tags'] = mb_convert_encoding($line[18], 'UTF-8', 'UTF-8');  
                    $input['product_type'] = 'normal';  
                    // Conert Price According to Currency   
                    $input['price'] = ($input['price'] / $sign->value); 
                    $input['previous_price'] = ($input['previous_price'] / $sign->value);   
                    $input['is_multiple_products'] = !empty($line[9]) ? 1 : 0;  
                    // Save Data    
                    if($product_exist)  
                    {   
                        DB::table('products')->where('sku', $line[0])->update($input);  
                        $prod = DB::select("select id, name, slug from products where sku='".$line[0]."'"); 
                        $prod = $prod[0];   
                    }   
                    else    
                    {   
                        DB::table('products')->insert($input);  
                        $prod = DB::select("select id, name, slug from products where sku='".$line[0]."'");                         
                        $prod = $prod[0];   
                        //echo "test2";exit;    
                    }   
                    $slug = str_slug($prod->name,'-').'-'.strtolower(str_random(3).$prod->id.str_random(3));    
                    $thumbnail = '';    
                    // Set Thumbnail    
                    if(!empty($line[7]))    
                    {   
                        if(file_exists(public_path('assets/import/images/'.strtolower($line[7]))))  
                        {   
                            $move = File::copy(public_path('assets/import/images/'.strtolower($line[7])), public_path('assets/images/products/'.strtolower($line[7]))); 
                            $img = Image::make('assets/import/images/'.strtolower($line[7]))->resize(285, 285); 
                            $thumbnail = time().str_random(8).'.jpg';   
                            $img->save(public_path().'/assets/images/thumbnails/'.$thumbnail);  
                            ///$prod->thumbnail  = $thumbnail;  
                        }   
                        else    
                        {   
                            // echo "Please first upload product images - ".$line[7];exit;  
                            $imagesNotFound[][$line[0]]['image'] = $line[7];    
                        }   
                    }   
                    DB::statement("update products set slug='".$slug."', thumbnail='".$thumbnail."' where sku='".$line[0]."'"); 
                    
                    //add gallary   
                    if(!empty($line[8]))    
                    {   
                        DB::table('galleries')->where('product_id',$prod->id)->delete();    
                        $gallary_imgages = explode(',',$line[8]);   
                        foreach($gallary_imgages as $image) 
                        {   
                            if(file_exists(public_path('assets/import/images/'.strtolower($image))))    
                            {   
                                $image = strtolower(trim($image));  
                                
                                /*$gallery = new Gallery;   
                                $gallery['photo'] = $image; 
                                $gallery['product_id'] = $prod->id; 
                                $gallery->save();*/ 
                                    
                                DB::statement("insert into galleries(photo,product_id) values('".$image."',".$prod->id.")");    
                                if($image){ 
                                    $move = File::copy(public_path('assets/import/images/'.$image), public_path('assets/images/galleries/'.$image));    
                                }   
                                    
                            }   
                            else    
                            {   
                                // echo "Please first upload product images - ".$image;exit;    
                                $image = strtolower(trim($image));  
                                DB::statement("insert into galleries(photo,product_id) values('".$image."',".$prod->id.")");    
                                $imagesNotFound[][$line[0]]['image'] = $image;  
                            }   
                        }   
                    }   
                   if(!empty($line[24]))    
                    {   
                        // WHITE:AMIT02_1.jpg,AMIT02_2.jpg;RED:AMIT02_1.jpg,AMIT02_2.jpg,AMIT02_3.jpg;GREEN:AMIT02_3.jpg;   
                        $line[24] = trim($line[24],";");    
                        $colorArrA = explode(';',$line[24]);    
                        DB::table('product_color_images')->where('product_id', $prod->id)->delete();    
                        for($imgCtr=0;$imgCtr<count($colorArrA);$imgCtr++)  
                        {   
                            $colorArrAColonBreak = explode(':',$colorArrA[$imgCtr]);    
                            $colName = trim($colorArrAColonBreak[0]);   
                            $colImages = isset($colorArrAColonBreak[1]) ? $colorArrAColonBreak[1] : "" ;    
                            $imageAttr = '';    
                            if($colImages!="")  
                            {   
                                $colImagesCommaBreak = explode(',',$colImages); 
                                for($cicb=0;$cicb<count($colImagesCommaBreak);$cicb++)  
                                {   
                                    
                                    $imageAttr.= isset($colImagesCommaBreak[$cicb]) ? url('/assets/images/galleries/')."/".strtolower($colImagesCommaBreak[$cicb])."," : "" ;   
                                }   
                                $imageAttr = trim($imageAttr,",");  
                            }   
                            DB::table('product_color_images')->insert(array('product_id' => $prod->id, 'color_name' => $colName , 'image' => $imageAttr));  
                        }   
                    }   
                        
                    //add variations    
                    $attributes = explode(';',$line[9]);    
                    DB::table('product_variations')->where('product_id',$prod->id)->delete();   
                    foreach($attributes as $key => $attr)   
                    {   
                        //print_r($attr);exit;  
                        $attr_name_arr = array();   
                        $attr_val_arr = array();    
                        $attr_json_arr = array();   
                        $exploded_attr = explode(',', $attr);   
                        $sku = '';$qty = 0;$price = 0;  
                        foreach($exploded_attr as $e_key => $e_attr)    
                        {   
                            $exp_attr = explode(':', $e_attr);  
                            //print_r($exp_attr);exit;  
                            if($exp_attr[0] == 'Sku')   
                            {   
                                $sku = $exp_attr[1];    
                            }   
                            if($exp_attr[0] == 'Qty')   
                            {   
                                $qty = $exp_attr[1];    
                            }   
                            if($exp_attr[0] == 'Price') 
                            {   
                                $price = $exp_attr[1];  
                            }   
                            if(!empty($exp_attr[1]))    
                            {   
                                array_push($attr_name_arr, $exp_attr[0]);   
                                array_push($attr_val_arr, $exp_attr[1]);    
                                $attr_json_arr[$exp_attr[0]] = $exp_attr[1];    
                            }   
                        }       
                        //print_r($attr_val_arr);exit;  
                        if (($key = array_search('Price', $attr_name_arr)) !== false) { 
                            unset($attr_name_arr[$key]);    
                        }   
                        if (($key = array_search('Sku', $attr_name_arr)) !== false) {   
                            unset($attr_name_arr[$key]);    
                        }   
                        if (($key = array_search('Qty', $attr_name_arr)) !== false) {   
                            unset($attr_name_arr[$key]);    
                        }   
                        unset($attr_json_arr['Sku']);   
                        unset($attr_json_arr['Qty']);   
                        unset($attr_json_arr['Price']); 
                        array_splice($attr_val_arr, count($attr_val_arr) - 3, 3);   
                            
                        DB::table('product_variations')->insert(array('product_id' => $prod->id,'sku'=>$sku,'attribute_names' => implode('-', $attr_name_arr),'attribute_values'=> implode('-', $attr_val_arr),'qty'=>$qty,'price'=>$price,'created_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s'),'json_attributes'=>json_encode($attr_json_arr)));    
                    }   
                }   
                else    
                {   
                    $log .= "<br>Sku: ".$line[0]." - No Category Found!<br>";   
                }   
            }   
            else    
            {   
                $log .= "<br>Sku: ".$line[0]." - Duplicate Product Code!<br>";  
            }   
        }   
        $imagesNotFoundHtml = '';   
        //--- Redirect Section  
        if(count($imagesNotFound) > 0)  
        {   
            $imagesNotFoundHtml = 'Please upload following product images :- <br> Item Code - Image';   
             for($imgC=0;$imgC<sizeof($imagesNotFound);$imgC++) 
            {   
                // print_r($imagesNotFound[$imgC]); 
                foreach($imagesNotFound[$imgC] as $keyy=>$vall) 
                {   
                    $imagesNotFoundHtml = $imagesNotFoundHtml." ".$keyy." - ".$vall['image']."<br>";    
                }   
            }   
        }   
        $msg = 'Bulk Product File Imported Successfully.<a href="'.route('admin-prod-index').'">View Product Lists.</a>'.$log;  
        $msg = $msg.'<br>'.$imagesNotFoundHtml; 
        return response()->json($msg);  
    }   
    public function productlist()   
    {   
        $category = Category::where('status',1)->orderBy('name','asc')->get();  
        $products = Product::where('product_type','!=','affiliate')->orderBy('name','asc')->get();  
        $productsData = array();    
        foreach($products as $key => $product)  
        {   
            $productsData[$key]['item_code'] = isset($product->sku) ? $product->sku : '';   
            $productsData[$key]['name_en'] = isset($product->name) ? $product->name : '';   
            $productsData[$key]['name_ar'] = isset($product->name_ar) ? $product->name_ar : ''; 
            $category_data = getCategoryName($product->category_id);    
            $productsData[$key]['category'] = isset($category_data->name) ? $category_data->name : '';  
            $sub_category = getSubCategoryName($product->subcategory_id);   
            $productsData[$key]['sub_category'] = isset($sub_category->name) ? $sub_category->name : '';    
            $child_category = getChildCategory($product->childcategory_id); 
            $productsData[$key]['child_category'] = isset($child_category->name) ? $child_category->name : '';  
            $brand = getBrandName($product->id);    
            $productsData[$key]['brand'] = $brand;  
            $variations = DB::table('product_variations')->where('product_id', $product->id)->get();    
            $attr_master = $datas = attribute_masters::orderBy('id','desc')->get()->toArray();  
            $attributes_arr = array();  
            foreach($attr_master as $attr)  
            {   
                $attributes_arr[] = $attr['name_en'];   
            }   
                
            if($variations->count() > 0)    
            {   
                $attr_arr = array();    
                $variation_arr = array();   
                foreach($variations as $variation)  
                {   
                    $attributes = (array)json_decode($variation->json_attributes);  
                    $index = 0; 
                        
                    foreach($attributes_arr as $attrkey => $val)    
                    {   
                        if(isset($attributes[$val]) && !empty($attributes[$val]))   
                        {   
                            $attr_arr[$val] = $attributes[$val];        
                        }   
                        else    
                        {   
                            $attr_arr[$val] = '';           
                        }   
                    }   
                    $attr_arr['Sku'] = $variation->sku; 
                    $attr_arr['Qty'] = $variation->qty; 
                    $attr_arr['Price'] = $variation->price; 
                    $attr_string = urldecode(str_replace('=',':',str_replace('&',',',http_build_query($attr_arr))));    
                    array_push($variation_arr, $attr_string);   
                }   
                $productsData[$key]['attributes'] = $variation_arr; 
            }   
            $productsData[$key]['price'] = $product->price; 
            $productsData[$key]['stock'] = $product->stock; 
            $productsData[$key]['description_en'] = $product->details;  
            $productsData[$key]['description_ar'] = $product->details_ar;   
        }   
        return view('admin.product.index',compact('category','productsData'));  
    }   
    public function media() 
    {   
        return view('admin.importimages.media');    
    }   
    public function mediaStore(Request $request)    
    {   
        $image = $request->file('file');    
        $imageName = $request->file->getClientOriginalName();   
        $image->move('assets/images/galleries/',strtolower($imageName));    
        $move = File::copy(public_path('assets/images/galleries/'.strtolower($imageName)), public_path('assets/images/products/'.strtolower($imageName)));  
        return response()->json(['success'=>$imageName]);   
    }   
    public function removeimage(Request $request)   
    {   
        $image = isset($request->image) ? $request->image : ''; 
        if(!empty($image))  
        {   
            unlink(public_path('assets/images/galleries/'.$image)); 
        }   
    }
}
