<?php

namespace App\Http\Controllers\Front;
use App\Classes\GeniusMailer;
use App\Http\Controllers\Controller;
use App\Models\Cart;
use App\Models\Coupon;
use App\Models\Currency;
use App\Models\Generalsetting;
use App\Models\Notification;
use App\Models\Order;
use App\Models\OrderTrack;
use App\Models\Product;
use App\Models\User;
use Config;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use Srmklive\PayPal\Services\ExpressCheckout;
use DB;
use App\Models\EmailTemplate;
use Mail;
class PaymentController extends Controller
{

  public function __construct()
    {
        //Set Spripe Keys
        $gs = Generalsetting::findOrFail(1);
        Config::set('paypal.mode', $gs->paypal_mode);
        Config::set('paypal.'.$gs->paypal_mode.'.username', $gs->paypal_username);
        Config::set('paypal.'.$gs->paypal_mode.'.password', $gs->paypal_password);
        Config::set('paypal.'.$gs->paypal_mode.'.secret', $gs->paypal_secret);

            if (Session::has('currency')) 
            {
              $this->curr = Currency::find(Session::get('currency'));
            }
            else
            {
                $this->curr = Currency::where('is_default','=',1)->first();
            }

        Config::set('paypal.currency', $this->curr->name);
    }


 public function store(Request $request){
        $input = $request->all();
        Session::put('paypal_data',$input);

        if($request->pass_check) {
            $users = User::where('email','=',$request->personal_email)->get();
            if(count($users) == 0) {
                if ($request->personal_pass == $request->personal_confirm){
                    $user = new User;
                    $user->name = $request->personal_name; 
                    $user->email = $request->personal_email;   
                    $user->password = bcrypt($request->personal_pass);
                    $token = md5(time().$request->personal_name.$request->personal_email);
                    $user->verification_link = $token;
                    $user->affilate_code = md5($request->name.$request->email);
                    $user->save();
                    Auth::guard('web')->login($user);                     
                }else{
                    return redirect()->back()->with('unsuccess',"Confirm Password Doesn't Match.");     
                }
            }
            else {
                return redirect()->back()->with('unsuccess',"This Email Already Exist.");  
            }
        }

     if (!Session::has('cart')) {
        return redirect()->route('front.cart')->with('success',"You don't have any product to checkout.");
     }
        $settings = Generalsetting::findOrFail(1);
        $provider = new ExpressCheckout;
        $data['items'][] = [
                            'name' => $settings->title." Order",
                            'price' => $request->total + $request->shipping_cost + $request->packing_cost
                        ];
        $data['invoice_description'] = '';
        $data['invoice_id'] = str_random(4).time();
        $data['total'] = $request->total + $request->shipping_cost + $request->packing_cost;
        $data['return_url'] = action('Front\PaymentController@notify');
        $data['cancel_url'] = action('Front\PaymentController@paycancle');
        $response = $provider->setExpressCheckout($data);
        Session::put('paypal_items',$data);
        return redirect($response['paypal_link']);
 }



public function notify(Request $request){

        $paypal_data = Session::get('paypal_data');
        $paypal_items = Session::get('paypal_items');
        $success_url = action('Front\PaymentController@payreturn');
        $cancel_url = action('Front\PaymentController@paycancle');
        $provider = new ExpressCheckout;
        $token = $request->token;
        $payerid = $request->PayerID;
        $response = $provider->getExpressCheckoutDetails($token);
        $item_number = $response['INVNUM'];
        $response = $provider->doExpressCheckoutPayment($paypal_items,$token,$payerid);
        $item_amount = $response['PAYMENTINFO_0_AMT'];
        // dd($response);
        if($response['PAYMENTINFO_0_ACK'] == 'Success'){

           $oldCart = Session::get('cart');
            $cart = new Cart($oldCart);

            foreach($cart->items as $key => $prod)
            {
                if(!empty($prod['item']['license']) && !empty($prod['item']['license_qty']))
                {
                        foreach($prod['item']['license_qty']as $ttl => $dtl)
                        {
                            if($dtl != 0)
                            {
                                $dtl--;
                                $produc = Product::findOrFail($prod['item']['id']);
                                $temp = $produc->license_qty;
                                $temp[$ttl] = $dtl;
                                $final = implode(',', $temp);
                                $produc->license_qty = $final;
                                $produc->update();
                                $temp =  $produc->license;
                                $license = $temp[$ttl];
                                 $oldCart = Session::has('cart') ? Session::get('cart') : null;
                                 $cart = new Cart($oldCart);
                                 $cart->updateLicense($prod['item']['id'],$license);  
                                 Session::put('cart',$cart);
                                break;
                            }                    
                        }
                }
            }

                     $settings = Generalsetting::findOrFail(1);
                     $order = new Order;

                    $order['user_id'] = $paypal_data['user_id'];
                    $order['cart'] = utf8_encode(bzcompress(serialize($cart), 9));
                    $order['totalQty'] = $paypal_data['totalQty'];
                    $order['pay_amount'] = $item_amount;
                    $order['method'] = $paypal_data['method'];
                    $order['customer_email'] = $paypal_data['email'];
                    $order['customer_name'] = $paypal_data['name'];
                    $order['customer_phone'] = $paypal_data['phone'];
                    $order['order_number'] = $item_number;
                    $order['shipping'] = $paypal_data['shipping'];
                    $order['pickup_location'] = $paypal_data['pickup_location'];
                    $order['customer_address'] = $paypal_data['address'];
                    $order['customer_country'] = $paypal_data['customer_country'];
                    $order['customer_city'] = $paypal_data['city'];
                    $order['customer_zip'] = $paypal_data['zip'];
                    $order['shipping_email'] = $paypal_data['shipping_email'];
                    $order['shipping_name'] = $paypal_data['shipping_name'];
                    $order['shipping_phone'] = $paypal_data['shipping_phone'];
                    $order['shipping_address'] = $paypal_data['shipping_address'];
                    $order['shipping_country'] = $paypal_data['shipping_country'];
                    $order['shipping_city'] = $paypal_data['shipping_city'];
                    $order['shipping_zip'] = $paypal_data['shipping_zip'];
                    $order['order_note'] = $paypal_data['order_notes'];
                    $order['coupon_code'] = $paypal_data['coupon_code'];
                    $order['coupon_discount'] = $paypal_data['coupon_discount'];
                    $order['payment_status'] = $response['PAYMENTINFO_0_PAYMENTSTATUS'];
                    $order['currency_sign'] = $this->curr->sign;
                    $order['currency_value'] = $this->curr->value;
                    $order['shipping_cost'] = $paypal_data['shipping_cost'];
                    $order['packing_cost'] = $paypal_data['packing_cost'];
                    $order['tax'] = $paypal_data['tax'];
                    $order['dp'] = $paypal_data['dp'];
                    $order['txnid'] = $response['PAYMENTINFO_0_TRANSACTIONID'];

        $order['vendor_shipping_id'] = $paypal_data['vendor_shipping_id'];
        $order['vendor_packing_id'] = $paypal_data['vendor_packing_id'];

                    if($order['dp'] == 1)
                    {
                        $order['status'] = 'completed';
                    }

                    if (Session::has('affilate')) 
                    {
                        $val = $item_amount / 100;
                        $sub = $val * $settings->affilate_charge;
                        $user = User::findOrFail(Session::get('affilate'));
                        $user->affilate_income += $sub;
                        $user->update();
                        $order['affilate_user'] = $user->name;
                        $order['affilate_charge'] = $sub;
                    }
                    $order->save();


        if($order->dp == 1){
            $track = new OrderTrack;
            $track->title = 'Completed';
            $track->text = 'Your order has completed successfully.';
            $track->order_id = $order->id;
            $track->save();
        }
        else {
            $track = new OrderTrack;
            $track->title = 'Pending';
            $track->text = 'You have successfully placed your order.';
            $track->order_id = $order->id;
            $track->save();
        }
                    
                    $notification = new Notification;
                    $notification->order_id = $order->id;
                    $notification->save();
                    
                    if($paypal_data['coupon_id'] != "")
                    {
                       $coupon = Coupon::findOrFail($paypal_data['coupon_id']);
                       $coupon->used++;
                       if($coupon->times != null)
                       {
                            $i = (int)$coupon->times;
                            $i--;
                            $coupon->times = (string)$i;
                       }
                       $coupon->update();

                    }
                    foreach($cart->items as $prod)
                    {
                        $x = (string)$prod['stock'];
                        if($x != null)
                        {
                            $product = Product::findOrFail($prod['item']['id']);
                            $product->stock =  $prod['stock'];
                            $product->update();                
                        }
                    }

        foreach($cart->items as $prod)
        {
            $x = (string)$prod['size_qty'];
            if(!empty($x))
            {
                $product = Product::findOrFail($prod['item']['id']);
                $x = (int)$x;
                $x = $x - $prod['qty'];
                $temp = $product->size_qty;
                $temp[$prod['size_key']] = $x;
                $temp1 = implode(',', $temp);
                $product->size_qty =  $temp1;
                $product->update();               
            }
        }


        foreach($cart->items as $prod)
        {
            $x = (string)$prod['stock'];
            if($x != null)
            {

                $product = Product::findOrFail($prod['item']['id']);
                $product->stock =  $prod['stock'];
                $product->update();  
                if($product->stock <= 5)
                {
                    $notification = new Notification;
                    $notification->product_id = $product->id;
                    $notification->save();                    
                }              
            }
        }

        $gs = Generalsetting::find(1);

        //Sending Email To Buyer

        if($gs->is_smtp == 1)
        {
        $data = [
            'to' => $paypal_data['email'],
            'type' => "new_order",
            'cname' => $paypal_data['name'],
            'oamount' => "",
            'aname' => "",
            'aemail' => "",
            'wtitle' => "",
            'onumber' => $item_number
        ];

        // $mailer = new GeniusMailer();
        // $mailer->sendAutoOrderMail($data,$order->id);            
        // }
        // else
        // {
           $to = $paypal_data['email'];
           $subject = "Your Order Placed!!";
           $msg = "Hello ".$paypal_data['name']."!\nYou have placed a new order.\nYour order number is ".$item_number.".Please wait for your delivery. \nThank you.";
            $headers = "From: ".$gs->from_name."<".$gs->from_email.">";
           mail($to,$subject,$msg,$headers);            
        }
        //Sending Email To Admin
        if($gs->is_smtp == 1)
        {
            $data = [
                'to' => $gs->email,
                'subject' => "New Order Recieved!!",
                'body' => "Hello Admin!<br>Your store has received a new order.<br>Order Number is ".$item_number.".Please login to your panel to check. <br>Thank you.",
            ];

        //     $mailer = new GeniusMailer();
        //     $mailer->sendCustomMail($data);            
        // }
        // else
        // {
           $to = $gs->email;
           $subject = "New Order Recieved!!";
           $msg = "Hello Admin!\nYour store has recieved a new order.\nOrder Number is ".$item_number.".Please login to your panel to check. \nThank you.";
            $headers = "From: ".$gs->from_name."<".$gs->from_email.">";
           mail($to,$subject,$msg,$headers);
        }


        Session::put('temporder',$order);
        Session::put('tempcart',$cart);
        Session::forget('cart');
        Session::forget('already');
        Session::forget('coupon');
        Session::forget('coupon_total');
        Session::forget('coupon_total1');
        Session::forget('coupon_percentage');
        Session::forget('cart');
        Session::forget('paypal_data');
        Session::forget('paypal_items');
            return redirect($success_url);
        }
        else {
            return redirect($cancel_url);
        }









}

     public function paycancle(){
        $this->code_image();
         return redirect()->back()->with('unsuccess','Payment Cancelled.');
     }



     public function payreturn(Request $request){
        $this->code_image();
        if(isset($request->paymentId)){
              $request_data = Session::get('request_data');
              /*echo "<pre>";
              print_r($request_data);exit;*/
              if($request->createaccount) {
                    $users = User::where('email','=',$request_data['billing_email'])->get();
                    
                    if($users->count() < 1) {
                        $user = new User;
                        $user->first_name = $request_data['billing_first_name'];
                        $user->last_name = $request_data['billing_last_name'];
                        $user->area = $request_data['billing_area'];
                        $user->block = $request_data['billing_block'];
                        $user->street = $request_data['billing_street'];
                        $user->city = $request_data['billing_city'];
                        $user->zip = $request_data['billing_zip'];
                        $user->country = $request_data['country'];
                        $user->phone = $request_data['billing_phone'];
                        $user->email = $request_data['billing_email'];
                        $user->password = bcrypt($request_data['password']);
                        $token = md5(time().$request_data['personal_name'].$request_data['personal_email']);
                        $user->verification_link = $token;
                        $user->save();
                        Auth::guard('web')->login($user);
                        if($gs->is_verification_email == 1)
                        {
                             $to = $request_data['billing_email'];
                                $subject = 'Verify your email address.';
                                
                                $message = "Dear Customer,\nSimply click the link below or copy paste in your browser to verify your email address.".url('user/register/verify/'.$token);

                                $msg = "Dear Customer\nWe noticed that you need to verify your email address". url('user/register/verify/'.$token)."Simply click here to verify";
                                $data  = array('to' => $to , 'subject' => $subject , 'msg' => $msg); 
                               
                                $data = [
                                    'to' => $to,
                                    'subject' => $subject,
                                    'body' => $msg,
                                ];
                                
                                $to = $to;
                                $subject = $subject;
                                $txt = $message;

                                $headers = "From: ".$gs->from_name."<".$gs->from_email.">";
                                //echo $to."   ".$headers."   ".$subject."  ".$txt;exit;
                                try{
                                    mail($to,$subject,$txt,$headers);    
                                }
                                catch(Exception $e)
                                {
                                    
                                }
                        }
                    }
                    else
                    {
                        echo json_encode(array('status'=>false,'message'=>'Email is already exist.'));exit;
                    }
                }
                $user = User::find(Auth::id());
                $user->first_name = $request_data['billing_first_name'];
                $user->last_name = $request_data['billing_last_name'];
                $user->area = $request_data['billing_area'];
                $user->block = $request_data['billing_block'];
                $user->street = $request_data['billing_street'];
                $user->city = $request_data['billing_city'];
                $user->zip = $request_data['billing_zip'];
                $user->country = $request_data['billing_country'];
                $user->phone = $request_data['billing_phone'];
                $user->email = $request_data['billing_email'];
                $user->shipping_first_name = isset($request_data['shipping_first_name']) ? $request_data['shipping_first_name'] : '';
                $user->shipping_last_name = isset($request_data['shipping_last_name']) ? $request_data['shipping_last_name'] : '';
                $user->shipping_area = isset($request_data['shipping_area']) ? $request_data['shipping_area'] : '';
                $user->shipping_block = isset($request_data['shipping_block']) ? $request_data['shipping_block'] : '';
                $user->shipping_street = isset($request_data['shipping_street']) ? $request_data['shipping_street'] : '';
                $user->shipping_city = isset($request_data['shipping_city']) ? $request_data['shipping_city'] : '';
                $user->shipping_zip = isset($request_data['shipping_zip']) ? $request_data['shipping_zip'] : '';
                $user->shipping_country = isset($request_data['shipping_country']) ? $request_data['shipping_country'] : '';
                $user->shipping_phone = isset($request_data['shipping_phone']) ? $request_data['shipping_phone'] : '';
                $user->shipping_email = isset($request_data['shipping_email']) ? $request_data['shipping_email'] : '';
                $user->shipping_first_name = isset($request_data['shipping_first_name']) ? $request_data['shipping_first_name'] : '';
                $user->save();
                if (!Session::has('cart')) {
                    return redirect(URL('/carts'));
                }
                if (Session::has('currency')) 
                {
                  $curr = Currency::find(Session::get('currency'));
                }
                else
                {
                    $curr = Currency::where('is_default','=',1)->first();
                }
                $gs = Generalsetting::findOrFail(1);
                $oldCart = Session::get('cart');
                $cart = new Cart($oldCart);
                $pid = "";
                $totalQty = 0;$total_price=0;
                $prdItemArr = array();
                $index = 0;
                $attr_id = 0;
                $prd_for_api = array();
                foreach($cart->items as $key => $value){
                    
                         $pd=Product::find($value['item']['id']);
                    $st=$pd->stock-$value['qty'];
                  Product::where('id','=',$value['item']['id'])->update(['stock'=>$st]);
                   //return  Product::find($value['item']['id']);
                   
                   
                    $variations = $value['variations'];
                    $attr_id = $value['attr_id'];
                    $pid .= ','.$value['item']['id'];
                    $totalQty++;
                    $total_price += number_format($value['unit_price']*$value['qty'],3);
                    $prdItemArr[$index]['ItemName'] = $value['item']['name'];
                    $prdItemArr[$index]['Quantity'] = $value['qty'];
                    $prdItemArr[$index]['UnitPrice'] = number_format($value['unit_price'],3);
                    $prd_for_api[$index]['ProductCode'] = $value['item']['sku'];
                    $prd_for_api[$index]['Unit_Name'] = 'PCS';
                    $prd_for_api[$index]['Quantity'] = $value['qty'];
                    $prd_for_api[$index]['Rate'] = $value['unit_price'];
                    $prd_for_api[$index]['Gross'] = $value['unit_price'];
                    $index++;
                }
                $prdItemArr = json_encode($prdItemArr);
               if(isset($request_data['ship_to_different_address']))
                {
                    if($request_data['ship_to_different_address']==1)
                    {
                          $shipping='shipto'; 
                    }
                    
                    else
                    {
                          $shipping='shipto'; 
                          
                          
                          $request_data['shipping_first_name'] = isset($request_data['billing_first_name']) ? $request_data['billing_first_name'] : '';
               $request_data['shipping_last_name'] = isset($request_data['billing_last_name']) ? $request_data['billing_last_name'] : '';
               $request_data['shipping_area'] = isset($request_data['billing_area']) ? $request_data['billing_area'] : '';
               $request_data['shipping_block'] = isset($request_data['billing_block']) ? $request_data['billing_block'] : '';
               $request_data['shipping_street'] = isset($request_data['billing_street']) ? $request_data['billing_street'] : '';
               $request_data['shipping_city'] = isset($request_data['billing_city']) ? $request_data['billing_city'] : '';
               $request_data['shipping_zip'] = isset($request_data['billing_zip']) ? $request_data['billing_zip'] : '';
               $request_data['shipping_country'] = isset($request_data['billing_country']) ? $request_data['billing_country'] : '';
               $request_data['shipping_phone'] = isset($request_data['billing_phone']) ? $request_data['billing_phone'] : '';
               $request_data['shipping_email'] = isset($request_data['billing_email']) ? $request_data['billing_email'] : '';
               
               
                    }
                }
                else
                {
                   $shipping='shipto'; 
                   
                   $request_data['shipping_first_name'] = isset($request_data['billing_first_name']) ? $request_data['billing_first_name'] : '';
               $request_data['shipping_last_name'] = isset($request_data['billing_last_name']) ? $request_data['billing_last_name'] : '';
               $request_data['shipping_area'] = isset($request_data['billing_area']) ? $request_data['billing_area'] : '';
               $request_data['shipping_block'] = isset($request_data['billing_block']) ? $request_data['billing_block'] : '';
               $request_data['shipping_street'] = isset($request_data['billing_street']) ? $request_data['billing_street'] : '';
               $request_data['shipping_city'] = isset($request_data['billing_city']) ? $request_data['billing_city'] : '';
               $request_data['shipping_zip'] = isset($request_data['billing_zip']) ? $request_data['billing_zip'] : '';
               $request_data['shipping_country'] = isset($request_data['billing_country']) ? $request_data['billing_country'] : '';
               $request_data['shipping_phone'] = isset($request_data['billing_phone']) ? $request_data['billing_phone'] : '';
               $request_data['shipping_email'] = isset($request_data['billing_email']) ? $request_data['billing_email'] : '';
               
                }
               
                $shipping_cost = isset($request_data['shipping_cost']) ? $request
                $shipping_cost = isset($request_data['shipping_cost']) ? $request_data['shipping_cost'] : 0;
                $tax = isset($request_data['tax']) ? $request_data['tax']: 0;
                $coupon_code = isset($request_data['code']) ? $request_data['coupon_code'] : '';
                $coupon_discount = isset($request_data['coupon_discount']) ? $request_data['coupon_discount'] : '';
                $str = ltrim($pid, ',');
                $coupon = Session::has('coupon') ? Session::get('coupon') : 0;
                $oldCart = Session::get('cart');
                $cart = new Cart($oldCart);
                $total = $total_price;
                if($gs->tax != 0)
                {
                    $tax = ($total / 100) * $gs->tax;
                    $total = $total + $tax;
                }
                if(!empty($shipping_cost))
                {
                    $total = $total + $shipping_cost;
                }
                if(!Session::has('coupon_total1'))
                {
                    $total = $total - $coupon;     
                    $total = $total + 0;               
                }
                else {
                    
                    $total = Session::get('coupon_total1'); 
                    $total = str_replace('KD', '', $total);
                    $total = (float)$total + round(0 * (float)$curr->value, 2); 
                }
                $ord_inc_id = $gs->order_increment_id;
                if(empty($ord_inc_id))
                {
                    $ord_inc_id = '100001';
                }
                else
                {
                    $ord_inc_id = (int)$ord_inc_id+1;
                }
                $ordernumber = 'ORD'.(string)$ord_inc_id;
                $order = new Order;
                $success_url = action('Front\PaymentController@payreturn');
                $item_name = $gs->title." Order";
                $item_number = str_random(4).time();
                $order['user_id'] = Auth::id();
                $order['cart'] = utf8_encode(bzcompress(serialize($cart), 9)); 
                $order['totalQty'] = $totalQty;
                $order['product_id'] = $str;
                $order['pay_amount'] = round($total_price / $curr->value, 2) + $shipping_cost + $tax - $coupon_discount;
                $order['method'] = $request_data['payment_method'];
                $order['shipping'] = $shipping;
                $order['shipping_cost'] = $shipping_cost;
                $order['packing_cost'] = 0;
                $order['tax'] = $tax;
                $order['order_number'] = $ordernumber;
                $order['order_note'] = $request_data['order_comments'];
                $order['coupon_code'] = $coupon_code;
                $order['coupon_discount'] = $coupon_discount;
                $order['dp'] = isset($request_data['dp']) ? $request_data['dp'] : 0;
                $order['payment_status'] = "Pending";
                $order['currency_sign'] = $curr->sign;
                $order['currency_value'] = $curr->value;
                $order['delivery_time'] = $request_data['delivery_time'];
                
                
                $order['shipping_first_name'] = isset($request_data['shipping_first_name']) ? $request_data['shipping_first_name'] : '';
                $order['shipping_last_name'] = isset($request_data['shipping_last_name']) ? $request_data['shipping_last_name'] : '';
                $order['shipping_area'] = isset($request_data['shipping_area']) ? $request_data['shipping_area'] : '';
                $order['shipping_block'] = isset($request_data['shipping_block']) ? $request_data['shipping_block'] : '';
                $order['shipping_street'] = isset($request_data['shipping_street']) ? $request_data['shipping_street'] : '';
                $order['shipping_city'] = isset($request_data['shipping_city']) ? $request_data['shipping_city'] : '';
                $order['shipping_zip'] = isset($request_data['shipping_zip']) ? $request_data['shipping_zip'] : '';
                $order['shipping_country'] = isset($request_data['shipping_country']) ? $request_data['shipping_country'] : '';
                $order['shipping_phone'] = isset($request_data['shipping_phone']) ? $request_data['shipping_phone'] : '';
                $order['shipping_email'] = isset($request_data['shipping_email']) ? $request_data['shipping_email'] : '';
                
                
                $order->save();
                
                Generalsetting::where('id',1)->update(array('order_increment_id'=>$ord_inc_id));
                $orderupdate = \DB::table("orders")->where('id',$order->id)->update(['order_number'=>$ordernumber]);
                $cartValues = Session::get('cartValues');
                foreach($cart->items as $v){
                    $insertOrderedProductDetails = \DB::table("ordered_product_details")->insertGetID(['order_number'=>$ordernumber,'product_id'=>$v['item']['id']
                        ,'product_name'=>$v['item']['name']]);
                }
                $track = new OrderTrack;
                $track->title = 'Pending';
                $track->text = 'You have successfully placed your order.';
                $track->order_id = $order->id;
                $track->save();

                $notification = new Notification;
                $notification->order_id = $order->id;
                $notification->save();
                if(isset($request_data['coupon_id']) && $request_data['coupon_id'] != "")
                {
                   $coupon = Coupon::findOrFail($request_data['coupon_id']);
                   $coupon->used++;
                   if($coupon->times != null)
                   {
                        $i = (int)$coupon->times;
                        $i--;
                        $coupon->times = (string)$i;
                   }
                    $coupon->update();
                }
                foreach($cart->items as $prod)
                {
                    $x = (string)$prod['stock'];
                    if($x != null)
                    {
                        $product = Product::findOrFail($prod['item']['id']);
                        $product->stock =  $prod['stock'];
                        //$product->update();  
                        $attr_stock = DB::table('product_variations')->select('qty')->where('id', $prod['attr_id'])->first();
                        if(isset($attr_stock->qt))
                        {
                            $stock = $attr_stock->qty;
                            DB::table('product_variations')->where('id', $prod['attr_id'])->update(array('qty'=>($stock-1)));    
                        }
                        
                        if($product->stock <= 5)
                        {
                            $notification = new Notification;
                            $notification->product_id = $product->id;
                            $notification->save();                    
                        }              
                    }
                }
                if($gs->is_smtp == 1)
                {
                    $data = [
                        'to' => $request_data['billing_email'],
                        'type' => "new_order",
                        'cname' => $request_data['billing_first_name']." ".$request_data['billing_last_name'],
                        'oamount' => "KD ".$order->pay_amount,
                        'aname' => "",
                        'aemail' => "",
                        'wtitle' => "",
                        'onumber' => $ordernumber,
                    ];

                    $mailer = new GeniusMailer();
                    $this->sendAutoOrderMail($data,$order->id,$order->order_number);            
                }
                else
                {
                   $to = $request_data['billing_email'];
                   $subject = "Your Order Placed!!";
                   $msg = "Hello ".$request_data['billing_name']."!\nYou have placed a new order.\nYour order number is ".$ordernumber.".Please wait for your delivery. \nThank you.";
                    $headers = "From: ".$gs->from_name."<".$gs->from_email.">";
                   mail($to,$subject,$msg,$headers);            
                }
                //Sending Email To Admin
                if($gs->is_smtp == 1)
                {
                    $data = [
                        'to' => $gs->email,
                        'subject' => "New Order Recieved!!",
                        'body' => "Hello Admin!<br>Your store has received a new order.<br>Order Number is ".$ordernumber.".Please login to your panel to check. <br>Thank you.",
                    ];

                    $mailer = new GeniusMailer();
                    $mailer->sendCustomMail($data);            
                }
                else
                {
                   $to = $gs->email;
                   $subject = "New Order Recieved!!";
                   $msg = "Hello Admin!\nYour store has recieved a new order.\nOrder Number is ".$ordernumber.".Please login to your panel to check. \nThank you.";
                    $headers = "From: ".$gs->from_name."<".$gs->from_email.">";
                   mail($to,$subject,$msg,$headers);
                }
              //Session::forget('cart');
              //$order_data = Session::get('online_payment_order');
              $online_payment = Session::get('online_payment');

              
              $user = Auth::user();
              $transaction_id = $request->paymentId;
              //$order = Order::where('id',$order_data->id)->first();
              $prd_for_api = array();
              $index = 0;
              foreach($online_payment->items as $key => $value){
                $prd_for_api[$index]['ProductCode'] = $value['item']['sku'];
                $prd_for_api[$index]['Unit_Name'] = 'PCS';
                $prd_for_api[$index]['Quantity'] = $value['qty'];
                $prd_for_api[$index]['Rate'] = $value['unit_price'];
                $prd_for_api[$index]['Gross'] = $value['unit_price'];
                $index++;
              }
               //save order api start
                $url = "http://168.187.178.135/Marafie/api/Focus/PostInv";
                $curl = curl_init();
                curl_setopt($curl, CURLOPT_URL,$url);
                curl_setopt($curl, CURLOPT_POST, 1);
                curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query(array('SInvHeaderDetails' => array('OrderNo'=>$order->order_number,'OrderDate'=>date('Y-m-d'),'Narration'=>'Test Narration','PaymentMode'=>'Knet'),'SInvBodyDetails'=>$prd_for_api)));
                $result = curl_exec($curl);
                $info = curl_getinfo($curl);
                curl_close($curl);
                $json = json_decode($result, true);
                //print_r($json);exit;
              //save order api end
              //if(empty($order->txnid)){
                //echo "test ".$transaction_id;exit;
                /*$order_save = Order::find($order_data->id);
                $order_save->payment_status = 'Completed';
                $order_save->timestamps = false;
                $order_save->txnid = $transaction_id;
                $order_save->save();*/
                /*echo "<pre>";
                print_r($order);exit;*/
                DB::table('orders')->where('id', $order->id)->update(array('payment_status' => 'Completed', 'txnid' => $transaction_id));
              //}
                //sleep(30);
              if (Session::has('currency')) 
                {
                    $curr = Currency::find(Session::get('currency'));
                }
                else
                {
                    $curr = Currency::where('is_default','=',1)->first();
                }
              $order_product = DB::table('ordered_product_details')->where('order_number',$order->order_number)->get();
              $tempcart = Session::get('online_payment');
              $product_data = Product::select('products.*')->join('ordered_product_details','ordered_product_details.product_id','=','products.id')->where('ordered_product_details.order_number',$order->order_number)->get();
                Session::forget('cart');
                Session::forget('already');
                Session::forget('coupon');
                Session::forget('coupon_total');
                Session::forget('coupon_total1');
                Session::forget('coupon_percentage');
                Session::save();
                
                          $order = Order::where('id',$order->id)->first();
            
      
         $cart = unserialize(bzdecompress(utf8_decode($order->cart)));
       
             return view('front.success',compact('order','tempcart','order_product','product_data','curr','gs','user','cart'));
        }
        if(Session::has('tempcart')){
            $oldCart = Session::get('tempcart');
            $tempcart = new Cart($oldCart);
            $order_data = Session::get('temporder');
            $order = Order::where('id',$order_data->id)->first();
            $order_product = DB::table('ordered_product_details')->where('order_number',$order->order_number)->get();
            return view('front.success',compact('tempcart','order','order_product'));
            
        }
        else{
            $tempcart = '';
            return redirect()->back();
        }
     }


      public function sendAutoOrderMail(array $mailData,$id,$order_number)
    {
        $setup = Generalsetting::find(1);
        $orderdata = Order::select('*')->where('id',$id)->get()->first();
        $order_number = $orderdata->order_number;
        $datas = array();
        if(!empty($orderdata))
        {
            $order =  Order::select('*')->leftjoin('ordered_product_details','ordered_product_details.order_number','=','orders.order_number')
            ->select('ordered_product_details.product_id','ordered_product_details.product_name','orders.totalQty','orders.pay_amount')
            ->where('orders.id','=',DB::raw("$id"))->where('user_id', DB::raw("$orderdata->user_id"))->get();
            /*$order_status_info = array(
                                    'order_placed' => false,
                                    'on_review' => false,
                                    'on_delivery' => false,
                                    'delivered' => false
                                );

            if($order->status == "pending") 
                $order_status_info['order_placed'] = true;

            if($order->status == "processing")
                $order_status_info['on_review'] = true;

            if($order->status == "on delivery") 
                $order_status_info['on_delivery'] = true;

            if($order->status == "completed")
                $order_status_info['delivered'] = true;*/

            $payment_info = array(
                                'order_id' => isset($orderdata->order_number) ? $orderdata->order_number : '',
                                'total_products' => isset($orderdata->totalQty) ? $orderdata->totalQty : '',
                                'total_cost' => isset($orderdata->pay_amount) ? 'KD'.$orderdata->pay_amount : '',
                                'ordered_date' => isset($orderdata->created_at) ? date('Y-m-d H:i:s', strtotime($orderdata->created_at)) : '',
                                'payment_method' => isset($orderdata->method) ? $orderdata->method : '',
                                'transaction_id' => isset($orderdata->txnid) ? $orderdata->txnid : '',
                                'payment_status' => ($orderdata->payment_status == 'Pending') ? 'Unpaid' : 'Paid'
                            );
            $userData = User::find($orderdata->user_id);
            $billing_info = array(
                                'name' => $userData->first_name.' '.$userData->last_name,
                                'email' => isset($userData->email) ? $userData->email : '',
                                'phone' => isset($userData->mobile) ? $userData->mobile : '',
                                'area' => isset($userData->area) ? $userData->area : '',
                                'block' => isset($userData->block) ? $userData->block : '',
                                'street' => isset($userData->street) ? $userData->street : '',
                                'country' => isset($userData->country) ? getcountry($userData->country) : '',
                                'city' => isset($userData->city) ? $userData->city : '',
                                'postal_code' => isset($userData->zip) ? $userData->zip : ''
                            );
            $billing_name = $userData->first_name.' '.$userData->last_name;
            $shipping_name = $userData->shipping_first_name.' '.$userData->shipping_last_name;
            $billing_email = isset($userData->email) ? $userData->email : '';
            $shipping_email = isset($userData->shipping_email) ? $userData->shipping_email : '';

            $shiping_info = array(
                                'name' => !empty($shipping_name) ? $shipping_name : $billing_name,
                                'email' => !empty($shipping_email) ? $shipping_email : $billing_email,
                                'phone' => !empty($userData->shipping_phone) ? $userData->shipping_phone : $userData->phone,
                                'area' => !empty($userData->shipping_area) ? $userData->shipping_area : $userData->area,
                                'block' => !empty($userData->shipping_block) ? $userData->shipping_block : $userData->block,
                                'street' => !empty($userData->shipping_street) ? $userData->shipping_street : $userData->street,
                                'country' => !empty($userData->shipping_country) ? getcountry($userData->shipping_country) : getcountry($userData->country),
                                'city' => !empty($userData->shipping_city) ? $userData->shipping_city : $userData->city,
                                'postal_code' => !empty($userData->shipping_zip) ? $userData->shipping_zip : $userData->zip
                            );

            $order_products = array();

            foreach($order as $key => $product)
            {
                $order_products[$key]['product_id'] = isset($product->product_id) ? $product->product_id : '';
                $order_products[$key]['product_name'] = isset($product->product_name) ? $product->product_name : '';
                $order_products[$key]['product_name'] = isset($product->product_name) ? $product->product_name : '';
                //$order_products[$key]['product_brand'] = isset($product->product_brand) ? $product->product_brand : '';
                //$order_products[$key]['product_category'] = isset($product->product_category) ? $product->product_category : '';
                $order_products[$key]['product_type'] = isset($product->product_type) ? $product->product_type : '';
                $order_products[$key]['total_qty'] = isset($product->totalQty) ? $product->totalQty : '';
                $order_products[$key]['pay_amount'] = isset($product->pay_amount) ? $product->pay_amount : '';
            }

            $datas =  array('payment_data' => $payment_info, 'billing_address' => $billing_info, 'shipping_address' => $shiping_info, 'products_data' => $order_products);
        }
        $billing_info_html = '<p style="margin:2px 0px;">'.$datas['billing_address']['name'].'</p>';
        $billing_info_html.= '<p style="margin:2px 0px;">'.$datas['billing_address']['area'].', '.$datas['billing_address']['area'].', '.$datas['billing_address']['street'].'</p>';
        $billing_info_html.= '<p style="margin:2px 0px;">'.$datas['billing_address']['city'].', '.$datas['billing_address']['postal_code'].'</p>';
        $billing_info_html.= '<p style="margin:2px 0px;">'.$datas['billing_address']['country'].'</p>';

        $shipping_info_html = '<p style="margin:2px 0px;">'.$datas['shipping_address']['name'].'</p>';
        $shipping_info_html.= '<p style="margin:2px 0px;">'.$datas['shipping_address']['area'].', '.$datas['shipping_address']['area'].', '.$datas['shipping_address']['street'].'</p>';
        $shipping_info_html.= '<p style="margin:2px 0px;">'.$datas['shipping_address']['city'].', '.$datas['shipping_address']['postal_code'].'</p>';
        $shipping_info_html.= '<p style="margin:2px 0px;">'.$datas['shipping_address']['country'].'</p>';
        $payment_method =$datas['payment_data']['payment_method'];
        $order_items_html = '';
        $order_items_html.= '<table border="0" cellpadding="0" cellspacing="0" width="100%">';
        $order_items_html.= '<tr style="height: 21px;">
                            <td align="left" bgcolor="#D2C7BA" width="50%" style="padding: 12px; font-size: 16px; line-height: 24px;">&nbsp;Item</td>
                            <td align="left" bgcolor="#D2C7BA" width="25%" style="padding: 12px; font-size: 16px; line-height: 24px;">Qty</td>
                            <td align="left" bgcolor="#D2C7BA" width="25%" style="padding: 12px;  font-size: 16px; line-height: 24px;">Price</td>
                            </tr>';
        foreach ($datas['products_data'] as $key => $value) {
            $order_items_html.= '<tr style="height: 21px;">';
            $order_items_html.= '<td align="left" width="50%" style="padding: 6px 12px;font-size: 16px; line-height: 24px;">'.$value['product_name'].'</td>';
            $order_items_html.= '<td align="left" width="25%" style="padding: 6px 12px;font-size: 16px; line-height: 24px;">'.$value['total_qty'].'</td>';
            $order_items_html.= '<td align="left" width="25%" style="padding: 6px 12px; font-size: 16px; line-height: 24px;">'.$value['pay_amount'].'</td>';
            $order_items_html.= '</tr>';
        }
        $order_items_html.= '<tr style="height: 21px;">';
        $order_items_html.= '<td align="left" width="25%" style="padding: 6px 12px; font-size: 16px; line-height: 24px;" colspan="2" >Total</td>';
        $order_items_html.= '<td align="left" width="25%" style="padding: 6px 12px; font-size: 16px; line-height: 24px;">'.$datas['payment_data']['total_cost'].'</td>';
        $order_items_html.= '</tr>';
        $order_items_html.='</table>';

        $temp = EmailTemplate::where('email_type','=',$mailData['type'])->first();

        $body = preg_replace("/{customer_name}/", $mailData['cname'] ,$temp->email_body);
        // $body = preg_replace("@logo@", $setup->logo ,$body);
        $body = preg_replace("/{order_amount}/", $mailData['oamount'] ,$body);
        $body = preg_replace("/{admin_name}/", $mailData['aname'] ,$body);
        $body = preg_replace("/{admin_email}/", $mailData['aemail'] ,$body);
        $body = preg_replace("/{order_number}/", $order_number ,$body);
        $body = preg_replace("/{website_title}/", $setup->title ,$body);
        $subject = preg_replace("/{order_number}/", $order_number ,$temp->email_subject);
        $body = str_replace("{order_date}", date('M d, Y H:i:s', strtotime($orderdata->created_at)) ,$body);
        $body = str_replace("{billing_info}", $billing_info_html,$body);
        $body = str_replace("{shipping_info}", $shipping_info_html ,$body);
        $body = str_replace("{payment_method}", $payment_method ,$body);
        $body = str_replace("{order_items}", $order_items_html ,$body);
        $data = [
            'email_body' => $body
        ];


        $objDemo = new \stdClass();
        $objDemo->to = $mailData['to'];
        $objDemo->from = $setup->from_email;
        $objDemo->title = $setup->from_name;
        $objDemo->subject = $subject;

        try{
            Mail::send('admin.email.mailbody',$data, function ($message) use ($objDemo,$id) {
                $message->from($objDemo->from,$objDemo->title);
                $message->to($objDemo->to);
                $message->subject($objDemo->subject);
        $order = Order::findOrFail($id);
        $cart = unserialize(bzdecompress(utf8_decode($order->cart)));
        


            });

        }
        catch (\Exception $e){
            //die("Not Sent!");
        }

        $files = glob('assets/prints/*'); //get all file names
        foreach($files as $file){
            if(is_file($file))
            unlink($file); //delete file
        }
        

    }
    // Capcha Code Image
    private function  code_image()
    {
        $actual_path = str_replace('project','',base_path());
        $image = imagecreatetruecolor(200, 50);
        $background_color = imagecolorallocate($image, 255, 255, 255);
        imagefilledrectangle($image,0,0,200,50,$background_color);

        $pixel = imagecolorallocate($image, 0,0,255);
        for($i=0;$i<500;$i++)
        {
            imagesetpixel($image,rand()%200,rand()%50,$pixel);
        }

        $font = $actual_path.'assets/front/fonts/NotoSans-Bold.ttf';
        $allowed_letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        $length = strlen($allowed_letters);
        $letter = $allowed_letters[rand(0, $length-1)];
        $word='';
        //$text_color = imagecolorallocate($image, 8, 186, 239);
        $text_color = imagecolorallocate($image, 0, 0, 0);
        $cap_length=6;// No. of character in image
        for ($i = 0; $i< $cap_length;$i++)
        {
            $letter = $allowed_letters[rand(0, $length-1)];
            imagettftext($image, 25, 1, 35+($i*25), 35, $text_color, $font, $letter);
            $word.=$letter;
        }
        $pixels = imagecolorallocate($image, 8, 186, 239);
        for($i=0;$i<500;$i++)
        {
            imagesetpixel($image,rand()%200,rand()%50,$pixels);
        }
        session(['captcha_string' => $word]);
        imagepng($image, $actual_path."assets/images/capcha_code.png");
    }
    public function payerror()
    {
        return redirect()->route('front.checkout')->with('error',"Something went wrong! Please try again later!");   
    }
}
