<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Collection extends Model
{
    protected $fillable = ['name','name_ar','photo','banner','banner_ar','banner_image'];
    protected $table = 'collection';
    public $timestamps = false;
}