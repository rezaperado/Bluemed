<?php

namespace App\Models;

use Illuminate\Foundation\Auth\User as Authenticatable;
use DB;
class User extends Authenticatable
{
    protected $guarded = [];
    // protected $fillable = ['name', 'photo', 'zip', 'residency', 'city', 'country', 'address', 'phone', 'fax', 'email','password','affilate_code','verification_link'];


    protected $hidden = [
        'password', 'remember_token'
    ];
    public function IsVendor(){
        if ($this->is_vendor == 2) {
           return true;
        }
        return false;
    }
    public function getVendorRole()
    {
        $vendor_role_id = DB::table('roles')->select('id')->where('name','Vendor')->get()->first();
        $vendor_role_id = $vendor_role_id->id;
        if($this->role_id == $vendor_role_id)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    public function role()
    {
        return $this->belongsTo('App\Models\Role');
    }
    public function orders()
    {
        return $this->hasMany('App\Models\Order');
    }

    public function comments()
    {
        return $this->hasMany('App\Models\Comment');
    }

    public function replies()
    {
        return $this->hasMany('App\Models\Reply');
    }

    public function ratings()
    {
        return $this->hasMany('App\Models\Rating');
    }

    public function wishlists()
    {
        return $this->hasMany('App\Models\Wishlist');
    }

    public function socialProviders()
    {
        return $this->hasMany('App\Models\SocialProvider');
    }

    public function withdraws()
    {
        return $this->hasMany('App\Models\Withdraw');
    }

    public function conversations()
    {
        return $this->hasMany('App\Models\AdminUserConversation');
    }

    public function notifications()
    {
        return $this->hasMany('App\Models\Notification');
    }

    public function reports()
    {
        return $this->hasMany('App\Models\Report','user_id');
    }
    public function products()
    {
        return $this->hasMany('App\Models\Product');
    }
    public function services()
    {
        return $this->hasMany('App\Models\Service');
    }
    public function checkStatus()
    {
        return count($this->verifies) > 0 ? ($this->verifies()->orderBy('id','desc')->first()->status == 'Verified' ? true : false) :false;
    }
    public function verifies()
    {
        return $this->hasMany('App\Models\Verification','user_id');
    }
    public function checkWarning()
    {
        return count($this->verifies) > 0 ? ( empty( $this->verifies()->where('admin_warning','=','1')->orderBy('id','desc')->first() ) ? false : (empty($this->verifies()->where('admin_warning','=','1')->orderBy('id','desc')->first()->status) ? true : false) ) : false;
    } 
    public function displayWarning()
    {
        return $this->verifies()->where('admin_warning','=','1')->orderBy('id','desc')->first()->warning_reason;
    }
    public function sectionCheck($value){
        $role_sections = DB::table('roles')->select('section')->where('id', $this->role_id)->get()->first();
        $role_sections = $role_sections->section;
        $sections = explode(" , ", $role_sections);
        if (in_array($value, $sections)){
            return true;
        }else{
            return false;
        }
    }
}
