<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class inventory extends Model
{
    protected $fillable = ['attribute_id','qty','description'];
    public $timestamps = false;
    
   
    public function products()
    {
        return $this->hasMany('App\Models\Product');
    }
    
    // public function setSlugAttribute($value)
    // {
    //     $this->attributes['slug'] = str_replace(' ', '-', $value);
    // }

}
