<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class DeliveryTime extends Model
{
    protected $fillable = ['time'];
    public $table = 'delivery_time';
    public $timestamps = false;
}
