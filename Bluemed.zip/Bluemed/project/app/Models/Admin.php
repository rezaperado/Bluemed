<?php

namespace App\Models;

use Illuminate\Foundation\Auth\User as Authenticatable;
use DB;
class Admin extends Authenticatable
{
    protected $guard = 'admin';

    protected $fillable = [
        'name', 'email', 'phone', 'password',  'photo', 'created_at', 'updated_at', 'remember_token','shop_name','role_id','author','vendor_id','role'
    ];

    protected $hidden = [
        'password', 'remember_token',
    ];
    public function role()
    {
        return $this->belongsTo('App\Models\Role');
    }
    public function IsSuper(){
        if ($this->id == 1) {
           return true;
        }
        return false;
    }
    public function IsAdmin(){
        if ($this->role == 'Administrator') {
           return true;
        }
        return false;
    }
    public function IsStaff(){
        if ($this->role == 'Staff') {
           return true;
        }
        return false;
    }
    public function sectionCheck($value){
        $role_sections = DB::table('roles')->select('section')->where('id', $this->role_id)->get()->first();
        $role_sections = $role_sections->section;
        $sections = explode(" , ", $role_sections);
        if (in_array($value, $sections)){
            return true;
        }else{
            return false;
        }
    }
}
