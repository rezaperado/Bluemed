<?php

namespace App\Models;
use Session;

use Illuminate\Database\Eloquent\Model;

class Cart extends Model
{
    public $items = null;
    public $totalQty = 0;
    public $totalPrice = 0;

    public function __construct($oldCart)
    {
        if ($oldCart) {
            $this->items = $oldCart->items;
            $this->totalQty = $oldCart->totalQty;
            $this->totalPrice = $oldCart->totalPrice;
        }
    }

// **************** ADD TO CART *******************
    public function updateqty($item, $id, $variations, $total_stock,$quantity)
    {
        $storedItem = ['qty' => 0,'stock' => $total_stock, 'price' => $item->price, 'item' => $item, 'dp' => '0','variations' => $variations];
        if($item->type == 'Physical')
        {
            if ($this->items) {
                if (array_key_exists($id, $this->items)) {
                    $storedItem = $this->items[$id];
                }
            }            
        }
        else {
            if ($this->items) {
                if (array_key_exists($id, $this->items)) {
                    $storedItem = $this->items[$id];
                    $storedItem['dp'] = 1;
                }
            }
        }

        $storedItem['qty'] = $quantity;
        $stck = (string)$total_stock;
        if($stck != null && $stck != 0){
                $storedItem['stock']--;
        }   
        $item_price = getVariationPrice($id);
        $storedItem['price'] = $item_price * $storedItem['qty'];
        $storedItem['unit_price'] = $item_price;
        $this->items[$id] = $storedItem;
        $this->totalQty++;
    }
    public function add($item, $id, $variations, $total_stock,$quantity, $attr_id = null) {

        $storedItem = ['qty' => 0,'stock' => $total_stock, 'price' => $item->price, 'item' => $item, 'dp' => '0','variations' => $variations,'attr_id' => $attr_id];
        if($item->type == 'Physical')
        {
            if ($this->items) {
                if (array_key_exists($id, $this->items)) {
                    $storedItem = $this->items[$id];
                }
            }            
        }
        else {
            if ($this->items) {
                if (array_key_exists($id, $this->items)) {
                    $storedItem = $this->items[$id];
                    $storedItem['dp'] = 1;
                }
            }
        }
        $storedItem['qty']+= $quantity;
        $stck = (string)$total_stock;
        if($stck != null && $stck != 0){
                $storedItem['stock']--;
        }   
        $item_price = getVariationPrice($id);
        $storedItem['price'] = $item_price * $storedItem['qty'];
        $storedItem['unit_price'] = $item_price;
        $this->items[$id] = $storedItem;
        $this->totalQty++;
    }

// **************** ADD TO CART ENDS *******************



// **************** ADD TO CART MULTIPLE *******************

    public function addnum($item, $id, $qty, $price) {
        $size_cost = 0;
        $storedItem = ['qty' => 0, 'price' => $item->price, 'item' => $item, 'dp' => '0'];
        if($item->type == 'Physical')
        {
            if ($this->items) {
                if (array_key_exists($id, $this->items)) {
                    $storedItem = $this->items[$id];
                }
            }            
        }
        else {
            if ($this->items) {
                if (array_key_exists($id.$size, $this->items)) {
                    $storedItem = $this->items[$id.$size];
                    $storedItem['dp'] = 1;
                }
            }
        }
        $item->price += $price;
        if(!empty($item->whole_sell_qty))
        {
            foreach(array_combine($item->whole_sell_qty,$item->whole_sell_discount) as $whole_sell_qty => $whole_sell_discount)
            {
                if($storedItem['qty'] == $whole_sell_qty)
                {   
                    $whole_discount[$id.$size] = $whole_sell_discount;
                    Session::put('current_discount',$whole_discount);
                    break;
                }                  
            }
            if(Session::has('current_discount')) {
                    $data = Session::get('current_discount');
                if (array_key_exists($id.$size, $data)) {
                    $discount = $item->price * ($data[$id.$size] / 100);
                    $item->price = $item->price - $discount;
                }
            }
        }

        $storedItem['price'] = $price * $storedItem['qty'];
        $this->items[$id] = $storedItem;
        $this->totalQty++;
    }


// **************** ADD TO CART MULTIPLE ENDS *******************


// **************** ADDING QUANTITY *******************

    public function adding($item, $id, $size_qty, $size_price) {
        $storedItem = ['qty' => 0, 'size_key' => 0,'size_qty' =>  $item->size_qty,'size_price' => $item->size_price, 'size' => $item->size, 'color' => $item->color, 'stock' => $item->stock, 'price' => $item->price, 'item' => $item, 'license' => ''];
        if ($this->items) {
            if (array_key_exists($id, $this->items)) {
                $storedItem = $this->items[$id];
            }
        }
        $storedItem['qty']++;

            if($item->stock != null){
                $storedItem['stock']--;
            }          
        $item->price += (double)$size_price;   
        if(!empty($item->whole_sell_qty))
        {
            foreach(array_combine($item->whole_sell_qty,$item->whole_sell_discount) as $whole_sell_qty => $whole_sell_discount)
            {
                if($storedItem['qty'] == $whole_sell_qty)
                {   
                    $whole_discount[$id] = $whole_sell_discount;
                    Session::put('current_discount',$whole_discount);
                    break;
                }                  
            }
            if(Session::has('current_discount')) {
                    $data = Session::get('current_discount');
                if (array_key_exists($id, $data)) {
                    $discount = $item->price * ($data[$id] / 100);
                    $item->price = $item->price - $discount;
                }
            }
        }

        $storedItem['price'] = $item->price * $storedItem['qty'];
        $this->items[$id] = $storedItem;
        $this->totalQty++;
    }

// **************** ADDING QUANTITY ENDS *******************


// **************** REDUCING QUANTITY *******************

    public function reducing($item, $id, $size_qty, $size_price) {
        $storedItem = ['qty' => 0, 'size_key' => 0, 'size_qty' =>  $item->size_qty,'size_price' => $item->size_price, 'size' => $item->size, 'color' => $item->color, 'stock' => $item->stock, 'price' => $item->price, 'item' => $item, 'license' => ''];
        if ($this->items) {
            if (array_key_exists($id, $this->items)) {
                $storedItem = $this->items[$id];
            }
        }
        $storedItem['qty']--;
            if($item->stock != null){
                $storedItem['stock']++;
            }            

        $item->price += (double)$size_price;   
        if(!empty($item->whole_sell_qty))
        {
            $len = count($item->whole_sell_qty);
            foreach($item->whole_sell_qty as $key => $data1)
            {
                if($storedItem['qty'] < $item->whole_sell_qty[$key])
                {   
                    if($storedItem['qty'] < $item->whole_sell_qty[0])
                    {   
                        Session::forget('current_discount');
                        break;
                    }  

                    $whole_discount[$id] = $item->whole_sell_discount[$key-1];
                    Session::put('current_discount',$whole_discount);
                    break;
                }      


            }
            if(Session::has('current_discount')) {
                    $data = Session::get('current_discount');
                if (array_key_exists($id, $data)) {
                    $discount = $item->price * ($data[$id] / 100);
                    $item->price = $item->price - $discount;
                }
            }
        }

        $storedItem['price'] = $item->price * $storedItem['qty'];
        $this->items[$id] = $storedItem;
        $this->totalQty--;
    }

// **************** REDUCING QUANTITY ENDS *******************

    public function updateLicense($id,$license) {

        $this->items[$id]['license'] = $license;
    }

    public function updateColor($item, $id,$color) {

        $this->items[$id]['color'] = $color;
    }

    public function removeItem($id) {
        $this->totalQty -= $this->items[$id]['qty'];
        $this->totalPrice -= $this->items[$id]['price'];
        
        unset($this->items[$id]);
            if(Session::has('current_discount')) {
                    $data = Session::get('current_discount');
                if (array_key_exists($id, $data)) {
                    unset($data[$id]);
                    Session::put('current_discount',$data);
                }
            }

    }
}
