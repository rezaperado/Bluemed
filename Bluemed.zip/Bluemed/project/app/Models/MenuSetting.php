<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class MenuSetting extends Model
{
    protected $fillable = ['title','link','parent','order','status','title_ar'];
    public $timestamps = false;
    public $table = 'menu_setting';
}
