<?php



namespace App\Models;



use Illuminate\Database\Eloquent\Model;



class Color extends Model

{
	protected $primaryKey = 'color_id'; // or null

    protected $fillable = ['color_name','color_code','color_name_ar'];

    protected $table = 'color_master';

    public $timestamps = false;

}