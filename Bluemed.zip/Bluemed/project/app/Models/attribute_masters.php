<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class attribute_masters extends Model
{
    protected $fillable = ['name_en','name_ar','units','description'];
    public $timestamps = false;
    
   
    public function products()
    {
        return $this->hasMany('App\Models\Product');
    }
    
    // public function setSlugAttribute($value)
    // {
    //     $this->attributes['slug'] = str_replace(' ', '-', $value);
    // }

}
