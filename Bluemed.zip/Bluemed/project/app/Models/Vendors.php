<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Vendors extends Model
{
	protected $fillable = ['user_id','shop_name', 'shop_detail', 'owner_name','shop_number', 'shop_address', 'registration_no', 'message', 'status','section','parent_id'];

	protected $table = 'vendors';
    protected $primaryKey = 'vendor_id';
    public $timestamps = false;

}
