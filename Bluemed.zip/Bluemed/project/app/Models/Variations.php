<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Variations extends Model
{
    protected $fillable = ['name'];
    public $timestamps = true;
}
