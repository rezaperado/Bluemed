<?php

return [

    'no_additional_fees' => 'No additional fees',

    'fast_return_process' => 'Fast returnings program',

    'quality_guarantee' => 'Quality Guarantee of products',

    'marafie_group' => 'Marafie Group',

    'free_delivery' => 'Always free delivery',

    'track_order' => 'Track Your Order',

    'register_or_sign_in' => 'Register or Sign in',

    'kwd' => 'KWD',

    'your_cart' => 'Your Cart',

    'all_categories' => 'All Categories',

    'search_for_products' => 'Search for anything',

    'contact_us' => 'Contact Us',

    'maintenance' => 'Maintenance',

    'shop_by_brands' => 'Shop by Brands',

    'products' => 'Products',

    'offers' => 'Offers',

    'about_us' => 'About Us',

    'home' => 'Home',

    'cart_is_empty' => 'Cart is empty',

    'featured_products' => 'Featured Products',

    'promotional_products' => 'Promotional Products',

    'new_arrivals' => 'New Arrivals',

    'offers_items' => 'Offers Items',

    'top_categories' => 'Top categories this week',

    'flash_deal' => 'Flash Deal',

    'best_value'=> 'Best Value Products'
,
    'recently_viewed' => 'Recently viewed products',

    'subscribe' => 'Subscribe',

    'enter_email_address' => 'Enter your email address',

    'signup_newsletter' => 'Sign up to Newsletter',

    'and_receive_offers' => 'and receive the latest Offers...',

    'linkedin' => 'Linkedin',

    'twitter' => 'Twitter',

    'instagram' => 'Instagram',

    'facebook' => 'Facebook',

    'customer_care' => 'CUSTOMER CARE',

    'my_account' => 'My Account',

    'track_order' => 'Track Order',

    'shop' => 'Shop',

    'wishlist' => 'Wishlist',

    'return_exchange' => 'Returns/Exchange',

    'faqs' => 'FAQs',

    'find_it_fast' => 'TOP CATEGORIES',

    'use_safe_payment' => 'WE ARE USING SAFE PAYMENTS',

    'secured_by' => 'Secured by:',

    'got_questions' => 'GOT QUESTIONS ? CALL US',

    'find_on_map' => 'Find us on map',

    'house_hold' => 'House Hold Cleaning Items',

    'days' => 'Days',

    'hrs' => 'Hrs',

    'min' => 'Min',

    'sec' => 'Sec',

    'top' =>'Top',

    'categories' => 'categories',

    'this_week' => 'this week',

    'add_cart' => 'Add to cart',

    'add_compare' => 'Add to compare',

    'show' => 'Show',

    'show_all' => 'Show All',

    'sort_by_alphabet_asc' => 'Sort by alphabetically (A-Z)',

    'sort_by_alphabet_desc' => 'Sort by alphabetically (Z-A)',

    'sort_by_featured' => 'Sort by featured product',

    'sort_by_promotional' => 'Sort by promotional product',

    'browse_category' => 'Browse Categories',

    'sort_by_popular' => 'Sort by popularity',

    'sort_by_rating' => 'Sort by average rating',

    'sort_by_new' => 'Sort by newness',

    'sort_by_price_low_to_high' => 'Sort by price: low to high',

    'sort_by_price_high_to_low' => 'Sort by price: high to low',

    'showing' => 'Showing',

    'results' => 'results',

    'grid_view' => 'Grid View',

    'grid_extended' => 'Grid Extended View',

    'list_view_large' => 'List View Large',

    'list_view' => 'List View',

    'list_view_small' => 'List View Small',

    'filters' => 'Filters',

    'filter' => 'Filter',

    'filter_by_category' => 'Filter by Categories',

    'latest_products' => 'Latest Products',

    'no_products_available' => 'No products available',

    'availability' => 'Availability: ',

    'in_stock' => 'in stock',

    'out_stock' => 'Out of Stock',

    'item_with' => 'Item with',

    'free_delivery' => 'Free Delivery',

    'quantity' => 'Quantity',

    'description' => 'Description',

    'reviews' => 'Reviews',

    'review' => 'Review',

    'related_products' => 'Related products',

    'customer_review' => 'customer review',

    'subtotal' => 'Subtotal',

    'view_cart' => 'View Cart',

    'checkout' => 'Checkout',

    'cart_total' => 'Cart totals',

    'total' => 'Total',

    'proceed_to_checkout' => 'Proceed to checkout',

    'back_shopping' => 'Back to Shopping',

    'price' => 'Price',

    'product' => 'Product',

    'cart' => 'Cart',

    'checkout' => 'Checkout',

    'return_customer' => 'Returning customer?',

    'click_here_to_signin' => 'Click here to login',

    'have_coupon_code' => 'Have a coupon?',

    'click_here_add_coupon' => 'Click here to enter your code',

    'your_order' => 'Your Order',

    'tax' => 'Tax',

    'cod' => 'Pay with cash upon delivery',

    'knet' => 'KNET',

    'read_the_term_condition' => 'I’ve read and accept the ',

    'terms_and_condition' => 'terms & conditions',

    'place_order' => 'Place Order',

    'account_exist' => 'If you have shopped with us before, please enter your details in the boxes below. If you are a new customer, please proceed to the Billing & Shipping section.',

    'email' => 'Email',

    'password' => 'Password',

    'remember_me' => 'Remember me',

    'lost_password' => 'Lost your password?',

    'login' => 'Login',

    'apply_coupon' => 'Apply coupon',

    'coupon_code'=>'Coupon code',

    'billing_details' => 'Billing Details',

    'first_name' => 'First Name',

    'last_name' => 'Last Name',

    'area' => 'Area',

    'block' => 'Block',

    'street' => 'Street',

    'city' => 'City',

    'country' => 'Country ',

    'zip' => 'Postcode / ZIP',

    'email_address' => 'Email Address',

    'phone' => 'Phone',

    'create_account' => 'Create an accont?',

    'ship_to_diff_address' => 'Ship to different address?',

    'order_notes' => 'Order notes',

    'order_notes_text'=> 'Notes about your order, e.g. special notes for delivery.',

    'select_country' => 'Select a country…',

    'account_password' => 'Account password',

    'dashboard' => 'Dashboard',

    'print_invoice' => 'Print Invoice',

    'order_number_is' => 'Thank you For Your Order,Your Order number is',

    'name' => 'Name',

    'payment_info' => 'Payment Information',

    'payment_method' => 'Payment Method',

    'payment_status' => 'Payment Status',

    'order_total' => 'Order Total',

    'product_ordered' => 'Products Ordered',

    'sr_no' => 'Sr. No',

    'product_title' => 'Product Title',

    'total_price' => 'Total Price',

    'grand_total' => 'Grand Total',

    'transaction_id' => 'Transaction ID',

    'order' => 'Order',

    'order_date'=> 'Order Date',

    'paid_amount' => 'Paid Amount',

    'address' => 'Address',

    'shipping_address' => 'Shipping Address',

    'id' => 'ID',

    'login_register' => 'Login/Register',

    'register' => 'Register',

    'create_account_text' => 'Create new account today to reap the benefits of a personalized shopping experience.',

    'confirm_password' => 'Confirm Password',

    'signup_benefit' => 'Sign up today and you will be able to :',

    'signup_benefit_1' => 'Speed your way through checkout',

    'signup_benefit_2' => 'Track your orders easily',

    'signup_benefit_3' => 'Keep a record of all your purchases',

    'account_info' => 'Account Information',

    'my_orders' => 'My Orders',

    'edit_profile' => 'Edit Profile',

    'change_password' => 'Change Password',

    'date'=>'Date',

    'order_status' => 'Order Status',

    'view' => 'View',

    'title' => 'Title',

    'note' => 'Note',

    'time' => 'Time',

    'no_data_available' => 'No data available',

    'close' => 'Close',

    'view_order' => 'View Order',

    'print_order' => 'Print Order Receipt',

    'order_number' => 'Order number',

    'order_products' => 'Order Products',

    'product_name' => 'Product Name',

    'shipping_charge' => 'Shipping Charge',

    'submit' => 'Submit',

    'current_password' => 'Current Password',

    'new_password' => 'New Password',

    'stock_status' => 'Stock Status',

    'unit_price' => 'Unit Price',

    'share_on' => 'Share on:',

    'contact' => 'Contact',

    'our_store' => 'Our Store',

    'leave_message' => 'Leave us a Message',

    'subject' => 'Subject',

    'your_message' => 'Your Message',

    'send_message' => 'Send Message',

    'career' => 'Careers',

    'email_us' => 'If you’re interested in employment opportunities at Marafie Group, please email us:',

    'opetation_hour' => 'Hours of Operation',

    'sat_to_thu' => 'Saturday to Thursday',

    'shuwaikh_branch' => 'Shuwaikh Branch:',

    'sharq_branch' => 'Sharq Branch:',

    'compare'=> 'Compare',

    'brand' => 'Brand',

    'forgot_password' => 'Forgot Password',

    'filter_by_price' => 'Filter by price',

    'search' => 'Search',

    'filteres' => 'Filters',

    'sku' => 'SKU',

    'category' => 'Category',

    'item_desc'=> 'Item Description',

    'brand' => 'Brand',

    'sub_category' => 'Sub Category',

    'add_review' => 'Add Review',

    'your_rating' => 'Your Rating',

    'your_review' => 'Your Review',
    'cod_text' => 'Pay with cash upon delivery.',
    'logout' => 'Logout',
    'welcome' => 'Welcome',
    'item_added' => 'Item added successfully',
    'continue_shopping' => 'Continue Shopping',
    'delivery_time' => 'Delivery Time',
    'attachments' => 'Attachments',
    'sign_in' => 'Sign In'
];