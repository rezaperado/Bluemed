<?php

return [

    'no_additional_fees' => 'لا رسوم إضافية',

    'marafie_group_free_delivery' => '',

    'fast_return_process' => 'برنامج عائد سريع',

    'quality_guarantee' => 'ضمان جودة المنتجات',

    'marafie_group' => 'مجموعة معرفي',

    'free_delivery' => 'توصيل مجاني دائما',

    'track_order' => 'تَتبع طلبك',

    'register_or_sign_in' => 'تسجيل أو تسجيل الدخول',

    'kwd' => 'دينار كويتي',

    'your_cart' => 'عربتك',

    'all_categories'=> 'جميع الفئات',

    'search_for_products' => 'ابحث عن أي شيء',

    'contact_us' => 'تواصل معنا ',

    'maintenance' => 'اعمال صيانة',

    'shop_by_brands' => 'علاماتنا التجارية',

    'products' => 'منتجات',

    'offers' => 'آخر العروض',

    'about_us' => 'من نحن',

    'home' => 'الرئيسيه ',

    'cart_is_empty' => 'السلة فارغة',

    'featured_products' => 'منتجات مميزة',

    'promotional_products' => 'العروض',

    'new_arrivals' => 'وصل حديثاً ',

    'offers_items' => 'عناصر العروض',

    'top_categories' => 'الفئات ',

    'flash_deal' => 'صفقات عاجلة ',

    'best_value' => 'أفضل المنتجات القيمة',

    'recently_viewed' => 'وصل حديثاً',

    'subscribe' => 'الاشتراك ',

    'enter_email_address' => 'ادخل البريد الالكتروني ',

    'signup_newsletter' => 'اشترك في النشرة الإخبارية',

    'and_receive_offers' => 'واحصل على اخر العروض ...',

    'linkedin' => 'Linkedin',

    'twitter' => 'Twitter',

    'instagram' => 'Instagram',

    'customer_care' => 'خدمة العملاء',

    'my_account' => 'حسابي',

    //'track_order' => 'المسار سجل',

    'shop' => 'متجر',

    'wishlist' => 'قائمة الأمنيات',

    'return_exchange' => 'سياسة الإستبدال والإسترجاع',

    'faqs' => 'الأسئلة الشائعة',

    'find_it_fast' => 'الفئات الأعلى',

    'use_safe_payment' => 'نحن نستخدم مدفوعات آمنة',

    'secured_by' => 'طرق الدفع',

    'got_questions' => 'لديك أسئلة ؟ إتصل بنا',

    'find_on_map' => 'خريطة الموقع',

    'facebook' => 'facebook',

    'house_hold' => 'مواد التنظيف المنزلية',

    'days' => 'أيام',

    'hrs' => 'ساعات',

    'min' => 'الحد الأدنى',

    'sec' => 'ثانية',

    'top' => 'أعلى',

    'categories' => 'التصنيفات',

    'this_week' => 'هذا الاسبوع',

    'add_cart' => 'أضف لعربتي ',

    'add_compare' => 'أضف للمقارنة',

    'show' => 'تبين',

    'show_all' => 'عرض الكل',

    'sort_by_alphabet_asc' => 'ترتيب أبجدي (أ-ي)',

    'sort_by_alphabet_desc' => 'الترتيب حسب الأبجدية (Z-A)',

    'sort_by_featured' => 'فرز حسب المنتج المميز',

    'sort_by_popular' => 'فرز حسب الشعبية',

    'sort_by_promotional' => 'فرز حسب المنتج الترويجي',

    'sort_by_rating' => 'فرز حسب متوسط التصنيف',

    'sort_by_new' => 'فرز حسب الحداثة',

    'sort_by_price_low_to_high' => 'فرز حسب السعر: من الأقل إلى الأعلى',

    'sort_by_price_high_to_low' => 'فرز حسب السعر: من الأعلى إلى الأقل',

    'browse_category' => 'تصفح الفئات',

    'showing' => 'عرض',

    'results' => 'النتائج',

    'grid_view' => 'عرض شبكي',

    'grid_extended' => 'عرض موسع للشبكة',

    'list_view_large' => 'عرض قائمة كبيرة',

    'list_view' => 'عرض القائمة',

    'list_view_small' => 'عرض قائمة صغيرة',

    'filters' => 'مرشحات',

    'filter' => 'مرشحات...',

    'filter_by_category' => 'تصفية حسب الفئات',

    'latest_products' => 'أحدث المنتجات',

    'no_products_available' => 'لا توجد منتجات متاحة',

    'availability' => 'الكمية المتوفرة',

    'in_stock' => 'في المخزن',

    'out_stock' => 'من المخزون',

    'item_with' => 'البند مع',

    'free_delivery' => 'توصيل مجاني',

    'quantity' => 'كمية',

    'description' => 'وصف',

    'reviews' => 'تقييم المنتج',

    'review' => 'الآراء والاقترحات',

    'related_products' => 'منتجات ذات صله',

    'customer_review' => 'رأي العميل',

    'subtotal' => 'المجموع الفرعي',

    'view_cart' => 'عرض السلة',

    'checkout' => 'الدفع',

    'cart_total' => 'إجماليات سلة التسوق',

    'total' => 'مجموع',

    'proceed_to_checkout' => 'باشرالخروج من الفندق',

    'back_shopping' => 'العودة إلى التسوق',

    'price' => 'السعر',

    'product' => 'المنتج',

    'cart' => 'عربة التسوق',

    'checkout' => 'الدفع',

    'return_customer' => 'الزبون العائد؟',

    'click_here_to_signin' => 'انقر هنا لتسجيل الدخول',

    'have_coupon_code' => 'هل لديك قسيمة؟',

    'click_here_add_coupon' => 'انقر هنا لإدخال الرمز الخاص بك',

    'your_order' => 'طلبك',

    'tax' => 'ضريبة',

    'cod' => 'الدفع نقدا عند التسليم',

    'knet' => 'كي نت',

    'read_the_term_condition' => 'لقد قرأت وأوافق على',

    'terms_and_condition' => 'البنود و الظروف',

    'place_order' => 'مكان الطلب ',

    'account_exist' => 'إذا قمت بالتسوق معنا من قبل ، يرجى إدخال التفاصيل الخاصة بك في المربعات أدناه. إذا كنت عميلاً جديدًا ، فيُرجى المتابعة إلى قسم الفوترة والشحن.',

    'email' => 'البريد الإلكتروني',

    'password' => 'كلمه السر',

    'remember_me' => 'تذكرنى',

    'lost_password' => 'فقدت كلمة المرور الخاصة بك؟',

    'login' => 'تسجيل الدخول',

    'apply_coupon' => 'تطبيق القسيمة',

    'coupon_code'=>'رمز الكوبون',

    'billing_details' => 'تفاصيل الفاتورة',

    'first_name' => 'الاسم الاول',

    'last_name' => 'الكنية',

    'area' => 'منطقة',

    'block' => 'منع',

    'street' => 'شارع',

    'city' => 'مدينة',

    'country' => 'بلد',

    'zip' => 'الرمز البريدي / الرمز البريدي',

    'email_address' => 'عنوان بريد الكتروني',

    'phone' => 'هاتف',

    'create_account' => 'انشئ حساب؟',

    'ship_to_diff_address' => 'هل تريد الشحن إلى عنوان مختلف؟',

    'order_notes' => 'ترتيب ملاحظات',

    'order_notes_text' => 'ملاحظات حول طلبك ، على سبيل المثال ملاحظات خاصة للتسليم.',

    'select_country' => 'اختر دولة…',

    'account_password' => 'كلمة مرور الحساب',

    'dashboard' => 'لوحة القيادة',

    'print_invoice' => 'فاتورة طباعة',

    'order_number_is' => 'شكرا لطلبك ، رقم طلبك هو',

    'name' => 'اسم',

    'payment_info' => 'معلومات الدفع',

    'payment_method' => 'طريقة الدفع او السداد',

    'payment_status' => 'حالة السداد',

    'order_total' => 'الطلب الكلي',

    'product_ordered' => 'المنتجات المطلوبة',

    'sr_no' => 'الأب رقم',

    'product_title' => 'عنوان المنتج',

    'total_price' => 'السعر الكلي',

    'grand_total' => 'المجموع الكلي',

    'transaction_id' => 'رقم المعاملة',

    'order' => 'طلب',

    'order_date'=> 'تاريخ الطلب',

    'paid_amount' => 'المبلغ المدفوع',

    'address' => 'عنوان',

    'shipping_address' => 'عنوان الشحن',

    'id' => 'هوية شخصية',

    'login_register' => 'دخولتسجيل',

    'register' => 'تسجيل',

    'create_account_text' => 'أنشئ حسابًا جديدًا اليوم لجني فوائد تجربة تسوق مخصصة.',

    'confirm_password' => 'تأكيد كلمة المرور',

    'signup_benefit' => 'اشترك اليوم وستتمكن من:',

    'signup_benefit_1' => 'سرعة طريقك من خلال الخروج',

    'signup_benefit_2' => 'تتبع طلباتك بسهولة',

    'signup_benefit_3' => 'احتفظ بسجل لجميع مشترياتك',

    'my_orders' => 'طلباتي',

    'edit_profile' => 'تعديل الملف الشخصي',

    'change_password' => 'تغيير كلمة المرور',

    'account_info' => 'معلومات الحساب',

    'date'=>'تاريخ',

    'order_status' => 'حالة الطلب',

    'view' => 'رأي',

    'title' => 'عنوان',

    'note' => 'ملحوظة',

    'time' => 'زمن',

    'no_data_available' => 'لا تتوافر بيانات',

    'close' => 'قريب',

    'view_order' => 'مشاهدة الطلب',

    'print_order' => 'إيصال أمر الطباعة',

    'order_number' => 'رقم الأمر',

    'order_products' => 'طلب المنتجات',

    'product_name' => 'اسم المنتج',

    'shipping_charge' => 'رسوم الشحن',

    'submit' => 'إرسال',

    'current_password' => 'كلمة المرور الحالي',

    'new_password' => 'كلمة السر الجديدة',

    'stock_status' => 'حالة الرصيد، وضع مخزون',

    'unit_price' => 'سعر الوحدة',

    'share_on' => 'مشاركه فى:',

    'contact' => 'اتصل',

    'our_store' => 'تسوق ',

    'leave_message' => 'اترك لنا رسالة',

    'subject' => 'موضوع',

    'your_message' => 'رسالتك',

    'send_message' => 'أرسل رسالة',

    'career' => 'وظائف',

    'email_us' => 'إذا كنت مهتمًا بفرص العمل في مجموعة Marafie ، فيرجى مراسلتنا عبر البريد الإلكتروني:',

    'opetation_hour' => 'ساعات العملية',

    'sat_to_thu' => 'من السبت إلى الخميس',

    'shuwaikh_branch' => 'فرع الشويخ:',

    'sharq_branch' => 'فرع شرق:',

    'compare'=> 'قارن',

    'brand' => 'العلامة التجارية',

    'forgot_password' => 'هل نسيت كلمة المرور',

    'filter_by_price' => 'تصفية حسب السعر',

    'search' => 'بحث',

    'filteres' => 'مرشحات',

    'sku' => 'رقم المنتج',

    'category' => 'الفئة',

    'item_desc' => 'الوصف',

    'brand' => 'الشركة',

    'sub_category' => 'تصنيف فرعي',

    'add_review' => 'رأيك يهمّنا',

    'your_rating' => 'تقييمك للمنتج',

    'your_review' => 'ملاحظاتك الشخصية',
    'cod_text' => 'الدفع نقدا عند الاستلام.',
    'logout' => 'تسجيل خروج',
    'welcome' => 'أهلا بك',
    'item_added' => 'تمت إضافة العنصر بنجاح',
    'continue_shopping' => 'مواصلة التسوق',
    'delivery_time' => 'موعد التسليم',
    'attachments' => 'المرفقات',
    'sign_in' => 'تسجيل الدخول'
];