@extends('layouts.front')
@section('body_class', 'page home page-template-default')
@section('content')
<input type="hidden" id="add_to_cart" value="<?php echo URL('/addcart')?>" />
<div class="col-full">
    <div class="row">
        <nav class="woocommerce-breadcrumb">
            <a href="<?= URL('/')?>">{{ __('messages.home') }}</a>
            <span class="delimiter">
                <i class="tm tm-breadcrumbs-arrow-right"></i>
            </span>{{ __('messages.compare') }}
        </nav>
        <!-- .woocommerce-breadcrumb -->
        <div id="primary" class="content-area">
            <main id="main" class="site-main">
                <div class="type-page hentry">
                    <div class="entry-content">
                        <div class="table-responsive">
                        	@if(session()->has('success'))
                                <div class="alert alert-success">
                                    {{ session()->get('success') }}
                                </div>
                            @endif
                            <?php if(!empty($products)):?>
                            <table class="table table-compare compare-list">
                                <tbody>
                                    <tr>
                                        <th>{{ __('messages.product') }}</th>
                                        <?php foreach($products as $key => $product):?>
                                        	<?php
                                        	$product = getProduct($key);
                                            $price = getVariationPrice($product->id);
                                            $variation = getVariation($product->id);
                                            $attr = isset($variation['attr']) ? $variation['attr'] : '';
                                            $total_stock = isset($variation['total_stock']) ? $variation['total_stock'] : 0;
                                            $stock = checkProductStock($product->sku);
                                            ?>
                                        <td>
                                            <a class="product" href="{{ route('front.product', $product->id) }}">
                                                <div class="product-image">
                                                    <div class="image">
                                                        <img width="300" height="300" alt="" class="attachment-shop_catalog size-shop_catalog wp-post-image" src="{{asset('assets/images/products/'.$product->photo)}}">
                                                    </div>
                                                </div>
                                                <div class="product-info">
                                                    <h3 class="product-title">{{$product->name}}</h3>
                                                    <div class="star-rating">
                                                        <span style="width:100%">Rated
                                                            <strong class="rating">5.00</strong> out of 5</span>
                                                    </div>
                                                </div>
                                            </a>
                                            <!-- /.product -->
                                        </td>
	                                    <?php endforeach;?>
                                    </tr>
                                    <tr>
                                        <th>{{ __('messages.price') }}</th>
                                        <?php foreach($products as $key => $product):?>
                                        	<?php $product = getProduct($key);?>
                                        <td>
                                            <div class="product-price price">
                                                <ins>
                                                    <span class="woocommerce-Price-amount amount">
                                                        <span class="woocommerce-Price-currencySymbol">{{$curr->sign}}</span>{{number_format($product->price,3)}}</span>
                                                </ins>
                                                <?php if(isset($product->previous_price) && !empty($product->previous_price) && $product->previous_price > $product->price):?>
                                                <del>
                                                    <span class="woocommerce-Price-amount amount">
                                                        <span class="woocommerce-Price-currencySymbol">{{$curr->sign}}</span>{{number_format($product->previous_price,3)}}</span>
                                                </del>
	                                            <?php endif;?>
                                            </div>
                                        </td>
                                        <?php endforeach;?>
                                    </tr>
                                    <tr>
                                        <th>{{ __('messages.availability') }}</th>
                                        <?php foreach($products as $key=>$product):?>
                                        	<?php $product = getProduct($key);
                                        	$variation = getVariation($product->id);
                                            $attr = isset($variation['attr']) ? $variation['attr'] : '';
                                            $total_stock = isset($variation['total_stock']) ? $variation['total_stock'] : 0;
                                        	?>
                                        <td>
                                        	<?php if((isset($stock) && $stock > 0)):?>
                                            <span>In stock</span>
                                            <?php else:?>
                                            	<span>Out of Stock</span>
                                            <?php endif;?>
                                        </td>
	                                    <?php endforeach;?>
                                    </tr>
                                    <tr>
                                        <th>{{ __('messages.description') }}</th>
                                        <?php foreach($products as $key => $product):?>
                                        	<?php $product = getProduct($key);?>
                                        <td>
                                            <p>
                                            	<?php 
                                            	if(app()->getLocale() == 'ar'){
												    echo htmlspecialchars_decode(stripslashes($product->details_ar));
												}
												else
												{
												    echo htmlspecialchars_decode(stripslashes($product->details));
												}
                                            	?>
                                            </p>
                                        </td>
	                                    <?php endforeach?>
                                    </tr>
                                    <tr>
                                        <th>{{ __('messages.add_cart') }}</th>
                                        <?php foreach($products as $key => $product):?>
                                        	<?php
                                        	$product = getProduct($key);
                                            $price = getVariationPrice($product->id);
                                            $variation = getVariation($product->id);
                                            $attr = isset($variation['attr']) ? $variation['attr'] : '';
                                            $total_stock = isset($variation['total_stock']) ? $variation['total_stock'] : 0;
                                            $stock = checkProductStock($product->sku);
                                            ?>
                                        <td>
                                        	<form class="variations_form cart" id="variations_form">
	                                            <input type="hidden" name="product_price" id="hidden_price" value="{{$price}}">
	                                            <input type="hidden" name="quantity" id="hidden_price" value="1">
	                                            <input name="_token" type="hidden" value="{{ csrf_token() }}"/>
	                                            <input type="hidden" value="{{$product->id}}" name="product_id">
	                                            <input type="hidden" name="total_stock" id="total_stock" value="{{$total_stock}}">
	                                            <?php if(!empty($attr)):?>
	                                            <?php foreach($attr as $key=>$val):?>
	                                                <input type="hidden" name="attr[<?= $key?>]" value="<?= $val?>">
	                                            <?php endforeach;?>
	                                            <?php endif;?>
	                                            <button class="button add_to_cart_button" type="button" style="margin: 0 auto;" <?= ($stock==0) ? 'disabled' : ''?>>{{ __('messages.add_cart') }}</button>
	                                        </form>
                                        </td>
	                                    <?php endforeach;?>
                                    </tr>
                                    <tr>
                                        <th>{{ __('messages.brand') }}</th>
                                        <?php foreach($products as $key => $product):?>
                                        	<?php $product = getProduct($key);?>
                                        <td><?= getBrandName($product->brand_id);?></td>
	                                    <?php endforeach?>
                                    </tr>
                                    <tr>
                                        <th>&nbsp;</th>
                                        <?php foreach($products as $key => $product):?>
                                        	<?php $product = getProduct($key);?>
                                        <td class="text-center">
                                            <a title="Remove" class="remove-icon pointer" href="{{ route('product.compare.remove',$product->id) }}">
                                                <i class="fa fa-times"></i>
                                            </a>
                                        </td>
	                                    <?php endforeach;?>
                                    </tr>
                                </tbody>
                            </table>
                            <?php else:?>
                            	<p>{{ __('messages.no_products_available') }}</p>
                            <?php endif;?>
                            <!-- /.table-compare compare-list -->
                        </div>
                        <!-- /.table-responsive -->
                    </div>
                    <!-- .entry-content -->
                </div>
                <!-- .hentry -->
            </main>
            <!-- #main -->
        </div>
        <!-- #primary -->
    </div>
    <!-- .row -->
</div>
@endsection