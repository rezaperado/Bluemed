@extends('layouts.front')
@section('content')
<input type="hidden" id="track_order" value="<?php echo URL('/trackorder')?>" />
<div class="col-full">
    <div class="row">
        <nav class="woocommerce-breadcrumb">
            <a href="<?= URL('/')?>">Home</a>
            <span class="delimiter">
                <i class="tm tm-breadcrumbs-arrow-right"></i>
            </span>Orders
        </nav>
        <!-- .woocommerce-breadcrumb -->
        <div id="primary" class="content-area">
            <main id="main" class="site-main">
                <div class="shop-archive-header">
                    <div class="jumbotron">
                        <div class="jumbotron-img">
                            <img width="416" height="283" alt="" src="assets/images/products/jumbo.jpg" class="jumbo-image alignright">
                        </div>
                        <div class="jumbotron-caption w-100 p-20">
                            <h3 class="jumbo-title">My Orders</h3>
                            <table class="table display w-100" id="order_list_table">
                              <thead>
                                <tr>
                                  <th class="text-center">#Order</th>
                                  <th class="text-center">Date</th>
                                  <th class="text-center">Order Total</th>
                                  <th class="text-center">Order Status</th>
                                  <th class="text-center">View</th>
                                  <th class="text-center">Track Order</th>
                                </tr>
                              </thead>
                              <tbody>
                                <?php foreach($orders as $order):?>
                                  <tr>
                                      <td class="text-center">{{$order->order_number}}</td>
                                      <td class="text-center">{{date('M d, Y',strtotime($order->created_at))}}</td>
                                      <td class="text-center">{{number_format($order->pay_amount,2)}}</td>
                                      <td class="text-center">{{ucfirst($order->order_status)}}</td>
                                      <td class="text-center"><a class="btn-view-order pointer" data-id="{{$order->id}}">View</a></td>
                                      <td class="text-center"><a data-id="{{$order->id}}" class="btn-track-order pointer">Track</a></td>
                                  </tr>
                                <?php endforeach;?>
                             </tbody>
                            </table>
                        </div>
                        <!-- .jumbotron-caption -->
                    </div>
                    <!-- .jumbotron -->
                </div>
            </main>
            <!-- #main -->
        </div>
        <!-- #primary -->
        <div id="secondary" class="widget-area shop-sidebar" role="complementary">
            <div class="widget woocommerce widget_product_categories techmarket_widget_product_categories" id="techmarket_product_categories_widget-2">
                <ul class="product-categories ">
                    <li class="product_cat">
                        <ul>
                          <li class="cat-item">
                                <a href="{{route('user-profile')}}">
                                    <span class="no-child"></span>Dashboard
                                </a>
                            </li>
                            <li class="cat-item">
                                <a href="{{route('user-orderlist')}}">
                                    <span class="no-child"></span>My Orders
                                </a>
                            </li>
                            <li class="cat-item">
                                <a href="{{route('edit-profile')}}">
                                    <span class="no-child"></span>Edit Profile
                                </a>
                            </li>
                            <li class="cat-item">
                                <a href="#">
                                    <span class="no-child"></span>Reset Profile
                                </a>
                            </li>
                            <li class="cat-item">
                                <a href="#">
                                    <span class="no-child"></span>Wishlist
                                </a>
                            </li>
                        </ul>
                    </li>
                </ul>
            </div>
            <!-- .widget_techmarket_products_carousel_widget -->
        </div>
        <!-- #secondary -->
    </div>
    <!-- .row -->
</div>


@endsection

@section('scripts')
	<script>
        
  </script>
@endsection