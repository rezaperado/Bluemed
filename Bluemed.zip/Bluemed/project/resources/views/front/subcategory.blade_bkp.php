@extends('layouts.front')
@section('body_class', 'left-sidebar')
@section('content')
<?php 
use Illuminate\Support\Facades\Input;
?>
<style type="text/css">
    .add_to_cart_button, .products .hover-area .button{background: #008000bd !important;}
    .show-all-cat-dropdown,.show-all-cat ul{border: none !important;}
</style>
<input type="hidden" value="<?= $min_price?>" id="min_price_val">
<input type="hidden" value="<?= $max_price?>" id="max_price_val">
<input type="hidden" value="<?= isset($min) ? $min : $min_price?>" id="min_price">
<input type="hidden" value="<?= isset($max) ? $max : $max_price?>" id="max_price">
<input type="hidden" id="add_to_cart" value="<?php echo URL('/addcart')?>" />
<div class="col-full">
    <div class="row">
        <nav class="woocommerce-breadcrumb">
            <a href="<?= URL('/');?>">Home</a>
            <span class="delimiter">
                <i class="tm tm-breadcrumbs-arrow-right"></i>
            </span>
            <a href="{{route('front.category',$cat->slug)}}">{{$cat->name}}</a>
            <span class="delimiter">
                <i class="tm tm-breadcrumbs-arrow-right"></i>
            </span>
            {{$subcat->name}}
        </nav>
        <!-- .woocommerce-breadcrumb -->
        <div id="primary" class="content-area">
            <main id="main" class="site-main">
                <div class="shop-control-bar">
                    <div class="handheld-sidebar-toggle">
                        <button type="button" class="btn sidebar-toggler">
                            <i class="fa fa-sliders"></i>
                            <span>Filters</span>
                        </button>
                    </div>
                    <!-- .handheld-sidebar-toggle -->
                    <h1 class="woocommerce-products-header__title page-title">{{$subcat->name}}</h1>
                    <ul role="tablist" class="shop-view-switcher nav nav-tabs">
                        <li class="nav-item">
                            <a href="#grid" title="Grid View" data-toggle="tab" class="nav-link <?= ($layout_type == 'grid') ? 'active' : ''?>">
                                <i class="tm tm-grid-small"></i>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="#grid-extended" title="Grid Extended View" data-toggle="tab" class="nav-link <?= ($layout_type == 'grid-extended') ? 'active' : ''?>">
                                <i class="tm tm-grid"></i>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="#list-view-large" title="List View Large" data-toggle="tab" class="nav-link <?= ($layout_type == 'list-view-large') ? 'active' : ''?>">
                                <i class="tm tm-listing-large"></i>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="#list-view" title="List View" data-toggle="tab" class="nav-link <?= ($layout_type == 'list-view') ? 'active' : ''?>">
                                <i class="tm tm-listing"></i>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="#list-view-small" title="List View Small" data-toggle="tab" class="nav-link <?= ($layout_type == 'list-view-small') ? 'active' : ''?>">
                                <i class="tm tm-listing-small"></i>
                            </a>
                        </li>
                    </ul>
                    <!-- .shop-view-switcher -->
                    <form class="form-techmarket-wc-ppp" method="POST">
                        <select class="techmarket-wc-wppp-select c-select page_length" name="page_length">
                            <option value="20" <?= ($page_length == 20) ? 'selected' : ''?>>Show 20</option>
                            <option value="40" <?= ($page_length == 40) ? 'selected' : ''?>>Show 40</option>
                            <option value="all" <?= ($page_length == 'all') ? 'selected' : ''?>>Show All</option>
                        </select>
                        <input type="hidden" value="5" name="shop_columns">
                        <input type="hidden" value="15" name="shop_per_page">
                        <input type="hidden" value="right-sidebar" name="shop_layout">
                    </form>
                    <!-- .form-techmarket-wc-ppp -->
                    <form method="get" class="woocommerce-ordering">
                        <select class="orderby" name="sort" id="sort_by">
                            <option value="alphabet" <?= ($sort == 'alphabet') ? 'selected' : ''?>>Sort by alphabetically</option>
                            <option value="featured" <?= ($sort == 'featured') ? 'selected' : ''?>>Sort by featured product</option>
                            <option value="promotional" <?= ($sort == 'promotional') ? 'selected' : ''?>>Sort by promotional product</option>
                            <option value="popularity" <?= ($sort == 'popularity') ? 'selected' : ''?>>Sort by popularity</option>
                            <option value="rating" <?= ($sort == 'rating') ? 'selected' : ''?>>Sort by average rating</option>
                            <option value="date" <?= ($sort == 'date') ? 'selected' : ''?>>Sort by newness</option>
                            <option value="price" <?= ($sort == 'price') ? 'selected' : ''?>>Sort by price: low to high</option>
                            <option value="price-desc" <?= ($sort == 'price-desc') ? 'selected' : ''?>>Sort by price: high to low</option>
                        </select>
                        <input type="hidden" value="5" name="shop_columns">
                        <input type="hidden" value="15" name="shop_per_page">
                        <input type="hidden" value="right-sidebar" name="shop_layout">
                    </form>
                    <!-- .woocommerce-ordering -->
                    <nav class="techmarket-advanced-pagination">
                        <form class="form-adv-pagination" method="post">
                            <input type="number" value="1" class="form-control" step="1" max="5" min="1" size="2" id="goto-page">
                        </form> of 5<a href="#" class="next page-numbers">→</a>
                    </nav>
                    <!-- .techmarket-advanced-pagination -->
                </div>
                <!-- .shop-control-bar -->
                <div class="tab-content">
                    <div id="grid" class="tab-pane <?= ($layout_type == 'grid') ? 'active' : ''?>" role="tabpanel">
                        <div class="woocommerce columns-5">
                            <div class="products">
                                <?php if($cats->count() > 0):?>
                                <?php foreach($cats as $product):?>
                                    <?php
                                    $price = getVariationPrice($product->id);
                                    $variation = getVariation($product->id);
                                    $attr = isset($variation['attr']) ? $variation['attr'] : '';
                                    $total_stock = isset($variation['total_stock']) ? $variation['total_stock'] : 0;

                                    ?>
                                    <div class="product first">
                                        <form class="variations_form cart" id="variations_form">
                                        <input type="hidden" name="product_price" id="hidden_price" value="{{$price}}">
                                        <input type="hidden" name="quantity" id="hidden_price" value="1">
                                        <input name="_token" type="hidden" value="{{ csrf_token() }}"/>
                                        <input type="hidden" value="{{$product->id}}" name="product_id">
                                        <input type="hidden" name="total_stock" id="total_stock" value="{{$total_stock}}">
                                        <?php if(!empty($attr)):?>
                                        <?php foreach($attr as $key=>$val):?>
                                            <input type="hidden" name="attr[<?= $key?>]" value="<?= $val?>">
                                        <?php endforeach;?>
                                        <?php endif;?>
                                        <div class="yith-wcwl-add-to-wishlist">
                                            <a href="#" rel="nofollow" class="add_to_wishlist"> Add to Wishlist</a>
                                        </div>
                                        <!-- .yith-wcwl-add-to-wishlist -->
                                        <a class="woocommerce-LoopProduct-link woocommerce-loop-product__link" href="{{ route('front.product', $product->id) }}">
                                            <?php if(isset($product->previous_price) && !empty($product->previous_price)):?>
                                                <span class="onsale">
                                                    <span class="woocommerce-Price-amount amount">
                                                        <span class="woocommerce-Price-currencySymbol">
                                                            <?= $curr;?>
                                                        </span>
                                                        <?= number_format(((float)$product->previous_price - (float)$price) ,2);?>
                                                    </span>
                                                </span>
                                            <?php endif;?>
                                            <img width="224" height="197" alt="" class="attachment-shop_catalog size-shop_catalog wp-post-image" src="{{asset('assets/images/products/'.$product->photo)}}">
                                            <?php if(isset($product->previous_price) && !empty($product->previous_price)):?>
                                                <span class="price">
                                                    <ins>
                                                        <span class="woocommerce-Price-currencySymbol">{{$curr}}</span>
                                                        <span class="amount">{{number_format($price,2)}}</span>
                                                    </ins>
                                                    <del>
                                                        <span class="woocommerce-Price-currencySymbol">{{$curr}}</span>
                                                        <span class="amount">{{number_format($product->previous_price,2)}}</span>
                                                    </del>
                                                    <span class="amount"> </span>
                                                </span>
                                            <?php else:?>
                                                <span class="price">
                                                    <ins>
                                                        <span class="amount"> </span>
                                                    </ins>
                                                    <span class="woocommerce-Price-currencySymbol">{{$curr}}</span>
                                                    <span class="amount">{{number_format($price , 2)}}</span>
                                                </span>
                                            <?php endif;?>
                                            <h2 class="woocommerce-loop-product__title">
                                                <?php if(app()->getLocale() == 'ar'):?>
                                                    {{$product->name_ar}}
                                                <?php else:?>
                                                    {{$product->name}}
                                                <?php endif;?>
                                            </h2>
                                        </a>
                                        <!-- .woocommerce-LoopProduct-link -->
                                        <div class="hover-area">
                                            <button class="button add_to_cart_button" type="button">Add to cart</button>
                                            <a class="add-to-compare-link" href="#">Add to compare</a>
                                        </div>
                                        </form>
                                        <!-- .hover-area -->
                                    </div>
                                <?php endforeach;?>
                                <?php else:?>
                                    <p class="no-prd"> No products available</p>
                                <?php endif;?>
                            </div>
                            <!-- .products -->
                        </div>
                        <!-- .woocommerce -->
                    </div>
                    <!-- .tab-pane -->
                    <div id="grid-extended" class="tab-pane <?= ($layout_type == 'grid-extended') ? 'active' : ''?>" role="tabpanel">
                        <div class="woocommerce columns-5">
                            <div class="products">
                                <?php if($cats->count() > 0):?>
                                <?php foreach($cats as $product):?>
                                    <?php
                                    $price = getVariationPrice($product->id);
                                    ?>
                                <div class="product">
                                    <div class="yith-wcwl-add-to-wishlist">
                                        <a href="#" rel="nofollow" class="add_to_wishlist"> Add to Wishlist</a>
                                    </div>
                                    <!-- .yith-wcwl-add-to-wishlist -->
                                    <a class="woocommerce-LoopProduct-link woocommerce-loop-product__link" href="single-product-fullwidth.html">
                                        <?php if(isset($product->previous_price) && !empty($product->previous_price)):?>
                                            <span class="onsale">
                                                <span class="woocommerce-Price-amount amount">
                                                    <span class="woocommerce-Price-currencySymbol">{{$curr}}</span><?= number_format(((float)$product->previous_price - (float)$price) ,2);?>
                                                </span>
                                            </span>
                                        <?php endif;?>
                                        <img width="224" height="197" alt="" class="attachment-shop_catalog size-shop_catalog wp-post-image" src="{{asset('assets/images/products/'.$product->photo)}}">
                                        <?php if(isset($product->previous_price) && !empty($product->previous_price)):?>
                                            <span class="price">
                                                <ins>
                                                    <span class="woocommerce-Price-currencySymbol">{{$curr}}</span>
                                                    <span class="amount">{{number_format($price,2)}}</span>
                                                </ins>
                                                <del>
                                                    <span class="amount">{{number_format($product->previous_price,2)}}</span>
                                                </del>
                                                <span class="amount"> </span>
                                            </span>
                                        <?php else:?>
                                            <span class="price">
                                                <ins>
                                                    <span class="amount"> </span>
                                                </ins>
                                                <span class="woocommerce-Price-currencySymbol">{{$curr}}</span>
                                                <span class="amount">{{number_format($price , 2)}}</span>
                                            </span>
                                        <?php endif;?>
                                        <h2 class="woocommerce-loop-product__title">
                                            <?php if(app()->getLocale() == 'ar'):?>
                                                {{$product->name_ar}}
                                            <?php else:?>
                                                {{$product->name}}
                                            <?php endif;?>
                                        </h2>
                                    </a>
                                    <!-- .woocommerce-LoopProduct-link -->
                                    <div class="techmarket-product-rating">
                                        <div title="Rated 5.00 out of 5" class="star-rating">
                                            <span style="width:100%">
                                                <strong class="rating">5.00</strong> out of 5</span>
                                        </div>
                                        <span class="review-count">(1)</span>
                                    </div>
                                    <!-- .techmarket-product-rating -->
                                    <span class="sku_wrapper">SKU:
                                        <span class="sku">{{$product->sku}}</span>
                                    </span>
                                    <div class="woocommerce-product-details__short-description">
                                        <?php echo htmlspecialchars_decode(stripslashes($product->product_info));?>
                                    </div>
                                    <!-- .woocommerce-product-details__short-description -->
                                    <a class="button product_type_simple add_to_cart_button" href="#">Add to cart</a>
                                    <a class="add-to-compare-link" href="#">Add to compare</a>
                                </div>
                                <?php endforeach;?>
                                <?php else:?>
                                    <p class="no-prd">No products available</p>
                                <?php endif;?>
                                <!-- .product -->
                            </div>
                            <!-- .products -->
                        </div>
                        <!-- .woocommerce -->
                    </div>
                    <!-- .tab-pane -->
                    <div id="list-view-large" class="tab-pane <?= ($layout_type == 'list-view-large') ? 'active' : ''?>" role="tabpanel">
                        <div class="woocommerce columns-1">
                            <div class="products">
                                <?php if($cats->count() > 0):?>
                                <?php foreach($cats as $product):?>
                                    <?php
                                    $price = getVariationPrice($product->id);
                                    ?>
                                <div class="product list-view-large">
                                    <div class="media">
                                        <img width="224" height="197" alt="" class="attachment-shop_catalog size-shop_catalog wp-post-image" src="{{asset('assets/images/products/'.$product->photo)}}">
                                        <div class="media-body">
                                            <div class="product-info">
                                                <div class="yith-wcwl-add-to-wishlist">
                                                    <a href="#" rel="nofollow" class="add_to_wishlist"> Add to Wishlist</a>
                                                </div>
                                                <!-- .yith-wcwl-add-to-wishlist -->
                                                <a class="woocommerce-LoopProduct-link woocommerce-loop-product__link" href="{{ route('front.product', $product->id) }}">
                                                    <h2 class="woocommerce-loop-product__title">
                                                        <?php if(app()->getLocale() == 'ar'):?>
                                                            {{$product->name_ar}}
                                                        <?php else:?>
                                                            {{$product->name}}
                                                        <?php endif;?>
                                                    </h2>
                                                    <div class="techmarket-product-rating">
                                                        <div title="Rated 5.00 out of 5" class="star-rating">
                                                            <span style="width:100%">
                                                                <strong class="rating">5.00</strong> out of 5</span>
                                                        </div>
                                                        <span class="review-count">(1)</span>
                                                    </div>
                                                </a>
                                                <!-- .woocommerce-LoopProduct-link -->
                                                <?php $brand = getBrandByProduct($product->id);?>
                                                <?php if(!empty($brand)):?>
                                                <div class="brand">
                                                    <a href="#">
                                                        <img alt="galaxy" src="{{asset('assets/images/brands/'.$brand->photo)}}">
                                                    </a>
                                                </div>
                                                <?php endif;?>
                                                <!-- .brand -->
                                                <div class="woocommerce-product-details__short-description">
                                                    <?php echo htmlspecialchars_decode(stripslashes($product->product_info));?>
                                                </div>
                                                <!-- .woocommerce-product-details__short-description -->
                                                <span class="sku_wrapper">SKU:
                                                    <span class="sku">{{$product->sku}}</span>
                                                </span>
                                            </div>
                                            <!-- .product-info -->
                                            <div class="product-actions">
                                                <div class="availability">
                                                    Availability:
                                                    <p class="stock in-stock">
                                                        <?php if((isset($product->stock) && $product->stock > 0) || $product->stock == ''):?>
                                                        <span class="total-stock"><?= $product->stock?></span>
                                                        in stock
                                                        <?php else:?>
                                                            out stock
                                                        <?php endif;?>
                                                    </p>
                                                </div>
                                                <?php if(isset($product->previous_price) && !empty($product->previous_price)):?>
                                                    <span class="price">
                                                        <ins>
                                                            <span class="woocommerce-Price-currencySymbol">{{$curr}}</span>
                                                            <span class="amount">{{number_format($price,2)}}</span>
                                                        </ins>
                                                        <del>
                                                            <span class="amount">{{number_format($product->previous_price,2)}}</span>
                                                        </del>
                                                        <span class="amount"> </span>
                                                    </span>
                                                <?php else:?>
                                                    <span class="price">
                                                        <ins>
                                                            <span class="amount"> </span>
                                                        </ins>
                                                        <span class="woocommerce-Price-currencySymbol">{{$curr}}</span>
                                                        <span class="amount">{{number_format($price , 2)}}</span>
                                                    </span>
                                                <?php endif;?>
                                                <!-- .price -->
                                                <a class="button add_to_cart_button" href="#">Add to Cart</a>
                                                <a class="add-to-compare-link" href="#">Add to compare</a>
                                            </div>
                                            <!-- .product-actions -->
                                        </div>
                                        <!-- .media-body -->
                                    </div>
                                    <!-- .media -->
                                </div>
                                <?php endforeach;?>
                                <?php else:?>
                                    <p class="no-prd"> No products available</p>
                                <?php endif;?>
                                <!-- .product -->
                            </div>
                            <!-- .products -->
                        </div>
                        <!-- .woocommerce -->
                    </div>
                    <!-- .tab-pane -->
                    <div id="list-view" class="tab-pane <?= ($layout_type == 'list-view') ? 'active' : ''?>" role="tabpanel">
                        <div class="woocommerce columns-1">
                            <div class="products">
                                <?php if($cat->count() > 0):?>
                                <?php foreach($cats as $product):?>
                                    <?php
                                    $price = getVariationPrice($product->id);
                                    ?>
                                <div class="product list-view ">
                                    <div class="media">
                                        <img width="224" height="197" alt="" class="attachment-shop_catalog size-shop_catalog wp-post-image" src="{{asset('assets/images/products/'.$product->photo)}}">
                                        <div class="media-body">
                                            <div class="product-info">
                                                <div class="yith-wcwl-add-to-wishlist">
                                                    <a href="#" rel="nofollow" class="add_to_wishlist"> Add to Wishlist</a>
                                                </div>
                                                <!-- .yith-wcwl-add-to-wishlist -->
                                                <a class="woocommerce-LoopProduct-link woocommerce-loop-product__link" href="{{ route('front.product', $product->id) }}">
                                                    <h2 class="woocommerce-loop-product__title">
                                                        <?php if(app()->getLocale() == 'ar'):?>
                                                            {{$product->name_ar}}
                                                        <?php else:?>
                                                            {{$product->name}}
                                                        <?php endif;?>
                                                    </h2>
                                                    <div class="techmarket-product-rating">
                                                        <div title="Rated 5.00 out of 5" class="star-rating">
                                                            <span style="width:100%">
                                                                <strong class="rating">5.00</strong> out of 5</span>
                                                        </div>
                                                        <span class="review-count">(1)</span>
                                                    </div>
                                                </a>
                                                <!-- .woocommerce-LoopProduct-link -->
                                                <?php $brand = getBrandByProduct($product->id);?>
                                                <?php if(!empty($brand)):?>
                                                <div class="brand">
                                                    <a href="#">
                                                        <img alt="galaxy" src="{{asset('assets/images/brands/'.$brand->photo)}}">
                                                    </a>
                                                </div>
                                                <?php endif;?>
                                                <!-- .brand -->
                                                <div class="woocommerce-product-details__short-description">
                                                    <?php echo htmlspecialchars_decode(stripslashes($product->product_info));?>
                                                </div>
                                                <!-- .woocommerce-product-details__short-description -->
                                            </div>
                                            <!-- .product-info -->
                                            <div class="product-actions">
                                                <div class="availability">
                                                    Availability:
                                                    <p class="stock in-stock">
                                                        <?php if((isset($product->stock) && $product->stock > 0) || $product->stock == ''):?>
                                                        <span class="total-stock"><?= $product->stock?></span>
                                                        in stock
                                                        <?php else:?>
                                                            out stock
                                                        <?php endif;?>
                                                    </p>
                                                </div>
                                                <?php if(isset($product->previous_price) && !empty($product->previous_price)):?>
                                                    <span class="price">
                                                        <ins>
                                                            <span class="woocommerce-Price-currencySymbol">{{$curr}}</span>
                                                            <span class="amount">{{number_format($price,2)}}</span>
                                                        </ins>
                                                        <del>
                                                            <span class="amount">{{number_format($product->previous_price,2)}}</span>
                                                        </del>
                                                        <span class="amount"> </span>
                                                    </span>
                                                <?php else:?>
                                                    <span class="price">
                                                        <ins>
                                                            <span class="amount"> </span>
                                                        </ins>
                                                        <span class="woocommerce-Price-currencySymbol">{{$curr}}</span>
                                                        <span class="amount">{{number_format($price , 2)}}</span>
                                                    </span>
                                                <?php endif;?>
                                                <!-- .price -->
                                                <a class="button add_to_cart_button" href="#">Add to Cart</a>
                                                <a class="add-to-compare-link" href="#">Add to compare</a>
                                            </div>
                                            <!-- .product-actions -->
                                        </div>
                                        <!-- .media-body -->
                                    </div>
                                    <!-- .media -->
                                </div>
                                <?php endforeach;?>
                                <?php else:?>
                                    <p class="no-prd"> No products available</p>
                                <?php endif;?>
                                <!-- .product -->
                            </div>
                            <!-- .products -->
                        </div>
                        <!-- .woocommerce -->
                    </div>
                    <!-- .tab-pane -->
                    <div id="list-view-small" class="tab-pane <?= ($layout_type == 'list-view-small') ? 'active' : ''?>" role="tabpanel">
                        <div class="woocommerce columns-1">
                            <div class="products">
                                <?php if($cats->count() > 0):?>
                                <?php foreach($cats as $product):?>
                                    <?php
                                    $price = getVariationPrice($product->id);
                                    ?>
                                <div class="product list-view-small ">
                                    <div class="media">
                                        <img width="224" height="197" alt="" class="attachment-shop_catalog size-shop_catalog wp-post-image" src="{{asset('assets/images/products/'.$product->photo)}}">
                                        <div class="media-body">
                                            <div class="product-info">
                                                <div class="yith-wcwl-add-to-wishlist">
                                                    <a href="#" rel="nofollow" class="add_to_wishlist"> Add to Wishlist</a>
                                                </div>
                                                <!-- .yith-wcwl-add-to-wishlist -->
                                                <a class="woocommerce-LoopProduct-link woocommerce-loop-product__link" href="{{ route('front.product', $product->id) }}">
                                                    <h2 class="woocommerce-loop-product__title">
                                                        <?php if(app()->getLocale() == 'ar'):?>
                                                            {{$product->name_ar}}
                                                        <?php else:?>
                                                            {{$product->name}}
                                                        <?php endif;?>
                                                    </h2>
                                                    <div class="techmarket-product-rating">
                                                        <div title="Rated 5.00 out of 5" class="star-rating">
                                                            <span style="width:100%">
                                                                <strong class="rating">5.00</strong> out of 5</span>
                                                        </div>
                                                        <span class="review-count">(1)</span>
                                                    </div>
                                                </a>
                                                <!-- .woocommerce-LoopProduct-link -->
                                                <div class="woocommerce-product-details__short-description">
                                                    <?php echo htmlspecialchars_decode(stripslashes($product->product_info));?>
                                                </div>
                                                <!-- .woocommerce-product-details__short-description -->
                                            </div>
                                            <!-- .product-info -->
                                            <div class="product-actions">
                                                <?php if(isset($product->previous_price) && !empty($product->previous_price)):?>
                                                    <span class="price">
                                                        <ins>
                                                            <span class="woocommerce-Price-currencySymbol">{{$curr}}</span>
                                                            <span class="amount">{{number_format($price,2)}}</span>
                                                        </ins>
                                                        <del>
                                                            <span class="amount">{{number_format($product->previous_price,2)}}</span>
                                                        </del>
                                                        <span class="amount"> </span>
                                                    </span>
                                                <?php else:?>
                                                    <span class="price">
                                                        <ins>
                                                            <span class="amount"> </span>
                                                        </ins>
                                                        <span class="woocommerce-Price-currencySymbol">{{$curr}}</span>
                                                        <span class="amount">{{number_format($price , 2)}}</span>
                                                    </span>
                                                <?php endif;?>
                                                <!-- .price -->
                                                <a class="button add_to_cart_button" href="#">Add to Cart</a>
                                                <a class="add-to-compare-link" href="#">Add to compare</a>
                                            </div>
                                            <!-- .product-actions -->
                                        </div>
                                        <!-- .media-body -->
                                    </div>
                                    <!-- .media -->
                                </div>
                                <?php endforeach;?>
                                <?php else:?>
                                    <p class="no-prd"> No products available</p>
                                <?php endif;?>
                                <!-- .product -->
                            </div>
                            <!-- .products -->
                        </div>
                        <!-- .woocommerce -->
                    </div>
                    <!-- .tab-pane -->
                </div>
                <!-- .tab-content -->
                <div class="shop-control-bar-bottom">
                    <form class="form-techmarket-wc-ppp" method="POST">
                        <select class="techmarket-wc-wppp-select c-select page_length" name="page_length">
                            <option value="20" <?= ($page_length == 20) ? 'selected' : ''?>>Show 20</option>
                            <option value="40" <?= ($page_length == 40) ? 'selected' : ''?>>Show 40</option>
                            <option value="all" <?= ($page_length == 'all') ? 'selected' : ''?>>Show All</option>
                        </select>
                        <input type="hidden" value="5" name="shop_columns">
                        <input type="hidden" value="15" name="shop_per_page">
                        <input type="hidden" value="right-sidebar" name="shop_layout">
                    </form>
                    <!-- .form-techmarket-wc-ppp -->
                    <p class="woocommerce-result-count">
                        Showing {{ $cats->firstItem() }} &ndash; {{ $cats->lastItem() }} of {{ $cats->total() }} (results)
                    </p>
                    <!-- .woocommerce-result-count -->
                    <nav class="woocommerce-pagination">
                        {{ $cats->appends(request()->input())->links('front.pagination') }}
                    </nav>
                    <!-- .woocommerce-pagination -->
                </div>
                <!-- .shop-control-bar-bottom -->
            </main>
            <!-- #main -->
        </div>
        <!-- #primary -->
        <div id="secondary" class="widget-area shop-sidebar" role="complementary">
            <div class="widget woocommerce widget_product_categories techmarket_widget_product_categories" id="techmarket_product_categories_widget-2">
                <ul class="product-categories ">
                    <li class="product_cat">
                        <span>Browse Categories</span>
                        <ul>
                            <?php foreach($categories as $category):?>
                                <li class="cat-item">
                                    <?php
                                    $sub_category = getSubCategory($category->id);
                                    ?>
                                    <?php if($sub_category->count() > 0):?>
                                        <li class="product_cat ">
                                            <span class="show-all-cat-dropdown <?= ($category->id == $cat->id) ? 'show-parent-cat current-category' : ''?>">
                                                <?php if(app()->getLocale() == 'ar'):?>{{$category->name_ar}}
                                                <?php else:?>
                                                    {{ucwords($category->name)}}
                                                <?php endif;?>
                                            <span class="child-indicator"></span></span>
                                            <ul class="p-l-0 p-r-0" style="<?= ($category->id == $subcat->id) ? 'display:block;' : 'display: none;'?>">
                                                <?php foreach($sub_category as $sub_cat):?>
                                                <li class="cat-item <?= ($sub_cat->id == $subcat->id) ? 'light-green' : ''?>">
                                                    <a href="{{ route('front.subcat',['slug1' => $category->slug, 'slug2' => $sub_cat->slug]) }}">
                                                            <?php if(app()->getLocale() == 'ar'):?>{{$sub_cat->name_ar}}
                                                            <?php else:?>
                                                                {{ucwords($sub_cat->name)}}
                                                            <?php endif;?>
                                                        </a>
                                                </li>
                                                <?php endforeach;?>
                                            </ul>
                                        </li>
                                    <?php else:?>
                                        <a href="{{ route('front.category', $category->slug) }}">
                                            <span class="no-child"></span>
                                            <?php if(app()->getLocale() == 'ar'):?>{{$category->name_ar}}
                                            <?php else:?>
                                                {{$category->name}}
                                            <?php endif;?>
                                        </a>
                                    <?php endif;?>
                                </li>
                            <?php endforeach;?>
                        </ul>
                    </li>
                </ul>
            </div>
            <div id="techmarket_products_filter-3" class="widget widget_techmarket_products_filter">
                <span class="gamma widget-title">Filters</span>
                <form id="filter-form">
                <div class="widget woocommerce widget_price_filter" id="woocommerce_price_filter-2">
                    <p>
                        <span class="gamma widget-title">Filter by price</span>
                        <div class="price_slider_amount">
                            <input id="amount" type="text" placeholder="Min price" data-min="6" value="33" name="price_filter" style="display: none;">
                            <?php if((isset($filters) && !empty($filters)) || (isset($min) && isset($max))):?>
                            <input type="hidden" name="filter_clear" id="filter_clear">
                            <button class="button btn-reset" type="button">Reset</button>
                            <?php endif?>
                            <button class="button" type="submit">Filter</button>
                        </div>
                        <div id="slider-range" class="price_slider"></div>
                </div>
                <?php foreach($attr_arr as $key=>$attr):?>
                    <?php $attr = array_unique($attr);?>
                <div class="widget woocommerce widget_layered_nav maxlist-more" id="woocommerce_layered_nav-2">
                    <span class="gamma widget-title"><?= $key?></span>
                    <ul>
                        <?php foreach($attr as $val):?>
                            
                        <li class="wc-layered-nav-term ">
                            <label class="chk-container"><?= $val?>
                            <?php if(isset($filters[$key])):?>
                              <input type="checkbox" class="attr_chk" name="attr[<?= $key?>][]" value="<?= $val?>" <?= (in_array($val,$filters[$key])) ? 'checked' : ''?>>
                            <?php else:?>
                                <input type="checkbox" class="attr_chk" name="attr[<?= $key?>][]" value="<?= $val?>">
                            <?php endif;?>
                              <span class="checkmark"></span>
                            </label>
                        </li>
                        <?php endforeach;?>
                    </ul>
                    <?php ?>
                </div>
                <?php endforeach;?>
                </form>
                <!-- .woocommerce widget_layered_nav -->
            </div>
            <div class="widget widget_techmarket_products_carousel_widget">
                <section id="single-sidebar-carousel" class="section-products-carousel">
                    <header class="section-header">
                        <h2 class="section-title">Latest Products</h2>
                        <nav class="custom-slick-nav"></nav>
                    </header>
                    <!-- .section-header -->
                    <div class="products-carousel" data-ride="tm-slick-carousel" data-wrap=".products" data-slick="{&quot;infinite&quot;:false,&quot;slidesToShow&quot;:1,&quot;slidesToScroll&quot;:1,&quot;rows&quot;:2,&quot;slidesPerRow&quot;:1,&quot;dots&quot;:false,&quot;arrows&quot;:true,&quot;prevArrow&quot;:&quot;&lt;a href=\&quot;#\&quot;&gt;&lt;i class=\&quot;tm tm-arrow-left\&quot;&gt;&lt;\/i&gt;&lt;\/a&gt;&quot;,&quot;nextArrow&quot;:&quot;&lt;a href=\&quot;#\&quot;&gt;&lt;i class=\&quot;tm tm-arrow-right\&quot;&gt;&lt;\/i&gt;&lt;\/a&gt;&quot;,&quot;appendArrows&quot;:&quot;#single-sidebar-carousel .custom-slick-nav&quot;}">
                        <div class="container-fluid">
                            <div class="woocommerce columns-1">
                                <div class="products">
                                    <?php foreach($latest_products as $product):?>
                                        <?php
                                        $price = getVariationPrice($product->id);
                                        ?>
                                    <div class="landscape-product-widget product">
                                        <a class="woocommerce-LoopProduct-link" href="{{ route('front.product', $product->id) }}">
                                            <div class="media">
                                                <img class="wp-post-image" src="{{asset('assets/images/products/'.$product->photo)}}" alt="">
                                                <div class="media-body">
                                                    <?php if(isset($product->previous_price) && !empty($product->previous_price)):?>
                                                        <span class="price">
                                                            <ins>
                                                                <span class="woocommerce-Price-currencySymbol">{{$curr}}</span>
                                                                <span class="amount">{{number_format($price,2)}}</span>
                                                            </ins>
                                                            <del>
                                                                <span class="woocommerce-Price-currencySymbol">{{$curr}}</span>
                                                                <span class="amount">{{number_format($product->previous_price,2)}}</span>
                                                            </del>
                                                            <span class="amount"> </span>
                                                        </span>
                                                        <?php else:?>
                                                            <span class="price">
                                                                <ins>
                                                                    <span class="amount"> </span>
                                                                </ins>
                                                                <span class="woocommerce-Price-currencySymbol">{{$curr}}</span>
                                                                <span class="amount">{{number_format($price , 2)}}</span>
                                                            </span>
                                                        <?php endif;?>
                                                    <!-- .price -->
                                                    <h2 class="woocommerce-loop-product__title">
                                                        <?php if(app()->getLocale() == 'ar'):?>
                                                            {{$product->name_ar}}
                                                        <?php else:?>
                                                            {{$product->name}}
                                                        <?php endif;?>
                                                    </h2>
                                                    <div class="techmarket-product-rating">
                                                        <div title="Rated 0 out of 5" class="star-rating">
                                                            <span style="width:0%">
                                                                <strong class="rating">0</strong> out of 5</span>
                                                        </div>
                                                        <span class="review-count">(0)</span>
                                                    </div>
                                                    <!-- .techmarket-product-rating -->
                                                </div>
                                                <!-- .media-body -->
                                            </div>
                                            <!-- .media -->
                                        </a>
                                        <!-- .woocommerce-LoopProduct-link -->
                                    </div>
                                    <?php endforeach;?>
                                </div>
                                <!-- .products -->
                            </div>
                            <!-- .woocommerce -->
                        </div>
                        <!-- .container-fluid -->
                    </div>
                    <!-- .products-carousel -->
                </section>
                <!-- .section-products-carousel -->
            </div>
            <!-- .widget_techmarket_products_carousel_widget -->
        </div>
        <!-- #secondary -->
    </div>
    <!-- .row -->
</div>
@endsection
<script type="text/javascript">

</script>