@extends('layouts.front')
@section('body_class', 'page home page-template-default')
@section('content')
<div class="col-full">
    <div class="row">
        <nav class="woocommerce-breadcrumb">
            <a href="<?= URL('/')?>">{{ __('messages.home') }}</a>
            <span class="delimiter">
                <i class="tm tm-breadcrumbs-arrow-right"></i>
            </span>{{ __('messages.login_register') }}
        </nav>
        <!-- .woocommerce-breadcrumb -->
        <div id="primary" class="content-area">
            <main id="main" class="site-main">
                <div class="type-page hentry">
                    <div class="entry-content">
                        <div class="woocommerce">
                            <div class="customer-login-form">
                                <span class="or-text">or</span>
                                @if(session()->has('success'))
                                        <div class="alert alert-success">
                                            {{ session()->get('success') }}
                                        </div>
                                    @endif
                                    @if(session()->has('error'))
                                        <div class="alert alert-danger w-100">
                                            {{ session()->get('error') }}
                                        </div>
                                    @endif
                                    @if ($errors->any())
                                        <div class="alert alert-danger w-50">
                                            <ul class="mr-b-0">
                                                @foreach ($errors->all() as $error)
                                                    <li>{{ $error }}</li>
                                                @endforeach
                                            </ul>
                                        </div>
                                    @endif
                                <div id="customer_login" class="u-columns col2-set w-100">
                                    <div class="u-column1 col-1">
                                        <h2>{{ __('messages.login') }}</h2>
                                        <form method="post" class="woocomerce-form woocommerce-form-login login" action="{{ route('user.login.submit') }}">
                                          {{ csrf_field() }}
                                            
                                            <p class="form-row form-row-wide">
                                                <label for="username">{{ __('messages.email_address') }}
                                                    <span class="required">*</span>
                                                </label>
                                                <input type="text" class="input-text" name="email" id="email" value="" autocomplete="off" readonly onfocus="this.removeAttribute('readonly');"/>
                                            </p>
                                            <p class="form-row form-row-wide">
                                                <label for="password">{{ __('messages.password') }}
                                                    <span class="required">*</span>
                                                </label>
                                                <input class="input-text" type="password" name="password" id="password" autocomplete="off" readonly onfocus="this.removeAttribute('readonly');"/>
                                            </p>
                                            <p class="form-row">
                                                <input class="woocommerce-Button button" type="submit" value="{{ __('messages.login') }}" name="login">
                                                <label for="rememberme" class="woocommerce-form__label woocommerce-form__label-for-checkbox inline">
                                                    <input class="woocommerce-form__input woocommerce-form__input-checkbox" name="rememberme" type="checkbox" id="rememberme" value="forever" /> {{ __('messages.remember_me') }}
                                                </label>
                                            </p>
                                            <p class="woocommerce-LostPassword lost_password">
                                                <a href="{{ route('user-forgot') }}">{{ __('messages.lost_password') }}</a>
                                            </p>
                                        </form>
                                        <!-- .woocommerce-form-login -->
                                    </div>
                                    <!-- .col-1 -->
                                    <div class="u-column2 col-2">
                                        <h2>{{ __('messages.register') }}</h2>
                                        <form class="register" id="user-register-form" action="{{ route('user-register-submit') }}" method="post">
                                             {{ csrf_field() }}
                                            <p class="before-register-text">
                                                {{ __('messages.create_account_text') }}
                                            </p>
                                            <p class="form-row form-row-wide">
                                                <label for="reg_email">{{ __('messages.email_address') }}
                                                    <span class="required">*</span>
                                                </label>
                                                <input type="email" value="" id="reg_email" name="email" class="woocommerce-Input woocommerce-Input--text input-text" autocomplete="off" readonly onfocus="this.removeAttribute('readonly');">
                                            </p>
                                            <p class="form-row form-row-wide">
                                                <label for="reg_password">{{ __('messages.password') }}
                                                    <span class="required">*</span>
                                                </label>
                                                <input type="password" id="reg_password" name="password" class="woocommerce-Input woocommerce-Input--text input-text" autocomplete="off" readonly onfocus="this.removeAttribute('readonly');">
                                            </p>
                                            <p class="form-row form-row-wide">
                                                <label for="reg_cnf_password">{{ __('messages.confirm_password') }}
                                                    <span class="required">*</span>
                                                </label>
                                                <input type="password" id="reg_cnf_password" name="confirm_password" class="woocommerce-Input woocommerce-Input--text input-text" autocomplete="off" readonly onfocus="this.removeAttribute('readonly');">
                                            </p>
                                            <p class="form-row">
                                                <input type="submit" class="woocommerce-Button button" name="register" value="{{ __('messages.register') }}" id="btn-register"/>
                                            </p>
                                            <div class="register-benefits">
                                                <h3>{{ __('messages.signup_benefit') }}</h3>
                                                <ul>
                                                    <li>{{ __('messages.signup_benefit_1') }}</li>
                                                    <li>{{ __('messages.signup_benefit_2') }}</li>
                                                    <li>{{ __('messages.signup_benefit_3') }}</li>
                                                </ul>
                                            </div>
                                        </form>
                                        <!-- .register -->
                                    </div>
                                    <!-- .col-2 -->
                                </div>
                                <!-- .col2-set -->
                            </div>
                            <!-- .customer-login-form -->
                        </div>
                        <!-- .woocommerce -->
                    </div>
                    <!-- .entry-content -->
                </div>
                <!-- .hentry -->
            </main>
            <!-- #main -->
        </div>
        <!-- #primary -->
    </div>
    <!-- .row -->
</div>

@endsection