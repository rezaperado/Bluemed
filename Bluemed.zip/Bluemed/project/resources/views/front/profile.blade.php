@extends('layouts.front')
@section('content')

<div class="col-full">
    <div class="row">
        <nav class="woocommerce-breadcrumb">
            <a href="<?= URL('/')?>">Home</a>
            <span class="delimiter">
                <i class="tm tm-breadcrumbs-arrow-right"></i>
            </span>My Account
        </nav>
        <!-- .woocommerce-breadcrumb -->
        <div id="primary" class="content-area">
            <main id="main" class="site-main">
                <div class="shop-archive-header">
                    <div class="jumbotron">
                        <div class="jumbotron-img">
                            <img width="416" height="283" alt="" src="assets/images/products/jumbo.jpg" class="jumbo-image alignright">
                        </div>
                        <div class="jumbotron-caption">
                            <h3 class="jumbo-title">Account Information</h3>
                            <table class="table no-border-table">
                              <tbody>
                                <tr>
                                    <th class="45%" width="10%">Name</th>
                                    <td width="10%">:</td>
                                    <td class="45%" width="100%">{{$user->first_name}}&nbsp;{{$user->last_name}}</td>
                                </tr>
                                <tr>
                                    <th class="45%" width="10%">Email</th>
                                    <td width="10%">:</td>
                                    <td class="45%" width="100%">{{$user->email}}</td>
                                </tr>
                                 <tr>
                                    <th class="45%" width="10%">Phone</th>
                                    <td width="10%">:</td>
                                    <td class="45%" width="100%">{{$user->phone}}</td>
                                </tr>
                                <tr>
                                    <th class="45%" width="10%">Area</th>
                                    <td width="10%">:</td>
                                    <td class="45%" width="100%">{{$user->area}}</td>
                                </tr>
                                <tr>
                                    <th class="45%" width="10%">Block</th>
                                    <td width="10%">:</td>
                                    <td class="45%" width="100%">{{$user->block}}</td>
                                </tr>
                                <tr>
                                    <th class="45%" width="10%">Street</th>
                                    <td width="10%">:</td>
                                    <td class="45%" width="100%">{{$user->street}}</td>
                                </tr>
                                <tr>
                                    <th class="45%" width="10%">City</th>
                                    <td width="10%">:</td>
                                    <td class="45%" width="100%">{{$user->city}}</td>
                                </tr>
                                 <tr>
                                    <th class="45%" width="10%">Zip</th>
                                    <td width="10%">:</td>
                                    <td class="45%" width="100%">{{$user->zip}}</td>
                                </tr>
                                <tr>
                                   <th class="45%" width="10%">Country</th>
                                   <td width="10%">:</td>
                                   <td class="45%" width="100%">{{getcountry($user->country)}}</td>
                               </tr>
                             </tbody>
                            </table>
                        </div>
                        <!-- .jumbotron-caption -->
                    </div>
                    <!-- .jumbotron -->
                </div>
            </main>
            <!-- #main -->
        </div>
        <!-- #primary -->
        <div id="secondary" class="widget-area shop-sidebar" role="complementary">
            <div class="widget woocommerce widget_product_categories techmarket_widget_product_categories" id="techmarket_product_categories_widget-2">
                <ul class="product-categories ">
                    <li class="product_cat">
                        <ul>
                          <li class="cat-item">
                                <a href="{{route('user-profile')}}">
                                    <span class="no-child"></span>Dashboard
                                </a>
                            </li>
                            <li class="cat-item">
                                <a href="{{route('user-orderlist')}}">
                                    <span class="no-child"></span>My Orders
                                </a>
                            </li>
                            <li class="cat-item">
                                <a href="{{route('edit-profile')}}">
                                    <span class="no-child"></span>Edit Profile
                                </a>
                            </li>
                            <li class="cat-item">
                                <a href="{{route('change-password')}}">
                                    <span class="no-child"></span>Change Password
                                </a>
                            </li>
                            <li class="cat-item">
                                <a href="#">
                                    <span class="no-child"></span>Wishlist
                                </a>
                            </li>
                        </ul>
                    </li>
                </ul>
            </div>
            <!-- .widget_techmarket_products_carousel_widget -->
        </div>
        <!-- #secondary -->
    </div>
    <!-- .row -->
</div>


@endsection

@section('scripts')
	<script>
        $(document).ready(function(){
            if($('select[name="country"]').val() == 119){
                    $('div#address2').hide();
                    $('input#address2').prop('required',false);
                    $('div#block').show();
                   $('div#street').show();
                   $('div#area').show();
                   $('input#block').prop('required',true);
                   $('input#area').prop('required',true);
                   $('input#street').prop('required',true);
                   $('input#zip').prop('required',false);
                   
            }else{
               $('div#address2').show();
               $('input#address2').prop('required',true);  
               $('div#block').hide();
               $('div#street').hide();
               $('div#area').hide();
               $('input#block').prop('required',false);
               $('input#area').prop('required',false);
               $('input#street').prop('required',false);
               $('input#zip').prop('required',true);
               
            }
            
            $('select[name="country"]').change(function(){
                //console.log($(this).val()); 
                if($(this).val() == 119){
                    $('div#address2').hide();
                    $('input#address2').prop('required',false);
                       $('div#block').show();
                       $('div#street').show();
                       $('div#area').show();
                       $('input#block').prop('required',true);
                       $('input#area').prop('required',true);
                       $('input#street').prop('required',true);
                       $('input#zip').prop('required',false);
                }else{
                    $('div#address2').show();
                    $('input#address2').prop('required',true);
                    $('div#block').hide();
                   $('div#street').hide();
                   $('div#area').hide();
                   $('input#block').prop('required',false);
                   $('input#area').prop('required',false);
                   $('input#street').prop('required',false);
                   $('input#zip').prop('required',true);
                   
                    
                }
                
            });
        });
    </script>
@endsection