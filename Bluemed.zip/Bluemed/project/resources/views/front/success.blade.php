@extends('layouts.front')
@section('body_class', 'page home page-template-default')
@section('content')
<section class="offer-banners payment-background">
    <div class="container payment_page">
    <div class="row justify-content-center">
            <div class="col-md-12 col-xs-12 col-sm-12 button-payment-page text-right">
                <a href="<?= URL('/user/profile')?>" class="btn btn-primarybtn btn-order add-newProduct-btn print"><i class="fa fa-dashboard"></i>{{ __('messages.dashboard') }}</a>
                <a href="<?= URL('/')?>" class="btn btn-order add-newProduct-btn print"><i class="fa fa-home"></i>{{ __('messages.home') }}</a>
                <a class="btn btn-order add-newProduct-btn print" href="{{ route('user-order-print',['id' => $order->id]) }}" target="_blank"><i class="fa fa-print"></i> {{ __('messages.print_invoice') }}</a>
            </div>
            <div class="col-12 text-center">
                <img src="{{asset('assets/images/'.$gs->logo)}}" width="150" alt="invoice_logo" class="invoice_logo">
                <p class="address_invoice" > Bluemed., New Gold Souq <i class="fa fa-phone">  (965) 1234 5678, (965) 1234 5678</i>, <i class="fa fa-envelope"> info@bluemed.com</i></p>
                <hr>
                <div class="title text-center header-order-number">
                     <h6>{{ __('messages.order_number_is') }}</h6> <h2>#{{$order->order_number}}</h2>
                </div>
            </div>
    </div>
    <div class="row"> 
      <div class="col-md-12 col-xs-12">
         <div class="row">
                                                        <div class="col-md-6">
                                                    <section class="woocommerce-order-details">
                                                        <h5 class="woocommerce-order-details__title">{{ __('messages.billing_details') }}</h5>
                                                        <table class="woocommerce-table woocommerce-table--order-details shop_table order_details">
                                                            <tr>
                                                              <th style="width:8%;">{{ __('messages.name') }}: </th><td>{{$user->first_name}}&nbsp;{{$user->last_name}}</td>
                                                            </tr>
                                                            <tr>
                                                              <th>{{ __('messages.email') }}:</th><td>{{$user->email}}</td>
                                                            </tr>
                                                            <tr>
                                                              <th>{{ __('messages.phone') }}:</th><td>{{$user->phone}}</td>
                                                            </tr>
                                                            <tr>
                                                              <th>{{ __('messages.area') }}:</th><td>{{$user->area}}</td>
                                                            </tr>
                                                            <tr>
                                                              <th>{{ __('messages.block') }}:</th><td>{{$user->block}}</td>
                                                            </tr>
                                                            <tr>
                                                              <th>{{ __('messages.city') }}:</th><td>{{$user->city}}</td>
                                                            </tr>
                                                            <tr>
                                                              <th>{{ __('messages.country') }}:</th><td>{{getcountry($user->country)}}</td>
                                                            </tr>
                                                            <tr>
                                                              <th>{{ __('messages.zip') }}:</th><td>{{$user->zip}}</td>
                                                            </tr>
                                                        </table>
                                                    </section>
                                                    </div>
                                                     <div class="col-md-6">
                                                         
                                                         @if($order->shipping=='shipto')
                                                     <section class="woocommerce-order-details">
                                                        <h5 class="woocommerce-order-details__title">Shipping Details</h5>
                                                        <table class="woocommerce-table woocommerce-table--order-details shop_table order_details">
                                                            <tr>
                                                              <th style="width:8%;">{{ __('messages.name') }}: </th><td>{{$order->shipping_first_name}}&nbsp;{{$order->shipping_last_name}}</td>
                                                            </tr>
                                                            <tr>
                                                              <th>{{ __('messages.email') }}:</th><td>{{$order->shipping_email}}</td>
                                                            </tr>
                                                            <tr>
                                                              <th>{{ __('messages.phone') }}:</th><td>{{$order->shipping_phone}}</td>
                                                            </tr>
                                                            <tr>
                                                              <th>{{ __('messages.area') }}:</th><td>{{$order->shipping_area}}</td>
                                                            </tr>
                                                            <tr>
                                                              <th>{{ __('messages.block') }}:</th><td>{{$order->shipping_block}}</td>
                                                            </tr>
                                                            <tr>
                                                              <th>{{ __('messages.city') }}:</th><td>{{$order->shipping_city}}</td>
                                                            </tr>
                                                            <tr>
                                                              <th>{{ __('messages.country') }}:</th><td>{{getcountry($order->shipping_country)}}</td>
                                                            </tr>
                                                            <tr>
                                                              <th>{{ __('messages.zip') }}:</th><td>{{$order->shipping_zip}}</td>
                                                            </tr>
                                                        </table>
                                                    </section>
                                                    @endif
                                                    </div>
                                                    </div>
      </div>
            <div class="col-md-6 col-xs-12">
        <div class="panel panel-default">
          <div class="panel-heading"><h5>{{ __('messages.payment_info') }}</h5></div>
          <div class="panel-body">
            <div class="table-responsive">
                <table class="table">
                  <tbody>
                    <tr>
                        <th width="45%">{{ __('messages.payment_method') }}</th>
                        <td width="10%">:</td>
                        <td width="45%">{{$order->method}}</td>
                    </tr>
                    <tr>
                        <th width="45%">{{ __('messages.transaction_id') }}</th>
                        <td width="10%">:</td>
                        <td width="45%">{{$order->txnid}}</td>
                    </tr>
                    <tr>
                        <th width="45%">{{ __('messages.payment_status') }}</th>
                        <td width="10%">:</td>
                        <td width="45%">@if($order->method=='CASH') PENDING @else  COMPLETED @endif</td>
                    </tr>
                    <?php 
                    $total_price = 0;
                    foreach($product_data as $product){
                        $price = getVariationPrice($product->id);
                        $total_price += $price;
                    }
                        ?>
                    <tr>
                        <th width="45%">{{ __('messages.order_total') }}</th>
                        <td width="10%">:</td>
                        <td width="45%">{{$curr->sign}}{{number_format($order->pay_amount,3)}}</td>
                    </tr>
                    </tbody>
                </table>
              </div>
          </div>
        </div>
      </div>
    </div>
     
      <div class="row">
        <div class="col-md-12 col-xs-12 product_table">
           <div class="panel panel-default">
            <div class="panel-heading"><h5>{{ __('messages.product_ordered') }}</h5></div>
            <div class="panel-body">
              <div class="table-responsive">
                  <table class="woocommerce-table woocommerce-table--order-details shop_table order_details table table-bordered">
                                                          <tr>
                                                            <th>#</th>
                                                            <th>{{ __('messages.sku') }}</th>
                                                            <th>Variation</th>
                                                            <th>{{ __('messages.product_name') }}</th>
                                                            <th>{{ __('messages.quantity') }}</th>
                                                            <th>{{ __('messages.price') }}</th>
                                                            <th>{{ __('messages.total_price') }}</th>
                                                          </tr>
                                                          <?php 
                                                                $total_price = 0;
                                                                $index = 1;
                                                                foreach($cart->items as $key=>$product):?>
                                                                <?php  $price = getVariationPrice($product['item']['id']);
                                                                  $total_price += $price*$product['qty'];
                                                                  ?>
                                                          <tr>
                                                            <td>{{$index}}</td>
                                                            
                                                            <td>{{$product['item']['sku']}}</td>
                                                            
                                                            <td> @if(isset($product['variations']['Size']))
                            
                            Size :- {{$product['variations']['Size']}} /
                            @endif
                            
                             @if(isset($product['variations']['Size']))
                            
                            Color :- {{$product['variations']['Color']}} /
                            @endif
                            
                             @if(isset($product['variations']['SKU']))
                            
                            SKU :- {{$product['variations']['SKU']}}
                            @endif</td>
                                                            
                                                            <td>{{strlen($product['item']['name']) > 25 ? substr($product['item']['name'],0,25).'...' : $product['item']['name']}}
                                                              </td>
                                                            <td>{{$product['qty']}}</td>
                                                            <td>{{$curr->sign}} {{number_format($price,3)}}</td>
                                                            <td>{{$curr->sign}} {{number_format($price*$product['qty'],3)}}</td>
                                                            
                                                          </tr>
                                                        <?php $index++;endforeach;?>
                                                        <td colspan="6" class="text-right">{{ __('messages.subtotal') }}</td><td>{{$order->currency_sign}}{{number_format($total_price * $order->currency_value,3)}}</td>
                                                        <?php if(!empty($order->shipping_cost)):?>
                                                        <tr>
                                                          <td colspan="6" class="text-right">{{ __('messages.shipping_charge') }}</td><td>{{$curr->sign}} {{number_format($order->shipping_cost,3)}}</td>
                                                        </tr>
                                                        <?php endif;?>
                                                        <tr>
                                                          <td colspan="6" class="text-right">{{ __('messages.total') }}</td><td>{{$order->currency_sign}}{{number_format($order->pay_amount,3)}}</td>
                                                        </tr>
                                                        </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    
</section>

@endsection