@extends('layouts.front')
@section('body_class', 'page home page-template-default')
@section('content')

<div class="col-full">
    <div class="row">
        <nav class="woocommerce-breadcrumb">
            <a href="<?= URL('/')?>">{{ __('messages.home') }}</a>
            <span class="delimiter">
                <i class="tm tm-breadcrumbs-arrow-right"></i>
            </span>
            {{ __('messages.contact') }}
        </nav>
        <!-- .woocommerce-breadcrumb -->
        <div id="primary" class="content-area">
            <main id="main" class="site-main">
                <div class="type-page hentry">
                    <div class="entry-content">
                        <div class="stretch-full-width-map">
                            <iframe height="514" allowfullscreen="" style="border:0" src="https://www.google.com/maps/embed/v1/place?q=place_id:ChIJ1dCD77uazz8R1UJlOlqPgnk&key=AIzaSyCKsM6pvyJR7rTtlkPeIpauaPjWCgPvqM8"></iframe>
                        </div>
                        <!-- .stretch-full-width-map -->
                        <div class="row contact-info">
                            @if(session()->has('success'))
                                        <div class="alert alert-success">
                                            {{ session()->get('success') }}
                                        </div>
                                    @endif
                            <div class="col-md-9 left-col">
                                <div class="text-block">
                                    <h2 class="contact-page-title">{{ __('messages.leave_message') }}</h2>
<!--                                    <p>Maecenas dolor elit, semper a sem sed, pulvinar molestie lacus. Aliquam dignissim, elit non mattis ultrices,
                                        <br> neque odio ultricies tellus, eu porttitor nisl ipsum eu massa.</p>-->
                                </div>
                                <div class="contact-form">
                                    <div role="form" class="wpcf7" id="wpcf7-f425-o1" lang="en-US" dir="ltr">
                                        <div class="screen-reader-response"></div>
                                        <form class="wpcf7-form" novalidate="novalidate" id="contact-form" method="post" action="{{ route('front.contact.submit') }}">
                                            <input name="_token" type="hidden" value="{{ csrf_token() }}"/>
                                            <div style="display: none;">
                                                <input type="hidden" name="_wpcf7" value="425" />
                                                <input type="hidden" name="_wpcf7_version" value="4.5.1" />
                                                <input type="hidden" name="_wpcf7_locale" value="en_US" />
                                                <input type="hidden" name="_wpcf7_unit_tag" value="wpcf7-f425-o1" />
                                                <input type="hidden" name="_wpnonce" value="e6363d91dd" />
                                            </div>
                                            <div class="form-group row">
                                                <div class="col-xs-12 col-md-6">
                                                    <label>{{ __('messages.first_name') }}
                                                        <abbr title="required" class="required">*</abbr>
                                                    </label>
                                                    <br>
                                                    <span class="wpcf7-form-control-wrap first-name">
                                                        <input type="text" aria-invalid="false" aria-required="true" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required input-text" name="first_name" size="40" value="" name="first-name">
                                                    </span>
                                                </div>
                                                <!-- .col -->
                                                <div class="col-xs-12 col-md-6">
                                                    <label>{{ __('messages.last_name') }}
                                                        <abbr title="required" class="required">*</abbr>
                                                    </label>
                                                    <br>
                                                    <span class="wpcf7-form-control-wrap last-name">
                                                        <input type="text" aria-invalid="false" aria-required="true" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required input-text" name="last_name" size="40" value="" name="last-name">
                                                    </span>
                                                </div>
                                                <!-- .col -->
                                            </div>
                                            <div class="form-group row">
                                                <div class="col-xs-12 col-md-6">
                                                    <label>{{ __('messages.email') }}
                                                        <abbr title="required" class="required">*</abbr>
                                                    </label>
                                                    <br>
                                                    <span class="wpcf7-form-control-wrap first-name">
                                                        <input type="email" aria-invalid="false" aria-required="true" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required input-text" size="40" value="" name="email">
                                                    </span>
                                                </div>
                                                <!-- .col -->
                                                <div class="col-xs-12 col-md-6">
                                                    <label>{{ __('messages.phone') }}
                                                        <abbr title="required" class="required">*</abbr>
                                                    </label>
                                                    <br>
                                                    <span class="wpcf7-form-control-wrap last-name">
                                                        <input type="text" aria-invalid="false" aria-required="true" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required input-text" size="40" value="" name="phonenumber">
                                                    </span>
                                                </div>
                                                <!-- .col -->
                                            </div>
                                            <!-- .form-group -->
                                            <div class="form-group">
                                                <label>{{ __('messages.subject') }} <abbr title="required" class="required">*</abbr></label>
                                                <br>
                                                <span class="wpcf7-form-control-wrap subject">
                                                    <input type="text" aria-invalid="false" class="wpcf7-form-control wpcf7-text input-text" size="40" value="" name="subject">
                                                </span>
                                            </div>
                                            <!-- .form-group -->
                                            <div class="form-group">
                                                <label>{{ __('messages.your_message') }} <abbr title="required" class="required">*</abbr></label>
                                                <br>
                                                <span class="wpcf7-form-control-wrap your-message">
                                                    <textarea aria-invalid="false" class="wpcf7-form-control wpcf7-textarea" rows="10" cols="40" name="message"></textarea>
                                                </span>
                                            </div>
                                            <!-- .form-group-->
                                            <div class="form-group clearfix">
                                                <p>
                                                    <input type="submit" value="{{ __('messages.send_message') }}" class="wpcf7-form-control wpcf7-submit" />
                                                </p>
                                            </div>
                                            <!-- .form-group-->
                                            <div class="wpcf7-response-output wpcf7-display-none"></div>
                                        </form>
                                        <!-- .wpcf7-form -->
                                    </div>
                                    <!-- .wpcf7 -->
                                </div>
                                <!-- .contact-form7 -->
                            </div>
                            <!-- .col -->
                            <div class="col-md-3 store-info">
                                <div class="text-block">
                                    <h2 class="contact-page-title">{{ __('messages.our_store') }}</h2>
                                    <address>
                                        <p class="m-b-2">{{ __('messages.shuwaikh_branch') }}</p><p class="m-b-2"><a href="https://goo.gl/maps/XcJc28jFX44ZKJXf8">https://goo.gl/maps/XcJc28jFX44ZKJXf8</a></p><br/>
                                        <p class="m-b-2">{{ __('messages.sharq_branch') }}</p><p class="m-b-2"><a href="https://goo.gl/maps/CscGE7SzYfhUwrQ19 ">https://goo.gl/maps/CscGE7SzYfhUwrQ19</a></p>
                                    </address>
                                    <h3>{{ __('messages.opetation_hour') }}</h3>
                                    <ul class="list-unstyled operation-hours inner-right-md">
                                        <li class="clearfix">
                                            <span class="day">{{ __('messages.sat_to_thu') }}: (8.30 A.M - 12.30 P.M) & (4.30 P.M - 8.30 P.M)</span>
                                            <!--<span class="pull-right flip hours">12-6 PM</span>-->
                                        </li>
                                       <!-- <li class="clearfix">
                                            <span class="day">Tuesday:</span>
                                            <span class="pull-right flip hours">12-6 PM</span>
                                        </li>
                                        <li class="clearfix">
                                            <span class="day">Wednesday:</span>
                                            <span class="pull-right flip hours">12-6 PM</span>
                                        </li>
                                        <li class="clearfix">
                                            <span class="day">Thursday:</span>
                                            <span class="pull-right flip hours">12-6 PM</span>
                                        </li>
                                        <li class="clearfix">
                                            <span class="day">Friday:</span>
                                            <span class="pull-right flip hours">12-6 PM</span>
                                        </li>
                                        <li class="clearfix">
                                            <span class="day">Saturday:</span>
                                            <span class="pull-right flip hours">12-6 PM</span>
                                        </li>
                                        <li class="clearfix">
                                            <span class="day">Sunday</span>
                                            <span class="pull-right flip hours">Closed</span>
                                        </li>-->
                                    </ul>
                                    <h3>{{ __('messages.career') }}</h3>
                                    <p class="inner-right-md">{{ __('messages.email_us') }} <a href="mailto:info@marafiegroup.com">info@marafiegroup.com</a></p>
                                </div>
                                <!-- .text-block -->
                            </div>
                            <!-- .col -->
                        </div>
                        <!-- .contact-info -->
                    </div>
                    <!-- .entry-content -->
                </div>
                <!-- .hentry -->
            </main>
            <!-- #main -->
        </div>
        <!-- #primary -->
    </div>
    <!-- .row -->
</div>

@endsection