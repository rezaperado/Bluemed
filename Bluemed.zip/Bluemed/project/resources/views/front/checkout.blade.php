@extends('layouts.front')
@section('body_class', 'page home page-template-default')
@section('content')
<div class="col-full">
    <div class="row">
        <nav class="woocommerce-breadcrumb">
            <a href="<?= URL('/')?>">{{ __('messages.home') }}</a>
            <span class="delimiter">
                <i class="tm tm-breadcrumbs-arrow-right"></i>
            </span>
            {{ __('messages.checkout') }}
        </nav>
        <!-- .woocommerce-breadcrumb -->
        <div class="content-area checkout-container" id="primary">
            <main class="site-main" id="main">
                <div class="type-page hentry">
                    <div class="entry-content">
                        <div class="woocommerce">

                        	<?php if (!Auth::user()):?>
                            <div class="woocommerce-info">{{ __('messages.return_customer') }} <a data-toggle="collapse" href="#login-form" aria-expanded="false" aria-controls="login-form" class="showlogin">{{ __('messages.click_here_to_signin') }}</a>
                            </div>
	                        <?php endif;?>
                            <div class="order-error alert alert-danger w-50" style="display: none;">
                                        
                                </div>
                            <div <?= count($errors->all())?> class="<?= (session()->has('error')) ? 'collapse show' : 'collapse'?>" id="login-form">
                            	@if(session()->has('success'))
                                        <div class="alert alert-success">
                                            {{ session()->get('success') }}
                                        </div>
                                @endif
                                @if(session()->has('error'))
                                    <div class="alert alert-danger w-50">
                                        {{ session()->get('error') }}
                                    </div>
                                @endif
                                @if ($errors->any())
                                    <div class="alert alert-danger w-50">
                                        <ul class="mr-b-0">
                                            @foreach ($errors->all() as $error)
                                                <li>{{ $error }}</li>
                                            @endforeach
                                        </ul>
                                    </div>
                                @endif
                                
                                <form method="post" class="woocomerce-form woocommerce-form-login login" id="checkout-login-form" action="{{ route('user.login.submit') }}">
                                	{{ csrf_field() }}
                                    <p>{{ __('messages.account_exist') }}</p>
                                    <p class="form-row form-row-first">
                                        <label for="username">{{ __('messages.email') }}
                                            <span class="required">*</span>
                                        </label>
                                        <input type="text" id="email" name="email" class="input-text">
                                    </p>
                                    <p class="form-row form-row-last">
                                        <label for="password">{{ __('messages.password') }}
                                            <span class="required">*</span>
                                        </label>
                                        <input type="password" id="password" name="password" class="input-text">
                                    </p>
                                    <div class="clear"></div>
                                    <p class="form-row">
                                        <input type="submit" value="{{ __('messages.login') }}" name="login" class="button">
                                        <label class="woocommerce-form__label woocommerce-form__label-for-checkbox inline checkout-remember">
                                            <input type="checkbox" value="forever" id="rememberme" name="rememberme" class="woocommerce-form__input woocommerce-form__input-checkbox">
                                            <span>{{ __('messages.remember_me') }}</span>
                                        </label>
                                    </p>
                                    <p class="lost_password">
                                        <a href="{{ route('user-forgot') }}">{{ __('messages.lost_password') }}</a>
                                    </p>
                                    <div class="clear"></div>
                                </form>
                            </div>
                            <!-- .collapse -->
                            <div class="woocommerce-info">{{ __('messages.have_coupon_code') }} <a data-toggle="collapse" href="#checkoutCouponForm" aria-expanded="false" aria-controls="checkoutCouponForm" class="showlogin">{{ __('messages.click_here_add_coupon') }}</a>
                            </div>
                            <div class="collapse" id="checkoutCouponForm">
                                <form method="post" class="checkout_coupon">
                                    {{ csrf_field() }}
                                    <input type="hidden" id="grand_total" name="grand_total">
                                    <p class="form-row form-row-first">
                                        <input type="text" value="" id="coupon_code" placeholder="{{ __('messages.coupon_code') }}" class="input-text" name="coupon_code">
                                        <label class="error coupon-error"></label>
                                    </p>
                                    <p class="form-row form-row-last">
                                        <button type="button" id="btn-apply-coupon" class="button">{{ __('messages.apply_coupon') }}</button>
                                    </p>
                                    <div class="clear"></div>
                                </form>
                            </div>
                            <!-- .collapse -->
                            <form action="<?php echo URL('/cashondelivery')?>" class="checkout woocommerce-checkout" method="post" name="checkout" id="checkout-form">
                            	{{ csrf_field() }}
                                <div id="customer_details" class="col2-set">
                                    <div class="col-1">
                                        <div class="woocommerce-billing-fields">
                                            <h3>{{ __('messages.billing_details') }}</h3>
                                            <div class="woocommerce-billing-fields__field-wrapper-outer">
                                                <div class="woocommerce-billing-fields__field-wrapper">
                                                    <p id="billing_first_name_field" class="form-row form-row-first validate-required">
                                                        <label class="" for="billing_first_name">{{ __('messages.first_name') }}
                                                            <abbr title="required" class="required">*</abbr>
                                                        </label>
                                                        <input type="text" value="<?= isset($user->first_name) ? $user->first_name : ''?>" placeholder="" id="billing_first_name" name="billing_first_name" class="input-text ">
                                                    </p>
                                                    <p id="billing_last_name_field" class="form-row form-row-last validate-required">
                                                        <label class="" for="billing_last_name">{{ __('messages.last_name') }}
                                                            <abbr title="required" class="required">*</abbr>
                                                        </label>
                                                        <input type="text" value="<?= isset($user->last_name) ? $user->last_name : ''?>" placeholder="" id="billing_last_name" name="billing_last_name" class="input-text ">
                                                    </p>
                                                    <p id="billing_first_name_field" class="form-row form-row-first validate-required">
                                                        <label class="" for="billing_area">{{ __('messages.area') }}
                                                            <abbr title="required" class="required">*</abbr>
                                                        </label>
                                                        <input type="text" value="<?= isset($user->area) ? $user->area : ''?>" placeholder="" id="billing_area" name="billing_area" class="input-text ">
                                                    </p>
                                                    <p id="billing_last_name_field" class="form-row form-row-last ">
                                                        <label class="" for="billing_block">{{ __('messages.block') }}
                                                            <abbr title="required" class="required">*</abbr>
                                                        </label>
                                                        <input type="text" value="<?= isset($user->block) ? $user->block : ''?>" placeholder="" id="billing_block" name="billing_block" class="input-text ">
                                                    </p>
                                                    <p id="billing_last_name_field" class="form-row form-row-last ">
                                                        <label class="" for="billing_street">{{ __('messages.street') }}
                                                            <abbr title="required" class="required">*</abbr>
                                                        </label>
                                                        <input type="text" value="<?= isset($user->street) ? $user->street : ''?>" placeholder="" id="billing_street" name="billing_street" class="input-text ">
                                                    </p>
                                                    <p id="billing_first_name_field" class="form-row form-row-first validate-required">
                                                        <label class="" for="billing_city">{{ __('messages.city') }}
                                                            <abbr title="required" class="required">*</abbr>
                                                        </label>
                                                        <input type="text" value="<?= isset($user->city) ? $user->city : ''?>" placeholder="" id="billing_city" name="billing_city" class="input-text ">
                                                    </p>
                                                    <p id="billing_last_name_field" class="form-row form-row-last ">
                                                        <label class="" for="billing_zip">{{ __('messages.zip') }}
                                                            <abbr title="required" class="required">*</abbr>
                                                        </label>
                                                        <input type="text" value="<?= isset($user->zip) ? $user->zip : ''?>" placeholder="" id="billing_zip" name="billing_zip" class="input-text ">
                                                    </p>
                                                    <p id="billing_first_name_field" class="form-row form-row-first validate-required">
                                                        <label class="" for="billing_country">{{ __('messages.country') }}
                                                            <abbr title="required" class="required">*</abbr>
                                                        </label>
                                                        <?php $countries = code_to_country();?>
                                                        <select autocomplete="country" class="country_to_state country_select select2-hidden-accessible" id="billing_country" name="billing_country" tabindex="-1" aria-hidden="true">
                                                            <option value="">{{ __('messages.select_country') }}</option>
                                                            <?php $user_country = isset($user->country) ? $user->country : '';?>
                                                            <?php foreach($countries as $key=>$val):?>
                                                            	<option value="{{$key}}" <?= ($key == $user_country) ? 'selected' : ''?>>{{$val}}</option>
                                                            <?php endforeach;?>
                                                        </select>
                                                    </p>
                                                    <div class="clear"></div>
                                                    <p id="billing_phone_field" class="form-row form-row-last validate-required validate-phone">
                                                        <label class="" for="billing_phone">{{ __('messages.phone') }}
                                                            <abbr title="required" class="required">*</abbr>
                                                        </label>
                                                        <input type="tel" value="<?= isset($user->phone) ? $user->phone : ''?>" placeholder="" id="billing_phone" name="billing_phone" class="input-text ">
                                                    </p>
                                                    <p id="billing_email_field" class="form-row form-row-first validate-required validate-email">
                                                        <label class="" for="billing_email">{{ __('messages.email_address') }}
                                                            <abbr title="required" class="required">*</abbr>
                                                        </label>
                                                        <input type="email" value="<?= isset($user->email) ? $user->email : ''?>" placeholder="" id="billing_email" name="billing_email" class="input-text ">
                                                    </p>
                                                </div>
                                            </div>
                                            <!-- .woocommerce-billing-fields__field-wrapper-outer -->
                                        </div>
                                        <!-- .woocommerce-billing-fields -->
                                        <?php if(empty($user)):?>
                                        <div class="woocommerce-account-fields">
                                            <p class="form-row form-row-wide woocommerce-validated">
                                                <label class="collapsed woocommerce-form__label woocommerce-form__label-for-checkbox checkbox" data-toggle="collapse" data-target="#createLogin" aria-controls="createLogin">
                                                    <input type="checkbox" value="1" name="createaccount" class="woocommerce-form__input woocommerce-form__input-checkbox input-checkbox">
                                                    <span>{{ __('messages.create_account') }}</span>
                                                </label>
                                            </p>
                                            <div class="create-account collapse" id="createLogin">
                                                <p data-priority="" id="account_password_field" class="form-row validate-required woocommerce-invalid woocommerce-invalid-required-field">
                                                    <label class="" for="account_password">{{ __('messages.account_password') }}
                                                        <abbr title="required" class="required">*</abbr>
                                                    </label>
                                                    <input type="password" value="" placeholder="{{ __('messages.password') }}" id="account_password" name="account_password" class="input-text ">
                                                </p>
                                                <div class="clear"></div>
                                            </div>
                                        </div>
                                        <?php endif;?>
                                        <!-- .woocommerce-account-fields -->
                                    </div>
                                    <!-- .col-1 -->
                                    <div class="col-2">
                                        <div class="woocommerce-shipping-fields">
                                            <h3 id="ship-to-different-address">
                                                <label class="collapsed woocommerce-form__label woocommerce-form__label-for-checkbox checkbox" data-toggle="collapse" data-target="#shipping-address" aria-controls="shipping-address">
                                                    <input id="ship-to-different-address-checkbox" class="woocommerce-form__input woocommerce-form__input-checkbox input-checkbox" type="checkbox" value="1" name="ship_to_different_address">
                                                    <span>{{ __('messages.ship_to_diff_address') }}</span>
                                                </label>
                                            </h3>
                                            <div class="shipping_address collapse" id="shipping-address">
                                                <div class="woocommerce-shipping-fields__field-wrapper">
                                                    <p id="billing_first_name_field" class="form-row form-row-first validate-required">
                                                        <label class="" for="shipping_first_name">{{ __('messages.first_name') }}
                                                            <abbr title="required" class="required">*</abbr>
                                                        </label>
                                                        <input type="text" value="<?= isset($user->shipping_first_name) ? $user->shipping_first_name : ''?>" placeholder="" id="shipping_first_name" name="shipping_first_name" class="input-text ">
                                                    </p>
                                                    <p id="billing_last_name_field" class="form-row form-row-last validate-required">
                                                        <label class="" for="shipping_last_name">{{ __('messages.last_name') }}
                                                            <abbr title="required" class="required">*</abbr>
                                                        </label>
                                                        <input type="text" value="<?= isset($user->shipping_last_name) ? $user->shipping_last_name : ''?>" placeholder="" id="shipping_last_name" name="shipping_last_name" class="input-text ">
                                                    </p>
                                                    <p id="billing_first_name_field" class="form-row form-row-first validate-required">
                                                        <label class="" for="shipping_area">{{ __('messages.area') }}
                                                            <abbr title="required" class="required">*</abbr>
                                                        </label>
                                                        <input type="text" value="<?= isset($user->shipping_area) ? $user->shipping_area : ''?>" placeholder="" id="shipping_area" name="shipping_area" class="input-text ">
                                                    </p>
                                                    <p id="billing_last_name_field" class="form-row form-row-last ">
                                                        <label class="" for="shipping_block">{{ __('messages.block') }}
                                                            <abbr title="required" class="required">*</abbr>
                                                        </label>
                                                        <input type="text" value="<?= isset($user->shipping_block) ? $user->shipping_block : ''?>" placeholder="" id="shipping_block" name="shipping_block" class="input-text ">
                                                    </p>
                                                    <p id="billing_last_name_field" class="form-row form-row-last ">
                                                        <label class="" for="shipping_street">{{ __('messages.street') }}
                                                            <abbr title="required" class="required">*</abbr>
                                                        </label>
                                                        <input type="text" value="<?= isset($user->shipping_street) ? $user->shipping_street : ''?>" placeholder="" id="shipping_street" name="shipping_street" class="input-text ">
                                                    </p>
                                                    <p id="billing_first_name_field" class="form-row form-row-first validate-required">
                                                        <label class="" for="shipping_city">{{ __('messages.city') }}
                                                            <abbr title="required" class="required">*</abbr>
                                                        </label>
                                                        <input type="text" value="<?= isset($user->shipping_city) ? $user->shipping_city : ''?>" placeholder="" id="shipping_city" name="shipping_city" class="input-text ">
                                                    </p>
                                                    <p id="billing_last_name_field" class="form-row form-row-last ">
                                                        <label class="" for="shipping_zip">{{ __('messages.zip') }}
                                                            <abbr title="required" class="required">*</abbr>
                                                        </label>
                                                        <input type="text" value="<?= isset($user->shipping_zip) ? $user->shipping_zip : ''?>" placeholder="" id="shipping_zip" name="shipping_zip" class="input-text ">
                                                    </p>
                                                    <p id="billing_first_name_field" class="form-row form-row-first validate-required">
                                                        <label class="" for="shipping_country">{{ __('messages.country') }}
                                                            <abbr title="required" class="required">*</abbr>
                                                        </label>
                                                        <?php $countries = code_to_country();?>
                                                        <select autocomplete="country" class="country_to_state country_select select2-hidden-accessible" id="shipping_country" name="shipping_country" tabindex="-1" aria-hidden="true">
                                                            <option value="">{{ __('messages.select_country') }}</option>
                                                            <?php $user_country = isset($user->shipping_country) ? $user->shipping_country : '';?>
                                                            <?php foreach($countries as $key=>$val):?>
                                                            	<option value="{{$key}}" <?= ($key== $user_country)?>>{{$val}}</option>
                                                            <?php endforeach;?>
                                                        </select>
                                                    </p>
                                                    <div class="clear"></div>
                                                    <p id="billing_phone_field" class="form-row form-row-last validate-required validate-phone">
                                                        <label class="" for="shipping_phone">{{ __('messages.phone') }}
                                                            <abbr title="required" class="required">*</abbr>
                                                        </label>
                                                        <input type="tel" value="<?= isset($user->shipping_phone) ? $user->shipping_phone : ''?>" placeholder="" id="shipping_phone" name="shipping_phone" class="input-text ">
                                                    </p>
                                                    <p id="shipping_email_field" class="form-row form-row-first validate-required validate-email">
                                                        <label class="" for="billing_email">{{ __('messages.email_address') }}
                                                            <abbr title="required" class="required">*</abbr>
                                                        </label>
                                                        <input type="email" value="<?= isset($user->shipping_email) ? $user->shipping_email : ''?>" placeholder="" id="shipping_email" name="shipping_email" class="input-text ">
                                                    </p>
                                                </div>
                                                <!-- .woocommerce-shipping-fields__field-wrapper -->
                                            </div>
                                            <!-- .shipping_address -->
                                        </div>
                                        <!-- .woocommerce-shipping-fields -->
                                        <div class="woocommerce-additional-fields">
                                            <div class="woocommerce-additional-fields__field-wrapper">
                                                <p id="order_comments_field" class="form-row notes">
                                                    <label class="" for="order_comments">{{ __('messages.order_notes') }}</label>
                                                    <textarea cols="5" rows="2" placeholder="{{ __('messages.order_notes_text') }}" id="order_comments" class="input-text " name="order_comments"></textarea>
                                                </p>
                                            </div>
                                            <!--
                                            <div class="woocommerce-additional-fields__field-wrapper">
                                                <p id="delivery_time_field" class="form-row notes">
                                                    <label class="" for="delivery_time">{{ __('messages.delivery_time') }}</label>
                                                    <select class="country_to_state country_select select2-hidden-accessible" name="delivery_time">
                                                        <option value=''>Select</option>
                                                        <?php foreach($deliveryTime as $time):?>
                                                        <option value="<?= $time->time?>"><?= $time->time?></option>
                                                        <?php endforeach;?>
                                                    </select>
                                                </p>
                                            </div>
                                            <! .woocommerce-additional-fields__field-wrapper-->
                                        </div>
                                        <!-- .woocommerce-additional-fields -->
                                    </div>
                                    <!-- .col-2 -->
                                </div>
                                <!-- .col2-set -->
                                <h3 id="order_review_heading">{{ __('messages.your_order') }}</h3>
                                <div class="woocommerce-checkout-review-order" id="order_review">
                                    <div class="order-review-wrapper">
                                        <h3 class="order_review_heading">{{ __('messages.your_order') }}</h3>
                                        <table class="shop_table woocommerce-checkout-review-order-table">
                                            <thead>
                                                <tr>
                                                    <th class="product-name">{{ __('messages.product') }}</th>
                                                    <th class="product-total">{{ __('messages.total') }}</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                            	<?php 
                                                /*echo "<pre>";
                                                print_r(Session::get('cart'));exit;*/
                                                if(!empty(Session::get('cart'))):?>
                                            		<?php $sub_total = 0;?>
                                            		@foreach(Session::get('cart')->items as $product)
                                            		<?php
                                                        $total_cost = (float)$product['unit_price'] * (int)$product['qty'];
                                                        $sub_total+= $total_cost;
                                                        //echo "<pre>";
                                                        //print_r($product);exit;
                                                        ?>
                                            		<tr class="cart_item">
	                                                    <td class="product-name">
	                                                        <strong class="product-quantity">{{$product['qty']}} ×</strong>
	                                                        <?php if(app()->getLocale() == 'ar'):?>
                                                                {{$product['item']->name_ar}}
                                                            <?php else:?>
                                                                {{$product['item']->name}}
                                                            <?php endif;?>
	                                                    </td>
	                                                    <td class="product-total">
	                                                        <span class="woocommerce-Price-amount amount">
	                                                            <span class="woocommerce-Price-currencySymbol">{{$curr->sign}}</span><span class="total_price">{{number_format($total_cost,3)}}</span></span>
                                                                
	                                                    </td>
	                                                </tr>
	                                                @endforeach
                                            	<?php endif;?>
                                            </tbody>
                                            <tfoot>
                                                <?php
                                                 if(!empty($shipping_data) && isset($shipping_data[0])):?>
                                            	<tr class="cart-subtotal">
                                                    <th>{{$shipping_data[0]->title}}</th>
                                                    <td data-title="Shipping"><span class="woocommerce-Price-amount amount">
                                                            <span class="woocommerce-Price-currencySymbol">{{$curr->sign}}</span>{{number_format($shipping_data[0]->price,3)}}</span></td>
                                                    <input type="hidden" name="shipping" value="{{$shipping_data[0]->title}}">
                                                    <input type="hidden" id="shipping_cost" name="shipping_cost" value="{{number_format($shipping_data[0]->price,3)}}">
                                                </tr>
                                                <?php endif;?>
                                                <!--tr class="cart-subtotal">
                                                    <th>{{ __('messages.tax') }}</th>
                                                    <?php $tax = ($sub_total / 100) * $tx;?>
                                                    <td data-title="Shipping"><span class="woocommerce-Price-amount amount">
                                                            <span class="woocommerce-Price-currencySymbol">{{$curr->sign}}</span>{{number_format($tax,3)}}</span></td>
                                                    <input type="hidden" name="tax" id="tax" value="{{number_format($tax,3)}}">
                                                </tr>
                                                <tr class="cart-subtotal">
                                                    <th>{{ __('messages.subtotal') }}</th>
                                                    <td>
                                                        <span class="woocommerce-Price-amount amount">
                                                            <span class="woocommerce-Price-currencySymbol">{{$curr->sign}}</span>{{number_format($sub_total,3)}}</span>
                                                    </td>
                                                </tr-->
                                                <tr class="cart-subtotal discount-row" style="<?= (Session::has('coupon') && !empty(Session::has('coupon'))) ? '' : 'display:none;'?>">
                                                    <th>{{ __('messages.discount') }}</th>
                                                    <td>
                                                        <span class="woocommerce-Price-amount amount">
                                                            -<span class="woocommerce-Price-currencySymbol">{{$curr->sign}}</span><span id="discount">{{number_format(Session::get('coupon'),3) }}</span></span>
                                                            <input type="hidden" id="couponcode" name="coupon_code" value="{{Session::get('coupon_code')}}">
                                                            <input type="hidden" id="coupon_discount" name="coupon_discount" value="{{number_format(Session::get('coupon'),3) }}">
                                                    </td>
                                                </tr>
                                                <tr class="order-total">
                                                    <th>{{ __('messages.total') }}</th>
                                                    <?php 
                                                    $shipping_charge = 0;
                                                    if(!empty($shipping_data) && isset($shipping_data[0]))
                                                    {
                                                        $shipping_charge = isset($shipping_data[0]->price) ? $shipping_data[0]->price : 0;    
                                                    }
                                                   // $grand_total = $sub_total+$tax+$shipping_charge; 
                                                    $grand_total = $sub_total+$shipping_charge;
                                                    if(!empty(Session::get('coupon')))
                                                    {
                                                        $grand_total = $grand_total - Session::get('coupon');
                                                    }
                                                    ?>
                                                    <td>
                                                        <strong>
                                                            <span class="woocommerce-Price-amount amount">
                                                                <span class="woocommerce-Price-currencySymbol">{{$curr->sign}}</span>
                                                                <span class="grand_total">{{number_format($grand_total,3)}}</span>
                                                                <input id="total_amount" type="hidden" value="{{number_format($grand_total,3)}}">
                                                        </strong>
                                                    </td>
                                                </tr>
                                            </tfoot>
                                        </table>
                                        <!-- /.woocommerce-checkout-review-order-table -->
                                        <div class="woocommerce-checkout-payment" id="payment">
                                            <ul class="wc_payment_methods payment_methods methods">
                                            	@if(isset($gs->cod_check) && $gs->cod_check == 1)
                                            	@if($digital == 0)
                                            <li class="wc_payment_method payment_method_cod">
                                                    <input type="radio" data-order_button_text="" value="CASH" name="payment_method" class="input-radio" id="payment_method_cod">
                                                    <label for="payment_method_cod">CASH </label>
                                                    
                                                </li> 
                                                @endif
												@endif
                                                
                                                <li class="wc_payment_method payment_method_cod">
                                                    <input type="radio" data-order_button_text="" value="KNET" name="payment_method" class="input-radio" id="payment_method_myfatoorah">
                                                    <label for="payment_method_myfatoorah">KNET </label>
                                                    
                                                </li>
                                            </ul>
                                            <div class="form-row place-order">
                                                <p class="form-row terms wc-terms-and-conditions woocommerce-validated">
                                                    <label class="woocommerce-form__label woocommerce-form__label-for-checkbox checkbox">
                                                        <input type="checkbox" id="terms" name="terms" class="woocommerce-form__input woocommerce-form__input-checkbox input-checkbox">
                                                        <span>{{ __('messages.read_the_term_condition') }} <a class="woocommerce-terms-and-conditions-link" href="#">{{ __('messages.terms_and_condition') }}</a></span>
                                                        <span class="required">*</span>
                                                    </label>
                                                    <input type="hidden" value="1" name="terms-field">
                                                </p>
                                                <button type="submit" id="btn-place-order" class="button wc-forward text-center">{{ __('messages.place_order') }}</a>
                                            </div>
                                        </div>
                                        <!-- /.woocommerce-checkout-payment -->
                                    </div>
                                    <!-- /.order-review-wrapper -->
                                </div>
                                <!-- .woocommerce-checkout-review-order -->
                            </form>
                            <!-- .woocommerce-checkout -->
                        </div>
                        <!-- .woocommerce -->
                    </div>
                    <!-- .entry-content -->
                </div>
                <!-- #post-## -->
            </main>
            <!-- #main -->
        </div>
        <!-- #primary -->
    </div>
    <!-- .row -->
</div>
<input type="hidden" id="cash_order" value="<?php echo URL('/cashondelivery')?>" />
<input type="hidden" id="place_order" value="<?php echo URL('/placeorder')?>" />
<input type="hidden" id="order_received" value="<?php echo URL('/orderreceived')?>" />
<input type="hidden" id="apply_coupon" value="<?php echo URL('/carts/coupon/check')?>" />
@endsection

@section('scripts')

<script type="text/javascript">
	
</script>

@endsection