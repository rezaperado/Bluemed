@extends('layouts.front')
@section('body_class', 'left-sidebar')
@section('content')
<?php 
use Illuminate\Support\Facades\Input;
?>
<div class="col-full">
    <div class="row">
        <nav class="woocommerce-breadcrumb">
            <a href="<?= URL('/')?>">{{ __('messages.home') }}</a>
            <span class="delimiter">
                <i class="tm tm-breadcrumbs-arrow-right"></i>
            </span>{{$cat->name}}
        </nav>
        <!-- .woocommerce-breadcrumb -->
        <div id="primary" class="content-area">
            <main id="main" class="site-main">
                <section class="section-product-categories">
                    <header class="section-header">
                        <h1 class="woocommerce-products-header__title page-title">{{$cat->name}}</h1>
                    </header>
                    <div class="woocommerce columns-5">
                        <div class="product-loop-categories">
                            <?php foreach($subcategory as $subcat):?>
                            <div class="product-category product ">
                                <a href="{{ route('front.subcat',['slug1' => $cat->slug, 'slug2' => $subcat->slug]) }}">
                                    <?php 
                                    $photo = (isset($subcat->photo) && !empty($subcat->photo)) ? $subcat->photo : 'default.png';
                                    ?>
                                    <img src="{{asset('assets/images/categories/'.$photo)}}" alt="{{$subcat->name}}}" width="224" height="197">
                                    <h2 class="woocommerce-loop-category__title">{{$subcat->name}}
                                        <mark class="count">(5)</mark>
                                    </h2>
                                </a>
                            </div>
                        <?php endforeach;?>
                        </div>
                        <!-- .product-loop-categories -->
                    </div>
                    <!-- .woocommerce -->
                </section>
                <!-- .section-product-categories -->
                <!-- .section-products-carousel -->
                
          
            <main id="main" class="site-main">
                <div class="shop-control-bar">
                    <div class="handheld-sidebar-toggle desktop-filter">
                        <button type="button" class="btn sidebar-toggler">
                            <i class="fa fa-sliders"></i>
                            <span>{{ __('messages.filteres') }}</span>
                        </button>
                    </div>
                    
                    <ul role="tablist" class="shop-view-switcher nav nav-tabs">
                        <li class="nav-item">
                            <a href="#grid" title="{{ __('messages.grid_view') }}" data-toggle="tab" class="nav-link <?= ($layout_type == 'grid') ? 'active' : ''?>">
                                <i class="tm tm-grid-small"></i>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="#grid-extended" title="{{ __('messages.grid_extended') }}" data-toggle="tab" class="nav-link <?= ($layout_type == 'grid-extended') ? 'active' : ''?>">
                                <i class="tm tm-grid"></i>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="#list-view-large" title="{{ __('messages.list_view_large') }}" data-toggle="tab" class="nav-link <?= ($layout_type == 'list-view-large') ? 'active' : ''?>">
                                <i class="tm tm-listing-large"></i>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="#list-view" title="{{ __('messages.list_view') }}" data-toggle="tab" class="nav-link <?= ($layout_type == 'list-view') ? 'active' : ''?>">
                                <i class="tm tm-listing"></i>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="#list-view-small" title="{{ __('messages.list_view_small') }}" data-toggle="tab" class="nav-link <?= ($layout_type == 'list-view-small') ? 'active' : ''?>">
                                <i class="tm tm-listing-small"></i>
                            </a>
                        </li>
                    </ul>
                    <!-- .shop-view-switcher -->
                    <form class="form-techmarket-wc-ppp" method="POST">
                        <select class="techmarket-wc-wppp-select c-select page_length" name="page_length">
                            <option value="20" <?= ($page_length == 20) ? 'selected' : ''?>>{{ __('messages.show') }} 20</option>
                            <option value="40" <?= ($page_length == 40) ? 'selected' : ''?>>{{ __('messages.show') }} 40</option>
                            <option value="all" <?= ($page_length == 'all') ? 'selected' : ''?>>{{ __('messages.show_all') }}</option>
                        </select>
                        <input type="hidden" value="5" name="shop_columns">
                        <input type="hidden" value="15" name="shop_per_page">
                        <input type="hidden" value="right-sidebar" name="shop_layout">
                    </form>
                    <!-- .form-techmarket-wc-ppp -->
                    <form method="get" class="woocommerce-ordering desktop-sorting">
                        <select class="orderby" name="sort" id="sort_by">
                            <option value="alphabet" <?= ($sort == 'alphabet') ? 'selected' : ''?>>{{ __('messages.sort_by_alphabet_asc') }}</option>
                            <option value="alphabet-desc" <?= ($sort == 'alphabet-desc') ? 'selected' : ''?>>{{ __('messages.sort_by_alphabet_desc') }}</option>
                            <option value="featured" <?= ($sort == 'featured') ? 'selected' : ''?>>{{ __('messages.sort_by_featured') }}</option>
                            <option value="promotional" <?= ($sort == 'promotional') ? 'selected' : ''?>>{{ __('messages.sort_by_promotional') }}</option>
                            <option value="popularity" <?= ($sort == 'popularity') ? 'selected' : ''?>>{{ __('messages.sort_by_popular') }}</option>
                            <option value="rating" <?= ($sort == 'rating') ? 'selected' : ''?>>{{ __('messages.sort_by_rating') }}</option>
                            <option value="date" <?= ($sort == 'date') ? 'selected' : ''?>>{{ __('messages.sort_by_new') }}</option>
                            <option value="price" <?= ($sort == 'price') ? 'selected' : ''?>>{{ __('messages.sort_by_price_low_to_high') }}</option>
                            <option value="price-desc" <?= ($sort == 'price-desc') ? 'selected' : ''?>>{{ __('messages.sort_by_price_high_to_low') }}</option>
                        </select>
                        <input type="hidden" value="5" name="shop_columns">
                        <input type="hidden" value="15" name="shop_per_page">
                        <input type="hidden" value="right-sidebar" name="shop_layout">
                    </form>
                    <!-- .woocommerce-ordering -->
                    <nav class="techmarket-advanced-pagination">
                        <form class="form-adv-pagination" method="post">
                            <input type="number" value="1" class="form-control" step="1" max="5" min="1" size="2" id="goto-page">
                        </form> of 5<a href="#" class="next page-numbers">→</a>
                    </nav>
                    <!-- .techmarket-advanced-pagination -->
                </div>
                <!-- .shop-control-bar -->
                <div class="tab-content">
                    <div id="grid" class="tab-pane <?= ($layout_type == 'grid') ? 'active' : ''?>" role="tabpanel">
                        <div class="mobile-filter-sorting handheld-only">
                            <div class="d-flex">
                                <div class="handheld-sidebar-toggle mobile-filter">
                                    <button type="button" class="btn sidebar-toggler">
                                        <i class="fa fa-sliders"></i>
                                        <span>{{ __('messages.filteres') }}</span>
                                    </button>
                                </div>
                                <form method="get" class="woocommerce-ordering">
                                    <select class="orderby" name="sort" id="sort_by">
                                        <option value="alphabet" <?= ($sort == 'alphabet') ? 'selected' : ''?>>{{ __('messages.sort_by_alphabet_asc') }}</option>
                                        <option value="alphabet-desc" <?= ($sort == 'alphabet-desc') ? 'selected' : ''?>>{{ __('messages.sort_by_alphabet_desc') }}</option>
                                        <option value="featured" <?= ($sort == 'featured') ? 'selected' : ''?>>{{ __('messages.sort_by_featured') }}</option>
                                        <option value="promotional" <?= ($sort == 'promotional') ? 'selected' : ''?>>{{ __('messages.sort_by_promotional') }}</option>
                                        <option value="popularity" <?= ($sort == 'popularity') ? 'selected' : ''?>>{{ __('messages.sort_by_popular') }}</option>
                                        <option value="rating" <?= ($sort == 'rating') ? 'selected' : ''?>>{{ __('messages.sort_by_rating') }}</option>
                                        <option value="date" <?= ($sort == 'date') ? 'selected' : ''?>>{{ __('messages.sort_by_new') }}</option>
                                        <option value="price" <?= ($sort == 'price') ? 'selected' : ''?>>{{ __('messages.sort_by_price_low_to_high') }}</option>
                                        <option value="price-desc" <?= ($sort == 'price-desc') ? 'selected' : ''?>>{{ __('messages.sort_by_price_high_to_low') }}</option>
                                    </select>
                                    <input type="hidden" value="5" name="shop_columns">
                                    <input type="hidden" value="15" name="shop_per_page">
                                    <input type="hidden" value="right-sidebar" name="shop_layout">
                                </form>
                            </div>
                        </div>
                        <div class="woocommerce columns-5">
                            <div class="products">
                                <?php if($cats->count() > 0):?>
                                <?php foreach($cats as $product):?>
                                    <?php
                                    $price = getVariationPrice($product->id);
                                    $variation = getVariation($product->id);

                                    $attr = isset($variation['attr']) ? $variation['attr'] : '';
                                    $total_stock = isset($variation['total_stock']) ? $variation['total_stock'] : 0;
                                    $attr_id = isset($variation['attr_id']) ? $variation['attr_id'] : 0;
                                    $stock = checkProductStock($product->sku);
                                    $wishlist = checkProductWishlist($product->id);
                                    ?>
                                    <div class="product first">
                                        <form class="variations_form cart" id="variations_form">
                                        <input type="hidden" name="product_price" id="hidden_price" value="{{$price}}">
                                        <input type="hidden" name="quantity" id="hidden_price" value="1">
                                        <input name="_token" type="hidden" value="{{ csrf_token() }}"/>
                                        <input type="hidden" value="{{$product->id}}" name="product_id">
                                        <input type="hidden" name="total_stock" id="total_stock" value="{{$total_stock}}">
                                        <input type="hidden" name="attr_id" id="attr_id" value="{{$attr_id}}">
                                        <?php if(!empty($attr)):?>
                                        <?php foreach($attr as $key=>$val):?>
                                            <input type="hidden" name="attr[<?= $key?>]" value="<?= $val?>">
                                        <?php endforeach;?>
                                        <?php endif;?>
                                        <div class="yith-wcwl-add-to-wishlist">
                                            <a rel="nofollow" class="pointer add_to_wishlist btn-add-wishlist <?= ($wishlist > 0) ? 'wishlist-added':''?>" data-id="{{$product->id}}"> Add to Wishlist</a>
                                        </div>
                                        <!-- .yith-wcwl-add-to-wishlist -->
                                        <a class="woocommerce-LoopProduct-link woocommerce-loop-product__link" href="{{ route('front.product', $product->id) }}">
                                            <?php $discount = $product->previous_price-$price;?>
                                            <?php if(isset($product->previous_price) && !empty($product->previous_price) && $discount > 0):?>
                                                <span class="onsale">
                                                    <span class="woocommerce-Price-amount amount">
                                                        <span class="woocommerce-Price-currencySymbol">
                                                            <?= $curr;?>
                                                        </span>
                                                        <?= number_format(((float)$product->previous_price - (float)$price) ,3);?>
                                                    </span>
                                                </span>
                                            <?php endif;?>
                                            <img width="224" height="197" alt="" class="attachment-shop_catalog size-shop_catalog wp-post-image" src="{{asset('assets/images/products/'.$product->photo)}}">
                                            <?php if(isset($product->previous_price) && !empty($product->previous_price)):?>
                                                <span class="price">
                                                    <ins>
                                                        <span class="woocommerce-Price-currencySymbol">{{$curr}}</span>
                                                        <span class="amount">{{number_format($price,3)}}</span>
                                                    </ins>
                                                    <del>
                                                        <span class="woocommerce-Price-currencySymbol">{{$curr}}</span>
                                                        <span class="amount">{{number_format($product->previous_price,3)}}</span>
                                                    </del>
                                                    <span class="amount"> </span>
                                                </span>
                                            <?php else:?>
                                                <span class="price">
                                                    <ins>
                                                        <span class="amount"> </span>
                                                    </ins>
                                                    <span class="woocommerce-Price-currencySymbol">{{$curr}}</span>
                                                    <span class="amount">{{number_format($price , 3)}}</span>
                                                </span>
                                            <?php endif;?>
                                            <h2 class="woocommerce-loop-product__title">
                                                <?php if(app()->getLocale() == 'ar'):?>
                                                    {{$product->name_ar}}
                                                <?php else:?>
                                                    {{$product->name}}
                                                <?php endif;?>
                                            </h2>
                                        </a>
                                        <!-- .woocommerce-LoopProduct-link -->
                                        <?php if($stock == 0):?>
                                        <p class="required">{{ __('messages.out_stock') }}</p>
                                        <?php endif;?>
                                        <div class="hover-area">
                                            <button class="button add_to_cart_button" type="button" <?= ($stock ==0) ? 'disabled' : ''?>>{{ __('messages.add_cart') }}</button>
                                            <a class="add-to-compare-link pointer btn-add-compare" data-id="{{$product->id}}">{{ __('messages.add_compare') }}</a>
                                        </div>
                                        </form>
                                        <!-- .hover-area -->
                                    </div>
                                <?php endforeach;?>
                                <?php else:?>
                                    <p class="no-prd"> {{ __('messages.no_products_available') }}</p>
                                <?php endif;?>
                            </div>
                            <!-- .products -->
                        </div>
                        <!-- .woocommerce -->
                    </div>
                    <!-- .tab-pane -->
                    <div id="grid-extended" class="tab-pane <?= ($layout_type == 'grid-extended') ? 'active' : ''?>" role="tabpanel">
                        <div class="woocommerce columns-5">
                            <div class="products">
                                <?php if($cats->count() > 0):?>
                                <?php foreach($cats as $product):?>
                                    <?php
                                    $price = getVariationPrice($product->id);
                                    $variation = getVariation($product->id);
                                    $attr = isset($variation['attr']) ? $variation['attr'] : '';
                                    $total_stock = isset($variation['total_stock']) ? $variation['total_stock'] : 0;
                                    $stock = checkProductStock($product->sku);
                                    $wishlist = checkProductWishlist($product->id);
                                    ?>
                                <div class="product">
                                    <form class="variations_form cart" id="variations_form">
                                        <input type="hidden" name="product_price" id="hidden_price" value="{{$price}}">
                                        <input type="hidden" name="quantity" id="hidden_price" value="1">
                                        <input name="_token" type="hidden" value="{{ csrf_token() }}"/>
                                        <input type="hidden" value="{{$product->id}}" name="product_id">
                                        <input type="hidden" name="total_stock" id="total_stock" value="{{$total_stock}}">
                                        <?php if(!empty($attr)):?>
                                        <?php foreach($attr as $key=>$val):?>
                                            <input type="hidden" name="attr[<?= $key?>]" value="<?= $val?>">
                                        <?php endforeach;?>
                                        <?php endif;?>
                                    <div class="yith-wcwl-add-to-wishlist">
                                        <a rel="nofollow" class="pointer add_to_wishlist btn-add-wishlist <?= ($wishlist > 0) ? 'wishlist-added':''?>" data-id="{{$product->id}}"> Add to Wishlist</a>
                                    </div>
                                    <!-- .yith-wcwl-add-to-wishlist -->
                                    <a class="woocommerce-LoopProduct-link woocommerce-loop-product__link" href="{{ route('front.product', $product->id) }}">
                                        <?php $discount = $product->previous_price-$price;?>
                                        <?php if(isset($product->previous_price) && !empty($product->previous_price) && $discount > 0):?>
                                            <span class="onsale">
                                                <span class="woocommerce-Price-amount amount">
                                                    <span class="woocommerce-Price-currencySymbol">{{$curr}}</span><?= number_format(((float)$product->previous_price - (float)$price) ,3);?>
                                                </span>
                                            </span>
                                        <?php endif;?>
                                        <img width="224" height="197" alt="" class="attachment-shop_catalog size-shop_catalog wp-post-image" src="{{asset('assets/images/products/'.$product->photo)}}">
                                        <?php if(isset($product->previous_price) && !empty($product->previous_price)):?>
                                            <span class="price">
                                                <ins>
                                                    <span class="woocommerce-Price-currencySymbol">{{$curr}}</span>
                                                    <span class="amount">{{number_format($price,3)}}</span>
                                                </ins>
                                                <?php if($price < $product->previous_price):?>
                                                <del>
                                                    <span class="amount">{{number_format($product->previous_price,3)}}</span>
                                                </del>
                                                <?php endif;?>
                                                <span class="amount"> </span>
                                            </span>
                                        <?php else:?>
                                            <span class="price">
                                                <ins>
                                                    <span class="amount"> </span>
                                                </ins>
                                                <span class="woocommerce-Price-currencySymbol">{{$curr}}</span>
                                                <span class="amount">{{number_format($price , 3)}}</span>
                                            </span>
                                        <?php endif;?>
                                        <h2 class="woocommerce-loop-product__title">
                                            <?php if(app()->getLocale() == 'ar'):?>
                                                {{$product->name_ar}}
                                            <?php else:?>
                                                {{$product->name}}
                                            <?php endif;?>
                                        </h2>
                                    </a>
                                    <!-- .woocommerce-LoopProduct-link -->
                                    <div class="techmarket-product-rating">
                                        <?php $average_rating = getAvgRating($product->id);
                                        $rating_count = getRatingCount($product->id);
                                        ?>
                                        <?php if($average_rating == 5):?>
                                        <div class="star-rating">
                                            <span style="width:100%">
                                                <strong class="rating">5.00</strong> out of 5</span>
                                        </div>
                                        <?php elseif($average_rating ==4):?>
                                        <div class="star-rating">
                                            <span style="width:80%">
                                                <strong class="rating">5.00</strong> out of 5</span>
                                        </div>
                                        <?php elseif($average_rating == 3):?>
                                        <div class="star-rating">
                                            <span style="width:60%">
                                                <strong class="rating">5.00</strong> out of 5</span>
                                        </div>
                                        <?php elseif($average_rating == 2):?>
                                        <div class="star-rating">
                                            <span style="width:40%">
                                                <strong class="rating">5.00</strong> out of 5</span>
                                        </div>
                                        <?php elseif($average_rating == 1):?>
                                        <div class="star-rating">
                                            <span style="width:10%">
                                                <strong class="rating">5.00</strong> out of 5</span>
                                        </div>
                                        <?php else:?>
                                                        <div class="star-rating">
                                                            <span style="width:0%">
                                                                <strong class="rating">5.00</strong> out of 5</span>
                                                        </div>
                                        <?php endif;?>
                                        <span class="review-count">({{$rating_count}})</span>
                                    </div>
                                    <!-- .techmarket-product-rating -->
                                    <span class="sku_wrapper">SKU:
                                        <span class="sku">{{$product->sku}}</span>
                                    </span>
                                    <div class="woocommerce-product-details__short-description">
                                        <?php echo htmlspecialchars_decode(stripslashes($product->product_info));?>
                                    </div>
                                    <!-- .woocommerce-product-details__short-description -->
                                    <?php if($stock == 0):?>
                                    <p class="required">{{ __('messages.out_stock') }}</p>
                                    <?php endif;?>
                                    <button class="button add_to_cart_button" type="button" <?= ($stock ==0) ? 'disabled' : ''?>>{{ __('messages.add_cart') }}</button>
                                    <a class="add-to-compare-link pointer btn-add-compare" data-id="{{$product->id}}">{{ __('messages.add_compare') }}</a>
                                    </form>
                                </div>
                                <?php endforeach;?>
                                <?php else:?>
                                    <p class="no-prd">{{ __('messages.no_products_available') }}</p>
                                <?php endif;?>
                                <!-- .product -->
                            </div>
                            <!-- .products -->
                        </div>
                        <!-- .woocommerce -->
                    </div>
                    <!-- .tab-pane -->
                    <div id="list-view-large" class="tab-pane <?= ($layout_type == 'list-view-large') ? 'active' : ''?>" role="tabpanel">
                        <div class="woocommerce columns-1">
                            <div class="products">
                                <?php if($cats->count() > 0):?>
                                <?php foreach($cats as $product):?>
                                    <?php
                                    $price = getVariationPrice($product->id);
                                    $variation = getVariation($product->id);
                                    $attr = isset($variation['attr']) ? $variation['attr'] : '';
                                    $total_stock = isset($variation['total_stock']) ? $variation['total_stock'] : 0;
                                    $stock = checkProductStock($product->sku);
                                    $wishlist = checkProductWishlist($product->id);
                                    ?>
                                <div class="product list-view-large">
                                    <form class="variations_form cart" id="variations_form">
                                        <input type="hidden" name="product_price" id="hidden_price" value="{{$price}}">
                                        <input type="hidden" name="quantity" id="hidden_price" value="1">
                                        <input name="_token" type="hidden" value="{{ csrf_token() }}"/>
                                        <input type="hidden" value="{{$product->id}}" name="product_id">
                                        <input type="hidden" name="total_stock" id="total_stock" value="{{$total_stock}}">
                                        <?php if(!empty($attr)):?>
                                        <?php foreach($attr as $key=>$val):?>
                                            <input type="hidden" name="attr[<?= $key?>]" value="<?= $val?>">
                                        <?php endforeach;?>
                                        <?php endif;?>
                                    <div class="media">
                                        <img width="224" height="197" alt="" class="attachment-shop_catalog size-shop_catalog wp-post-image" src="{{asset('assets/images/products/'.$product->photo)}}">
                                        <div class="media-body">
                                            <div class="product-info">
                                                <div class="yith-wcwl-add-to-wishlist">
                                                    <a rel="nofollow" class="pointer add_to_wishlist btn-add-wishlist <?= ($wishlist > 0) ? 'wishlist-added':''?>" data-id="{{$product->id}}"> Add to Wishlist</a>
                                                </div>
                                                <!-- .yith-wcwl-add-to-wishlist -->
                                                <a class="woocommerce-LoopProduct-link woocommerce-loop-product__link" href="{{ route('front.product', $product->id) }}">
                                                    <h2 class="woocommerce-loop-product__title">
                                                        <?php if(app()->getLocale() == 'ar'):?>
                                                            {{$product->name_ar}}
                                                        <?php else:?>
                                                            {{$product->name}}
                                                        <?php endif;?>
                                                    </h2>
                                                    <div class="techmarket-product-rating">
                                                        <?php $average_rating = getAvgRating($product->id);
                                                        $rating_count = getRatingCount($product->id);
                                                        ?>
                                                        <?php if($average_rating == 5):?>
                                                        <div class="star-rating">
                                                            <span style="width:100%">
                                                                <strong class="rating">5.00</strong> out of 5</span>
                                                        </div>
                                                        <?php elseif($average_rating ==4):?>
                                                        <div class="star-rating">
                                                            <span style="width:80%">
                                                                <strong class="rating">5.00</strong> out of 5</span>
                                                        </div>
                                                        <?php elseif($average_rating == 3):?>
                                                        <div class="star-rating">
                                                            <span style="width:60%">
                                                                <strong class="rating">5.00</strong> out of 5</span>
                                                        </div>
                                                        <?php elseif($average_rating == 2):?>
                                                        <div class="star-rating">
                                                            <span style="width:40%">
                                                                <strong class="rating">5.00</strong> out of 5</span>
                                                        </div>
                                                        <?php elseif($average_rating == 1):?>
                                                        <div class="star-rating">
                                                            <span style="width:10%">
                                                                <strong class="rating">5.00</strong> out of 5</span>
                                                        </div>
                                                        <?php else:?>
                                                        <div class="star-rating">
                                                            <span style="width:0%">
                                                                <strong class="rating">5.00</strong> out of 5</span>
                                                        </div>
                                                        <?php endif;?>
                                                        <span class="review-count">({{$rating_count}})</span>
                                                    </div>
                                                </a>
                                                <!-- .woocommerce-LoopProduct-link -->
                                                <?php $brand = getBrandByProduct($product->id);?>
                                                <?php if(!empty($brand)):?>
                                                <div class="brand">
                                                    <a href="#">
                                                        <img alt="galaxy" src="{{asset('assets/images/brands/'.$brand->photo)}}">
                                                    </a>
                                                </div>
                                                <?php endif;?>
                                                <!-- .brand -->
                                                <div class="woocommerce-product-details__short-description">
                                                    <?php echo htmlspecialchars_decode(stripslashes($product->product_info));?>
                                                </div>
                                                <!-- .woocommerce-product-details__short-description -->
                                                <span class="sku_wrapper">SKU:
                                                    <span class="sku">{{$product->sku}}</span>
                                                </span>
                                            </div>
                                            <!-- .product-info -->
                                            <div class="product-actions">
                                                <div class="availability">
                                                    {{ __('messages.availability') }}
                                                    <p class="stock in-stock">
                                                        <?php if((isset($stock) && $stock > 0)):?>
                                                        <span class="total-stock"><?= $stock?></span>
                                                        {{ __('messages.in_stock') }}
                                                        <?php else:?>
                                                            <span class="required">{{ __('messages.out_stock') }}</span>
                                                        <?php endif;?>
                                                    </p>
                                                </div>
                                                <?php $discount = $product->previous_price - $price;?>
                                                <?php if(isset($product->previous_price) && !empty($product->previous_price) && $discount > 0):?>
                                                    <span class="price">
                                                        <ins>
                                                            <span class="woocommerce-Price-currencySymbol">{{$curr}}</span>
                                                            <span class="amount">{{number_format($price,3)}}</span>
                                                        </ins>
                                                        <?php if($price < $product->previous_price):?>
                                                        <del>
                                                            <span class="amount">{{number_format($product->previous_price,3)}}</span>
                                                        </del>
                                                        <?php endif;?>
                                                        <span class="amount"> </span>
                                                    </span>
                                                <?php else:?>
                                                    <span class="price">
                                                        <ins>
                                                            <span class="amount"> </span>
                                                        </ins>
                                                        <span class="woocommerce-Price-currencySymbol">{{$curr}}</span>
                                                        <span class="amount">{{number_format($price , 3)}}</span>
                                                    </span>
                                                <?php endif;?>
                                                <!-- .price -->
                                                <button class="button add_to_cart_button" type="button" <?= ($stock == 0) ? 'disabled' : ''?>>{{ __('messages.add_cart') }}</button>
                                                <a class="add-to-compare-link pointer btn-add-compare" data-id="{{$product->id}}">{{ __('messages.add_compare') }}</a>
                                            </div>
                                            <!-- .product-actions -->
                                        </div>
                                        <!-- .media-body -->
                                    </div>
                                    <!-- .media -->
                                    </form>
                                </div>
                                <?php endforeach;?>
                                <?php else:?>
                                    <p class="no-prd"> {{ __('messages.no_products_available') }}</p>
                                <?php endif;?>
                                <!-- .product -->
                            </div>
                            <!-- .products -->
                        </div>
                        <!-- .woocommerce -->
                    </div>
                    <!-- .tab-pane -->
                    <div id="list-view" class="tab-pane <?= ($layout_type == 'list-view') ? 'active' : ''?>" role="tabpanel">
                        <div class="woocommerce columns-1">
                            <div class="products">
                                <?php if($cat->count() > 0):?>
                                <?php foreach($cats as $product):?>
                                    <?php
                                    $price = getVariationPrice($product->id);
                                    $variation = getVariation($product->id);
                                    $attr = isset($variation['attr']) ? $variation['attr'] : '';
                                    $total_stock = isset($variation['total_stock']) ? $variation['total_stock'] : 0;
                                    $stock = checkProductStock($product->sku);
                                    $wishlist = checkProductWishlist($product->id);
                                    ?>
                                <div class="product list-view ">
                                     <form class="variations_form cart" id="variations_form">
                                        <input type="hidden" name="product_price" id="hidden_price" value="{{$price}}">
                                        <input type="hidden" name="quantity" id="hidden_price" value="1">
                                        <input name="_token" type="hidden" value="{{ csrf_token() }}"/>
                                        <input type="hidden" value="{{$product->id}}" name="product_id">
                                        <input type="hidden" name="total_stock" id="total_stock" value="{{$total_stock}}">
                                        <?php if(!empty($attr)):?>
                                        <?php foreach($attr as $key=>$val):?>
                                            <input type="hidden" name="attr[<?= $key?>]" value="<?= $val?>">
                                        <?php endforeach;?>
                                        <?php endif;?>
                                    <div class="media">
                                        <img width="224" height="197" alt="" class="attachment-shop_catalog size-shop_catalog wp-post-image" src="{{asset('assets/images/products/'.$product->photo)}}">
                                        <div class="media-body">
                                            <div class="product-info">
                                                <div class="yith-wcwl-add-to-wishlist">
                                                    <a rel="nofollow" class="pointer add_to_wishlist btn-add-wishlist <?= ($wishlist > 0) ? 'wishlist-added':''?>" data-id="{{$product->id}}"> Add to Wishlist</a>
                                                </div>
                                                <!-- .yith-wcwl-add-to-wishlist -->
                                                <a class="woocommerce-LoopProduct-link woocommerce-loop-product__link" href="{{ route('front.product', $product->id) }}">
                                                    <h2 class="woocommerce-loop-product__title">
                                                        <?php if(app()->getLocale() == 'ar'):?>
                                                            {{$product->name_ar}}
                                                        <?php else:?>
                                                            {{$product->name}}
                                                        <?php endif;?>
                                                    </h2>
                                                    <div class="techmarket-product-rating">
                                                        <?php $average_rating = getAvgRating($product->id);
                                                        $rating_count = getRatingCount($product->id);
                                                        ?>
                                                        <?php if($average_rating == 5):?>
                                                        <div class="star-rating">
                                                            <span style="width:100%">
                                                                <strong class="rating">5.00</strong> out of 5</span>
                                                        </div>
                                                        <?php elseif($average_rating ==4):?>
                                                        <div class="star-rating">
                                                            <span style="width:80%">
                                                                <strong class="rating">5.00</strong> out of 5</span>
                                                        </div>
                                                        <?php elseif($average_rating == 3):?>
                                                        <div class="star-rating">
                                                            <span style="width:60%">
                                                                <strong class="rating">5.00</strong> out of 5</span>
                                                        </div>
                                                        <?php elseif($average_rating == 2):?>
                                                        <div class="star-rating">
                                                            <span style="width:40%">
                                                                <strong class="rating">5.00</strong> out of 5</span>
                                                        </div>
                                                        <?php elseif($average_rating == 1):?>
                                                        <div class="star-rating">
                                                            <span style="width:10%">
                                                                <strong class="rating">5.00</strong> out of 5</span>
                                                        </div>
                                                        <?php else:?>
                                                        <div class="star-rating">
                                                            <span style="width:0%">
                                                                <strong class="rating">5.00</strong> out of 5</span>
                                                        </div>
                                                        <?php endif;?>
                                                        <span class="review-count">({{$rating_count}})</span>
                                                    </div>
                                                </a>
                                                <!-- .woocommerce-LoopProduct-link -->
                                                <?php $brand = getBrandByProduct($product->id);?>
                                                <?php if(!empty($brand)):?>
                                                <div class="brand">
                                                    <a href="#">
                                                        <img alt="galaxy" src="{{asset('assets/images/brands/'.$brand->photo)}}">
                                                    </a>
                                                </div>
                                                <?php endif;?>
                                                <!-- .brand -->
                                                <div class="woocommerce-product-details__short-description">
                                                    <?php echo htmlspecialchars_decode(stripslashes($product->product_info));?>
                                                </div>
                                                <!-- .woocommerce-product-details__short-description -->
                                            </div>
                                            <!-- .product-info -->
                                            <div class="product-actions">
                                                <div class="availability">
                                                    {{ __('messages.availability') }}
                                                    <p class="stock in-stock">
                                                        <?php if((isset($stock) && $stock > 0)):?>
                                                        <span class="total-stock"><?= $stock?></span>
                                                        {{ __('messages.in_stock') }}
                                                        <?php else:?>
                                                            <span class="required">{{ __('messages.out_stock') }}</span>
                                                        <?php endif;?>
                                                    </p>
                                                </div>
                                                <?php $discount = $product->previous_price - $price;?>
                                                <?php if(isset($product->previous_price) && !empty($product->previous_price) && $discount > 0):?>
                                                    <span class="price">
                                                        <ins>
                                                            <span class="woocommerce-Price-currencySymbol">{{$curr}}</span>
                                                            <span class="amount">{{number_format($price,3)}}</span>
                                                        </ins>
                                                        <?php if($price < $product->previous_price):?>
                                                        <del>
                                                            <span class="amount">{{number_format($product->previous_price,3)}}</span>
                                                        </del>
                                                        <?php endif;?>
                                                        <span class="amount"> </span>
                                                    </span>
                                                <?php else:?>
                                                    <span class="price">
                                                        <ins>
                                                            <span class="amount"> </span>
                                                        </ins>
                                                        <span class="woocommerce-Price-currencySymbol">{{$curr}}</span>
                                                        <span class="amount">{{number_format($price , 3)}}</span>
                                                    </span>
                                                <?php endif;?>
                                                <!-- .price -->
                                                <button class="button add_to_cart_button" type="button" <?= ($stock==0) ? 'disabled' : ''?>>{{ __('messages.add_cart') }}</button>
                                                <a class="add-to-compare-link pointer btn-add-compare" data-id="{{$product->id}}">{{ __('messages.add_compare') }}</a>
                                            </div>
                                            <!-- .product-actions -->
                                        </div>
                                        <!-- .media-body -->
                                    </div>
                                    <!-- .media -->
                                    </form>
                                </div>
                                <?php endforeach;?>
                                <?php else:?>
                                    <p class="no-prd"> {{ __('messages.no_products_available') }}</p>
                                <?php endif;?>
                                <!-- .product -->
                            </div>
                            <!-- .products -->
                        </div>
                        <!-- .woocommerce -->
                    </div>
                    <!-- .tab-pane -->
                    <div id="list-view-small" class="tab-pane <?= ($layout_type == 'list-view-small') ? 'active' : ''?>" role="tabpanel">
                        <div class="woocommerce columns-1">
                            <div class="products">
                                <?php if($cats->count() > 0):?>
                                <?php foreach($cats as $product):?>
                                    <?php
                                    $price = getVariationPrice($product->id);
                                    $variation = getVariation($product->id);
                                    $attr = isset($variation['attr']) ? $variation['attr'] : '';
                                    $total_stock = isset($variation['total_stock']) ? $variation['total_stock'] : 0;

                                    $stock = checkProductStock($product->sku);
                                    $wishlist = checkProductWishlist($product->id);
                                    ?>
                                <div class="product list-view-small ">
                                    <form class="variations_form cart" id="variations_form">
                                        <input type="hidden" name="product_price" id="hidden_price" value="{{$price}}">
                                        <input type="hidden" name="quantity" id="hidden_price" value="1">
                                        <input name="_token" type="hidden" value="{{ csrf_token() }}"/>
                                        <input type="hidden" value="{{$product->id}}" name="product_id">
                                        <input type="hidden" name="total_stock" id="total_stock" value="{{$total_stock}}">
                                        <?php if(!empty($attr)):?>
                                        <?php foreach($attr as $key=>$val):?>
                                            <input type="hidden" name="attr[<?= $key?>]" value="<?= $val?>">
                                        <?php endforeach;?>
                                        <?php endif;?>
                                    <div class="media">
                                        <img width="224" height="197" alt="" class="attachment-shop_catalog size-shop_catalog wp-post-image" src="{{asset('assets/images/products/'.$product->photo)}}">
                                        <div class="media-body">
                                            <div class="product-info">
                                                <div class="yith-wcwl-add-to-wishlist">
                                                    <a rel="nofollow" class="pointer add_to_wishlist btn-add-wishlist <?= ($wishlist > 0) ? 'wishlist-added':''?>" data-id="{{$product->id}}"> Add to Wishlist</a>
                                                </div>
                                                <!-- .yith-wcwl-add-to-wishlist -->
                                                <a class="woocommerce-LoopProduct-link woocommerce-loop-product__link" href="{{ route('front.product', $product->id) }}">
                                                    <h2 class="woocommerce-loop-product__title">
                                                        <?php if(app()->getLocale() == 'ar'):?>
                                                            {{$product->name_ar}}
                                                        <?php else:?>
                                                            {{$product->name}}
                                                        <?php endif;?>
                                                    </h2>
                                                    <div class="techmarket-product-rating">
                                                        <?php $average_rating = getAvgRating($product->id);
                                                        $rating_count = getRatingCount($product->id);
                                                        ?>
                                                        <?php if($average_rating == 5):?>
                                                        <div class="star-rating">
                                                            <span style="width:100%">
                                                                <strong class="rating">5.00</strong> out of 5</span>
                                                        </div>
                                                        <?php elseif($average_rating ==4):?>
                                                        <div class="star-rating">
                                                            <span style="width:80%">
                                                                <strong class="rating">5.00</strong> out of 5</span>
                                                        </div>
                                                        <?php elseif($average_rating == 3):?>
                                                        <div class="star-rating">
                                                            <span style="width:60%">
                                                                <strong class="rating">5.00</strong> out of 5</span>
                                                        </div>
                                                        <?php elseif($average_rating == 2):?>
                                                        <div class="star-rating">
                                                            <span style="width:40%">
                                                                <strong class="rating">5.00</strong> out of 5</span>
                                                        </div>
                                                        <?php elseif($average_rating == 1):?>
                                                        <div class="star-rating">
                                                            <span style="width:10%">
                                                                <strong class="rating">5.00</strong> out of 5</span>
                                                        </div>
                                                        <?php else:?>
                                                        <div class="star-rating">
                                                            <span style="width:0%">
                                                                <strong class="rating">5.00</strong> out of 5</span>
                                                        </div>
                                                        <?php endif;?>
                                                        <span class="review-count">({{$rating_count}})</span>
                                                    </div>
                                                </a>
                                                <!-- .woocommerce-LoopProduct-link -->
                                                <div class="woocommerce-product-details__short-description">
                                                    <?php echo htmlspecialchars_decode(stripslashes($product->product_info));?>
                                                </div>
                                                <!-- .woocommerce-product-details__short-description -->
                                            </div>
                                            <!-- .product-info -->
                                            <div class="product-actions">
                                                <?php $discount = $product->previous_price - $price;?>
                                                <?php if(isset($product->previous_price) && !empty($product->previous_price) && $discount > 0):?>
                                                    <span class="price">
                                                        <ins>
                                                            <span class="woocommerce-Price-currencySymbol">{{$curr}}</span>
                                                            <span class="amount">{{number_format($price,3)}}</span>
                                                        </ins>
                                                        <?php if($price < $product->previous_price):?>
                                                        <del>
                                                            <span class="amount">{{number_format($product->previous_price,3)}}</span>
                                                        </del>
                                                        <?php endif;?>
                                                        <span class="amount"> </span>
                                                    </span>
                                                <?php else:?>
                                                    <span class="price">
                                                        <ins>
                                                            <span class="amount"> </span>
                                                        </ins>
                                                        <span class="woocommerce-Price-currencySymbol">{{$curr}}</span>
                                                        <span class="amount">{{number_format($price , 3)}}</span>
                                                    </span>
                                                <?php endif;?>
                                                <!-- .price -->
                                                <?php if($stock == 0):?>
                                                <p class="required">{{ __('messages.out_stock') }}</p>
                                                <?php endif;?>
                                                <button class="button add_to_cart_button" type="button" <?= ($stock==0) ? 'disabled' : ''?>>{{ __('messages.add_cart') }}</button>
                                                <a class="add-to-compare-link pointer btn-add-compare" data-id="{{$product->id}}">{{ __('messages.add_compare') }}</a>
                                            </div>
                                            <!-- .product-actions -->
                                        </div>
                                        <!-- .media-body -->
                                    </div>
                                    <!-- .media -->
                                    </form>
                                </div>
                                <?php endforeach;?>
                                <?php else:?>
                                    <p class="no-prd"> {{ __('messages.no_products_available') }}</p>
                                <?php endif;?>
                                <!-- .product -->
                            </div>
                            <!-- .products -->
                        </div>
                        <!-- .woocommerce -->
                    </div>
                    <!-- .tab-pane -->
                </div>
                <!-- .tab-content -->
                <div class="shop-control-bar-bottom">
                    <form class="form-techmarket-wc-ppp" method="POST">
                        <select class="techmarket-wc-wppp-select c-select page_length" name="page_length">
                            <option value="20" <?= ($page_length == 20) ? 'selected' : ''?>>{{ __('messages.show') }} 20</option>
                            <option value="40" <?= ($page_length == 40) ? 'selected' : ''?>>{{ __('messages.show') }} 40</option>
                            <option value="all" <?= ($page_length == 'all') ? 'selected' : ''?>>{{ __('messages.show_all') }}</option>
                        </select>
                        <input type="hidden" value="5" name="shop_columns">
                        <input type="hidden" value="15" name="shop_per_page">
                        <input type="hidden" value="right-sidebar" name="shop_layout">
                    </form>
                    <!-- .form-techmarket-wc-ppp -->
                    <p class="woocommerce-result-count">
                        {{ __('messages.showing') }} {{ $cats->firstItem() }} &ndash; {{ $cats->lastItem() }} of {{ $cats->total() }} ({{ __('messages.results') }})
                    </p>
                    <!-- .woocommerce-result-count -->
                    <nav class="woocommerce-pagination">
                        {{ $cats->appends(request()->input())->links('front.pagination') }}
                    </nav>
                    <!-- .woocommerce-pagination -->
                </div>
                <!-- .shop-control-bar-bottom -->
            </main>
            <!-- #main -->
        
            <!-- #main -->
     
            </main>
            <!-- #main -->
        </div>
        <!-- #primary -->
        <div id="secondary" class="widget-area shop-sidebar" role="complementary">
            <div class="widget woocommerce widget_product_categories techmarket_widget_product_categories" id="techmarket_product_categories_widget-2">
                <ul class="product-categories ">
                    <li class="product_cat">
                        <span>{{ __('messages.browse_category') }}</span>
                        <ul>
                            <?php foreach($categories as $category):?>
                                <li class="cat-item">
                                    <?php
                                    $sub_category = getSubCategory($category->id);
                                    ?>
                                    <?php if($sub_category->count() > 0):?>
                                        <li class="product_cat ">
                                            <span class="show-all-cat-dropdown <?= ($category->id == $cat->id) ? 'show-parent-cat current-category' : ''?>">
                                                <?php if(app()->getLocale() == 'ar'):?>{{$category->name_ar}}
                                                <?php else:?>
                                                    {{ucwords($category->name)}}
                                                <?php endif;?>
                                            <span class="child-indicator"></span></span>
                                            <ul class="" style="<?= ($category->id == $cat->id) ? 'display:block;' : 'display: none;'?>">
                                                <?php foreach($sub_category as $sub_cat):?>
                                                <li class="cat-item">
                                                    <a href="{{ route('front.subcat',['slug1' => $category->slug, 'slug2' => $sub_cat->slug]) }}">
                                                            <?php if(app()->getLocale() == 'ar'):?>{{$sub_cat->name_ar}}
                                                            <?php else:?>
                                                                {{ucwords($sub_cat->name)}}
                                                            <?php endif;?>
                                                        </a>
                                                </li>
                                                <?php endforeach;?>
                                            </ul>
                                        </li>
                                    <?php else:?>
                                        <a href="{{ route('front.category', $category->slug) }}">
                                            <span class="no-child"></span>
                                            <?php if(app()->getLocale() == 'ar'):?>{{$category->name_ar}}
                                            <?php else:?>
                                                {{$category->name}}
                                            <?php endif;?>
                                        </a>
                                    <?php endif;?>
                                </li>
                            <?php endforeach;?>
                        </ul>
                    </li>
                </ul>
            </div>
            <!-- .techmarket_widget_product_categories -->
            <div class="widget widget_techmarket_products_carousel_widget">
                <section id="single-sidebar-carousel" class="section-products-carousel">
                    <header class="section-header">
                        <h2 class="section-title">{{ __('messages.latest_products') }}</h2>
                        <nav class="custom-slick-nav"></nav>
                    </header>
                    <!-- .section-header -->
                    <div class="products-carousel" data-ride="tm-slick-carousel" data-wrap=".products" data-slick="{&quot;infinite&quot;:false,&quot;slidesToShow&quot;:1,&quot;slidesToScroll&quot;:1,&quot;rows&quot;:2,&quot;slidesPerRow&quot;:1,&quot;dots&quot;:false,&quot;arrows&quot;:true,&quot;prevArrow&quot;:&quot;&lt;a href=\&quot;#\&quot;&gt;&lt;i class=\&quot;tm tm-arrow-left\&quot;&gt;&lt;\/i&gt;&lt;\/a&gt;&quot;,&quot;nextArrow&quot;:&quot;&lt;a href=\&quot;#\&quot;&gt;&lt;i class=\&quot;tm tm-arrow-right\&quot;&gt;&lt;\/i&gt;&lt;\/a&gt;&quot;,&quot;appendArrows&quot;:&quot;#single-sidebar-carousel .custom-slick-nav&quot;}">
                        <div class="container-fluid">
                            <div class="woocommerce columns-1">
                                <div class="products">
                                    <?php foreach($latest_products as $product):?>
                                        <?php
                                        $price = getVariationPrice($product->id);
                                        ?>
                                    <div class="landscape-product-widget product">
                                        <a class="woocommerce-LoopProduct-link" href="{{ route('front.product', $product->id) }}">
                                            <div class="media">
                                                <img class="wp-post-image" src="{{asset('assets/images/products/'.$product->photo)}}" alt="">
                                                <div class="media-body">
                                                    <?php if(isset($product->previous_price) && !empty($product->previous_price)):?>
                                                        <span class="price">
                                                            <ins>
                                                                <span class="woocommerce-Price-currencySymbol">{{$curr}}</span>
                                                                <span class="amount">{{number_format($price,3)}}</span>
                                                            </ins>
                                                            <del>
                                                                <span class="woocommerce-Price-currencySymbol">{{$curr}}</span>
                                                                <span class="amount">{{number_format($product->previous_price,3)}}</span>
                                                            </del>
                                                            <span class="amount"> </span>
                                                        </span>
                                                        <?php else:?>
                                                            <span class="price">
                                                                <ins>
                                                                    <span class="amount"> </span>
                                                                </ins>
                                                                <span class="woocommerce-Price-currencySymbol">{{$curr}}</span>
                                                                <span class="amount">{{number_format($price , 3)}}</span>
                                                            </span>
                                                        <?php endif;?>
                                                    <!-- .price -->
                                                    <h2 class="woocommerce-loop-product__title">
                                                        <?php if(app()->getLocale() == 'ar'):?>
                                                            {{$product->name_ar}}
                                                        <?php else:?>
                                                            {{$product->name}}
                                                        <?php endif;?>
                                                    </h2>
                                                    <div class="techmarket-product-rating">
                                                        <div title="Rated 0 out of 5" class="star-rating">
                                                            <span style="width:0%">
                                                                <strong class="rating">0</strong> out of 5</span>
                                                        </div>
                                                        <span class="review-count">(0)</span>
                                                    </div>
                                                    <!-- .techmarket-product-rating -->
                                                </div>
                                                <!-- .media-body -->
                                            </div>
                                            <!-- .media -->
                                        </a>
                                        <!-- .woocommerce-LoopProduct-link -->
                                    </div>
                                    <?php endforeach;?>
                                </div>
                                <!-- .products -->
                            </div>
                            <!-- .woocommerce -->
                        </div>
                        <!-- .container-fluid -->
                    </div>
                    <!-- .products-carousel -->
                </section>
                <!-- .section-products-carousel -->
            </div>
            <!-- .widget_techmarket_products_carousel_widget -->
        </div>
    </div>
    <!-- .row -->
</div>
@endsection
<script type="text/javascript">

</script>