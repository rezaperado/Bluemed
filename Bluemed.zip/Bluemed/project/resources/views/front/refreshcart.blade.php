<li>
    <div class="widget woocommerce widget_shopping_cart">
        <div class="widget_shopping_cart_content">
            <ul class="woocommerce-mini-cart cart_list product_list_widget ">
                <?php $total = 0;?>
                <?php if(!empty(Session::get('cart'))):?>
                @foreach(Session::get('cart')->items as $product)
                <?php
                $total += (float)$product['unit_price'] * (int)$product['qty']; 
                //echo "<pre>";
                //print_r($product);exit;
                ?>
                <li class="woocommerce-mini-cart-item mini_cart_item">
                    <a href="#" class="remove" aria-label="Remove this item" data-product_id="{{$product['item']['id']}}" data-product_sku="">×</a>
                    <a href="{{ route('front.product',$product['item']['id']) }}">
                        <img src="{{ $product['item']['photo'] ? filter_var($product['item']['photo'], FILTER_VALIDATE_URL) ?$product['item']['photo']:asset('assets/images/products/'.$product['item']['photo']):asset('assets/images/noimage.png') }}" class="attachment-shop_thumbnail size-shop_thumbnail wp-post-image" alt="">
                        <?php if(app()->getLocale() == 'ar'):?>
                            {{$product['item']->name_ar}}
                        <?php else:?>
                            {{$product['item']->name}}
                        <?php endif;?>
                    </a>
                    <span class="quantity">{{$product['qty']}} ×
                        <span class="woocommerce-Price-amount amount">
                            <span class="woocommerce-Price-currencySymbol">{{$curr->sign}}</span>{{number_format($product['unit_price'],3)}}</span>
                    </span>
                </li>
                @endforeach
                <?php else:?>
                <li>Cart is empty</li>
                <?php endif;?>
            </ul>
            <!-- .cart_list -->
            <?php if(!empty(Session::get('cart'))):?>
            <p class="woocommerce-mini-cart__total total">
                <strong>{{ __('messages.subtotal') }}:</strong>
                <span class="woocommerce-Price-amount amount">
                    <span class="woocommerce-Price-currencySymbol">{{$curr->sign}}</span>{{number_format($total,3)}}</span>
            </p>
            <p class="woocommerce-mini-cart__buttons buttons">
                <a href="{{ route('front.cart') }}" class="button wc-forward">{{ __('messages.view_cart') }}</a>
                <a href="{{ route('front.checkout') }}" class="button checkout wc-forward">{{ __('messages.checkout') }}</a>
            </p>
            <?php endif;?>
        </div>
        <!-- .widget_shopping_cart_content -->
    </div>
    <!-- .widget_shopping_cart -->
</li>