@extends('layouts.front')
@section('body_class', 'page home page-template-default')
@section('content')
<section class="offer-banners payment-background">
    <div class="container payment_page">
    <div class="row justify-content-center">
            <div class="col-md-12 col-xs-12 col-sm-12 button-payment-page text-right">
                <a href="<?= URL('/user/profile')?>" class="btn btn-primarybtn btn-order add-newProduct-btn print"><i class="fa fa-dashboard"></i>{{ __('messages.dashboard') }}</a>
                <a href="<?= URL('/')?>" class="btn btn-order add-newProduct-btn print"><i class="fa fa-home"></i>{{ __('messages.home') }}</a>
                <a class="btn btn-order add-newProduct-btn print" href="{{ route('user-order-print',['id' => $order->id]) }}" target="_blank"><i class="fa fa-print"></i> {{ __('messages.print_invoice') }}</a>
            </div>
            <div class="col-12 text-center">
                <img src="{{asset('assets/images/'.$gs->logo)}}" width="150" alt="invoice_logo" class="invoice_logo">
                <p class="address_invoice" > Marafie Group Building Free Trade Zone / The Future street، Kuwait <i class="fa fa-phone">  (965) 2461 1026, (965) 2461 1027</i>, <i class="fa fa-envelope"> info@marafiegroup.com</i></p>
                <hr>
                <div class="title text-center header-order-number">
                     <h6>{{ __('messages.order_number_is') }}</h6> <h2>#{{$order->order_number}}</h2>
                </div>
            </div>
    </div>
    <div class="row"> 
      <div class="col-md-6 col-xs-12">
        <div class="panel panel-default">
          <div class="panel-heading"><h5>{{ __('messages.billing_details') }}</h5></div>
          <div class="panel-body">
            <div class="table-responsive">
                <table class="table">
                  <tbody>
                    <tr>
                        <th class="45%" width="45%">{{ __('messages.name') }}</th>
                        <td width="10%">:</td>
                        <td class="45%" width="45%">{{$user->first_name}}&nbsp;{{$user->last_name}}</td>
                    </tr>
                    <tr>
                        <th width="45%">{{ __('messages.email') }}</th>
                        <td width="10%">:</td>
                        <td width="45%">{{$user->email}}</td>
                    </tr>
                    <tr>
                        <th width="45%">{{ __('messages.phone') }}</th>
                        <td width="10%">:</td>
                        <td width="45%">{{$user->phone}}</td>
                    </tr>
                    <tr>
                        <th width="45%">{{ __('messages.area') }}</th>
                        <td width="10%">:</td>
                        <td width="45%">{{$user->area}}</td>
                    </tr>
                    <tr>
                        <th width="45%">{{ __('messages.block') }}</th>
                        <td width="10%">:</td>
                        <td width="45%">{{$user->block}}</td>
                    </tr>
                    <tr>
                        <th width="45%">{{ __('messages.street') }}</th>
                        <td width="10%">:</td>
                        <td width="45%">{{$user->street}}</td>
                    </tr>
                    <tr>
                        <th width="45%">{{ __('messages.city') }}</th>
                        <td width="10%">:</td>
                        <td width="45%">{{$user->city}}</td>
                    </tr>
                    <tr>
                        <th width="45%">{{ __('messages.zip') }}</th>
                        <td width="10%">:</td>
                        <td width="45%">{{$user->zip}}</td>
                    </tr>
                                      </tbody>
                </table>
            </div>
          </div>
        </div>
      </div>
            <div class="col-md-6 col-xs-12">
        <div class="panel panel-default">
          <div class="panel-heading"><h5>{{ __('messages.payment_info') }}</h5></div>
          <div class="panel-body">
            <div class="table-responsive">
                <table class="table">
                  <tbody>
                    <tr>
                        <th width="45%">{{ __('messages.payment_method') }}</th>
                        <td width="10%">:</td>
                        <td width="45%">{{$order->method}}</td>
                    </tr>
                    <tr>
                        <th width="45%">{{ __('messages.payment_status') }}</th>
                        <td width="10%">:</td>
                        <td width="45%">{{ucfirst($order->payment_status)}}</td>
                    </tr>
                    <?php 
                    $total_price = 0;
                    foreach($product_data as $product){
                        $price = getVariationPrice($product->id);
                        $total_price += $price;
                    }
                        ?>
                    <tr>
                        <th width="45%">{{ __('messages.order_total') }}</th>
                        <td width="10%">:</td>
                        <td width="45%">{{$curr->sign}}{{number_format(($total_price+$order->shipping_cost-$order->coupon_discount),2)}}</td>
                    </tr>
                    </tbody>
                </table>
              </div>
          </div>
        </div>
      </div>
    </div>
      <div class="row">
        <div class="col-lg-12 col-md-12">
            <p><strong>{{ __('messages.delivery_time') }}:</strong> {{$order->delivery_time}}</p>
        </div>
      </div>
      <div class="row">
        <div class="col-md-12 col-xs-12 product_table">
           <div class="panel panel-default">
            <div class="panel-heading"><h5>{{ __('messages.product_ordered') }}</h5></div>
            <div class="panel-body">
              <div class="table-responsive">
                <table class="table table-bordered_ table-striped" id="users_table">
                  <thead>
                    <tr>
                      <th class="text-center">{{ __('messages.sr_no') }}</th>
                      <th class="text-center">{{ __('messages.product_title') }}</th>
                      <th class="text-center">{{ __('messages.quantity') }}</th>
                      <th class="table_amount text-center" style="width: 20%;">{{ __('messages.total_price') }} (KWD)</th>
                    </tr>
                  </thead>
                  <tbody>
                        <?php foreach($product_data as $key=>$product):?>
                        <tr>
                          <td class="text-center">{{$key+1}}</td>
                          <td class="text-center"><?php if(app()->getLocale() == 'ar'):?>
                                                            {{$product->name_ar}}
                                                        <?php else:?>
                                                            {{$product->name}}
                                                        <?php endif;?></td>
                          <td class="table_quntity text-center">1</td>
                          <td class="table_amount text-center">{{$curr->sign}}{{number_format($price,2)}}</td>
                        </tr>
                        <?php endforeach;?>
                        <tr>
                          <td colspan="3" style="text-align: right;"><b>{{ __('messages.grand_total') }}:</b></td>
                          <td class="table_amount text-center"><b>{{$curr->sign}}{{number_format(($total_price+$order->shipping_cost-$order->coupon_discount),2)}}</b></td>
                        </tr>
                 </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    
</section>

@endsection