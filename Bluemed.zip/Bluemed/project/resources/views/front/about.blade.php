@extends('layouts.front')
@section('body_class', 'page home page-template-default')
@section('content')
<style>
@media screen and (max-width:767px)
{
	#masthead{border-bottom: 2px solid #ddd;}
	.site-content{padding-top:30px;}
}
</style>
<div class="col-full">
	<div class="row">
		<nav class="woocommerce-breadcrumb">
            <a href="<?= URL('/')?>">{{ __('messages.home') }}</a>
            <span class="delimiter">
                <i class="tm tm-breadcrumbs-arrow-right"></i>
            </span>
            {{ __('messages.about_us') }}
        </nav>
        <div id="primary" class="content-area">
        	 <?php if(app()->getLocale() == 'ar'):?>
        	<?php echo htmlspecialchars_decode(stripslashes($data->details_ar));?>
        	<?php else:?>
        	<?php echo htmlspecialchars_decode(stripslashes($data->details));?>
        	<?php endif;?>
        </div>
	</div>
</div>
@endsection