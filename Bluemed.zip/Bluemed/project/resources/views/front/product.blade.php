@extends('layouts.front')
@section('body_class', 'woocommerce-active single-product full-width extended')
@section('content')
<style>
   .summary.entry-summary .footer-social-icons .social-icons.nav .nav-item + .nav-item {
    margin-left: 0.5em !important;
}
.summary.entry-summary .footer-social-icons .social-icons li i{color: #7aeede !important;}
.zoomContainer{z-index: 8;}
body.rtl #primary{margin-top: 2rem;}

.slick-active
{
    height:100%;
}
</style>
<?php 
$product_attribute_names = array();
$product_default_option = array();
$product_attributes = array();
$prd_attr = array();
$related_products = $product->category->products()->where('status','=',1)->where('id','!=',$product->id)->take(8)->get();
$arabic_attr_arr = array();
foreach($arabic_attr as $key=>$val)
{
    $arabic_attr_arr[strtolower($val->name_en)] = $val->name_ar;
}
if(app()->getLocale() == 'ar'){
    $product_description = $product->details_ar;
}
else
{
    $product_description = $product->details;
}

if($_SERVER['REMOTE_ADDR'] == '157.32.251.108')
{

    
}


$clr='';
$sz='';
$clr_sku='';
if(isset($_REQUEST['color']))
{
$clr=$_REQUEST['color'];


}


if(isset($_REQUEST['size']))
{
$sz=$_REQUEST['size'];


}



$color_attr_values = array();
foreach($product_variations as $attr_key => $variation)
{

    $product_attribute_names = explode('-', $variation->attribute_names);
    $product_attribute_values = explode('-', $variation->attribute_values);
    $attribute_values = array();

    foreach($product_attribute_names as $attrkey => $attrname)
    {
        $vals = '';
        if(isset($product_attribute_values[$attrkey]))
            $vals = $product_attribute_values[$attrkey];
        $prd_attr[$attr_key][$attrname] = $vals; 
    }

    foreach($product_attribute_names as $key => $name)
    {
        $vals = '';
        /*echo $key;
        print_r($product_attribute_values);exit;*/
        if(isset($product_attribute_values[$key]))
            $vals = $product_attribute_values[$key];
        if(!empty($name))
        $product_default_option[$name] = $vals;

    if(strtolower($name) == 'color')
        {


            $color_attr_values[] = DB::table('color_master')->where('color_name','=',$vals)->value('color_code');

            if($clr=='')
            {
                $clr=$vals;
            }
        }


    }
    $prd_attr[$attr_key]['sku'] = $variation->sku;
    $prd_attr[$attr_key]['qty'] = $variation->qty;
    $prd_attr[$attr_key]['price'] = $variation->price;
    $prd_attr[$attr_key]['attr_id'] = $variation->id;

    $color_attr_values = array_filter($color_attr_values);
$color_attr_values = array_unique($color_attr_values);

}
/*echo "<pre>";
print_r($product_default_option);exit;*/

if($sz!='')
$clr_sku=DB::table('product_variations')->where('product_id','=',$product->id)->where('json_attributes','like','%'.$clr.'%')->where('json_attributes','like','%"'.$sz.'"%')->value('sku');
else
{
    $sizeclr1=DB::table('product_variations')->where('product_id','=',$product->id)->where('json_attributes','like','%'.$clr.'%')->limit(1)->get();

                                                           

 foreach($sizeclr1 as $sc1)

 {                            
$clr_sku=$sc1->sku;


}
                                                          

}


                                                          


?>

<input type="hidden" value="{{url('/')}}/item/{{$product->id}}" id="show_url">
@if($clr!='' && $clr_sku!='')
<input type="hidden" value="{{url('/')}}/item/{{$product->id}}?color={{$clr}}&size=" id="show_url1">

@else
<input type="hidden" value="{{url('/')}}/item/{{$product->id}}?size=" id="show_url1">
@endif
<input type="hidden" id="product_attributes" value="'<?= json_encode($prd_attr)?>'">

<div id="content" class="site-content" tabindex="-1">
    <div class="col-full">
        <div class="row">
            <nav class="woocommerce-breadcrumb">
                <a href="{{URL('/')}}">{{ __('messages.home') }}</a>
                <span class="delimiter">
                    <i class="tm tm-breadcrumbs-arrow-right"></i>
                </span>
                <a href="{{route('front.category',$product->category->slug)}}">
                    <?php 
                    $cat = getCategoryName($product->category_id);
                    //print_r($category->name_ar);exit;
                    ?>
                    <?php if(app()->getLocale() == 'ar'):?>
                        {{$cat->name_ar}}
                    <?php else:?>
                        {{$cat->name}}
                    <?php endif;?>
                </a>

                @if(isset($product->subcategory->name) && !empty($product->subcategory->name))
                <span class="delimiter">
                    <i class="tm tm-breadcrumbs-arrow-right"></i>
                </span>
                <a
              href="{{ route('front.subcat',['slug1' => $product->category->slug, 'slug2' => $product->subcategory->slug]) }}">
               {{$product->subcategory->name}}
                </a>
              @endif
                <span class="delimiter">
                    <i class="tm tm-breadcrumbs-arrow-right"></i>
                </span>
                <?php if(app()->getLocale() == 'ar'):?>
                    {{$product->name_ar}}
                <?php else:?>
                    {{$product->name}}
                <?php endif;?>
            </nav>
            <!-- .woocommerce-breadcrumb -->
            <div id="primary" class="content-area">
                <main id="main" class="site-main">
                    <div class="product product-type-simple">
                        <div class="single-product-wrapper">
                            <div class="product-images-wrapper thumb-count-4">
                                <?php 

                                $price = getVariationPrice($product->id);
                                $discount = $product->previous_price-$price;?>
                                <?php if(isset($product->previous_price) && !empty($product->previous_price) && $discount > 0):?>
                                    <span class="onsale">-
                                        <span class="woocommerce-Price-amount amount">
                                            <span class="woocommerce-Price-currencySymbol">{{$curr->sign}} </span><?= number_format($product->previous_price-$price,3)?></span>
                                    </span>
                                <?php endif;?>
                                <!-- .onsale -->
                                <div id="techmarket-single-product-gallery" class="techmarket-single-product-gallery techmarket-single-product-gallery--with-images techmarket-single-product-gallery--columns-4 images" data-columns="4">

                                    <div class="techmarket-single-product-gallery-images" data-ride="tm-slick-carousel" data-wrap=".woocommerce-product-gallery__wrapper" data-slick="{&quot;infinite&quot;:false,&quot;slidesToShow&quot;:1,&quot;slidesToScroll&quot;:1,&quot;dots&quot;:false,&quot;arrows&quot;:false,&quot;asNavFor&quot;:&quot;#techmarket-single-product-gallery .techmarket-single-product-gallery-thumbnails__wrapper&quot;}">
                                        
                                        <div class="woocommerce-product-gallery woocommerce-product-gallery--with-images woocommerce-product-gallery--columns-4 images" data-columns="4">
                                            <!-- <a href="#" class="woocommerce-product-gallery__trigger">🔍</a> -->
                                            <figure class="woocommerce-product-gallery__wrapper ">
                                               
                                               @if($clr=='') 
                                                <div data-thumb="{{asset('assets/images/products/'.$product->photo)}}" class="zoom-box woocommerce-product-gallery__image active-slide">
                                                    <!-- <a class="jqzoom" href="{{asset('assets/images/products/'.$product->photo)}}" class="prod-img"> -->
                                                        <img width="600" height="600" src="{{asset('assets/images/products/'.$product->photo)}}" data-zoom-image="{{asset('assets/images/products/'.$product->photo)}}"  class="attachment-shop_single zoom-img size-shop_single " alt="">
                                                    <!-- </a> -->
                                                </div>

                                                @endif

                                                <?php $im=0; foreach($gallary as $image):  ?>

                                                    <?php

                                                    if($clr!='')
                                                    {
$colour_cn=DB::table('product_color_images')->where('product_id','=',$image->product_id)->where('image','like','%'.$image->photo.'%')->where('color_name','=',$clr)->count();
}
else
{
    $colour_cn=1;
}
                              if($colour_cn!=0) {
                                                   $im++;   ?>
                                                <div data-thumb="{{asset('assets/images/galleries/'.$image->photo)}}" class="woocommerce-product-gallery__image zoom-box @if($im==1) active-slide @endif ">
                                                    <!-- <a class="jqzoom" href="{{asset('assets/images/galleries/'.$image->photo)}}" class="prod-img"> -->
                                                        <img width="600" height="600" src="{{asset('assets/images/galleries/'.$image->photo)}}" data-zoom-image="{{asset('assets/images/galleries/'.$image->photo)}}" class="attachment-shop_single zoom-img size-shop_single " alt="">
                                                    <!-- </a> -->
                                                </div>
                                            <?php } endforeach;?>
                                                <!-- <div data-thumb="{{asset('assets/images/products/sm-card-2.jpg')}}" class="woocommerce-product-gallery__image">
                                                    <a href="assets/images/products/big-card-2.jpg" tabindex="-1">
                                                        <img width="600" height="600" src="{{asset('assets/images/products/big-card-1.jpg')}}" class="attachment-shop_single size-shop_single" alt="">
                                                    </a>
                                                </div>
                                                <div data-thumb="{{asset('assets/images/products/sm-card-2.jpg')}}" class="woocommerce-product-gallery__image">
                                                    <a href="assets/images/products/big-card-2.jpg" tabindex="-1">
                                                        <img width="600" height="600" src="{{asset('assets/images/products/big-card-1.jpg')}}" class="attachment-shop_single size-shop_single" alt="">
                                                    </a>
                                                </div>
                                                <div data-thumb="{{asset('assets/images/products/sm-card-2.jpg')}}" class="woocommerce-product-gallery__image">
                                                    <a href="assets/images/products/big-card-2.jpg" tabindex="-1">
                                                        <img width="600" height="600" src="{{asset('assets/images/products/big-card-1.jpg')}}" class="attachment-shop_single size-shop_single" alt="">
                                                    </a>
                                                </div> -->
                                            </figure>
                                        </div>
                                        <!-- .woocommerce-product-gallery -->
                                    </div>
                                    <!-- .techmarket-single-product-gallery-images -->
                                    <div class="techmarket-single-product-gallery-thumbnails" data-ride="tm-slick-carousel" data-wrap=".techmarket-single-product-gallery-thumbnails__wrapper" data-slick="{&quot;infinite&quot;:false,&quot;slidesToShow&quot;:4,&quot;slidesToScroll&quot;:1,&quot;dots&quot;:false,&quot;arrows&quot;:true,&quot;vertical&quot;:true,&quot;verticalSwiping&quot;:true,&quot;focusOnSelect&quot;:true,&quot;touchMove&quot;:true,&quot;prevArrow&quot;:&quot;&lt;a href=\&quot;#\&quot;&gt;&lt;i class=\&quot;tm tm-arrow-up\&quot;&gt;&lt;\/i&gt;&lt;\/a&gt;&quot;,&quot;nextArrow&quot;:&quot;&lt;a href=\&quot;#\&quot;&gt;&lt;i class=\&quot;tm tm-arrow-down\&quot;&gt;&lt;\/i&gt;&lt;\/a&gt;&quot;,&quot;asNavFor&quot;:&quot;#techmarket-single-product-gallery .woocommerce-product-gallery__wrapper&quot;,&quot;responsive&quot;:[{&quot;breakpoint&quot;:765,&quot;settings&quot;:{&quot;vertical&quot;:false,&quot;horizontal&quot;:true,&quot;verticalSwiping&quot;:false,&quot;slidesToShow&quot;:4}}]}">

                                      

                                        <figure class="techmarket-single-product-gallery-thumbnails__wrapper">
                                              @if($clr=='') 
                                            <figure data-thumb="{{asset('assets/images/products/'.$product->photo)}}" class="techmarket-wc-product-gallery__image all-image">
                                                <img width="180" height="180" src="{{asset('assets/images/products/'.$product->photo)}}" data-zoom-image="{{asset('assets/images/products/'.$product->photo)}}" class="attachment-shop_thumbnail size-shop_thumbnail wp-post-image zoom-img_" alt="">
                                            </figure>

                                            @endif
                                            <?php $im=0; foreach($gallary as $image):  ?>

                                               <?php
if($clr!='')
                                                    {
$colour_cn=DB::table('product_color_images')->where('product_id','=',$image->product_id)->where('image','like','%'.$image->photo.'%')->where('color_name','=',$clr)->count();
}
else
{
    $colour_cn=1;
}
                              if($colour_cn!=0) {
                                                   $im++; ?>
                                            <figure data-thumb="{{asset('assets/images/galleries/'.$image->photo)}}" class="techmarket-wc-product-gallery__image all-image ">
                                                <img width="180" height="180" src="{{asset('assets/images/galleries/'.$image->photo)}}" data-zoom-image="{{asset('assets/images/galleries/'.$image->photo)}}" class="attachment-shop_thumbnail size-shop_thumbnail wp-post-image @if($im==1) zoom-img_ @endif" alt="">
                                            </figure>
                                            <?php } endforeach;?>
                                        </figure>
                                        <!-- .techmarket-single-product-gallery-thumbnails__wrapper -->
                                    </div>
                                    <!-- .techmarket-single-product-gallery-thumbnails -->
                                </div>
                                <!-- .techmarket-single-product-gallery -->
                            </div>
                            <!-- .product-images-wrapper -->
                            <div class="summary entry-summary">
                                <div class="single-product-header">
                                    <h1 class="product_title entry-title">
                                        <?php if(app()->getLocale() == 'ar'):?> {{$product->name_ar}}
                                        <?php else:?>
                                            {{$product->name}}
                                        <?php endif;?>
                                    </h1>
                                    <?php $wishlist = checkProductWishlist($product->id);?>
                                    <a rel="nofollow" class="pointer add-to-wishlist btn-add-wishlist <?= ($wishlist > 0) ? 'wishlist-added':''?>" data-id="{{$product->id}}"> </a>
                                </div>
                                <!-- .single-product-header -->
                                <div class="single-product-meta">
                                    <!-- <div class="brand">
                                        <a href="#">
                                            <img alt="galaxy" src="{{asset('assets/images/brands/5.png')}}">
                                        </a>
                                    </div> -->
                                    <div class="cat-and-sku ltr">

<table>
<tr> <td style="width:30%;padding:2px"> <span class="sku_wrapper"><b >{{ __('messages.sku') }}:</b></span></td> <td style="padding:2px">

@if($clr_sku=='')
    <span class="sku">{{$product->sku}}</span>
    @else
   <span class="sku">{{$clr_sku}}</span>  
@endif
</td></tr>


<tr> <td style="width:30%;padding:2px"><span class="sku_wrapper"><b >{{ __('messages.category') }}:</b></span></td> <td style="padding:2px"><span class="sku_">
                                                <?php 
                    $cat = getCategoryName($product->category_id);
                    //print_r($category->name_ar);exit;
                    ?>
                    <?php if(app()->getLocale() == 'ar'):?>
                        {{$cat->name_ar}}
                    <?php else:?>
                        {{$cat->name}}
                    <?php endif;?>
                                           
                                        </span></td></tr>

<?php if(isset($product->subcategory->name) && !empty($product->subcategory->name)):?>
                                        <tr> <td style="width:30%;padding:2px"><span class="sku_wrapper"><b >{{ __('messages.sub_category') }}:</b></span></td> <td style="padding:2px;">  
                                            <span class="sku_">{{$product->subcategory->name}}</span>
                                        </span>
                                      </td></tr>

  <?php endif;?>



    <tr> <td style="width:30%;padding:2px"><span class="sku_wrapper brand_nm"><b >{{ __('messages.brand') }}:</b></span></td> <td style="padding:2px;">  
                                               <?php $brand = getBrandByProduct($product->id);?>
                                            <span class="sku_">{{isset($brand->name) ? $brand->name : '-'}}</span>
                                     
                                      </td></tr>



</table>

                                       
                                        
                                            
                                        
                                      
                                        
                                         
                                    
                                    </div>
                                    <div class="cat-and-sku w-100 rtl">
                                        <span class="sku_wrapper">
                                            <b style="margin-left: 1.2rem;font-weight: bold;">{{ __('messages.sku') }}:</b>
                                            <span class="sku">{{$product->sku}}</span>
                                            
                                        </span>
                                        <span class="sku_wrapper">
                                            <span class="sku_">
                                                <b style="    margin-left: 2.9rem;font-weight: bold;">{{ __('messages.category') }}:</b>
                                                <?php 
                    $cat = getCategoryName($product->category_id);
                    //print_r($category->name_ar);exit;
                    ?>
                    <?php if(app()->getLocale() == 'ar'):?>
                        {{$cat->name_ar}}
                    <?php else:?>
                        {{$cat->name}}
                    <?php endif;?>
                                            </span>
                                            
                                        </span>
                                        <?php if(isset($product->subcategory->name) && !empty($product->subcategory->name)):?>
                                        <span class="sku_wrapper">
                                            <b style="margin-left: 1.9rem;font-weight: bold;">{{ __('messages.sub_category') }}:</b>
                                            <span class="sku_">{{$product->subcategory->name}}</span>
                                            
                                        </span>
                                        <?php endif;?>
                                        <span class="sku_wrapper brand_nm">
                                            <b style="margin-left: 1.9rem;font-weight: bold;">{{ __('messages.brand') }}:</b>
                                            <?php $brand = getBrandByProduct($product->id);?>
                                            <span class="sku_">{{isset($brand->name_ar) ? $brand->name_ar : '-'}}</span>
                                            
                                        </span>
                                    </div>
                                    <?php if(app()->getLocale() == 'ar'):?>
                                    <div class="desc-div" style="margin: 1rem 0 0;">
                                        <p style="margin-bottom:0;"><b style="font-weight: bold;">{{ __('messages.item_desc') }}</b></p>
                                        <?php echo htmlspecialchars_decode(stripslashes($product_description));?>
                                    </div>
                                    <?php else:?>
                                    <div class="desc-div" style="margin: 1rem 0 0;">
                                        <p style="margin-bottom:0;"><b>{{ __('messages.item_desc') }}</b></p>
                                        <?php echo htmlspecialchars_decode(stripslashes($product_description));?>
                                    </div>
                                    <?php endif;?>
                                    <!-- <div class="product-label">
                                        <div class="ribbon label green-label">
                                            <span>A+</span>
                                        </div>
                                    </div> -->
                                </div>

                                <!-- .single-product-meta -->
                                <div class="rating-and-sharing-wrapper">
                                    <div class="woocommerce-product-rating">
                                        <?php if($average_rating == 5):?>
                                        <div title="Rated 5 out of 5" class="star-rating">
                                            <span style="width:100%"></span>
                                        </div>
                                        <?php elseif($average_rating ==4):?>
                                        <div title="Rated 5 out of 5" class="star-rating">
                                            <span style="width:80%"></span>
                                        </div>
                                        <?php elseif($average_rating ==3):?>
                                        <div title="Rated 5 out of 5" class="star-rating">
                                            <span style="width:60%"></span>
                                        </div>
                                        <?php elseif($average_rating ==2):?>
                                        <div title="Rated 5 out of 5" class="star-rating">
                                            <span style="width:40%"></span>
                                        </div>
                                        <?php elseif($average_rating ==1):?>
                                        <div title="Rated 5 out of 5" class="star-rating">
                                            <span style="width:20%"></span>
                                        </div>
                                        <?php else:?>
                                        <div title="Rated 5 out of 5" class="star-rating">
                                            <span style="width:0%"></span>
                                        </div>
                                        <?php endif;?>
                                        <a rel="nofollow" class="woocommerce-review-link" href="#reviews">(<span class="count">{{$review_count}}</span> {{ __('messages.customer_review') }})</a>
                                    </div>
                                </div>
                                <div class="product-attachments">
                                    <?php if(!empty($product->attachment)):?>
                                            <?php 
                                            $attachmentData = explode(",",$product->attachment);
                                            ?>
                                            <h6>{{ __('messages.attachments') }}:</h6>
                                            <?php foreach($attachmentData as $attachment):?>
                                                <p class="mb-2"><a href="<?= URL('/')?>/assets/files/<?= $attachment?>"><i class="fa fa-download"></i>&nbsp;<?= $attachment?></a></p>
                                            <?php endforeach;?>
                                        <?php endif;?>
                                </div>
                                <!-- .rating-and-sharing-wrapper -->
                                <div class="woocommerce-product-details__short-description">
                                    <?php echo htmlspecialchars_decode(stripslashes($product->product_info));?>
                                    <!-- <ul>
                                        <li>Multimedia Speakers</li>
                                        <li>120 watts peak</li>
                                        <li>Front-facing subwoofer</li>
                                        <li>Refresh Rate: 120Hz (Effective)</li>
                                        <li>Backlight: LED</li>
                                        <li>Smart Functionality: Yes, webOS 3.0</li>
                                        <li>Dimensions (W x H x D): TV without stand: 43.5″ x 25.4″ x 3.0″, TV with stand: 43.5″ x 27.6″ x 8.5″</li>
                                        <li>Inputs: 3 HMDI, 2 USB, 1 RF, 1 Component, 1 Composite, 1 Optical, 1 RS232C, 1 Ethernet</li>
                                    </ul> -->
                                </div>
                                <hr style="margin-top: 24px"/>
                                <div class="footer-social-icons" style="margin-top: 35px;">
                                    <ul class="social-icons nav">
                                        <?php
                                        $actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
                                        ?>
                                        <li class="nav-item">
                                            <a class="sm-icon-label-link nav-link" href="https://www.instagram.com/?url=<?= $actual_link?>">
                                                <i class="fa fa-instagram"></i></a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="sm-icon-label-link nav-link" href="http://www.facebook.com/sharer.php?u=<?= $actual_link?>">
                                                <i class="fa fa-facebook"></i> </a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="sm-icon-label-link nav-link" href="http://twitter.com/share?text=<?= $product->name?>&url=<?= $actual_link?>">
                                                <i class="fa fa-twitter"></i> </a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="sm-icon-label-link nav-link" href="http://www.linkedin.com/shareArticle?mini=true&url=<?= $actual_link?>">
                                                <i class="fa fa-linkedin"></i> </a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="sm-icon-label-link nav-link" href="whatsapp://send?text=<?= $actual_link?>">
                                                <i class="fa fa-whatsapp"></i> </a>
                                        </li>
                                       <!-- <li class="nav-item">
                                            <a class="sm-icon-label-link nav-link" href="#">
                                                <i class="fa fa-vimeo-square"></i> Vimeo</a>
                                        </li>-->
                                        
                                    </ul>
                                </div>
                                <!-- .woocommerce-product-details__short-description -->
                            </div>
                            <!-- .entry-summary -->
                            <div class="product-actions-wrapper">
                                <div class="product-actions">
                                    <div class="availability">
                                        <?php 
                                        $stock = $product->stock;

                                        if($stock=='')
                                            $stock='1000';

                                        ?>
                                        {{ __('messages.availability') }} 
                                        <p class="stock in-stock">
                                            <?php if((isset($stock) && $stock > 0)):?>
                                            <!--<span class="total-stock_"><?= $stock?></span>-->
                                            {{ __('messages.in_stock') }}
                                            <?php else:?>
                                                {{ __('messages.out_stock') }}
                                            <?php endif;?>

                                           
                                        </p>
                                    </div>
                                    <!-- .availability -->
                                    <!-- <div class="additional-info">
                                        <i class="tm tm-free-delivery"></i>{{ __('messages.item_with') }}
                                        <strong>{{ __('messages.free_delivery') }}</strong>
                                    </div> -->
                                    <!-- .additional-info -->
                                    <p class="price">
                                        <span class="woocommerce-Price-amount amount">
                                            <span class="woocommerce-Price-currencySymbol">{{$curr->sign}}</span>&nbsp;<span class="product-price">{{number_format($product->price,3)}}</span></span>
                                    </p>
                                    <!-- .price -->
                                    <form class="variations_form cart" id="variations_form">
                                        <input name="_token" type="hidden" value="{{ csrf_token() }}"/>
                                        <table class="variations">
                                            <tbody>

                                                <input type="hidden" data-attribute_name="SKU" name="attr[SKU]" class="product_attribute r-{{$clr_sku}} r-{{$clr_sku}}" id="SKU" value="{{$clr_sku}}" >


                                                <?php   $shw_attr=array(); foreach($product_default_option as $key => $attr):
                                                    ?>
                                                   

                                                    @if($key=='Color')

                                                     <tr>
                                                    <td class="label">
                                                        <label for="pa_screen-size">
                                                            <?php if(app()->getLocale() == 'ar'):?>
                                                            <?= $arabic_attr_arr[strtolower($key)]?>
                                                            <?php else:?>
                                                                {{$key}}
                                                            <?php endif;?>

                                                        </label>
                                                    </td>
                                                    </tr>
                                                    <tr>
                                                    <td class="value">
                                                     <p>   <?php foreach($color_attr_values as $color):?>
<?php
$color_namet=DB::table('color_master')->where('color_code','=',$color)->value('color_name');
$colour_nm=str_replace(" ","-",$color_namet);
?>
                                                     <input type="radio" data-attribute_name="{{$key}}" name="attr[{{$key}}]" class="product_attribute r-{{$colour_nm}} r-{{$color_namet}}" id="{{$key}}" value="{{$color_namet}}" @if($color_namet==$clr) checked @endif style="display:none">

                                                      


                                        <button class="attr-color-selection" type="button"data-name="{{$color_namet}}" style="background-color:{{$color}};width:10px; @if($color_namet==$clr) border:2px solid black; @endif" onclick="show_image('{{$colour_nm}}','{{$color_namet}}')">&nbsp;</button>


                                    <?php endforeach;?>
                                    <p>
                                                    </td>
                                                </tr>

 @elseif($key=='Size')

  <tr class="size1">
                                                    <td class="label">
                                                        <label for="pa_screen-size">
                                                            <?php if(app()->getLocale() == 'ar'):?>
                                                            <?= $arabic_attr_arr[strtolower($key)]?>
                                                            <?php else:?>
                                                                {{$key}}
                                                            <?php endif;?>

                                                        </label>
                                                    </td>
                                                    </tr>

  <tr class="size">
                                                    <td >
                                                        <select  name="attr[{{$key}}]" class=""  id="{{$key}}"onchange="set_size(this.value)">

                                                            <?php $sizeclr=DB::table('product_variations')->where('product_id','=',$product->id)->where('json_attributes','like','%'.$clr.'%')->get();

                                                           
$rept0=array();

$ch=0;
                                                            ?>

            @foreach($sizeclr as $sc)
<?php $jsn=json_decode($sc->json_attributes);  ?>
                @if(isset($jsn->Size))

                <?php
$ch++;
                if($sz == $jsn->Size){
                                                                            $select = 'selected';
                                                                        }else{
                                                                            $select = '';
                                                                        }


                                                                        ?>
@if(!in_array($jsn->Size,$rept0))
                            <?php

                     $rept0[]=$jsn->Size;
                                                            ?>

             

              <option value="{{$jsn->Size}}" <?php echo $select ?>>{{$jsn->Size}}</option>
              @endif

              @endif
                                                            @endforeach
                                                        </select>
                                                    </td>
                                                </tr>

                                                <?php
 if($ch==0)
                                                            {
                                                                $shw_attr[]=$key;
                                                            }
                                                ?>

                                                <script type="text/javascript"> @if(count($rept0)==0)  document.getElementsByClassName('size')[0].style.display = 'none';  document.getElementsByClassName('size1')[0].style.display = 'none'; @endif</script>


 @elseif($key=='Length' )



  <tr class="length">
                                                    <td class="label">
                                                        <label for="pa_screen-size">
                                                            <?php if(app()->getLocale() == 'ar'):?>
                                                            <?= $arabic_attr_arr[strtolower($key)]?>
                                                            <?php else:?>
                                                                {{$key}}
                                                            <?php endif;?>

                                                        </label>
                                                    </td>
                                                    </tr>

<tr class="length1">

<td class="value">
                                                        <select data-show_option_none="yes" data-attribute_name="{{$key}}" sel="{{$clr}}" name="attr[{{$key}}]" class="" id="{{$key}}">

                                                            <?php $sizeclr=DB::table('product_variations')->where('product_id','=',$product->id)->where('json_attributes','like','%'.$clr.'%')->where('json_attributes','like','%'.$sz.'%')->get();

                                                            

 $rept=array();
                                                          $ch=0;  ?>

                                                            @foreach($sizeclr as $sc)

                                                            <?php
                           $jsn=json_decode($sc->json_attributes); 
                          ?>
     @if(isset($jsn->Length))

@if(!in_array($jsn->Length,$rept))
                            <?php
$ch++;
                     $rept[]=$jsn->Length;
                                                            ?>

        

              <option value="{{$jsn->Length}}"  class="attached enabled" >{{$jsn->Length}}</option>
              @endif

              @endif
                                                            @endforeach
                                                        </select>
                                                    </td>
                                                </tr>
 <?php
 if($ch==0)
                                                            {
                                                                $shw_attr[]=$key;
                                                            }
                                                ?>

                                                <script type="text/javascript"> @if(count($rept)==0)  document.getElementsByClassName('length')[0].style.display = 'none';  document.getElementsByClassName('length1')[0].style.display = 'none'; @endif</script>


 @elseif($key=='Units' )

  <tr class="units">
                                                    <td class="label">
                                                        <label for="pa_screen-size">
                                                            <?php if(app()->getLocale() == 'ar'):?>
                                                            <?= $arabic_attr_arr[strtolower($key)]?>
                                                            <?php else:?>
                                                                {{$key}}
                                                            <?php endif;?>

                                                        </label>
                                                    </td>
                                                    </tr>

<tr class="units1">

<td class="value">
        <select data-show_option_none="yes" data-attribute_name="{{$key}}" name="attr[{{$key}}]" class="product_attribute get_value" id="{{$key}}">

        <?php $sizeclr=DB::table('product_variations')->where('product_id','=',$product->id)->where('json_attributes','like','%'.$clr.'%')->where('json_attributes','like','%'.$sz.'%')->get(); 
      $ch=0;
        $rept1=array();

        ?>


                @foreach($sizeclr as $sc)

                                                                        <?php
                           $jsn=json_decode($sc->json_attributes); 
                          ?>
@if(isset($jsn->Units))
@if(!in_array($jsn->Units,$rept1))
                            <?php
$ch++;
                     $rept1[]=$jsn->Units;
                                                            ?>

             

              <option value="{{$jsn->Units}}"  class="attached enabled" >{{$jsn->Units}}</option>
              @endif

              @endif
                                                            @endforeach
                                                        </select>
                                                    </td>
                                                </tr>
                                                 <?php
 if($ch==0)
                                                            {
                                                                $shw_attr[]=$key;
                                                            }
                                                ?>

    <script type="text/javascript"> @if(count($rept1)==0)  document.getElementsByClassName('units')[0].style.display = 'none';  document.getElementsByClassName('units1')[0].style.display = 'none'; @endif</script>



@elseif($key=='ORIGIN' )

 <tr class="origin">
                                                    <td class="label">
                                                        <label for="pa_screen-size">
                                                            <?php if(app()->getLocale() == 'ar'):?>
                                                            <?= $arabic_attr_arr[strtolower($key)]?>
                                                            <?php else:?>
                                                                {{$key}}
                                                            <?php endif;?>

                                                        </label>
                                                    </td>
                                                    </tr>


<tr class="origin1">
<td class="value">
        <select data-show_option_none="yes" data-attribute_name="{{$key}}" name="attr[{{$key}}]" class="product_attribute get_value" id="{{$key}}">

        <?php $sizeclr=DB::table('product_variations')->where('product_id','=',$product->id)->where('json_attributes','like','%'.$clr.'%')->where('json_attributes','like','%'.$sz.'%')->get(); 

       $ch=0;

        $rept2=array(); 

        ?>

                @foreach($sizeclr as $sc)

              <?php
                           $jsn=json_decode($sc->json_attributes); 
                          ?>
 @if(isset($jsn->ORIGIN))
@if(!in_array($jsn->ORIGIN,$rept2))
                            <?php
$ch++;
                     $rept2[]=$jsn->ORIGIN;
                                                            ?>

            

              <option value="{{$jsn->ORIGIN}}"  class="attached enabled" >{{$jsn->ORIGIN}}</option>
              @endif

              @endif
                                                            @endforeach
                                                        </select>
                                                    </td>
                                                </tr>

                                                 <?php
 if($ch==0)
                                                            {
                                                                $shw_attr[]=$key;
                                                            }
                                                ?>
<script type="text/javascript"> @if(count($rept2)==0)  document.getElementsByClassName('origin')[0].style.display = 'none';  document.getElementsByClassName('origin1')[0].style.display = 'none'; @endif</script>

@elseif($key=='MOQ' )


 <tr class="moqq">
                                                    <td class="label">
                                                        <label for="pa_screen-size">
                                                            <?php if(app()->getLocale() == 'ar'):?>
                                                            <?= $arabic_attr_arr[strtolower($key)]?>
                                                            <?php else:?>
                                                                {{$key}}
                                                            <?php endif;?>

                                                        </label>
                                                    </td>
                                                    </tr>


<tr class="moqq1">

<td class="value">
        <select data-show_option_none="yes" data-attribute_name="{{$key}}" name="attr[{{$key}}]" class="product_attribute get_value" id="{{$key}}">

        <?php $sizeclr=DB::table('product_variations')->where('product_id','=',$product->id)->where('json_attributes','like','%'.$clr.'%')->where('json_attributes','like','%'.$sz.'%')->get(); 

        $ch=0;



        $rept3=array(); ?>

                @foreach($sizeclr as $sc)

             <?php
                           $jsn=json_decode($sc->json_attributes); 
                          ?>
 @if(isset($jsn->MOQ))
@if(!in_array($jsn->MOQ,$rept3))
                            <?php
$ch++;
                     $rept3[]=$jsn->MOQ;
                                                            ?>

            

              <option value="{{$jsn->MOQ}}"  class="attached enabled" >{{$jsn->MOQ}}</option>
              @endif

              @endif
                                                            @endforeach
                                                        </select>
                                                    </td>
                                                </tr>

 <?php
 if($ch==0)
                                                            {
                                                                $shw_attr[]=$key;
                                                            }
                                                ?>

<script type="text/javascript"> @if(count($rept3)==0)  document.getElementsByClassName('moqq')[0].style.display = 'none';  document.getElementsByClassName('moqq1')[0].style.display = 'none'; @endif</script>


                                                @elseif($key=='warranty' && $clr!='')


 <tr class="warnty">
                                                    <td class="label">
                                                        <label for="pa_screen-size">
                                                            <?php if(app()->getLocale() == 'ar'):?>
                                                            <?= $arabic_attr_arr[strtolower($key)]?>
                                                            <?php else:?>
                                                                {{$key}}
                                                            <?php endif;?>

                                                        </label>
                                                    </td>
                                                    </tr>


<tr class="warnty1">
<td class="value">
        <select data-show_option_none="yes" data-attribute_name="{{$key}}" name="attr[{{$key}}]" class="product_attribute get_value" id="{{$key}}">

        <?php $sizeclr=DB::table('product_variations')->where('product_id','=',$product->id)->where('json_attributes','like','%'.$clr.'%')->where('json_attributes','like','%'.$sz.'%')->get(); 

        $ch=0;


        $rept4=array(); ?>

                @foreach($sizeclr as $sc)

            <?php
                           $jsn=json_decode($sc->json_attributes); 
                          ?>
  @if(isset($jsn->warranty))
@if(!in_array($jsn->warranty,$rept4))
                            <?php
$ch++;
                     $rept4[]=$jsn->warranty;
                                                            ?>

           

              <option value="{{$jsn->warranty}}"  class="attached enabled" >{{$jsn->warranty}}</option>
              @endif

              @endif
                                                            @endforeach
                                                        </select>
                                                    </td>
                                                </tr>
 <?php
 if($ch==0)
                                                            {
                                                                $shw_attr[]=$key;
                                                            }
                                                ?>


<script type="text/javascript"> @if(count($rept4)==0)  document.getElementsByClassName('warnty')[0].style.display = 'none';  document.getElementsByClassName('warnty1')[0].style.display = 'none'; @endif</script>
                                  
                                    @elseif($key=='WT')



                                                  @else

                                                 <tr>
                                                    <td class="label">
                                                        <label for="pa_screen-size">
                                                            <?php if(app()->getLocale() == 'ar'):?>
                                                            <?= $arabic_attr_arr[strtolower($key)]?>
                                                            <?php else:?>
                                                                {{$key}}
                                                            <?php endif;?>

                                                        </label>
                                                    </td>
                                                    </tr>


                                                 <tr>
                                                    <td class="value">
                                                        <select data-show_option_none="yes" data-attribute_name="{{$key}}" name="attr[{{$key}}]" class="product_attribute" id="{{$key}}">
                                                            <option value="{{$attr}}" class="attached enabled">{{$attr}}</option>
                                                        </select>
                                                    </td>
                                                </tr>

                                                @endif
                                                <?php endforeach;?>
                                            </tbody>
                                        </table>
                                        <div class="single_variation_wrap">
                                            <div class="woocommerce-variation-add-to-cart variations_button woocommerce-variation-add-to-cart-disabled">
                                                <div class="quantity">
                                                    <label for="quantity-input">{{ __('messages.quantity') }}</label>
                                                    <input id="quantity-input" type="number" name="quantity" value="1" title="Qty" class="input-text qty text" size="4" required>
                                                </div>
                                                
                                                <button <?= 'test'.$stock?> class="single_add_to_cart_button button alt wc-variation-selection-needed" type="button" <?= ($stock==0) ? 'disabled' : ''?>>{{ __('messages.add_cart') }}</button>
                                                <input type="hidden" value="2471" name="add-to-cart">
                                                <input type="hidden" value="{{$product->id}}" name="product_id">
                                                <input type="hidden" name="product_price" id="hidden_price">
                                                <input type="hidden" value="0" class="variation_id" name="variation_id">
                                                <input type="hidden" name="total_stock" id="total_stock" value="0">
                                                <input type="hidden" name="attr_id" id="attr_id" value="0">
                                            </div>
                                        </div>
                                        <!-- .single_variation_wrap -->
                                    </form>
                                    <!-- .variations_form -->
                                    <a class="add-to-compare-link pointer btn-add-compare" data-id="{{$product->id}}">{{ __('messages.add_compare') }}</a>
                                </div>
                                <!-- .product-actions -->
                            </div>
                            <!-- .product-actions-wrapper -->
                        </div>
                        <div class="woocommerce-tabs wc-tabs-wrapper">
                            <ul role="tablist" class="nav tabs wc-tabs">
                                <!-- <li class="nav-item accessories_tab">
                                    <a class="nav-link active" data-toggle="tab" role="tab" aria-controls="tab-accessories" href="#tab-accessories">Accessories</a>
                                </li> -->
                                <!-- <li class="nav-item description_tab">
                                    <a class="nav-link active" data-toggle="tab" role="tab" aria-controls="tab-description" href="#tab-description">{{ __('messages.description') }}</a>
                                </li> -->
                                <!-- <li class="nav-item specification_tab">
                                    <a class="nav-link" data-toggle="tab" role="tab" aria-controls="tab-specification" href="#tab-specification">Specification</a>
                                </li> -->
                                <li class="nav-item reviews_tab">
                                    <a class="nav-link active" data-toggle="tab" role="tab" aria-controls="tab-reviews" href="#tab-reviews">{{ __('messages.reviews') }} (<span id="review_count">{{$review_count}}</span>)</a>
                                </li>
                            </ul>
                            <!-- /.ec-tabs -->
                            <div class="tab-content">
                                <!-- <div class="tab-pane panel active wc-tab" id="tab-description" role="tabpanel">
                                    <?php echo htmlspecialchars_decode(stripslashes($product_description));?>
                                </div> -->
                                <div class="tab-pane active" id="tab-reviews" role="tabpanel">
                                    <div class="techmarket-advanced-reviews" id="reviews">
                                        <div class="advanced-review row">
                                            <div class="advanced-review-rating">
                                                <h2 class="based-title">{{ __('messages.review') }} ({{$review_count}})</h2>
                                                <div class="avg-rating">
                                                    <span class="avg-rating-number">{{number_format($average_rating,1)}}</span>
                                                    <div class="rating-stars text-center">
                                                        <ul id="stars">
                                                          <li class="star <?= ($average_rating >=1) ? 'selected' : ''?>" title="Poor" data-value="1">
                                                            <i class="fa fa-star fa-fw"></i>
                                                          </li>
                                                          <li class="star <?= ($average_rating >=2) ? 'selected' : ''?>" title="Fair" data-value="2">
                                                            <i class="fa fa-star fa-fw"></i>
                                                          </li>
                                                          <li class="star <?= ($average_rating >=3) ? 'selected' : ''?>" title="Good" data-value="3">
                                                            <i class="fa fa-star fa-fw"></i>
                                                          </li>
                                                          <li class="star <?= ($average_rating >=4) ? 'selected' : ''?>" title="Excellent" data-value="4">
                                                            <i class="fa fa-star fa-fw"></i>
                                                          </li>
                                                          <li class="star <?= ($average_rating >=5) ? 'selected' : ''?>" title="WOW!!!" data-value="5">
                                                            <i class="fa fa-star fa-fw"></i>
                                                          </li>
                                                        </ul>
                                                    </div>
                                                </div>
                                                <!-- /.avg-rating -->
                                                <div class="rating-histogram">
                                                    <div class="rating-bar">
                                                        <div title="Rated 5 out of 5" class="star-rating">
                                                            <span style="width:100%"></span>
                                                        </div>
                                                        <div class="rating-count">{{$five_star_rating}}</div>
                                                        <div class="rating-percentage-bar">
                                                            <span class="rating-percentage" style="width:100%"></span>
                                                        </div>
                                                    </div>
                                                    <div class="rating-bar">
                                                        <div title="Rated 4 out of 5" class="star-rating">
                                                            <span style="width:80%"></span>
                                                        </div>
                                                        <div class="rating-count zero">{{$four_star_rating}}</div>
                                                        <div class="rating-percentage-bar">
                                                            <span class="rating-percentage" style="width:80%"></span>
                                                        </div>
                                                    </div>
                                                    <div class="rating-bar">
                                                        <div title="Rated 3 out of 5" class="star-rating">
                                                            <span style="width:60%"></span>
                                                        </div>
                                                        <div class="rating-count zero">{{$three_star_rating}}</div>
                                                        <div class="rating-percentage-bar">
                                                            <span class="rating-percentage" style="width:60%"></span>
                                                        </div>
                                                    </div>
                                                    <div class="rating-bar">
                                                        <div title="Rated 2 out of 5" class="star-rating">
                                                            <span style="width:40%"></span>
                                                        </div>
                                                        <div class="rating-count zero">{{$two_star_rating}}</div>
                                                        <div class="rating-percentage-bar">
                                                            <span class="rating-percentage" style="width:40%"></span>
                                                        </div>
                                                    </div>
                                                    <div class="rating-bar">
                                                        <div title="Rated 1 out of 5" class="star-rating">
                                                            <span style="width:20%"></span>
                                                        </div>
                                                        <div class="rating-count zero">{{$one_star_rating}}</div>
                                                        <div class="rating-percentage-bar">
                                                            <span class="rating-percentage" style="width:20%"></span>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- /.rating-histogram -->
                                            </div>
                                            <!-- /.advanced-review-rating -->
                                            <div class="advanced-review-comment">
                                                <div id="review_form_wrapper">
                                                    <div id="review_form">
                                                        <div class="comment-respond" id="respond">
                                                            <h3 class="comment-reply-title" id="reply-title">{{ __('messages.add_review') }}</h3>
                                                            <form novalidate="" class="comment-form" id="review-form" method="post" action="{{ route('writereview') }}">
                                                                <input name="_token" type="hidden" value="{{ csrf_token() }}"/>
                                                                <input type="hidden" name="rating" id="total_rating">
                                                                <input type="hidden" name="product_id" value="{{$id}}">
                                                                <div class="comment-form-rating">
                                                                    <label>{{ __('messages.your_rating') }}</label>
                                                                    <div class='rating-stars text-center'>
                                                                        <ul id='stars'>
                                                                          <li class='star' title='Poor' data-value='1'>
                                                                            <i class='fa fa-star fa-fw'></i>
                                                                          </li>
                                                                          <li class='star' title='Fair' data-value='2'>
                                                                            <i class='fa fa-star fa-fw'></i>
                                                                          </li>
                                                                          <li class='star' title='Good' data-value='3'>
                                                                            <i class='fa fa-star fa-fw'></i>
                                                                          </li>
                                                                          <li class='star' title='Excellent' data-value='4'>
                                                                            <i class='fa fa-star fa-fw'></i>
                                                                          </li>
                                                                          <li class='star' title='WOW!!!' data-value='5'>
                                                                            <i class='fa fa-star fa-fw'></i>
                                                                          </li>
                                                                        </ul>
                                                                      </div>
                                                                </div>
                                                                <p class="comment-form-comment">
                                                                    <label for="comment">{{ __('messages.your_review') }}</label>
                                                                    <textarea aria-required="true" rows="8" cols="45" name="comment" id="comment"></textarea>
                                                                </p>
                                                                <p class="comment-form-author">
                                                                    <label for="author">{{ __('messages.name') }}
                                                                        <span class="required">*</span>
                                                                    </label>
                                                                    <input type="text" aria-required="true" size="30" value="" name="name" id="author">
                                                                </p>
                                                                <p class="comment-form-email">
                                                                    <label for="email">{{ __('messages.email') }}
                                                                        <span class="required">*</span>
                                                                    </label>
                                                                    <input type="email" aria-required="true" size="30" value="" name="email" id="email">
                                                                </p>
                                                                <p class="form-submit">
                                                                    <input type="submit" value="{{ __('messages.add_review') }}" class="submit btn-submit-review" id="btn-submit-review" name="submit">
                                                                    <input type="hidden" id="comment_post_ID" value="185" name="comment_post_ID">
                                                                    <input type="hidden" value="0" id="comment_parent" name="comment_parent">
                                                                </p>
                                                            </form>
                                                            <!-- /.comment-form -->
                                                        </div>
                                                        <!-- /.comment-respond -->
                                                    </div>
                                                    <!-- /#review_form -->
                                                </div>
                                                <!-- /#review_form_wrapper -->
                                            </div>
                                            <!-- /.advanced-review-comment -->
                                        </div>
                                        <!-- /.advanced-review -->
                                        <div id="comments">
                                            <ol class="commentlist">
                                                <li id="li-comment-83" class="comment byuser comment-author-admin bypostauthor even thread-even depth-1">
                                                    <?php foreach($reviews as $review):?>
                                                    <div class="comment_container" id="comment-83">
                                                        <div class="comment-text" style="margin:15px 0;">
                                                            
                                                            <p class="meta m-b-0">
                                                                <strong itemprop="author" class="woocommerce-review__author">{{$review->first_name}}&nbsp;{{$review->last_name}}</strong>
                                                                <span class="woocommerce-review__dash">&ndash;</span>
                                                                <time datetime="2017-06-21T08:05:40+00:00" itemprop="datePublished" class="woocommerce-review__published-date">{{date('M d, Y', strtotime($review->review_date))}}</time>
                                                            </p>
                                                            <div class="description">
                                                                <p>{{$review->review}}</p>
                                                            </div>
                                                            <div class="rating-stars text-center">
                                                                <ul id="stars">
                                                                  <li class="star <?= ($review->rating>=1) ? 'selected' : '' ?>" title="Poor" data-value="1">
                                                                    <i class="fa fa-star fa-fw"></i>
                                                                  </li>
                                                                  <li class="star <?= ($review->rating>=2) ? 'selected' : '' ?>" title="Fair" data-value="2">
                                                                    <i class="fa fa-star fa-fw"></i>
                                                                  </li>
                                                                  <li class="star <?= ($review->rating>=3) ? 'selected' : '' ?>" title="Good" data-value="3">
                                                                    <i class="fa fa-star fa-fw"></i>
                                                                  </li>
                                                                  <li class="star <?= ($review->rating>=4) ? 'selected' : '' ?>" title="Excellent" data-value="4">
                                                                    <i class="fa fa-star fa-fw"></i>
                                                                  </li>
                                                                  <li class="star <?= ($review->rating>=5) ? 'selected' : '' ?>" title="WOW!!!" data-value="5">
                                                                    <i class="fa fa-star fa-fw"></i>
                                                                  </li>
                                                                </ul>
                                                              </div>
                                                            <!-- /.description -->
                                                        </div>
                                                        <!-- /.comment-text -->
                                                    </div>
                                                    <?php endforeach;?>
                                                    <!-- /.comment_container -->
                                                </li>
                                                <!-- /.comment -->
                                            </ol>
                                            <!-- /.commentlist -->
                                        </div>
                                        <!-- /#comments -->
                                    </div>
                                    <!-- /.techmarket-advanced-reviews -->
                                </div>
                            </div>
                        </div>
                        <?php 
                        $is_rtl = 'false';
                        if(app()->getLocale() == 'ar')                    
                            $is_rtl = 'true';
                        ?>
                        <!-- .single-product-wrapper -->
                        <div class="tm-related-products-carousel section-products-carousel" id="tm-related-products-carousel" data-ride="tm-slick-carousel" data-wrap=".products" data-slick="{&quot;slidesToShow&quot;:7,&quot;slidesToScroll&quot;:7,&quot;dots&quot;:true,&quot;rtl&quot;:<?= $is_rtl?>,&quot;arrows&quot;:true,&quot;prevArrow&quot;:&quot;&lt;a href=\&quot;#\&quot;&gt;&lt;i class=\&quot;tm tm-arrow-left\&quot;&gt;&lt;\/i&gt;&lt;\/a&gt;&quot;,&quot;nextArrow&quot;:&quot;&lt;a href=\&quot;#\&quot;&gt;&lt;i class=\&quot;tm tm-arrow-right\&quot;&gt;&lt;\/i&gt;&lt;\/a&gt;&quot;,&quot;appendArrows&quot;:&quot;#tm-related-products-carousel .custom-slick-nav&quot;,&quot;responsive&quot;:[{&quot;breakpoint&quot;:767,&quot;settings&quot;:{&quot;slidesToShow&quot;:1,&quot;slidesToScroll&quot;:1}},{&quot;breakpoint&quot;:780,&quot;settings&quot;:{&quot;slidesToShow&quot;:3,&quot;slidesToScroll&quot;:3}},{&quot;breakpoint&quot;:1200,&quot;settings&quot;:{&quot;slidesToShow&quot;:4,&quot;slidesToScroll&quot;:4}},{&quot;breakpoint&quot;:1400,&quot;settings&quot;:{&quot;slidesToShow&quot;:5,&quot;slidesToScroll&quot;:5}}]}">
                            <section class="related">
                                <header class="section-header">
                                    <h2 class="section-title">{{ __('messages.related_products') }}</h2>
                                    <nav class="custom-slick-nav"></nav>
                                </header>
                                <!-- .section-header -->
                                <div class="products">
                                    <?php foreach($related_products as $product):?>
                                        <?php $wishlist = checkProductWishlist($product->id);?>
                                    <div class="product">
                                        <div class="yith-wcwl-add-to-wishlist">
                                            <a rel="nofollow" class="pointer add_to_wishlist btn-add-wishlist <?= ($wishlist > 0) ? 'wishlist-added':''?>" data-id="{{$product->id}}"> </a>
                                        </div>
                                        <a href="{{ route('front.product', $product->id) }}" class="woocommerce-LoopProduct-link ">
                                            <?php 
                                            $price = getVariationPrice($product->id);
                                            $discount = $product->previous_price-$price;?>
                                            <?php if(isset($product->previous_price) && !empty($product->previous_price) && $discount > 0):?>
                                                <span class="onsale">
                                                    <span class="woocommerce-Price-amount amount">
                                                        <span class="woocommerce-Price-currencySymbol">{{$curr->sign}}</span><?= number_format(((float)$product->previous_price - (float)$price) ,3);?>
                                                    </span>
                                                </span>
                                            <?php endif;?>
                                            <img src="{{asset('assets/images/products/'.$product->photo)}}" width="224" height="197" class="wp-post-image" alt="">
                                            <?php if(isset($product->previous_price) && !empty($product->previous_price)):?>
                                                <span class="price">
                                                    <ins>
                                                        <span class="amount">{{number_format($product->price,3)}}</span>
                                                    </ins>
                                                    <?php if($discount > 0):?>
                                                    <del>
                                                        <span class="amount">{{number_format($product->previous_price,3)}}</span>
                                                    </del>
                                                <?php endif;?>
                                                    <span class="amount"> </span>
                                                </span>
                                            <?php else:?>
                                                <span class="price">
                                                    <ins>
                                                        <span class="amount"> </span>
                                                    </ins>
                                                    <span class="amount">{{number_format($product->price , 3)}}</span>
                                                </span>
                                            <?php endif;?>
                                            <!-- /.price -->
                                            <h2 class="woocommerce-loop-product__title">
                                                <?php if(app()->getLocale() == 'ar'):?>{{$product->name_ar}}
                                                <?php else:?>
                                                    {{$product->name}}
                                                <?php endif;?>
                                            </h2>
                                        </a>
                                        <?php
                                        $stock = checkProductStock($product->sku);
                                        ?>
                                        <div class="hover-area">
                                            <button <?= $stock?> class="single_add_to_cart_button button alt wc-variation-selection-needed" type="button" <?= ($stock==0) ? 'disabled' : ''?>>{{ __('messages.add_cart') }}</button>
                                            <a class="add-to-compare-link" href="#">{{ __('messages.add_compare') }}</a>
                                        </div>
                                    </div>
                                    <!-- /.product-outer -->
                                    <?php endforeach;?>
                                    <!-- /.product-outer -->
                                </div>
                            </section>
                            <!-- .single-product-wrapper -->
                        </div>
                        <!-- .tm-related-products-carousel ->
                        
                        <section class="section-landscape-products-carousel recently-viewed" id="recently-viewed">
                            <header class="section-header">
                                <h2 class="section-title">{{ __('messages.recently_viewed') }}</h2>
                                <nav class="custom-slick-nav"></nav>
                            </header>
                            <?php 
                            $is_rtl = 'false';
                            if(app()->getLocale() == 'ar')                    
                                $is_rtl = 'true';
                            ?>
                            <div class="products-carousel" data-ride="tm-slick-carousel" data-wrap=".products" data-slick="{&quot;slidesToShow&quot;:5,&quot;slidesToScroll&quot;:2,&quot;dots&quot;:true,&quot;rtl&quot;:<?= $is_rtl?>,&quot;arrows&quot;:true,&quot;prevArrow&quot;:&quot;&lt;a href=\&quot;#\&quot;&gt;&lt;i class=\&quot;tm tm-arrow-left\&quot;&gt;&lt;\/i&gt;&lt;\/a&gt;&quot;,&quot;nextArrow&quot;:&quot;&lt;a href=\&quot;#\&quot;&gt;&lt;i class=\&quot;tm tm-arrow-right\&quot;&gt;&lt;\/i&gt;&lt;\/a&gt;&quot;,&quot;appendArrows&quot;:&quot;#recently-viewed .custom-slick-nav&quot;,&quot;responsive&quot;:[{&quot;breakpoint&quot;:992,&quot;settings&quot;:{&quot;slidesToShow&quot;:2,&quot;slidesToScroll&quot;:2}},{&quot;breakpoint&quot;:1200,&quot;settings&quot;:{&quot;slidesToShow&quot;:3,&quot;slidesToScroll&quot;:3}},{&quot;breakpoint&quot;:1400,&quot;settings&quot;:{&quot;slidesToShow&quot;:3,&quot;slidesToScroll&quot;:3}},{&quot;breakpoint&quot;:1700,&quot;settings&quot;:{&quot;slidesToShow&quot;:4,&quot;slidesToScroll&quot;:4}}]}">
                                <div class="container-fluid">
                                    <div class="woocommerce columns-5">
                                        <div class="products">
                                            <?php foreach($recently_viewed as $product):?>
                                            <div class="landscape-product product">
                                                <a class="woocommerce-LoopProduct-link" href="{{ route('front.product', $product->id) }}">
                                                    <div class="media">
                                                        <img class="wp-post-image" src="{{asset('assets/images/products/'.$product->photo)}}" alt="">
                                                        <div class="media-body">
                                                            <span class="price">
                                                                <ins>
                                                                    <span class="amount"> </span>
                                                                </ins>
                                                                <span class="amount"> {{$curr->sign}} {{number_format($product->price,3)}}</span>
                                                            </span>
                                                            <!-- .price ->
                                                            <h2 class="woocommerce-loop-product__title">
                                                                <?php if(app()->getLocale() == 'ar'):?>
                                                                    {{$product->name_ar}}
                                                                <?php else:?>
                                                                    {{$product->name}}
                                                                <?php endif;?>
                                                            </h2>
                                                            <div class="techmarket-product-rating">
                                                                <div title="Rated 0 out of 5" class="star-rating">
                                                                    <span style="width:0%">
                                                                        <strong class="rating">0</strong> out of 5</span>
                                                                </div>
                                                                <span class="review-count">(0)</span>
                                                            </div>
                                                            <!-- .techmarket-product-rating ->
                                                        </div>
                                                        <!-- .media-body ->
                                                    </div>
                                                    <!-- .media ->
                                                </a>
                                                <!-- .woocommerce-LoopProduct-link->
                                            </div>
                                            <?php endforeach;?>
                                        </div>
                                    </div>
                                    <!-- .woocommerce ->
                                </div>
                                <!-- .container-fluid ->
                            </div>
                            <!-- .products-carousel ->
                        </section>
                        <!-- .section-landscape-products-carousel -->
                        
                        <!-- .brands-carousel -->
                    </div>
                    </div>
                    <!-- .product -->
                </main>
                <!-- #main -->
            </div>
            <!-- #primary -->
        </div>
        <!-- .row -->
    </div>
    <section class="brands-carousel">
                            <?php 
                            $is_rtl = 'false';
                            if(app()->getLocale() == 'ar')                    
                                $is_rtl = 'true';
                            ?>
                            <h2 class="sr-only">Brands Carousel</h2>
                            <div class="col-full" data-ride="tm-slick-carousel" data-wrap=".brands" data-slick="{&quot;slidesToShow&quot;:6,&quot;slidesToScroll&quot;:1,&quot;dots&quot;:false,&quot;rtl&quot;:<?= $is_rtl?>,&quot;arrows&quot;:true,&quot;responsive&quot;:[{&quot;breakpoint&quot;:400,&quot;settings&quot;:{&quot;slidesToShow&quot;:1,&quot;slidesToScroll&quot;:1}},{&quot;breakpoint&quot;:800,&quot;settings&quot;:{&quot;slidesToShow&quot;:3,&quot;slidesToScroll&quot;:3}},{&quot;breakpoint&quot;:992,&quot;settings&quot;:{&quot;slidesToShow&quot;:3,&quot;slidesToScroll&quot;:3}},{&quot;breakpoint&quot;:1200,&quot;settings&quot;:{&quot;slidesToShow&quot;:4,&quot;slidesToScroll&quot;:4}},{&quot;breakpoint&quot;:1400,&quot;settings&quot;:{&quot;slidesToShow&quot;:5,&quot;slidesToScroll&quot;:5}}]}">
                                <div class="brands">
                                    <?php foreach($brands as $brand):?>
                                    <div class="item">
                                        <a href="{{ route('front.brand',$brand->id) }}">
                                            <figure>
                                                <figcaption class="text-overlay">
                                                    <div class="info">
                                                        <h4>{{$brand->name}}</h4>
                                                    </div>
                                                    <!-- /.info -->
                                                </figcaption>
                                                <img width="145" height="50" class="img-responsive desaturate" alt="{{$brand->name}}" src="{{asset('assets/images/brands/'.$brand->photo)}}">
                                            </figure>
                                        </a>
                                    </div>
                                    <?php endforeach;?>
                                </div>
                            </div>
                            <!-- .col-full -->
                        </section>
    <!-- .col-full -->
</div>
<input type="hidden" id="get_attribute_combination" value="<?php echo URL('/getattributecombination')?>" />
<input type="hidden" id="add_to_cart" value="<?php echo URL('/addcart')?>" />
<input type="hidden" id="write_review" value="<?php echo URL('/writereview')?>" />
<input type="hidden" value="<?= $_SERVER['REMOTE_ADDR'];?>" id="ip_addr">
@endsection

@section('js')


@endsection
<script src="https://code.jquery.com/jquery-3.1.1.min.js" > </script>
<script type="text/javascript">
var product_attr = '<?= json_encode($prd_attr)?>';
var product_attribute_names = '<?= json_encode($product_attribute_names)?>';
var get_val = '<?php echo $sz ?>';
$(document).ready(function(){
					if (get_val !='') {
						console.log(get_val);
		$('.get_value').val(get_val);
		//document.getElementByClassName("get_value").value = get_val;
	}
})

</script>
<style type="text/css">

</style>