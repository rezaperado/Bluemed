<?php 
use App\Models\Category;
?>
@extends('layouts.front')
@section('body_class', 'page-template-template-homepage-v12')
@section('content')


<style>
.site-header.header-v10 {
    padding-bottom: 0;
}
</style>

<div class="col-full">
    <div class="row">
        
        <nav class="woocommerce-breadcrumb">
            <a href="<?= URL('/');?>">{{ __('messages.home') }}</a>
            <span class="delimiter">
                <i class="tm tm-breadcrumbs-arrow-right"></i>
            </span>
             Collections 
             
             <center><h3 style="margin-botoom:0px;">Collections</h3></center>
        </nav>
        
        
        <div id="primary" class="content-area">
            <main id="main" class="site-main">
                <?php 
                /*echo "<pre>";
                print_r($ps);exit;*/
                ?>
                  <div class="homev12-slider-with-banners row">
                   
                  <div class="category-slider main-browser-row" style="width: 100% !important;">
                        <div class="row justify-content-md-center">
                            <?php foreach($collection as $category):?>
                                
                          <div class="banner text-in-left" style="margin: 25px 25px;">
                                <a href="{{url('/')}}/collection/{{$category->id}}">
                                    <!--div class="top-small-banner" style=" background-image: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)),  url({{asset('assets/images/collections/'.$category['photo'])}}); height: 15em;" class="banner-bg p-0"-->
                                    <div class="top-small-banner" style=" background-image: url({{asset('assets/images/collections/'.$category['photo'])}}); height: 15em;" class="banner-bg p-0">
                                        <div class="caption w-100 text-center h-100">
                                            <div class="banner-info h-100 w-100">
                                               
                                               <!-- <h3 class="title m-b-0 <?= strlen($category['name'] > 10) ? 'style="padding:5.1rem 0 !important;"' : ''?>">
                                                    <strong>
                                                    <?php if(app()->getLocale() == 'ar'):?>
                                                        {{$category['name_ar']}}
                                                    <?php else:?>
                                                        {{$category['name']}}
                                                    <?php endif;?>
                                                    </strong>
                                                </h3>-->
                                            </div>
                                        </div>
                                        <!-- .caption -->
                                    </div>
                                    
                               <div style="background-color: #002534;
    / text-align: center; /
    / text-align: center; /
    vertical-align: middle;
    height: 50px;
    display: flex;
    justify-content: center;
    align-items: center;" >
                                        
                          <h6 style="color: white;
    padding: 15px">             <?php if(app()->getLocale() == 'ar'):?>
                                            {{substr($category['name_ar'], 0, 40)}}<?php if(strlen($category['name_ar'])>40){ echo '...';} ?>
                                        
                                        <?php else:?>
                                            {{substr($category['name'], 0, 40)}}<?php if(strlen($category['name_ar'])>40){ echo '...';} ?>
                                        <?php endif;?>
                                        
                                        
                                    </h6>
                                   </div>      
                                    
                                    
                                </a>
                            </div>
                            <?php endforeach;?>
                        </div>
                        
                    </div>
                   
                </div>
                
               

                
                
            </main>
            <!-- #main -->
        </div>
        <!-- #primary -->
    </div>
    <!-- .row -->

</div>


@endsection

@section('scripts')

@endsection