@extends('layouts.front')
@section('content')
<div class="col-full">
    <div class="row">
        <nav class="woocommerce-breadcrumb">
            <a href="<?= URL('/')?>">Home</a>
            <span class="delimiter">
                <i class="tm tm-breadcrumbs-arrow-right"></i>
            </span>Change Password
        </nav>
        <!-- .woocommerce-breadcrumb -->
        <div id="primary" class="content-area">
            <main id="main" class="site-main">
                <div class="shop-archive-header">
                    <div class="jumbotron">
                        <div class="jumbotron-img">
                            <img width="416" height="283" alt="" src="assets/images/products/jumbo.jpg" class="jumbo-image alignright">
                        </div>
                        <div class="jumbotron-caption w-100 p-20">
                            <h3 class="jumbo-title">Change Password</h3>
                            @if(session()->has('success'))
                                        <div class="alert alert-success">
                                            {{ session()->get('success') }}
                                        </div>
                                    @endif
                                    @if(session()->has('error'))
                                        <div class="alert alert-danger">
                                            {{ session()->get('error') }}
                                        </div>
                                    @endif
                            <form action="{{ route('user-reset-submit') }}" class="checkout woocommerce-checkout" method="post" name="checkout" id="change-password-form">
                            	{{ csrf_field() }}
                                <div id="customer_details" class="col2-set w-100">
                                    <div class="col-1">
                                        <div class="woocommerce-billing-fields">
                                            <div class="woocommerce-billing-fields__field-wrapper-outer">
                                                <div class="woocommerce-billing-fields__field-wrapper">
                                                    <p id="billing_first_name_field" class="form-row form-row-first validate-required">
                                                        <label class="" for="billing_first_name">Current Password
                                                            <abbr title="required" class="required">*</abbr>
                                                        </label>
                                                        <input type="password" value="" placeholder="" id="billing_first_name" name="current_password" class="input-text ">
                                                    </p>
                                                    <p id="billing_first_name_field" class="form-row form-row-first validate-required">
                                                        <label class="" for="billing_first_name">New Password
                                                            <abbr title="required" class="required">*</abbr>
                                                        </label>
                                                        <input type="password" value="" placeholder="" id="billing_first_name" name="new_password" class="input-text ">
                                                    </p>
                                                    <p id="billing_first_name_field" class="form-row form-row-first validate-required">
                                                        <label class="" for="billing_first_name">Confirm Password
                                                            <abbr title="required" class="required">*</abbr>
                                                        </label>
                                                        <input type="password" value="" placeholder="" id="billing_first_name" name="confirm_password" class="input-text ">
                                                    </p>
                                                    <p id="billing_first_name_field" class="form-row form-row-first validate-required">
                                                        <!-- <label class="" for="billing_first_name">Confirm Password
                                                            <abbr title="required" class="required">*</abbr>
                                                        </label>
                                                        <input type="password" value="" placeholder="" id="billing_first_name" name="confirm_password" class="input-text "> -->
                                                    </p>
                                                    <div class="clear"></div>
                                                    <p id="billing_email_field" class="form-row form-row-first validate-required validate-email">
                                                        <input class="woocommerce-Button button" type="submit" value="Submit">
                                                    </p>
                                                </div>
                                            </div>
                                            <!-- .woocommerce-billing-fields__field-wrapper-outer -->
                                        </div>
                                    </div>
                                    <!-- .col-2 -->
                                </div>
                                <!-- .woocommerce-checkout-review-order -->
                            </form>
                        </div>
                        <!-- .jumbotron-caption -->
                    </div>
                    <!-- .jumbotron -->
                </div>
            </main>
            <!-- #main -->
        </div>
        <!-- #primary -->
        <div id="secondary" class="widget-area shop-sidebar" role="complementary">
            <div class="widget woocommerce widget_product_categories techmarket_widget_product_categories" id="techmarket_product_categories_widget-2">
                <ul class="product-categories ">
                    <li class="product_cat">
                        <ul>
                        	<li class="cat-item">
                                <a href="{{route('user-profile')}}">
                                    <span class="no-child"></span>Dashboard
                                </a>
                            </li>
                            <li class="cat-item">
                                <a href="{{route('user-orderlist')}}">
                                    <span class="no-child"></span>My Orders
                                </a>
                            </li>
                            <li class="cat-item">
                                <a href="{{route('edit-profile')}}">
                                    <span class="no-child"></span>Edit Profile
                                </a>
                            </li>
                            <li class="cat-item">
                                <a href="{{route('change-password')}}">
                                    <span class="no-child"></span>Change Password
                                </a>
                            </li>
                            <li class="cat-item">
                                <a href="#">
                                    <span class="no-child"></span>Wishlist
                                </a>
                            </li>
                        </ul>
                    </li>
                </ul>
            </div>
            <!-- .widget_techmarket_products_carousel_widget -->
        </div>
        <!-- #secondary -->
    </div>
    <!-- .row -->
</div>
@endsection

@section('scripts')
	<script>
        
  </script>
@endsection