@extends('layouts.front')
@section('body_class', 'page home page-template-default')
@section('content')
<div class="col-full">
  <div class="row">
    <nav class="woocommerce-breadcrumb">
        <a href="<?= URL('/')?>">{{ __('messages.home') }}</a>
        <span class="delimiter">
            <i class="tm tm-breadcrumbs-arrow-right"></i>
        </span>
        {{ __('messages.faq') }}
    </nav>
      <div id="primary" class="content-area">
         <section class="faq-section">
            <div class="container">
              <div class="row justify-content-center">
                <div class="col-lg-8 col-md-10">
                  <div id="accordion">

                    @foreach($faqs as $fq)
                    <h3 class="heading">{{ $fq->title }}</h3>
                    <div class="content">
                      <p>{!! $fq->details !!}</p>
                    </div>
                    @endforeach
                  </div>
                </div>
              </div>
            </div>
          </section>
      </div>
  </div>
</div>


<!-- faq Area Start -->

<!-- faq Area End-->

@endsection