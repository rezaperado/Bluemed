@extends('layouts.front')
@section('body_class', 'left-sidebar')
@section('content')
<input type="hidden" id="add_to_cart" value="<?php echo URL('/addcart')?>" />
<!-- Breadcrumb Area Start -->
<style>
#grid-extended .add_to_cart_button{    margin: 0 auto 12px !important;}
</style>
<div class="col-full">
    <div class="row">
        <nav class="woocommerce-breadcrumb">
            <a href="<?= URL('/');?>">{{ __('messages.home') }}</a>
            <span class="delimiter">
                <i class="tm tm-breadcrumbs-arrow-right"></i>
            </span>
            {{ __('messages.search') }}
        </nav>
        <!-- .woocommerce-breadcrumb -->
        <div id="" class="content-area col-md-12">
            <main id="main" class="site-main">
                <div class="shop-control-bar">
                    <div class="handheld-sidebar-toggle">
                        <button type="button" class="btn sidebar-toggler">
                            <i class="fa fa-sliders"></i>
                            <span>{{ __('messages.filteres') }}</span>
                        </button>
                    </div>
                    <!-- .handheld-sidebar-toggle -->
                    <h1 class="woocommerce-products-header__title page-title">{{ __('messages.search') }}: {{$search}}</h1>
                    <ul role="tablist" class="shop-view-switcher nav nav-tabs">
                        <li class="nav-item">
                            <a href="#grid" title="Grid View" data-toggle="tab" class="nav-link <?= ($layout_type == 'grid') ? 'active' : ''?>">
                                <i class="tm tm-grid-small"></i>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="#grid-extended" title="Grid Extended View" data-toggle="tab" class="nav-link <?= ($layout_type == 'grid-extended') ? 'active' : ''?>">
                                <i class="tm tm-grid"></i>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="#list-view-large" title="List View Large" data-toggle="tab" class="nav-link <?= ($layout_type == 'list-view-large') ? 'active' : ''?>">
                                <i class="tm tm-listing-large"></i>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="#list-view" title="List View" data-toggle="tab" class="nav-link <?= ($layout_type == 'list-view') ? 'active' : ''?>">
                                <i class="tm tm-listing"></i>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="#list-view-small" title="List View Small" data-toggle="tab" class="nav-link <?= ($layout_type == 'list-view-small') ? 'active' : ''?>">
                                <i class="tm tm-listing-small"></i>
                            </a>
                        </li>
                    </ul>
                    <!-- .shop-view-switcher -->
                    <form class="form-techmarket-wc-ppp" method="POST">
                        <select class="techmarket-wc-wppp-select c-select page_length" name="page_length">
                            <option value="20" <?= ($page_length == 20) ? 'selected' : ''?>>{{ __('messages.show') }} 20</option>
                            <option value="40" <?= ($page_length == 40) ? 'selected' : ''?>>{{ __('messages.show') }} 40</option>
                            <option value="all" <?= ($page_length == 'all') ? 'selected' : ''?>>{{ __('messages.show_all') }}</option>
                        </select>
                        <input type="hidden" value="5" name="shop_columns">
                        <input type="hidden" value="15" name="shop_per_page">
                        <input type="hidden" value="right-sidebar" name="shop_layout">
                    </form>
                    <!-- .form-techmarket-wc-ppp -->
                    <form method="get" class="woocommerce-ordering">
                        <select class="orderby" name="sort" id="sort_by">
                            <option value="alphabet" <?= ($sort == 'alphabet') ? 'selected' : ''?>>{{ __('messages.sort_by_alphabet_asc') }}</option>
                            <option value="alphabet-desc" <?= ($sort == 'alphabet-desc') ? 'selected' : ''?>>{{ __('messages.sort_by_alphabet_desc') }}</option>
                            <option value="featured" <?= ($sort == 'featured') ? 'selected' : ''?>>{{ __('messages.sort_by_featured') }}</option>
                            <option value="promotional" <?= ($sort == 'promotional') ? 'selected' : ''?>>{{ __('messages.sort_by_promotional') }}</option>
                            <option value="popularity" <?= ($sort == 'popularity') ? 'selected' : ''?>>{{ __('messages.sort_by_popular') }}</option>
                            <option value="rating" <?= ($sort == 'rating') ? 'selected' : ''?>>{{ __('messages.sort_by_rating') }}</option>
                            <option value="date" <?= ($sort == 'date') ? 'selected' : ''?>>{{ __('messages.sort_by_new') }}</option>
                            <option value="price" <?= ($sort == 'price') ? 'selected' : ''?>>{{ __('messages.sort_by_price_low_to_high') }}</option>
                            <option value="price-desc" <?= ($sort == 'price-desc') ? 'selected' : ''?>>{{ __('messages.sort_by_price_high_to_low') }}</option>
                        </select>
                        <input type="hidden" value="5" name="shop_columns">
                        <input type="hidden" value="15" name="shop_per_page">
                        <input type="hidden" value="right-sidebar" name="shop_layout">
                    </form>
                    <!-- .woocommerce-ordering -->
                    <nav class="techmarket-advanced-pagination">
                        <form class="form-adv-pagination" method="post">
                            <input type="number" value="1" class="form-control" step="1" max="5" min="1" size="2" id="goto-page">
                        </form> of 5<a href="#" class="next page-numbers">→</a>
                    </nav>
                    <!-- .techmarket-advanced-pagination -->
                </div>
                <!-- .shop-control-bar -->
                <div class="tab-content">
                    <div id="grid" class="tab-pane <?= ($layout_type == 'grid') ? 'active' : ''?>" role="tabpanel">
                        <div class="woocommerce columns-5">
                            <div class="products">
                                <?php if($products->count() > 0):?>
                                <?php foreach($products as $product):?>
                                    <?php
                                    $price = getVariationPrice($product->id);
                                    $variation = getVariation($product->id);
                                    $attr = isset($variation['attr']) ? $variation['attr'] : '';
                                    $total_stock = isset($variation['total_stock']) ? $variation['total_stock'] : 0;

                                    ?>
                                    <div class="product first">
                                        <form class="variations_form cart" id="variations_form">
                                        <input type="hidden" name="product_price" id="hidden_price" value="{{$price}}">
                                        <input type="hidden" name="quantity" id="hidden_price" value="1">
                                        <input name="_token" type="hidden" value="{{ csrf_token() }}"/>
                                        <input type="hidden" value="{{$product->id}}" name="product_id">
                                        <input type="hidden" name="total_stock" id="total_stock" value="{{$total_stock}}">
                                        <?php if(!empty($attr)):?>
                                        <?php foreach($attr as $key=>$val):?>
                                            <input type="hidden" name="attr[<?= $key?>]" value="<?= $val?>">
                                        <?php endforeach;?>
                                        <?php endif;?>
                                        <div class="yith-wcwl-add-to-wishlist">
                                            <a rel="nofollow" class="pointer add_to_wishlist btn-add-wishlist" data-id="{{$product->id}}"> Add to Wishlist</a>
                                        </div>
                                        <!-- .yith-wcwl-add-to-wishlist -->
                                        <a class="woocommerce-LoopProduct-link woocommerce-loop-product__link" href="{{ route('front.product', $product->id) }}">
                                            <?php $discount = $product->previous_price-$price;?>
                                            <?php if(isset($product->previous_price) && !empty($product->previous_price) && $discount > 0):?>
                                                    <span class="woocommerce-Price-amount amount">
                                                        <span class="woocommerce-Price-currencySymbol">
                                                            <?= $curr;?>
                                                        </span>
                                                        <?= number_format(((float)$product->previous_price - (float)$price) ,3);?>
                                                    </span>
                                                </span>
                                            <?php endif;?>
                                            <img width="224" height="197" alt="" class="attachment-shop_catalog size-shop_catalog wp-post-image" src="{{asset('assets/images/products/'.$product->photo)}}">
                                            <?php if(isset($product->previous_price) && !empty($product->previous_price)):?>
                                                <span class="price">
                                                    <ins>
                                                        <span class="woocommerce-Price-currencySymbol">{{$curr}}</span>
                                                        <span class="amount">{{number_format($price,3)}}</span>
                                                    </ins>
                                                    <?php if($price < $product->previous_price):?>
                                                    <del>
                                                        <span class="woocommerce-Price-currencySymbol">{{$curr}}</span>
                                                        <span class="amount">{{number_format($product->previous_price,3)}}</span>
                                                    </del>
                                                <?php endif;?>
                                                    <span class="amount"> </span>
                                                </span>
                                            <?php else:?>
                                                <span class="price">
                                                    <ins>
                                                        <span class="amount"> </span>
                                                    </ins>
                                                    <span class="woocommerce-Price-currencySymbol">{{$curr}}</span>
                                                    <span class="amount">{{number_format($price , 3)}}</span>
                                                </span>
                                            <?php endif;?>
                                            <h2 class="woocommerce-loop-product__title">
                                                <?php if(app()->getLocale() == 'ar'):?>
                                                    {{$product->name_ar}}
                                                <?php else:?>
                                                    {{$product->name}}
                                                <?php endif;?>
                                            </h2>
                                        </a>
                                        <!-- .woocommerce-LoopProduct-link -->
                                        <div class="hover-area">
                                            <?php
                                        $stock = getProductStock($product->id);
                                        ?>
                                            <button class="button add_to_cart_button" type="button" <?= ($stock==0) ? 'disabled' : ''?>>Add to cart</button>
                                            <a class="add-to-compare-link" href="#">Add to compare</a>
                                        </div>
                                        </form>
                                        <!-- .hover-area -->
                                    </div>
                                <?php endforeach;?>
                                <?php else:?>
                                    <p class="no-prd"> No products available</p>
                                <?php endif;?>
                            </div>
                            <!-- .products -->
                        </div>
                        <!-- .woocommerce -->
                    </div>
                    <!-- .tab-pane -->
                    <div id="grid-extended" class="tab-pane <?= ($layout_type == 'grid-extended') ? 'active' : ''?>" role="tabpanel">
                        <div class="woocommerce columns-5">
                            <div class="products">
                                <?php if($products->count() > 0):?>
                                <?php foreach($products as  $product):?>
                                    <?php
                                    $price = getVariationPrice($product->id);
                                    $variation = getVariation($product->id);
                                    $attr = isset($variation['attr']) ? $variation['attr'] : '';
                                    $total_stock = isset($variation['total_stock']) ? $variation['total_stock'] : 0;
                                    $wishlist = checkProductWishlist($product->id);
                                    ?>
                                <div class="product">
                                    <form class="variations_form cart" id="variations_form">
                                        <input type="hidden" name="product_price" id="hidden_price" value="{{$price}}">
                                        <input type="hidden" name="quantity" id="hidden_price" value="1">
                                        <input name="_token" type="hidden" value="{{ csrf_token() }}"/>
                                        <input type="hidden" value="{{$product->id}}" name="product_id">
                                        <input type="hidden" name="total_stock" id="total_stock" value="{{$total_stock}}">
                                        <?php if(!empty($attr)):?>
                                        <?php foreach($attr as $key=>$val):?>
                                            <input type="hidden" name="attr[<?= $key?>]" value="<?= $val?>">
                                        <?php endforeach;?>
                                        <?php endif;?>
                                    <div class="yith-wcwl-add-to-wishlist">
                                        <a rel="nofollow" class="pointer add_to_wishlist btn-add-wishlist <?= ($wishlist > 0) ? 'wishlist-added':''?>" data-id="{{$product->id}}"> Add to Wishlist</a>
                                    </div>
                                    <!-- .yith-wcwl-add-to-wishlist -->
                                    <a class="woocommerce-LoopProduct-link woocommerce-loop-product__link" href="{{ route('front.product', $product->id) }}">
                                        <?php $discount = $product->previous_price-$price;?>
                                            <?php if(isset($product->previous_price) && !empty($product->previous_price) && $discount > 0):?>
                                            <span class="onsale">
                                                <span class="woocommerce-Price-amount amount">
                                                    <span class="woocommerce-Price-currencySymbol">{{$curr}}</span><?= number_format(((float)$product->previous_price - (float)$price) ,3);?>
                                                </span>
                                            </span>
                                        <?php endif;?>
                                        <img width="224" height="197" alt="" class="attachment-shop_catalog size-shop_catalog wp-post-image" src="{{asset('assets/images/products/'.$product->photo)}}">
                                        <?php if(isset($product->previous_price) && !empty($product->previous_price)):?>
                                            <span class="price">
                                                <ins>
                                                    <span class="woocommerce-Price-currencySymbol">{{$curr}}</span>
                                                    <span class="amount">{{number_format($price,3)}}</span>
                                                </ins>
                                                <?php if($price < $product->previous_price):?>
                                                <del>
                                                    <span class="amount">{{number_format($product->previous_price,3)}}</span>
                                                </del>
                                            <?php endif;?>
                                                <span class="amount"> </span>
                                            </span>
                                        <?php else:?>
                                            <span class="price">
                                                <ins>
                                                    <span class="amount"> </span>
                                                </ins>
                                                <span class="woocommerce-Price-currencySymbol">{{$curr}}</span>
                                                <span class="amount">{{number_format($price ,3)}}</span>
                                            </span>
                                        <?php endif;?>
                                        <h2 class="woocommerce-loop-product__title">
                                            <?php if(app()->getLocale() == 'ar'):?>
                                                {{$product->name_ar}}
                                            <?php else:?>
                                                {{$product->name}}
                                            <?php endif;?>
                                        </h2>
                                    </a>
                                    <!-- .woocommerce-LoopProduct-link -->
                                    <div class="techmarket-product-rating">
                                        <div title="Rated 5.00 out of 5" class="star-rating">
                                            <span style="width:100%">
                                                <strong class="rating">5.00</strong> out of 5</span>
                                        </div>
                                        <span class="review-count">(1)</span>
                                    </div>
                                    <!-- .techmarket-product-rating -->
                                    <span class="sku_wrapper">SKU:
                                        <span class="sku">{{$product->sku}}</span>
                                    </span>
                                    <div class="woocommerce-product-details__short-description">
                                        <?php echo htmlspecialchars_decode(stripslashes($product->product_info));?>
                                    </div>
                                    <?php
                                        $stock = getProductStock($product->id);
                                        ?>
                                            <button class="button add_to_cart_button" type="button" <?= ($stock==0) ? 'disabled' : ''?>>Add to cart</button>
                                            <a class="add-to-compare-link" href="#">Add to compare</a>
                                    </form>
                                </div>
                                <?php endforeach;?>
                                <?php else:?>
                                    <p class="no-prd">No products available</p>
                                <?php endif;?>
                                <!-- .product -->
                            </div>
                            <!-- .products -->
                        </div>
                        <!-- .woocommerce -->
                    </div>
                    <!-- .tab-pane -->
                    <div id="list-view-large" class="tab-pane <?= ($layout_type == 'list-view-large') ? 'active' : ''?>" role="tabpanel">
                        <div class="woocommerce columns-1">
                            <div class="products">
                                <?php if($products->count() > 0):?>
                                <?php foreach($products as  $product):?>
                                    <?php
                                    $price = getVariationPrice($product->id);
                                    $variation = getVariation($product->id);
                                    $attr = isset($variation['attr']) ? $variation['attr'] : '';
                                    $total_stock = isset($variation['total_stock']) ? $variation['total_stock'] : 0;
                                    $wishlist = checkProductWishlist($product->id);
                                    ?>
                                <div class="product list-view-large">
                                    <form class="variations_form cart" id="variations_form">
                                        <input type="hidden" name="product_price" id="hidden_price" value="{{$price}}">
                                        <input type="hidden" name="quantity" id="hidden_price" value="1">
                                        <input name="_token" type="hidden" value="{{ csrf_token() }}"/>
                                        <input type="hidden" value="{{$product->id}}" name="product_id">
                                        <input type="hidden" name="total_stock" id="total_stock" value="{{$total_stock}}">
                                        <?php if(!empty($attr)):?>
                                        <?php foreach($attr as $key=>$val):?>
                                            <input type="hidden" name="attr[<?= $key?>]" value="<?= $val?>">
                                        <?php endforeach;?>
                                        <?php endif;?>
                                    <div class="media">
                                        <img width="224" height="197" alt="" class="attachment-shop_catalog size-shop_catalog wp-post-image" src="{{asset('assets/images/products/'.$product->photo)}}">
                                        <div class="media-body">
                                            <div class="product-info">
                                                <div class="yith-wcwl-add-to-wishlist">
                                                    <a rel="nofollow" class="pointer add_to_wishlist btn-add-wishlist <?= ($wishlist > 0) ? 'wishlist-added':''?>" data-id="{{$product->id}}"> Add to Wishlist</a>
                                                </div>
                                                <!-- .yith-wcwl-add-to-wishlist -->
                                                <a class="woocommerce-LoopProduct-link woocommerce-loop-product__link" href="{{ route('front.product', $product->id) }}">
                                                    <h2 class="woocommerce-loop-product__title">
                                                        <?php if(app()->getLocale() == 'ar'):?>
                                                            {{$product->name_ar}}
                                                        <?php else:?>
                                                            {{$product->name}}
                                                        <?php endif;?>
                                                    </h2>
                                                    <div class="techmarket-product-rating">
                                                        <div title="Rated 5.00 out of 5" class="star-rating">
                                                            <span style="width:100%">
                                                                <strong class="rating">5.00</strong> out of 5</span>
                                                        </div>
                                                        <span class="review-count">(1)</span>
                                                    </div>
                                                </a>
                                                <!-- .woocommerce-LoopProduct-link -->
                                                <?php $brand = getBrandByProduct($product->id);?>
                                                <?php if(!empty($brand)):?>
                                                <div class="brand">
                                                    <a href="#">
                                                        <img alt="galaxy" src="{{asset('assets/images/brands/'.$brand->photo)}}">
                                                    </a>
                                                </div>
                                                <?php endif;?>
                                                <!-- .brand -->
                                                <div class="woocommerce-product-details__short-description">
                                                    <?php echo htmlspecialchars_decode(stripslashes($product->product_info));?>
                                                </div>
                                                <!-- .woocommerce-product-details__short-description -->
                                                <span class="sku_wrapper">SKU:
                                                    <span class="sku">{{$product->sku}}</span>
                                                </span>
                                            </div>
                                            <!-- .product-info -->
                                            <div class="product-actions">
                                                <div class="availability">
                                                    Availability:
                                                    <p class="stock in-stock">
                                                        <?php if((isset($product->stock) && $product->stock > 0) || $product->stock == ''):?>
                                                        <span class="total-stock"><?= $product->stock?></span>
                                                        in stock
                                                        <?php else:?>
                                                            out stock
                                                        <?php endif;?>
                                                    </p>
                                                </div>
                                                <?php if(isset($product->previous_price) && !empty($product->previous_price)):?>
                                                    <span class="price">
                                                        <ins>
                                                            <span class="woocommerce-Price-currencySymbol">{{$curr}}</span>
                                                            <span class="amount">{{number_format($price,3)}}</span>
                                                        </ins>
                                                        <?php if($price < $product->previous_price):?>
                                                        <del>
                                                            <span class="amount">{{number_format($product->previous_price,3)}}</span>
                                                        </del>
                                                    <?php endif;?>
                                                        <span class="amount"> </span>
                                                    </span>
                                                <?php else:?>
                                                    <span class="price">
                                                        <ins>
                                                            <span class="amount"> </span>
                                                        </ins>
                                                        <span class="woocommerce-Price-currencySymbol">{{$curr}}</span>
                                                        <span class="amount">{{number_format($price , 3)}}</span>
                                                    </span>
                                                <?php endif;?>
                                                <!-- .price -->
                                                <?php
                                                $stock = getProductStock($product->id);
                                                ?>
                                            <button class="button add_to_cart_button" type="button" <?= ($stock==0) ? 'disabled' : ''?>>Add to cart</button>
                                            <a class="add-to-compare-link" href="#">Add to compare</a>
                                            </div>
                                            <!-- .product-actions -->
                                        </div>
                                        <!-- .media-body -->
                                    </div>
                                    <!-- .media -->
                                    </form>
                                </div>
                                <?php endforeach;?>
                                <?php else:?>
                                    <p class="no-prd"> No products available</p>
                                <?php endif;?>
                                <!-- .product -->
                            </div>
                            <!-- .products -->
                        </div>
                        <!-- .woocommerce -->
                    </div>
                    <!-- .tab-pane -->
                    <div id="list-view" class="tab-pane <?= ($layout_type == 'list-view') ? 'active' : ''?>" role="tabpanel">
                        <div class="woocommerce columns-1">
                            <div class="products">
                                <?php if($products->count() > 0):?>
                                <?php foreach($products as  $product):?>
                                    <?php
                                    $price = getVariationPrice($product->id);
                                    $variation = getVariation($product->id);
                                    $attr = isset($variation['attr']) ? $variation['attr'] : '';
                                    $total_stock = isset($variation['total_stock']) ? $variation['total_stock'] : 0;
                                    $wishlist = checkProductWishlist($product->id);
                                    ?>
                                <div class="product list-view ">
                                    <form class="variations_form cart" id="variations_form">
                                        <input type="hidden" name="product_price" id="hidden_price" value="{{$price}}">
                                        <input type="hidden" name="quantity" id="hidden_price" value="1">
                                        <input name="_token" type="hidden" value="{{ csrf_token() }}"/>
                                        <input type="hidden" value="{{$product->id}}" name="product_id">
                                        <input type="hidden" name="total_stock" id="total_stock" value="{{$total_stock}}">
                                        <?php if(!empty($attr)):?>
                                        <?php foreach($attr as $key=>$val):?>
                                            <input type="hidden" name="attr[<?= $key?>]" value="<?= $val?>">
                                        <?php endforeach;?>
                                        <?php endif;?>
                                    <div class="media">
                                        <img width="224" height="197" alt="" class="attachment-shop_catalog size-shop_catalog wp-post-image" src="{{asset('assets/images/products/'.$product->photo)}}">
                                        <div class="media-body">
                                            <div class="product-info">
                                                <div class="yith-wcwl-add-to-wishlist">
                                                    <a rel="nofollow" class="pointer add_to_wishlist btn-add-wishlist <?= ($wishlist > 0) ? 'wishlist-added':''?>" data-id="{{$product->id}}"> Add to Wishlist</a>
                                                </div>
                                                <!-- .yith-wcwl-add-to-wishlist -->
                                                <a class="woocommerce-LoopProduct-link woocommerce-loop-product__link" href="{{ route('front.product', $product->id) }}">
                                                    <h2 class="woocommerce-loop-product__title">
                                                        <?php if(app()->getLocale() == 'ar'):?>
                                                            {{$product->name_ar}}
                                                        <?php else:?>
                                                            {{$product->name}}
                                                        <?php endif;?>
                                                    </h2>
                                                    <div class="techmarket-product-rating">
                                                        <div title="Rated 5.00 out of 5" class="star-rating">
                                                            <span style="width:100%">
                                                                <strong class="rating">5.00</strong> out of 5</span>
                                                        </div>
                                                        <span class="review-count">(1)</span>
                                                    </div>
                                                </a>
                                                <!-- .woocommerce-LoopProduct-link -->
                                                <?php $brand = getBrandByProduct($product->id);?>
                                                <?php if(!empty($brand)):?>
                                                <div class="brand">
                                                    <a href="#">
                                                        <img alt="galaxy" src="{{asset('assets/images/brands/'.$brand->photo)}}">
                                                    </a>
                                                </div>
                                                <?php endif;?>
                                                <!-- .brand -->
                                                <div class="woocommerce-product-details__short-description">
                                                    <?php echo htmlspecialchars_decode(stripslashes($product->product_info));?>
                                                </div>
                                                <!-- .woocommerce-product-details__short-description -->
                                            </div>
                                            <!-- .product-info -->
                                            <div class="product-actions">
                                                <div class="availability">
                                                    Availability:
                                                    <p class="stock in-stock">
                                                        <?php if((isset($product->stock) && $product->stock > 0) || $product->stock == ''):?>
                                                        <span class="total-stock"><?= $product->stock?></span>
                                                        in stock
                                                        <?php else:?>
                                                            out stock
                                                        <?php endif;?>
                                                    </p>
                                                </div>
                                                <?php if(isset($product->previous_price) && !empty($product->previous_price)):?>
                                                    <span class="price">
                                                        <ins>
                                                            <span class="woocommerce-Price-currencySymbol">{{$curr}}</span>
                                                            <span class="amount">{{number_format($price,3)}}</span>
                                                        </ins>
                                                        <?php if($price < $product->previous_price):?>
                                                        <del>
                                                            <span class="amount">{{number_format($product->previous_price,3)}}</span>
                                                        </del>
                                                    <?php endif;?>
                                                        <span class="amount"> </span>
                                                    </span>
                                                <?php else:?>
                                                    <span class="price">
                                                        <ins>
                                                            <span class="amount"> </span>
                                                        </ins>
                                                        <span class="woocommerce-Price-currencySymbol">{{$curr}}</span>
                                                        <span class="amount">{{number_format($price , 3)}}</span>
                                                    </span>
                                                <?php endif;?>
                                               <?php
                                                $stock = getProductStock($product->id);
                                                ?>
                                            <button class="button add_to_cart_button" type="button" <?= ($stock==0) ? 'disabled' : ''?>>Add to cart</button>
                                            <a class="add-to-compare-link" href="#">Add to compare</a>
                                            </div>
                                            <!-- .product-actions -->
                                        </div>
                                        <!-- .media-body -->
                                    </div>
                                    <!-- .media -->
                                    </form>
                                </div>
                                <?php endforeach;?>
                                <?php else:?>
                                    <p class="no-prd"> No products available</p>
                                <?php endif;?>
                                <!-- .product -->
                            </div>
                            <!-- .products -->
                        </div>
                        <!-- .woocommerce -->
                    </div>
                    <!-- .tab-pane -->
                    <div id="list-view-small" class="tab-pane <?= ($layout_type == 'list-view-small') ? 'active' : ''?>" role="tabpanel">
                        <div class="woocommerce columns-1">
                            <div class="products">
                                <?php if($products->count() > 0):?>
                                <?php foreach($products as  $product):?>
                                    <?php
                                    $price = getVariationPrice($product->id);
                                    $variation = getVariation($product->id);
                                    $attr = isset($variation['attr']) ? $variation['attr'] : '';
                                    $total_stock = isset($variation['total_stock']) ? $variation['total_stock'] : 0;
                                    $wishlist = checkProductWishlist($product->id);
                                    ?>
                                <div class="product list-view-small ">
                                    <form class="variations_form cart" id="variations_form">
                                        <input type="hidden" name="product_price" id="hidden_price" value="{{$price}}">
                                        <input type="hidden" name="quantity" id="hidden_price" value="1">
                                        <input name="_token" type="hidden" value="{{ csrf_token() }}"/>
                                        <input type="hidden" value="{{$product->id}}" name="product_id">
                                        <input type="hidden" name="total_stock" id="total_stock" value="{{$total_stock}}">
                                        <?php if(!empty($attr)):?>
                                        <?php foreach($attr as $key=>$val):?>
                                            <input type="hidden" name="attr[<?= $key?>]" value="<?= $val?>">
                                        <?php endforeach;?>
                                        <?php endif;?>
                                    <div class="media">
                                        <img width="224" height="197" alt="" class="attachment-shop_catalog size-shop_catalog wp-post-image" src="{{asset('assets/images/products/'.$product->photo)}}">
                                        <div class="media-body">
                                            <div class="product-info">
                                                <div class="yith-wcwl-add-to-wishlist">
                                                    <a rel="nofollow" class="pointer add_to_wishlist btn-add-wishlist <?= ($wishlist > 0) ? 'wishlist-added':''?>" data-id="{{$product->id}}"> Add to Wishlist</a>
                                                </div>
                                                <!-- .yith-wcwl-add-to-wishlist -->
                                                <a class="woocommerce-LoopProduct-link woocommerce-loop-product__link" href="{{ route('front.product', $product->id) }}">
                                                    <h2 class="woocommerce-loop-product__title">
                                                        <?php if(app()->getLocale() == 'ar'):?>
                                                            {{$product->name_ar}}
                                                        <?php else:?>
                                                            {{$product->name}}
                                                        <?php endif;?>
                                                    </h2>
                                                    <div class="techmarket-product-rating">
                                                        <div title="Rated 5.00 out of 5" class="star-rating">
                                                            <span style="width:100%">
                                                                <strong class="rating">5.00</strong> out of 5</span>
                                                        </div>
                                                        <span class="review-count">(1)</span>
                                                    </div>
                                                </a>
                                                <!-- .woocommerce-LoopProduct-link -->
                                                <div class="woocommerce-product-details__short-description">
                                                    <?php echo htmlspecialchars_decode(stripslashes($product->product_info));?>
                                                </div>
                                                <!-- .woocommerce-product-details__short-description -->
                                            </div>
                                            <!-- .product-info -->
                                            <div class="product-actions">
                                                <?php if(isset($product->previous_price) && !empty($product->previous_price)):?>
                                                    <span class="price">
                                                        <ins>
                                                            <span class="woocommerce-Price-currencySymbol">{{$curr}}</span>
                                                            <span class="amount">{{number_format($price,3)}}</span>
                                                        </ins>
                                                        <?php if($price < $product->previous_price):?>
                                                        <del>
                                                            <span class="amount">{{number_format($product->previous_price,3)}}</span>
                                                        </del>
                                                    <?php endif;?>
                                                        <span class="amount"> </span>
                                                    </span>
                                                <?php else:?>
                                                    <span class="price">
                                                        <ins>
                                                            <span class="amount"> </span>
                                                        </ins>
                                                        <span class="woocommerce-Price-currencySymbol">{{$curr}}</span>
                                                        <span class="amount">{{number_format($price , 3)}}</span>
                                                    </span>
                                                <?php endif;?>
                                                <?php
                                                $stock = getProductStock($product->id);
                                                ?>
                                            <button class="button add_to_cart_button" type="button" <?= ($stock==0) ? 'disabled' : ''?>>Add to cart</button>
                                            <a class="add-to-compare-link" href="#">Add to compare</a>
                                            </div>
                                            <!-- .product-actions -->
                                        </div>
                                        <!-- .media-body -->
                                    </div>
                                    <!-- .media -->
                                    </form>
                                </div>
                                <?php endforeach;?>
                                <?php else:?>
                                    <p class="no-prd"> No products available</p>
                                <?php endif;?>
                                <!-- .product -->
                            </div>
                            <!-- .products -->
                        </div>
                        <!-- .woocommerce -->
                    </div>
                    <!-- .tab-pane -->
                </div>
                <!-- .tab-content -->
                <div class="shop-control-bar-bottom">
                    <form class="form-techmarket-wc-ppp" method="POST">
                        <select class="techmarket-wc-wppp-select c-select page_length" name="page_length">
                            <option value="20" <?= ($page_length == 20) ? 'selected' : ''?>>Show 20</option>
                            <option value="40" <?= ($page_length == 40) ? 'selected' : ''?>>Show 40</option>
                            <option value="all" <?= ($page_length == 'all') ? 'selected' : ''?>>Show All</option>
                        </select>
                        <input type="hidden" value="5" name="shop_columns">
                        <input type="hidden" value="15" name="shop_per_page">
                        <input type="hidden" value="right-sidebar" name="shop_layout">
                    </form>
                    <!-- .form-techmarket-wc-ppp -->
                    <p class="woocommerce-result-count">
                        Showing {{ $products->firstItem() }} &ndash; {{ $products->lastItem() }} of {{ $products->total() }} (results)
                    </p>
                    <!-- .woocommerce-result-count -->
                    <nav class="woocommerce-pagination">
                        {{ $products->appends(request()->input())->links('front.pagination') }}
                    </nav>
                    <!-- .woocommerce-pagination -->
                </div>
                <!-- .shop-control-bar-bottom -->
            </main>
            <!-- #main -->
        </div>
        <!-- #secondary -->
    </div>
    <!-- .row -->
</div>
<!-- SubCategori Area End -->
@endsection

@section('scripts')

<script type="text/javascript">
	$("#sortby").on('change', function () {
		var sort = $("#sortby").val();
		@if(empty($sort))
		window.location = window.location.href + '&sort=' + sort;
		@else
		var url = window.location.href.split("&sort");;
		window.location = url[0] + '&sort=' + sort;
		@endif
	});

	$(function () {
		$("#slider-range").slider({
			range: true,
			orientation: "horizontal",
			min: 0,
			max: 1000,
			values: [{
				{
					isset($_GET['min']) ? $_GET['min'] : '0'
				}
			}, {
				{
					isset($_GET['max']) ? $_GET['max'] : '1000'
				}
			}],
			step: 5,

			slide: function (event, ui) {
				if (ui.values[0] == ui.values[1]) {
					return false;
				}

				$("#min_price").val(ui.values[0]);
				$("#max_price").val(ui.values[1]);
			}
		});

		$("#min_price").val($("#slider-range").slider("values", 0));
		$("#max_price").val($("#slider-range").slider("values", 1));

	});
</script>

@endsection