@extends('layouts.front')
@section('body_class', 'page home page-template-default')
@section('content')
<div class="col-full">
    <div class="row">
        <nav class="woocommerce-breadcrumb">
            <a href="<?= URL('/')?>">{{ __('messages.home') }}</a>
            <span class="delimiter">
                <i class="tm tm-breadcrumbs-arrow-right"></i>
            </span>
            {{ __('messages.cart') }}
        </nav>
        <!-- .woocommerce-breadcrumb -->
        <div id="primary" class="content-area">
            <main id="main" class="site-main">
                <div class="type-page hentry">
                    <div class="entry-content">
                        <div class="woocommerce">
                            <div class="cart-wrapper">
                                <?php if((isset($products)) && !empty($products)):?>
                                <form method="get" action="#" class="woocommerce-cart-form">
                                    <table class="shop_table shop_table_responsive cart">
                                        <thead>
                                            <tr>
                                                <th class="product-remove">&nbsp;</th>
                                                <th class="product-thumbnail">&nbsp;</th>
                                                <th class="product-name">{{ __('messages.product') }}</th>
                                                <th class="product-price">{{ __('messages.price') }}</th>
                                                <th class="product-quantity">{{ __('messages.quantity') }}</th>
                                                <th class="product-subtotal">{{ __('messages.total') }}</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                          
                                          <?php 
                                          $total_price = 0;
                                          foreach($products as $key => $product):?>
                                            <?php 
                                            $qty = $product['qty'];
                                            $price = $product['price'];
                                            $stock = $product['stock'];
                                            $item = $product['item'];
                                            $unit_price = $product['unit_price'];
                                            $variations = (isset($product['variations']) && !empty($product['variations'])) ? $product['variations'] : '';
                                          /*echo "<pre>";
                                          print_r($variations);exit;*/
                                          ?>
                                            <tr id="item_row_{{$item->id}}">
                                                <td class="product-remove">
                                                    <a class="remove" href="#">×</a>
                                                </td>
                                                <td class="product-thumbnail">
                                                    <a href="{{ route('front.product', $item->id) }}">
                                                        <img width="180" height="180" alt="" class="wp-post-image" src="{{asset('assets/images/products/'.$item->photo)}}">
                                                    </a>
                                                </td>
                                                <td data-title="{{ __('messages.product') }}" class="product-name">
                                                    <div class="media cart-item-product-detail">
                                                        <a href="{{ route('front.product', $item->id) }}">
                                                            <img width="180" height="180" alt="" class="wp-post-image" src="{{asset('assets/images/products/'.$item->photo)}}">
                                                        </a>
                                                        <div class="media-body align-self-center">
                                                            <a href="{{ route('front.product', $item->id) }}">
                                                              <?php if(app()->getLocale() == 'ar'):?>
                                                                  {{$item->name_ar}}
                                                              <?php else:?>
                                                                  {{$item->name}}
                                                              <?php endif;?>
                                                            </a>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td data-title="{{ __('messages.price') }}" class="product-price">
                                                    <span class="woocommerce-Price-amount amount">
                                                        <span class="woocommerce-Price-currencySymbol">{{$curr}}</span>{{number_format($unit_price,3)}}
                                                    </span>
                                                </td>
                                                <td class="product-quantity" data-title="{{ __('messages.quantity') }}">
                                                    <div class="quantity">
                                                        <label for="quantity-input-2">Quantity</label>
                                                        <input id="quantity-input-2" type="number" name="cart[e2230b853516e7b05d79744fbd4c9c13][qty]" value="{{$qty}}" title="Qty" class="input-text qty text product-qty" data-productid="{{$item->id}}"  data-price="{{$unit_price}}" data-stock="{{$stock}}" size="4">
                                                    </div>
                                                </td>
                                                <td data-title="{{ __('messages.total') }}" class="product-subtotal">
                                                    <span class="woocommerce-Price-amount amount">
                                                        <span class="woocommerce-Price-currencySymbol">{{$curr}}</span><span id="sub_total_{{$item->id}}">
                                                        {{number_format(($qty*$unit_price),3)}}</span>
                                                        <?php
                                                        $total_price+= number_format(($qty*$unit_price),2);
                                                        ?>
                                                    </span>
                                                    <a title="Remove this item" class="pointer remove remove-product" data-id="{{$item->id}}" data-href="{{ route('product.cart.remove',$product['item']['id']) }}" >×</a>
                                                </td>
                                            </tr>
                                          <?php endforeach;?>
                                        </tbody>
                                    </table>
                                    <!-- .shop_table shop_table_responsive -->
                                </form>
                                <!-- .woocommerce-cart-form -->
                                <div class="cart-collaterals">
                                    <div class="cart_totals">
                                        <h2>{{ __('messages.cart_total') }}</h2>
                                        <table class="shop_table shop_table_responsive">
                                            <tbody>
                                                <tr class="cart-subtotal">
                                                    <th>{{ __('messages.subtotal') }}</th>
                                                    <td data-title="{{ __('messages.subtotal') }}">
                                                        <span class="woocommerce-Price-amount amount">
                                                            <span class="woocommerce-Price-currencySymbol">{{$curr}}</span><span id="sub_total">{{number_format($total_price,3)}}</span></span>
                                                    </td>
                                                </tr>
                                                <?php if(!empty($shipping_data) && isset($shipping_data->title)):?>
                                                <!-- <tr class="cart-subtotal">
                                                    <th>{{$shipping_data->title}}</th>
                                                    <td data-title="Shipping"><span class="woocommerce-Price-amount amount">
                                                            <span class="woocommerce-Price-currencySymbol">{{$curr}}</span>{{number_format($shipping_data->price,3)}}</span></td>
                                                </tr> -->
	                                            <?php endif;?>
                                                <tr class="cart-subtotal">
                                                    <th>Tax</th>
                                                    <?php $tax = ($total_price / 100) * $tx;?>
                                                    <td data-title="Shipping"><span class="woocommerce-Price-amount amount">
                                                            <span class="woocommerce-Price-currencySymbol">{{$curr}}</span>{{number_format($tax,3)}}</span></td>
                                                </tr>
                                                <tr class="order-total">
                                                    <th>{{ __('messages.total') }}</th>
                                                    <?php 
                                                    $shipping_charge = 0;
                                                    if(!empty($shipping_data) && isset($shipping_data->price))
                                                    	$shipping_charge = $shipping_data->price;
                                                    ?>
                                                    <td data-title="Total">
                                                        <strong>
                                                            <span class="woocommerce-Price-amount amount">
                                                                <span class="woocommerce-Price-currencySymbol">{{$curr}}</span><span id="total_price">{{number_format($total_price+$tx+$shipping_charge,3)}}</span></span>
                                                        </strong>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        <!-- .shop_table shop_table_responsive -->
                                        <div class="wc-proceed-to-checkout">
                                            <!-- <form class="woocommerce-shipping-calculator" method="post" action="#">
                                                <p>
                                                    <a class="shipping-calculator-button" data-toggle="collapse" href="#shipping-form" aria-expanded="false" aria-controls="shipping-form">Calculate shipping</a>
                                                </p>
                                                <div class="collapse" id="shipping-form">
                                                    <div class="shipping-calculator-form">
                                                        <p id="calc_shipping_country_field" class="form-row form-row-wide">
                                                            <select rel="calc_shipping_state" class="country_to_state" id="calc_shipping_country" name="calc_shipping_country">
                                                                <option value="">Select a country…</option>
                                                                <option value="AX">Åland Islands</option>
                                                                <option value="AF">Afghanistan</option>
                                                                <option value="AL">Albania</option>
                                                                <option value="DZ">Algeria</option>
                                                                <option value="AS">American Samoa</option>
                                                                <option value="AD">Andorra</option>
                                                                <option value="AO">Angola</option>
                                                                <option value="AI">Anguilla</option>
                                                                <option value="AQ">Antarctica</option>
                                                                <option value="AG">Antigua and Barbuda</option>
                                                                <option value="AR">Argentina</option>
                                                                <option value="AM">Armenia</option>
                                                                <option value="AW">Aruba</option>
                                                                <option value="AU">Australia</option>
                                                                <option value="AT">Austria</option>
                                                                <option value="AZ">Azerbaijan</option>
                                                            </select>
                                                        </p>
                                                        <p id="calc_shipping_state_field" class="form-row form-row-wide validate-required">
                                                            <span>
                                                                <select id="calc_shipping_state" name="calc_shipping_state">
                                                                    <option value="">Select an option…</option>
                                                                    <option value="AP">Andhra Pradesh</option>
                                                                    <option value="AR">Arunachal Pradesh</option>
                                                                    <option value="AS">Assam</option>
                                                                    <option value="BR">Bihar</option>
                                                                    <option value="CT">Chhattisgarh</option>
                                                                    <option value="GA">Goa</option>
                                                                    <option value="GJ">Gujarat</option>
                                                                    <option value="HR">Haryana</option>
                                                                    <option value="HP">Himachal Pradesh</option>
                                                                    <option value="JK">Jammu and Kashmir</option>
                                                                    <option value="JH">Jharkhand</option>
                                                                    <option value="KA">Karnataka</option>
                                                                    <option value="KL">Kerala</option>
                                                                    <option value="MP">Madhya Pradesh</option>
                                                                    <option value="MH">Maharashtra</option>
                                                                    <option value="MN">Manipur</option>
                                                                    <option value="ML">Meghalaya</option>
                                                                    <option value="MZ">Mizoram</option>
                                                                    <option value="NL">Nagaland</option>
                                                                    <option value="OR">Orissa</option>
                                                                    <option value="PB">Punjab</option>
                                                                    <option value="RJ">Rajasthan</option>
                                                                    <option value="SK">Sikkim</option>
                                                                    <option value="TN">Tamil Nadu</option>
                                                                    <option value="TS">Telangana</option>
                                                                    <option value="TR">Tripura</option>
                                                                    <option value="UK">Uttarakhand</option>
                                                                    <option value="UP">Uttar Pradesh</option>
                                                                    <option value="WB">West Bengal</option>
                                                                    <option value="AN">Andaman and Nicobar Islands</option>
                                                                    <option value="CH">Chandigarh</option>
                                                                    <option value="DN">Dadra and Nagar Haveli</option>
                                                                    <option value="DD">Daman and Diu</option>
                                                                    <option value="DL">Delhi</option>
                                                                    <option value="LD">Lakshadeep</option>
                                                                    <option value="PY">Pondicherry (Puducherry)</option>
                                                                </select>
                                                            </span>
                                                        </p>
                                                        <p id="calc_shipping_postcode_field" class="form-row form-row-wide validate-required">
                                                            <input type="text" id="calc_shipping_postcode" name="calc_shipping_postcode" placeholder="Postcode / ZIP" value="" class="input-text">
                                                        </p>
                                                        <p>
                                                            <button class="button" value="1" name="calc_shipping" type="submit">Update totals</button>
                                                        </p>
                                                    </div>
                                                </div>
                                            </form> -->
                                            <!-- .wc-proceed-to-checkout -->
                                            <a class="checkout-button button alt wc-forward" href="{{ route('front.checkout') }}">{{ __('messages.proceed_to_checkout') }}</a>
                                            <a class="back-to-shopping" href="<?= URL('/')?>">{{ __('messages.back_shopping') }}</a>
                                        </div>
                                        <!-- .wc-proceed-to-checkout -->
                                    </div>
                                    <!-- .cart_totals -->
                                </div>
                                <!-- .cart-collaterals -->
                                <?php else:?>
                                    <p>{{ __('messages.cart_is_empty') }}</p>
                                <?php endif;?>
                            </div>
                            <!-- .cart-wrapper -->
                        </div>
                        <!-- .woocommerce -->
                    </div>
                    <!-- .entry-content -->
                </div>
                <!-- .hentry -->
            </main>
            <!-- #main -->
        </div>
        <!-- #primary -->
    </div>
    <!-- .row -->
</div>
<input type="hidden" id="update_qty" value="<?php echo URL('/updatecartqty')?>" />
<input type="hidden" id="remove_product" value="<?php echo URL('/updatecartqty')?>" />
@endsection