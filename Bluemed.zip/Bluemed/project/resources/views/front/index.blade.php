<?php 
use App\Models\Category;
?>
@extends('layouts.front')
@section('body_class', 'page-template-template-homepage-v12')
@section('content')

@if($ps->slider == 1)

@if(count($sliders))

@include('includes.slider-style')

@endif

@endif
<style>
.site-header.header-v10 {
    padding-bottom: 0;
}
</style>
<div class="col-md-12 p-0" id="homepage-banner-slider">
                    <?php if($sliders->count() > 0 && $ps->slider):?>
                        <?php foreach($sliders as $slider):?>
                            <div class="slider-block column-1">
                                <div class="home-v12-slider">
                                    <div class="home-v12-slider home-slider">
                                        <!-- <div class="slider-1" style="background-image: url({{asset('assets/images/sliders/'.$slider->photo)}});"> -->
                                        <div class="slider-1">
                                            <img  class="img-fluid" src="{{asset('assets/images/sliders/'.$slider->photo)}}">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach;?>
                    <?php endif;?>
                    </div>
<div class="col-full">
    <div class="row">
        <div id="primary" class="content-area">
            <main id="main" class="site-main">
                <?php 
                /*echo "<pre>";
                print_r($ps);exit;*/
                ?>
                <div class="homev12-slider-with-banners row">
                   
                  <div class="category-slider main-browser-row" style="width: 100% !important;">
						<div class="row justify-content-md-center">
                            <?php foreach($collection as $category):?>
                                
							<div class="banner text-in-left" style="margin: 25px 25px;">
                                <a href="{{url('/')}}/collection/{{$category->id}}">
								<div class="top-small-banner" style=" background-image: url({{asset('assets/images/collections/'.$category['photo'])}}); height: 15em;" class="banner-bg p-0">
								<!--div class="top-small-banner" style=" background-image: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)),  url({{asset('assets/images/collections/'.$category['photo'])}}); height: 15em;" class="banner-bg p-0"-->
                                        <div class="caption w-100 text-center h-100">
                                            <div class="banner-info h-100 w-100">
                                               
                                               <!-- <h3 class="title m-b-0 <?= strlen($category['name'] > 10) ? 'style="padding:5.1rem 0 !important;"' : ''?>">
                                                    <strong>
                                                    <?php if(app()->getLocale() == 'ar'):?>
                                                        {{$category['name_ar']}}
                                                    <?php else:?>
                                                        {{$category['name']}}
                                                    <?php endif;?>
                                                    </strong>
                                                </h3>-->
                                            </div>
                                        </div>
                                        <!-- .caption -->
                                    </div>
                                    
                                      <div style="background-color: #002534;
							    / text-align: center; /
							    / text-align: center; /
							    vertical-align: middle;
							    height: 50px;
							    display: flex;
							    justify-content: center;
							    align-items: center;">
                                        
                          <h6 style="color: white; margin: 0px; font-weight: 200;">             
                          <?php if(app()->getLocale() == 'ar'):?>
                                            {{substr($category['name_ar'], 0, 40)}}<?php if(strlen($category['name_ar'])>40){ echo '...';} ?>
                                        
                                        <?php else:?>
                                            {{substr($category['name'], 0, 40)}}<?php if(strlen($category['name_ar'])>40){ echo '...';} ?>
                                        <?php endif;?>
                                        
                                        
                                    </h6>
                                   </div>             
                                                
                                </a>
                            </div>
                            <?php endforeach;?>
                        </div>
                        
                    </div>
                    
                   
                </div>
                <?php if($feature_products->count() > 0 && $ps->featured):?>
                <!-- .homev12-slider-with-banners -->
                <section class="section-products-carousel" id="featured_products">
                    <header class="section-header">
                        <h2 class="section-title">{{ __('messages.featured_products') }}</h2>
                        <nav class="custom-slick-nav"></nav>
                        <!-- .custom-slick-nav -->
                    </header>
                    <!-- .section-header -->
                    <div class="products-carousel" id="new-arrival-carousel" data-ride="tm-slick-carousel" data-wrap=".products" data-slick="{&quot;infinite&quot;:false,&quot;slidesToShow&quot;:8,&quot;slidesToScroll&quot;:8,&quot;dots&quot;:true,&quot;arrows&quot;:true,&quot;prevArrow&quot;:&quot;&lt;a href=\&quot;#\&quot;&gt;&lt;i class=\&quot;tm tm-arrow-left\&quot;&gt;&lt;\/i&gt;&lt;\/a&gt;&quot;,&quot;nextArrow&quot;:&quot;&lt;a href=\&quot;#\&quot;&gt;&lt;i class=\&quot;tm tm-arrow-right\&quot;&gt;&lt;\/i&gt;&lt;\/a&gt;&quot;,&quot;appendArrows&quot;:&quot;#featured_products .custom-slick-nav&quot;,&quot;responsive&quot;:[{&quot;breakpoint&quot;:650,&quot;settings&quot;:{&quot;slidesToShow&quot;:1,&quot;slidesToScroll&quot;:1}},{&quot;breakpoint&quot;:780,&quot;settings&quot;:{&quot;slidesToShow&quot;:3,&quot;slidesToScroll&quot;:3}},{&quot;breakpoint&quot;:1200,&quot;settings&quot;:{&quot;slidesToShow&quot;:4,&quot;slidesToScroll&quot;:4}},{&quot;breakpoint&quot;:1400,&quot;settings&quot;:{&quot;slidesToShow&quot;:6,&quot;slidesToScroll&quot;:6}}]}">
                        <div class="container-fluid">
                            <div class="woocommerce columns-8">
                                <div class="products">
                                        <?php foreach($feature_products as $product):?>
                                            <?php
                                            $price = getVariationPrice($product->id);
                                            $variation = getVariation($product->id);
                                            $attr = isset($variation['attr']) ? $variation['attr'] : '';
                                            $total_stock = isset($variation['total_stock']) ? $variation['total_stock'] : 0;
                                            $stock = checkProductStock($product->sku);
                                            $wishlist = checkProductWishlist($product->id);
                                            $attr_id = isset($variation['attr_id']) ? $variation['attr_id'] : 0;
                                            ?>
                                            <form class="variations_form cart" id="variations_form">
                                                <input type="hidden" name="product_price" id="hidden_price" value="{{$price}}">
                                                <input type="hidden" name="quantity" id="hidden_price" value="1">
                                                <input name="_token" type="hidden" value="{{ csrf_token() }}"/>
                                                <input type="hidden" value="{{$product->id}}" name="product_id">
                                                <input type="hidden" name="total_stock" id="total_stock" value="{{$total_stock}}">
                                                <input type="hidden" name="attr_id" id="attr_id" value="{{$attr_id}}">
                                                <?php if(!empty($attr)):?>
                                                <?php foreach($attr as $key=>$val):?>
                                                    <input type="hidden" name="attr[<?= $key?>]" value="<?= $val?>">
                                                <?php endforeach;?>
                                                <?php endif;?>
                                                <div class="product">
                                                    <div class="yith-wcwl-add-to-wishlist">
                                                        <a rel="nofollow" class="pointer add_to_wishlist btn-add-wishlist <?= ($wishlist > 0) ? 'wishlist-added':''?>" data-id="{{$product->id}}"> Add to Wishlist</a>
                                                    </div>
                                                    <a href="{{ route('front.product', $product->id) }}" class="woocommerce-LoopProduct-link">
                                                        <?php $discount = $product->previous_price-$price;?>
                                                        <?php if(isset($product->previous_price) && !empty($product->previous_price) && $discount > 0):?>
                                                            <span class="onsale">
                                                                <span class="woocommerce-Price-amount amount">
                                                                    <span class="woocommerce-Price-currencySymbol">
                                                                        {{$curr}}
                                                                    </span>
                                                                    <?= number_format(((float)$product->previous_price - (float)$price) ,3);?>
                                                                </span>
                                                            </span>
                                                            <?php 
                                                            $discount_per = calculatePercentage($product->previous_price,$price);
                                                            ?>
                                                            <!-- <div class="discount-label green"> <span>-<?= number_format(((float)$product->previous_price - (float)$price) ,3);?>%</span> </div> -->
                                                        <?php endif;?>
                                                        <img src="{{asset('assets/images/products/'.$product->photo)}}" width="224" height="197" class="wp-post-image" alt="">
                                                        <?php if(isset($product->previous_price) && !empty($product->previous_price)):?>
                                                            <span class="price">
                                                                <ins>
                                                                    <span class="woocommerce-Price-currencySymbol">
                                                                        {{$curr}}
                                                                    </span>
                                                                    <span class="amount">{{number_format($price,3)}}</span>
                                                                </ins>
                                                                <?php if($price < $product->previous_price):?>
                                                                <del>
                                                                    <span class="amount">{{number_format($product->previous_price,3)}}</span>
                                                                </del>
                                                                <?php endif;?>
                                                                <span class="amount"> </span>
                                                            </span>
                                                        <?php else:?>
                                                            <span class="price">
                                                                <ins>
                                                                    <span class="amount"> </span>
                                                                </ins>
                                                                <span class="woocommerce-Price-currencySymbol">
                                                                    {{$curr}}
                                                                </span>
                                                                <span class="amount">{{number_format($price , 3)}}</span>
                                                            </span>
                                                        <?php endif;?>
                                                        <!-- /.price -->
                                                        <h2 class="woocommerce-loop-product__title"><?php if(app()->getLocale() == 'ar'):?>
                                                            {{$product->name_ar}}
                                                        <?php else:?>
                                                            {{$product->name}}
                                                        <?php endif;?></h2>
                                                    </a>
                                                    <div class="hover-area">
                                                        <button class="button add_to_cart_button" type="button" <?= ($stock==0) ? 'disabled' : ''?>>{{ __('messages.add_cart') }}</button>
                                                        <a class="add-to-compare-link pointer btn-add-compare" data-id="{{$product->id}}">{{ __('messages.add_compare') }}</a>
                                                    </div>
                                                </div>
                                            </form>
                                        <?php endforeach;?>
                                </div>
                            </div>
                        </div>
                        <!-- .container-fluid -->
                    </div>
                    <!-- .products-carousel -->
                </section>
                <?php endif;?>
                <?php if($promotional_products->count() > 0 && $ps->promotional_products):?>
                <!-- .homev12-slider-with-banners -->
                <section class="section-products-carousel" id="promotional_products">
                    <header class="section-header">
                        <h2 class="section-title">{{ __('messages.promotional_products') }}</h2>
                        <nav class="custom-slick-nav"></nav>
                        <!-- .custom-slick-nav -->
                    </header>
                    <!-- .section-header -->
                    <div class="products-carousel" id="new-arrival-carousel" data-ride="tm-slick-carousel" data-wrap=".products" data-slick="{&quot;infinite&quot;:false,&quot;slidesToShow&quot;:8,&quot;slidesToScroll&quot;:8,&quot;dots&quot;:true,&quot;arrows&quot;:true,&quot;prevArrow&quot;:&quot;&lt;a href=\&quot;#\&quot;&gt;&lt;i class=\&quot;tm tm-arrow-left\&quot;&gt;&lt;\/i&gt;&lt;\/a&gt;&quot;,&quot;nextArrow&quot;:&quot;&lt;a href=\&quot;#\&quot;&gt;&lt;i class=\&quot;tm tm-arrow-right\&quot;&gt;&lt;\/i&gt;&lt;\/a&gt;&quot;,&quot;appendArrows&quot;:&quot;#featured_products .custom-slick-nav&quot;,&quot;responsive&quot;:[{&quot;breakpoint&quot;:650,&quot;settings&quot;:{&quot;slidesToShow&quot;:1,&quot;slidesToScroll&quot;:1}},{&quot;breakpoint&quot;:780,&quot;settings&quot;:{&quot;slidesToShow&quot;:3,&quot;slidesToScroll&quot;:3}},{&quot;breakpoint&quot;:1200,&quot;settings&quot;:{&quot;slidesToShow&quot;:4,&quot;slidesToScroll&quot;:4}},{&quot;breakpoint&quot;:1400,&quot;settings&quot;:{&quot;slidesToShow&quot;:6,&quot;slidesToScroll&quot;:6}}]}">
                        <div class="container-fluid">
                            <div class="woocommerce columns-8">
                                <div class="products">
                                        <?php foreach($promotional_products as $product):?>
                                            <?php
                                            $price = getVariationPrice($product->id);
                                            $variation = getVariation($product->id);
                                            $attr = isset($variation['attr']) ? $variation['attr'] : '';
                                            $total_stock = isset($variation['total_stock']) ? $variation['total_stock'] : 0;
                                            $stock = checkProductStock($product->sku);
                                            $wishlist = checkProductWishlist($product->id);
                                            $attr_id = isset($variation['attr_id']) ? $variation['attr_id'] : 0;
                                            ?>
                                            <form class="variations_form cart" id="variations_form">
                                                <input type="hidden" name="product_price" id="hidden_price" value="{{$price}}">
                                                <input type="hidden" name="quantity" id="hidden_price" value="1">
                                                <input name="_token" type="hidden" value="{{ csrf_token() }}"/>
                                                <input type="hidden" value="{{$product->id}}" name="product_id">
                                                <input type="hidden" name="total_stock" id="total_stock" value="{{$total_stock}}">
                                                <input type="hidden" name="attr_id" id="attr_id" value="{{$attr_id}}">
                                                <?php if(!empty($attr)):?>
                                                <?php foreach($attr as $key=>$val):?>
                                                    <input type="hidden" name="attr[<?= $key?>]" value="<?= $val?>">
                                                <?php endforeach;?>
                                                <?php endif;?>
                                                <div class="product">
                                                    <div class="yith-wcwl-add-to-wishlist">
                                                        <a rel="nofollow" class="pointer add_to_wishlist btn-add-wishlist <?= ($wishlist > 0) ? 'wishlist-added':''?>" data-id="{{$product->id}}"> Add to Wishlist</a>
                                                    </div>
                                                    <a href="{{ route('front.product', $product->id) }}" class="woocommerce-LoopProduct-link">
                                                        <?php $discount = $product->previous_price-$price;?>
                                                        <?php if(isset($product->previous_price) && !empty($product->previous_price) && $discount > 0):?>
                                                            <span class="onsale">
                                                                <span class="woocommerce-Price-amount amount">
                                                                    <span class="woocommerce-Price-currencySymbol">
                                                                        {{$curr}}
                                                                    </span>
                                                                    <?= number_format(((float)$product->previous_price - (float)$price) ,3);?>
                                                                </span>
                                                            </span>
                                                        <?php endif;?>
                                                        <img src="{{asset('assets/images/products/'.$product->photo)}}" width="224" height="197" class="wp-post-image" alt="">
                                                        <?php if(isset($product->previous_price) && !empty($product->previous_price)):?>
                                                            <span class="price">
                                                                <ins>
                                                                    <span class="woocommerce-Price-currencySymbol">
                                                                        {{$curr}}
                                                                    </span>
                                                                    <span class="amount">{{number_format($price,3)}}</span>
                                                                </ins>
                                                                <?php if($price < $product->previous_price):?>
                                                                <del>
                                                                    <span class="amount">{{number_format($product->previous_price,3)}}</span>
                                                                </del>
                                                            <?php endif;?>
                                                                <span class="amount"> </span>
                                                            </span>
                                                        <?php else:?>
                                                            <span class="price">
                                                                <ins>
                                                                    <span class="amount"> </span>
                                                                </ins>
                                                                <span class="woocommerce-Price-currencySymbol">
                                                                    {{$curr}}
                                                                </span>
                                                                <span class="amount">{{number_format($price , 3)}}</span>
                                                            </span>
                                                        <?php endif;?>
                                                        <!-- /.price -->
                                                        <h2 class="woocommerce-loop-product__title"><?php if(app()->getLocale() == 'ar'):?>
                                                            {{$product->name_ar}}
                                                        <?php else:?>
                                                            {{$product->name}}
                                                        <?php endif;?></h2>
                                                    </a>
                                                    <div class="hover-area">
                                                        <button class="button add_to_cart_button" type="button" <?= ($stock == 0) ? 'disabled' : ''?>>{{ __('messages.add_cart') }}</button>
                                                        <a class="add-to-compare-link pointer btn-add-compare" data-id="{{$product->id}}">{{ __('messages.add_compare') }}</a>
                                                    </div>
                                                </div>
                                            </form>
                                        <?php endforeach;?>
                                </div>
                            </div>
                        </div>
                        <!-- .container-fluid -->
                    </div>
                    <!-- .products-carousel -->
                </section>
                <?php endif;?>
                <?php if($latest_products->count() > 0 && $ps->hot_sale):?>
                <!-- .homev12-slider-with-banners -->
                <section class="section-products-carousel" id="homev12-carousel-1">
                    <header class="section-header">
                        <h2 class="section-title">{{ __('messages.new_arrivals') }}</h2>
                        <nav class="custom-slick-nav"></nav>
                        <!-- .custom-slick-nav -->
                    </header>
                    <!-- .section-header -->
                    <div class="products-carousel" id="new-arrival-carousel" data-ride="tm-slick-carousel" data-wrap=".products" data-slick="{&quot;infinite&quot;:false,&quot;slidesToShow&quot;:8,&quot;slidesToScroll&quot;:8,&quot;dots&quot;:true,&quot;arrows&quot;:true,&quot;prevArrow&quot;:&quot;&lt;a href=\&quot;#\&quot;&gt;&lt;i class=\&quot;tm tm-arrow-left\&quot;&gt;&lt;\/i&gt;&lt;\/a&gt;&quot;,&quot;nextArrow&quot;:&quot;&lt;a href=\&quot;#\&quot;&gt;&lt;i class=\&quot;tm tm-arrow-right\&quot;&gt;&lt;\/i&gt;&lt;\/a&gt;&quot;,&quot;appendArrows&quot;:&quot;#homev12-carousel-1 .custom-slick-nav&quot;,&quot;responsive&quot;:[{&quot;breakpoint&quot;:650,&quot;settings&quot;:{&quot;slidesToShow&quot;:1,&quot;slidesToScroll&quot;:1}},{&quot;breakpoint&quot;:780,&quot;settings&quot;:{&quot;slidesToShow&quot;:3,&quot;slidesToScroll&quot;:3}},{&quot;breakpoint&quot;:1200,&quot;settings&quot;:{&quot;slidesToShow&quot;:4,&quot;slidesToScroll&quot;:4}},{&quot;breakpoint&quot;:1400,&quot;settings&quot;:{&quot;slidesToShow&quot;:6,&quot;slidesToScroll&quot;:6}}]}">
                        <div class="container-fluid">
                            <div class="woocommerce columns-8">
                                <div class="products">
                                        <?php foreach($latest_products as $product):?>
                                            <?php
                                            $price = getVariationPrice($product->id);
                                            $variation = getVariation($product->id);
                                            $attr = isset($variation['attr']) ? $variation['attr'] : '';
                                            $total_stock = isset($variation['total_stock']) ? $variation['total_stock'] : 0;
                                            $stock = checkProductStock($product->sku);
                                            $wishlist = checkProductWishlist($product->id);
                                            $attr_id = isset($variation['attr_id']) ? $variation['attr_id'] : 0;
                                            ?>
                                            <form class="variations_form cart" id="variations_form">
                                                <input type="hidden" name="product_price" id="hidden_price" value="{{$price}}">
                                                <input type="hidden" name="quantity" id="hidden_price" value="1">
                                                <input name="_token" type="hidden" value="{{ csrf_token() }}"/>
                                                <input type="hidden" value="{{$product->id}}" name="product_id">
                                                <input type="hidden" name="total_stock" id="total_stock" value="{{$total_stock}}">
                                                <input type="hidden" name="attr_id" id="attr_id" value="{{$attr_id}}">
                                                <?php if(!empty($attr)):?>
                                                <?php foreach($attr as $key=>$val):?>
                                                    <input type="hidden" name="attr[<?= $key?>]" value="<?= $val?>">
                                                <?php endforeach;?>
                                                <?php endif;?>
                                                <div class="product">
                                                    <div class="yith-wcwl-add-to-wishlist">
                                                        <a rel="nofollow" class="pointer add_to_wishlist btn-add-wishlist <?= ($wishlist > 0) ? 'wishlist-added':''?>" data-id="{{$product->id}}"> Add to Wishlist</a>
                                                    </div>
                                                    <a href="{{ route('front.product', $product->id) }}" class="woocommerce-LoopProduct-link">
                                                        <?php $discount = $product->previous_price-$price;?>
                                                        <?php if(isset($product->previous_price) && !empty($product->previous_price) && $discount> 0):?>
                                                            <span class="onsale">
                                                                <span class="woocommerce-Price-amount amount">
                                                                    <span class="woocommerce-Price-currencySymbol">
                                                                        {{$curr}}
                                                                    </span>
                                                                    <?= number_format(((float)$product->previous_price - (float)$price) ,3);?>
                                                                </span>
                                                            </span>
                                                        <?php endif;?>
                                                        <img src="{{asset('assets/images/products/'.$product->photo)}}" width="224" height="197" class="wp-post-image" alt="">
                                                        <?php if(isset($product->previous_price) && !empty($product->previous_price)):?>
                                                            <span class="price">
                                                                <ins>
                                                                    <span class="woocommerce-Price-currencySymbol">
                                                                        {{$curr}}
                                                                    </span>
                                                                    <span class="amount">{{number_format($price,3)}}</span>
                                                                </ins>
                                                                <?php if($price < $product->previous_price):?>
                                                                <del>
                                                                    <span class="amount">{{number_format($product->previous_price,3)}}</span>
                                                                </del>
                                                                <?php endif;?>
                                                                <span class="amount"> </span>
                                                            </span>
                                                        <?php else:?>
                                                            <span class="price">
                                                                <ins>
                                                                    <span class="woocommerce-Price-currencySymbol">
                                                                        {{$curr}}
                                                                    </span>
                                                                    <span class="amount"> </span>
                                                                </ins>
                                                                <span class="amount">{{number_format($price , 3)}}</span>
                                                            </span>
                                                        <?php endif;?>
                                                        <!-- /.price -->
                                                        <h2 class="woocommerce-loop-product__title"><?php if(app()->getLocale() == 'ar'):?>
                                                            {{$product->name_ar}}
                                                        <?php else:?>
                                                            {{$product->name}}
                                                        <?php endif;?></h2>
                                                    </a>
                                                    <div class="hover-area">
                                                        <button class="button add_to_cart_button" type="button" <?= ($stock==0) ? 'disabled' : ''?>>{{ __('messages.add_cart') }}</button>
                                                        <a class="add-to-compare-link pointer btn-add-compare" data-id="{{$product->id}}">{{ __('messages.add_compare') }}</a>
                                                    </div>
                                                </div>
                                            </form>
                                        <?php endforeach;?>
                                </div>
                            </div>
                        </div>
                        <!-- .container-fluid -->
                    </div>
                    <!-- .products-carousel -->
                </section>
                <?php endif;?>

                <?php if($ps->offered_items):?>
                <!-- .section-products-carousel -->
                <section class="section-products-carousel" id="offer_products">
                    <header class="section-header">
                        <h2 class="section-title">{{ __('messages.offers_items') }}</h2>
                        <nav class="custom-slick-nav"></nav>
                        <!-- .custom-slick-nav -->
                    </header>
                    <!-- .section-header -->
                    <div class="products-carousel" id="new-arrival-carousel" data-ride="tm-slick-carousel" data-wrap=".products" data-slick="{&quot;infinite&quot;:false,&quot;slidesToShow&quot;:8,&quot;slidesToScroll&quot;:8,&quot;dots&quot;:true,&quot;arrows&quot;:true,&quot;prevArrow&quot;:&quot;&lt;a href=\&quot;#\&quot;&gt;&lt;i class=\&quot;tm tm-arrow-left\&quot;&gt;&lt;\/i&gt;&lt;\/a&gt;&quot;,&quot;nextArrow&quot;:&quot;&lt;a href=\&quot;#\&quot;&gt;&lt;i class=\&quot;tm tm-arrow-right\&quot;&gt;&lt;\/i&gt;&lt;\/a&gt;&quot;,&quot;appendArrows&quot;:&quot;#offer_products .custom-slick-nav&quot;,&quot;responsive&quot;:[{&quot;breakpoint&quot;:650,&quot;settings&quot;:{&quot;slidesToShow&quot;:1,&quot;slidesToScroll&quot;:1}},{&quot;breakpoint&quot;:780,&quot;settings&quot;:{&quot;slidesToShow&quot;:3,&quot;slidesToScroll&quot;:3}},{&quot;breakpoint&quot;:1200,&quot;settings&quot;:{&quot;slidesToShow&quot;:4,&quot;slidesToScroll&quot;:4}},{&quot;breakpoint&quot;:1400,&quot;settings&quot;:{&quot;slidesToShow&quot;:6,&quot;slidesToScroll&quot;:6}}]}">
                        <div class="container-fluid">
                            <div class="woocommerce columns-8">
                                <div class="products">
                                        <?php foreach($offer_products as $product):?>
                                            <?php
                                            $price = getVariationPrice($product->id);
                                            $variation = getVariation($product->id);
                                            $attr = isset($variation['attr']) ? $variation['attr'] : '';
                                            $total_stock = isset($variation['total_stock']) ? $variation['total_stock'] : 0;
                                            $stock = checkProductStock($product->sku);
                                            $wishlist = checkProductWishlist($product->id);
                                            $attr_id = isset($variation['attr_id']) ? $variation['attr_id'] : 0;
                                            ?>
                                            <form class="variations_form cart" id="variations_form">
                                                <input type="hidden" name="product_price" id="hidden_price" value="{{$price}}">
                                                <input type="hidden" name="quantity" id="hidden_price" value="1">
                                                <input name="_token" type="hidden" value="{{ csrf_token() }}"/>
                                                <input type="hidden" value="{{$product->id}}" name="product_id">
                                                <input type="hidden" name="total_stock" id="total_stock" value="{{$total_stock}}">
                                                <input type="hidden" name="attr_id" id="attr_id" value="{{$attr_id}}">
                                                <?php if(!empty($attr)):?>
                                                <?php foreach($attr as $key=>$val):?>
                                                    <input type="hidden" name="attr[<?= $key?>]" value="<?= $val?>">
                                                <?php endforeach;?>
                                                <?php endif;?>
                                                <div class="product">
                                                    <div class="yith-wcwl-add-to-wishlist">
                                                        <a rel="nofollow" class="pointer add_to_wishlist btn-add-wishlist <?= ($wishlist > 0) ? 'wishlist-added':''?>" data-id="{{$product->id}}"> Add to Wishlist</a>
                                                    </div>
                                                    <a href="{{ route('front.product', $product->id) }}" class="woocommerce-LoopProduct-link">
                                                        <?php $discount = $product->previous_price-$price;?>
                                                        <?php if(isset($product->previous_price) && !empty($product->previous_price) && $discount > 0):?>
                                                            <span class="onsale">
                                                                <span class="woocommerce-Price-amount amount">
                                                                    <span class="woocommerce-Price-currencySymbol">
                                                                        {{$curr}}
                                                                    </span>
                                                                    <?= number_format(((float)$product->previous_price - (float)$price) ,3);?>
                                                                </span>
                                                            </span>
                                                        <?php endif;?>
                                                        <img src="{{asset('assets/images/products/'.$product->photo)}}" width="224" height="197" class="wp-post-image" alt="">
                                                        <?php if(isset($product->previous_price) && !empty($product->previous_price)):?>
                                                            <span class="price">
                                                                <ins>
                                                                    <span class="woocommerce-Price-currencySymbol">
                                                                        {{$curr}}
                                                                    </span>
                                                                    <span class="amount">{{number_format($price,3)}}</span>
                                                                </ins>
                                                                <?php if($price < $product->previous_price):?>
                                                                <del>
                                                                    <span class="amount">{{number_format($product->previous_price,3)}}</span>
                                                                </del>
                                                                <?php endif;?>
                                                                <span class="amount"> </span>
                                                            </span>
                                                        <?php else:?>
                                                            <span class="price">
                                                                <ins>
                                                                    <span class="amount"> </span>
                                                                </ins>
                                                                <span class="woocommerce-Price-currencySymbol">
                                                                    {{$curr}}
                                                                </span>
                                                                <span class="amount">{{number_format($price , 3)}}</span>
                                                            </span>
                                                        <?php endif;?>
                                                        <!-- /.price -->
                                                        <h2 class="woocommerce-loop-product__title"><?php if(app()->getLocale() == 'ar'):?>
                                                            {{$product->name_ar}}
                                                        <?php else:?>
                                                            {{$product->name}}
                                                        <?php endif;?></h2>
                                                    </a>
                                                    <div class="hover-area">
                                                        <button class="button add_to_cart_button" type="button" <?= ($stock==0) ? 'disabled' : ''?>>{{ __('messages.add_cart') }}</button>
                                                        <a class="add-to-compare-link pointer btn-add-compare" data-id="{{$product->id}}">{{ __('messages.add_compare') }}</a>
                                                    </div>
                                                </div>
                                            </form>
                                        <?php endforeach;?>
                                </div>
                            </div>
                        </div>
                        <!-- .container-fluid -->
                    </div>
                    <!-- .products-carousel -->
                </section>
                <?php endif;?>

                <?php if($ps->top_categories):?>
                <!-- .section-products-carousel-tabs -->
                <section class="section-top-categories section-categories-carousel-v1 section-categories-carousel" id="categories-carousel-2">
                    <header class="section-header">
                        <h2 class="section-title">{{ __('messages.top') }}
                            <br>{{ __('messages.categories') }}
                            <br>{{ __('messages.this_week') }}</h2>
                        <nav class="custom-slick-nav"></nav>
                        <!-- .custom-slick-nav -->
                    </header>
                    <!-- .section-header -->
                    <div class="product-categories product-categories-carousel" data-ride="tm-slick-carousel" data-wrap=".products" data-slick="{&quot;infinite&quot;:false,&quot;slidesToShow&quot;:7,&quot;slidesToScroll&quot;:1,&quot;dots&quot;:false,&quot;arrows&quot;:true,&quot;prevArrow&quot;:&quot;&lt;a href=\&quot;#\&quot;&gt;&lt;i class=\&quot;tm tm-arrow-left\&quot;&gt;&lt;\/i&gt;&lt;\/a&gt;&quot;,&quot;nextArrow&quot;:&quot;&lt;a href=\&quot;#\&quot;&gt;&lt;i class=\&quot;tm tm-arrow-right\&quot;&gt;&lt;\/i&gt;&lt;\/a&gt;&quot;,&quot;appendArrows&quot;:&quot;#categories-carousel-2 .custom-slick-nav&quot;,&quot;responsive&quot;:[{&quot;breakpoint&quot;:480,&quot;settings&quot;:{&quot;slidesToShow&quot;:1,&quot;slidesToScroll&quot;:1}},{&quot;breakpoint&quot;:1200,&quot;settings&quot;:{&quot;slidesToShow&quot;:2,&quot;slidesToScroll&quot;:2}},{&quot;breakpoint&quot;:1700,&quot;settings&quot;:{&quot;slidesToShow&quot;:5,&quot;slidesToScroll&quot;:5}}]}">
                        <div class="woocommerce columns-7">
                            

                            <div class="products">
                                <?php foreach($categories as $category):?>
                                <div class="product-category product">
                                    <a href="{{ route('front.category',['slug' => $category->slug]) }}">
                                        <img width="300" height="500" class="category-img"  alt="{{$category->name}}" src="{{asset('assets/images/categories/'.$category->photo)}}">
                                        <h2 class="woocommerce-loop-category__title">
                                            <?php if(app()->getLocale() == 'ar'):?>
                                                {{$category->name_ar}}
                                            <?php else:?>
                                                    {{$category->name}}
                                            <?php endif;?>
                                        </h2>
                                    </a>
                                </div>
                                <?php endforeach;?>
                            </div>
                            <!-- .products-->
                        </div>
                        <!-- .woocommerce -->
                    </div>
                </section>
                <!-- .section-top-categories -->
                <?php endif;?>
                <?php if($ps->flash_deal):?>

                <section class="section-products-carousel" id="flash_deal_products">
                    <header class="section-header">
                        <h2 class="section-title">{{ __('messages.flash_deal') }}</h2>
                        <nav class="custom-slick-nav"></nav>
                        <!-- .custom-slick-nav -->
                    </header>
                    <!-- .section-header -->
                    <div class="products-carousel" id="new-arrival-carousel" data-ride="tm-slick-carousel" data-wrap=".products" data-slick="{&quot;infinite&quot;:false,&quot;slidesToShow&quot;:8,&quot;slidesToScroll&quot;:8,&quot;dots&quot;:true,&quot;arrows&quot;:true,&quot;prevArrow&quot;:&quot;&lt;a href=\&quot;#\&quot;&gt;&lt;i class=\&quot;tm tm-arrow-left\&quot;&gt;&lt;\/i&gt;&lt;\/a&gt;&quot;,&quot;nextArrow&quot;:&quot;&lt;a href=\&quot;#\&quot;&gt;&lt;i class=\&quot;tm tm-arrow-right\&quot;&gt;&lt;\/i&gt;&lt;\/a&gt;&quot;,&quot;appendArrows&quot;:&quot;#flash_deal_products .custom-slick-nav&quot;,&quot;responsive&quot;:[{&quot;breakpoint&quot;:650,&quot;settings&quot;:{&quot;slidesToShow&quot;:1,&quot;slidesToScroll&quot;:1}},{&quot;breakpoint&quot;:780,&quot;settings&quot;:{&quot;slidesToShow&quot;:3,&quot;slidesToScroll&quot;:3}},{&quot;breakpoint&quot;:1200,&quot;settings&quot;:{&quot;slidesToShow&quot;:4,&quot;slidesToScroll&quot;:4}},{&quot;breakpoint&quot;:1400,&quot;settings&quot;:{&quot;slidesToShow&quot;:6,&quot;slidesToScroll&quot;:6}}]}">
                        <div class="container-fluid">
                            <div class="woocommerce columns-8">
                                <div class="products">
                                        <?php foreach($discount_products as $product):?>
                                            <?php
                                            $current_date = strtotime(date('Y-m-d H:i:s'));
                                            $discount_date = strtotime($product->discount_date);
                                            if($discount_date < $current_date)
                                                continue;
                                            ?>
                                            <?php
                                            $price = getVariationPrice($product->id);
                                            $variation = getVariation($product->id);
                                            $attr = isset($variation['attr']) ? $variation['attr'] : '';
                                            $total_stock = isset($variation['total_stock']) ? $variation['total_stock'] : 0;
                                            $stock = checkProductStock($product->sku);
                                            $wishlist = checkProductWishlist($product->id);
                                            $attr_id = isset($variation['attr_id']) ? $variation['attr_id'] : 0;
                                            ?>
                                            <form class="variations_form cart" id="variations_form">
                                                <input type="hidden" name="product_price" id="hidden_price" value="{{$price}}">
                                                <input type="hidden" name="quantity" id="hidden_price" value="1">
                                                <input name="_token" type="hidden" value="{{ csrf_token() }}"/>
                                                <input type="hidden" value="{{$product->id}}" name="product_id">
                                                <input type="hidden" name="total_stock" id="total_stock" value="{{$total_stock}}">
                                                <input type="hidden" name="attr_id" id="attr_id" value="{{$attr_id}}">
                                                <div class="product" <?= $discount_date?>>
                                                    <div class="yith-wcwl-add-to-wishlist">
                                                        <a rel="nofollow" class="pointer add_to_wishlist btn-add-wishlist <?= ($wishlist > 0) ? 'wishlist-added':''?>" data-id="{{$product->id}}"> Add to Wishlist</a>
                                                    </div>
                                                    <a href="{{ route('front.product', $product->id) }}" class="woocommerce-LoopProduct-link">
                                                        <?php $discount = $product->previous_price-$price;?>
                                                        <?php if(isset($product->previous_price) && !empty($product->previous_price) && $discount > 0):?>
                                                            <span class="onsale">
                                                                <span class="woocommerce-Price-amount amount">
                                                                    <span class="woocommerce-Price-currencySymbol">
                                                                        {{$curr}}
                                                                    </span>
                                                                    <?= number_format(((float)$product->previous_price - (float)$price) ,3);?>
                                                                </span>
                                                            </span>
                                                        <?php endif;?>
                                                        <img src="{{asset('assets/images/products/'.$product->photo)}}" width="224" height="197" class="wp-post-image" alt="">
                                                        <?php if(isset($product->previous_price) && !empty($product->previous_price)):?>
                                                            <span class="price">
                                                                <ins>
                                                                    <span class="woocommerce-Price-currencySymbol">
                                                                        {{$curr}}
                                                                    </span>
                                                                    <span class="amount">{{number_format($price,3)}}</span>
                                                                </ins>
                                                                <?php if($price < $product->previous_price):?>
                                                                <del>
                                                                    <span class="amount">{{number_format($product->previous_price,3)}}</span>
                                                                </del>
                                                                <?php endif;?>
                                                                <span class="amount"> </span>
                                                            </span>
                                                        <?php else:?>
                                                            <span class="price">
                                                                <ins>
                                                                    <span class="amount"> </span>
                                                                </ins>
                                                                <span class="woocommerce-Price-currencySymbol">
                                                                    {{$curr}}
                                                                </span>
                                                                <span class="amount">{{number_format($price , 3)}}</span>
                                                            </span>
                                                        <?php endif;?>
                                                        <!-- /.price -->
                                                        <h2 class="woocommerce-loop-product__title"><?php if(app()->getLocale() == 'ar'):?>
                                                            {{$product->name_ar}}
                                                        <?php else:?>
                                                            {{$product->name}}
                                                        <?php endif;?></h2>
                                                    </a>
                                                    <div class="hover-area">
                                                        <button class="button add_to_cart_button" type="button" <?= ($stock==0) ? 'disabled' : ''?>>{{ __('messages.add_cart') }}</button>
                                                        <a class="add-to-compare-link pointer btn-add-compare" data-id="{{$product->id}}">{{ __('messages.add_compare') }}</a>
                                                    </div>
                                                    <?php 

                                                    $current_date = date('Y-m-d H:i:s');
                                                    $discount_date = date('Y-m-d H:i:s', strtotime($product->discount_date));
                                                    $date1 = strtotime($current_date);  
                                                    $date2 = strtotime($discount_date);

                                                    $diff = abs($date2 - $date1);
                                                    $years = floor($diff / (365*60*60*24));
                                                    $months = floor(($diff - $years * 365*60*60*24) / (30*60*60*24));
                                                    $days = floor(($diff - $years * 365*60*60*24 - $months*30*60*60*24)/ (60*60*24));
                                                    $hours = floor(($diff - $years * 365*60*60*24 - $months*30*60*60*24 - $days*60*60*24) / (60*60));
                                                    $minutes = floor(($diff - $years * 365*60*60*24 - $months*30*60*60*24 - $days*60*60*24 - $hours*60*60)/ 60);  
                                                    $seconds = floor(($diff - $years * 365*60*60*24 - $months*30*60*60*24 - $days*60*60*24 - $hours*60*60 - $minutes*60));
                                                    ?>
                                                    <div class="deal-counter" data-countdown="{{date('m/d/Y', strtotime($product->discount_date))}}">
                                                        <div class="col-md-12 p-0 d-flex">
                                                            <div class="col-md-3 p-0">{{$days}}</div>
                                                            <div class="col-md-3 p-0">{{$hours}}</div>
                                                            <div class="col-md-3 p-0">{{$minutes}}</div>
                                                            <div class="col-md-3 p-0">{{$seconds}}</div>
                                                        </div>
                                                        <div class="col-md-12 p-0 d-flex">
                                                            <div class="col-md-3 p-0">{{ __('messages.days') }}</div>
                                                            <div class="col-md-3 p-0">{{ __('messages.hrs') }}</div>
                                                            <div class="col-md-3 p-0">{{ __('messages.min') }}</div>
                                                            <div class="col-md-3 p-0">{{ __('messages.sec') }}</div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </form>
                                        <?php endforeach;?>
                                </div>
                            </div>
                        </div>
                        <!-- .container-fluid -->
                    </div>
                    <!-- .products-carousel -->
                </section>
                <?php endif;?>
                <?php if($ps->featured_banner):?>
                    <div class="banner full-width-banner text-in-left banners-v2">
                        <a href="{{ route('front.category',$main_cat->slug) }}">
                            <div style="background-size: cover; background-position: center center; background-image: url( {{asset('assets/images/featuredbanner/'.$featured_banner->photo)}} ); height: 236px;" class="banner-bg">
                                <div class="caption">
                                    <!-- <div class="banner-info">
                                        <h3 class="title">
                                            <strong>All Categories</strong>
                                            <br> from start to end</h3>
                                        <h4 class="subtitle">Discover all Cleaning Items</h4>
                                    </div> -->
                                    <!-- .banner-info -->
                                    <!-- <span class="banner-action button">Browse now
                                        <i class="feature-icon d-flex ml-4 tm tm-long-arrow-right"></i>
                                    </span> -->
                                </div>
                                <!-- .caption -->
                            </div>
                            <!-- .banner-bg -->
                        </a>
                    </div>
                <?php endif;?>
                <?php if($best_value_products->count() > 0 && $ps->best_value):?>
                <!-- .homev12-slider-with-banners -->
                <section class="section-products-carousel" id="best_value_products">
                    <header class="section-header">
                        <h2 class="section-title">{{ __('messages.best_value') }}</h2>
                        <nav class="custom-slick-nav"></nav>
                        <!-- .custom-slick-nav -->
                    </header>
                    <!-- .section-header -->
                    <div class="products-carousel" id="new-arrival-carousel" data-ride="tm-slick-carousel" data-wrap=".products" data-slick="{&quot;infinite&quot;:false,&quot;slidesToShow&quot;:8,&quot;slidesToScroll&quot;:8,&quot;dots&quot;:true,&quot;arrows&quot;:true,&quot;prevArrow&quot;:&quot;&lt;a href=\&quot;#\&quot;&gt;&lt;i class=\&quot;tm tm-arrow-left\&quot;&gt;&lt;\/i&gt;&lt;\/a&gt;&quot;,&quot;nextArrow&quot;:&quot;&lt;a href=\&quot;#\&quot;&gt;&lt;i class=\&quot;tm tm-arrow-right\&quot;&gt;&lt;\/i&gt;&lt;\/a&gt;&quot;,&quot;appendArrows&quot;:&quot;#best_value_products .custom-slick-nav&quot;,&quot;responsive&quot;:[{&quot;breakpoint&quot;:650,&quot;settings&quot;:{&quot;slidesToShow&quot;:1,&quot;slidesToScroll&quot;:1}},{&quot;breakpoint&quot;:780,&quot;settings&quot;:{&quot;slidesToShow&quot;:3,&quot;slidesToScroll&quot;:3}},{&quot;breakpoint&quot;:1200,&quot;settings&quot;:{&quot;slidesToShow&quot;:4,&quot;slidesToScroll&quot;:4}},{&quot;breakpoint&quot;:1400,&quot;settings&quot;:{&quot;slidesToShow&quot;:6,&quot;slidesToScroll&quot;:6}}]}">
                        <div class="container-fluid">
                            <div class="woocommerce columns-8">
                                <div class="products">
                                        <?php foreach($best_value_products as $product):?>
                                            <?php
                                            $price = getVariationPrice($product->id);
                                            $variation = getVariation($product->id);
                                            $attr = isset($variation['attr']) ? $variation['attr'] : '';
                                            $total_stock = isset($variation['total_stock']) ? $variation['total_stock'] : 0;
                                            $stock = checkProductStock($product->sku);
                                            $wishlist = checkProductWishlist($product->id);

                                            $attr_id = isset($variation['attr_id']) ? $variation['attr_id'] : 0;
                                            ?>
                                            <form class="variations_form cart" id="variations_form">
                                                <input type="hidden" name="product_price" id="hidden_price" value="{{$price}}">
                                                <input type="hidden" name="quantity" id="hidden_price" value="1">
                                                <input name="_token" type="hidden" value="{{ csrf_token() }}"/>
                                                <input type="hidden" value="{{$product->id}}" name="product_id">
                                                <input type="hidden" name="total_stock" id="total_stock" value="{{$total_stock}}">
                                                <input type="hidden" name="attr_id" id="attr_id" value="{{$attr_id}}">
                                                <?php if(!empty($attr)):?>
                                                <?php foreach($attr as $key=>$val):?>
                                                    <input type="hidden" name="attr[<?= $key?>]" value="<?= $val?>">
                                                <?php endforeach;?>
                                                <?php endif;?>
                                                <div class="product">
                                                    <div class="yith-wcwl-add-to-wishlist">
                                                        <a rel="nofollow" class="pointer add_to_wishlist btn-add-wishlist <?= ($wishlist > 0) ? 'wishlist-added':''?>" data-id="{{$product->id}}"> Add to Wishlist</a>
                                                    </div>
                                                    <a href="{{ route('front.product', $product->id) }}" class="woocommerce-LoopProduct-link">
                                                        <?php $discount = $product->previous_price-$price;?>
                                                        <?php if(isset($product->previous_price) && !empty($product->previous_price) && $discount > 0):?>
                                                            <span class="onsale">
                                                                <span class="woocommerce-Price-amount amount">
                                                                    <span class="woocommerce-Price-currencySymbol">
                                                                        {{$curr}}
                                                                    </span>
                                                                    <?= number_format(((float)$product->previous_price - (float)$price) ,3);?>
                                                                </span>
                                                            </span>
                                                        <?php endif;?>
                                                        <img src="{{asset('assets/images/products/'.$product->photo)}}" width="224" height="197" class="wp-post-image" alt="">
                                                        <?php if(isset($product->previous_price) && !empty($product->previous_price)):?>
                                                            <span class="price">
                                                                <ins>
                                                                    <span class="woocommerce-Price-currencySymbol">
                                                                        {{$curr}}
                                                                    </span>
                                                                    <span class="amount">{{number_format($price,3)}}</span>
                                                                </ins>
                                                                <?php if($price < $product->previous_price):?>
                                                                <del>
                                                                    <span class="amount">{{number_format($product->previous_price,3)}}</span>
                                                                </del>
                                                                <?php endif;?>
                                                                <span class="amount"> </span>
                                                            </span>
                                                        <?php else:?>
                                                            <span class="price">
                                                                <ins>
                                                                    <span class="amount"> </span>
                                                                </ins>
                                                                <span class="woocommerce-Price-currencySymbol">
                                                                    {{$curr}}
                                                                </span>
                                                                <span class="amount">{{number_format($price , 3)}}</span>
                                                            </span>
                                                        <?php endif;?>
                                                        <!-- /.price -->
                                                        <h2 class="woocommerce-loop-product__title"><?php if(app()->getLocale() == 'ar'):?>
                                                            {{$product->name_ar}}
                                                        <?php else:?>
                                                            {{$product->name}}
                                                        <?php endif;?></h2>
                                                    </a>
                                                    <div class="hover-area">
                                                        <button class="button add_to_cart_button" type="button" <?= ($stock==0) ? 'disabled' : ''?>>{{ __('messages.add_cart') }}</button>
                                                        <a class="add-to-compare-link pointer btn-add-compare" data-id="{{$product->id}}">{{ __('messages.add_compare') }}</a>
                                                    </div>
                                                </div>
                                            </form>
                                        <?php endforeach;?>
                                </div>
                            </div>
                        </div>
                        <!-- .container-fluid -->
                    </div>
                    <!-- .products-carousel -->
                </section>
                <?php endif;?>
                <!-- .banners-->
                <!-- .banner -->
              <!--  <section class="section-landscape-products-carousel recently-viewed" id="recently-viewed">
                    <header class="section-header">
                        <h2 class="section-title">{{ __('messages.recently_viewed') }}</h2>
                        <nav class="custom-slick-nav"></nav>
                    </header>
                    <?php 
                    $is_rtl = 'false';
                    if(app()->getLocale() == 'ar')                    
                        $is_rtl = 'true';
                    ?>
                    <div class="products-carousel" data-ride="tm-slick-carousel" data-wrap=".products" data-slick="{&quot;slidesToShow&quot;:5,&quot;slidesToScroll&quot;:2,&quot;dots&quot;:true,&quot;rtl&quot;:<?= $is_rtl?>,&quot;arrows&quot;:true,&quot;prevArrow&quot;:&quot;&lt;a href=\&quot;#\&quot;&gt;&lt;i class=\&quot;tm tm-arrow-left\&quot;&gt;&lt;\/i&gt;&lt;\/a&gt;&quot;,&quot;nextArrow&quot;:&quot;&lt;a href=\&quot;#\&quot;&gt;&lt;i class=\&quot;tm tm-arrow-right\&quot;&gt;&lt;\/i&gt;&lt;\/a&gt;&quot;,&quot;appendArrows&quot;:&quot;#recently-viewed .custom-slick-nav&quot;,&quot;responsive&quot;:[{&quot;breakpoint&quot;:992,&quot;settings&quot;:{&quot;slidesToShow&quot;:2,&quot;slidesToScroll&quot;:2}},{&quot;breakpoint&quot;:1200,&quot;settings&quot;:{&quot;slidesToShow&quot;:3,&quot;slidesToScroll&quot;:3}},{&quot;breakpoint&quot;:1400,&quot;settings&quot;:{&quot;slidesToShow&quot;:3,&quot;slidesToScroll&quot;:3}},{&quot;breakpoint&quot;:1700,&quot;settings&quot;:{&quot;slidesToShow&quot;:4,&quot;slidesToScroll&quot;:4}}]}">
                        <div class="container-fluid">
                            <div class="woocommerce columns-5">
                                <div class="products">
                                    <?php foreach($recently_viewed as $product):?>
                                    <div class="landscape-product product">
                                        <a class="woocommerce-LoopProduct-link" href="{{ route('front.product', $product->id) }}">
                                            <div class="media">
                                                <img class="wp-post-image" src="{{asset('assets/images/products/'.$product->photo)}}" alt="">
                                                <div class="media-body">
                                                    <span class="price">
                                                        <ins>
                                                            <span class="amount"> </span>
                                                        </ins>
                                                        <span class="amount"> {{$curr}} {{number_format($product->price,3)}}</span>
                                                    </span>
                                                   
                                                    <h2 class="woocommerce-loop-product__title">
                                                        <?php if(app()->getLocale() == 'ar'):?>
                                                            {{$product->name_ar}}
                                                        <?php else:?>
                                                            {{$product->name}}
                                                        <?php endif;?>
                                                    </h2>
                                                    <div class="techmarket-product-rating">
                                                        <div title="Rated 0 out of 5" class="star-rating">
                                                            <span style="width:0%">
                                                                <strong class="rating">0</strong> out of 5</span>
                                                        </div>
                                                        <span class="review-count">(0)</span>
                                                    </div>
                                                   
                                                </div>
                                               
                                            </div>
                                           
                                        </a>
                                       
                                    </div>
                                    <?php endforeach;?>
                                </div>
                            </div>
                           
                        </div>
                      
                    </div>
                  
                </section> -->
                <!-- .section-landscape-products-carousel -->
                
            </main>
            <!-- #main -->
        </div>
        <!-- #primary -->
    </div>
    <!-- .row -->

</div>
<section class="brands-carousel">
    <?php 
    $is_rtl = 'false';
    if(app()->getLocale() == 'ar')                    
        $is_rtl = 'true';
    ?>
    <h5 class="ml-5 ">Our Brands</h5>
    <div class="col-full" data-ride="tm-slick-carousel" data-wrap=".brands" data-slick="{&quot;slidesToShow&quot;:6,&quot;slidesToScroll&quot;:1,&quot;dots&quot;:false,&quot;arrows&quot;:true,&quot;rtl&quot;:<?= $is_rtl?>,&quot;responsive&quot;:[{&quot;breakpoint&quot;:400,&quot;settings&quot;:{&quot;slidesToShow&quot;:1,&quot;slidesToScroll&quot;:1}},{&quot;breakpoint&quot;:800,&quot;settings&quot;:{&quot;slidesToShow&quot;:3,&quot;slidesToScroll&quot;:3}},{&quot;breakpoint&quot;:992,&quot;settings&quot;:{&quot;slidesToShow&quot;:3,&quot;slidesToScroll&quot;:3}},{&quot;breakpoint&quot;:1200,&quot;settings&quot;:{&quot;slidesToShow&quot;:4,&quot;slidesToScroll&quot;:4}},{&quot;breakpoint&quot;:1400,&quot;settings&quot;:{&quot;slidesToShow&quot;:5,&quot;slidesToScroll&quot;:5}}]}">
        <div class="brands">
            <?php foreach($brands as $brand):?>
            <div class="item">
                <a href="{{ route('front.brand',$brand->id) }}">
                    <figure>
                        <figcaption class="text-overlay">
                            <div class="info">
                                <h4>{{$brand->name}}</h4>
                            </div>
                            <!-- /.info -->
                        </figcaption>
                        <img width="145" height="50" class="img-responsive desaturate" alt="{{$brand->name}}" src="{{asset('assets/images/brands/'.$brand->photo)}}" style="height:130px;width:150px;">
                    </figure>
                </a>
            </div>
            <?php endforeach;?>
        </div>
    </div>
    <!-- .col-full -->
</section>
<!-- .brands-carousel -->






<section class="brands-carousel">
    <?php 
    $is_rtl = 'false';
    if(app()->getLocale() == 'ar')                    
        $is_rtl = 'true';
    ?>
    <h5 class="ml-5">Our Vendors</h5>
    <div class="col-full" data-ride="tm-slick-carousel" data-wrap=".brands" data-slick="{&quot;slidesToShow&quot;:6,&quot;slidesToScroll&quot;:1,&quot;dots&quot;:false,&quot;arrows&quot;:true,&quot;rtl&quot;:<?= $is_rtl?>,&quot;responsive&quot;:[{&quot;breakpoint&quot;:400,&quot;settings&quot;:{&quot;slidesToShow&quot;:1,&quot;slidesToScroll&quot;:1}},{&quot;breakpoint&quot;:800,&quot;settings&quot;:{&quot;slidesToShow&quot;:3,&quot;slidesToScroll&quot;:3}},{&quot;breakpoint&quot;:992,&quot;settings&quot;:{&quot;slidesToShow&quot;:3,&quot;slidesToScroll&quot;:3}},{&quot;breakpoint&quot;:1200,&quot;settings&quot;:{&quot;slidesToShow&quot;:4,&quot;slidesToScroll&quot;:4}},{&quot;breakpoint&quot;:1400,&quot;settings&quot;:{&quot;slidesToShow&quot;:5,&quot;slidesToScroll&quot;:5}}]}">
        <div class="brands">
            <?php foreach($vendor as $vend):?>
            
            @if($vend->photo!='')
            <div class="item">
                <a href="#">
                    <figure>
                        <figcaption class="text-overlay">
                            <div class="info">
                                <h4>{{$vend->name}}</h4>
                            </div>
                            <!-- /.info -->
                        </figcaption>
                        <img width="145" height="50" class="img-responsive desaturate" alt="{{$vend->name}}" src="{{asset('assets/images/users/'.$vend->photo)}}" style="height:130px;width:150px;">
                    </figure>
                </a>
            </div>
            @endif
            <?php endforeach;?>
        </div>
    </div>
    <!-- .col-full -->
</section>
<!-- .vendor-carousel -->
<input type="hidden" id="add_to_cart" value="<?php echo URL('/addcart')?>" />
{{-- Info Area End  --}}


@endsection

@section('scripts')

@endsection