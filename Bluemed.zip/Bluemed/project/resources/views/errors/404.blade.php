@extends('layouts.front')
@section('body_class', 'page home page-template-default')
@section('content')

<div class="col-full">
  <div class="container">
    <div class="row">
      <nav class="woocommerce-breadcrumb">
          <a href="<?= URL('/')?>">{{ __('messages.home') }}</a>
          <span class="delimiter">
              <i class="tm tm-breadcrumbs-arrow-right"></i>
          </span>
          {{ __('messages.about_us') }}
      </nav>
      <div id="primary" class="content-area">
        <div class="content text-center">
          <img
            src="{{ $gs->error_banner ? asset('assets/images/'.$gs->error_banner):asset('assets/images/noimage.png') }}"
            alt="" style="margin:0 auto;">
          <h4 class="heading">
            Oops! You're lost...
          </h4>
          <p class="text">
            The page you are looking for might have been moved, renamed, or might never existed.
          </p>
          <a class="mybtn1 btn btn-success" href="{{ route('front.index') }}">Back Home</a>
        </div>
      </div>
    </div>
  </div>
</div>


@endsection