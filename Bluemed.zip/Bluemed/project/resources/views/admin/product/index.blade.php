@extends('layouts.admin') 

@section('content')
<link href="https://cdn.datatables.net/buttons/1.6.2/css/buttons.dataTables.min.css"/>  
<style>
.chk_product,.chk_all{height:16px;width:16px;}
#geniustable thead th:last-child{display: flex !important;}
#geniustable thead th:last-child .header-action .nice-select{width: 70%;display: block !important;margin: 0 16px;background: #1e7e34 !important;}
.btn-delete{background: #1e7e34;
    color: #fff;
    border-radius: 50%;
    padding: 4px 10px;
    line-height: 20px;}
.btn-delete:hover{color:#fff !important;}
table.dataTable tbody td:first-child{
    width: 2% !important;
}
th.sorting_disabled{width: 175px !important;}
table.dataTable tbody td:nth-child(5){width:3% !important;}
#geniustable thead tr{background-color: #b5e2b5;}
#geniustable_wrapper{display: block;}
.dt-buttons{height: 37px;width: 1rem;display: contents;}
.dt-buttons .buttons-excel{margin: 0.5rem 2rem;border: 0;background: #1e7e34;color: #fff;padding: 0.2rem 2rem;border-radius: 50px;}
#product_excel_data tr th,#product_excel_data tr td{padding: 0 !important;}
#btn-export-excel{height: 30px;margin: 0 1rem;background: #1e7e34;border: 0;color: #fff;border-radius: 50px;padding: 0.5rem 1rem 2rem;}
#geniustable_length{display: flex;}
</style>
<style>	
.dropbtn {	
  /*padding: 10px;*/	
  font-size: 14px;	
  border: none;	
  background-color: #1e7e34 !important;	
    border-radius: 50px;	
    color: #fff;	
    padding: 4px 20px;	
}	
.dropdown {	
  position: relative;	
  display: inline-block;	
}	
.dropdown-content {	
  display: none;	
  position: absolute;	
  background-color: #f1f1f1;	
  min-width: 160px;	
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);	
  z-index: 1;	
}	
.dropdown-content a {	
  color: black !important;	
  padding: 12px 16px;	
  text-decoration: none;	
  display: block;	
}	
.dropdown-content a:hover {background-color: #ddd;}	
.dropdown:hover .dropdown-content {display: block;}	
.dropdown:hover .dropbtn {background-color: #3e8e41;}	
</style>
					<input type="hidden" id="headerdata" value="{{ __("PRODUCT") }}">
					<div class="content-area">
						<div class="mr-breadcrumb">
							<div class="row">
								<div class="col-lg-12">
										<h4 class="heading">{{ __("Products") }}</h4>
										<ul class="links">
											<li>
												<a href="{{ route('admin.dashboard') }}">{{ __("Dashboard") }} </a>
											</li>
											<li>
												<a href="javascript:;">{{ __("Products") }} </a>
											</li>
											<li>
												<a href="{{ route('admin-prod-index') }}">{{ __("All Products") }}</a>
											</li>
										</ul>
								</div>
							</div>
						</div>
						<div class="product-area">
							<div class="row">
								<div class="col-lg-12">
									<div class="mr-table allproduct">

                        @include('includes.admin.form-success')  
                        	<div class="filter-container">
                        		<select name="category" id="category" style="width:15%;margin: 0px 20px 20px 20px;">
                                   <option value="">Select Category</option>
                                    @foreach($category as $cat)
                                        <option value="{{$cat->id}}">{{$cat->name}}</option>
                                    @endforeach
                                </select>
                                <select name="sub_category" id="sub_category" style="width: 15%;margin: 0px 5px 5px 5px;">
                                   <option value="">Select Sub Category</option>
                                    
                                </select>
                                <select name="brand" id="brand" style="width: 15%;margin: 0px 5px 5px 5px;">
                                   <option value="">Select Brand</option>
                                   <option value="0"></option>
                                    @foreach($brands as $brand)
                                        <option value="{{$brand->id}}">{{$brand->name}}</option>
                                    @endforeach
                                </select> 
								<select name="vendor" id="vendor" style="width: 15%;margin: 0px 5px 5px 5px;">
                                   <option value="">Select Vendor</option>
                                    @foreach($vendor as $val)
                                        <option value="{{$val->id}}">{{$val->shop_name}}</option>
                                    @endforeach
                                </select>
                                <input type="number" id="stock" class="input-field" placeholder="Stock" name="stock" style="width:10%;"/>
                                <button class="add-btn" type="button" id="btn-filter" style="margin:0 15px;">Filter</button>
                                <select name="sort" id="sort" style="width:10%;margin: 10px 5px 5px 5px;float:right;">
                                	<option value="">Sort By</option>
                                	<option value="asc">Name (A-Z)</option>
                                	<option value="desc">Name (Z-A)</option>
                                	<option value="price-asc">Price Low to High</option>
                                	<option value="price-desc">Price High to Low</option>
                                </select>

                            </div>
										<div class="table-responsiv">
												<table id="geniustable" class="table table-hover dt-responsive" cellspacing="0" width="100%">
													<thead>
														<tr>
															<th style="padding: 10px !important;"><input type="checkbox" id="chk_all" class="chk_all"></th>
									                        <th style="width:65px !important;">{{ __("Item Code") }}</th>
									                        <th style="width:20%;">{{ __("Name") }}</th>
									                        <!-- <th>{{ __("Type") }}</th> -->
									                        <th>{{ __("Stock") }}</th>
									                        <th>{{ __("Price") }}</th>
									                        <th>{{ __("Status") }}</th>
									                        <th style="display: flex;">
									                        	{{ __("Actions") }}
									                        	<div class="action-list header-action"><select class="process select droplinks" id="status"><option value="">Select</option><option data-val="1" value="1" >Activate</option><option data-val="0" value="0">Deactivate</option></select></div>
									                        	<a href="javascript:;" class="delete btn-delete"><i class="fas fa-trash-alt"></i></a>
									                        </th>
														</tr>
													</thead>
												</table>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>



{{-- HIGHLIGHT MODAL --}}

										<div class="modal fade" id="modal2" tabindex="-1" role="dialog" aria-labelledby="modal2" aria-hidden="true">
										
										
										<div class="modal-dialog highlight" role="document">
										<div class="modal-content">
												<div class="submit-loader">
														<img  src="{{asset('assets/images/'.$gs->admin_loader)}}" alt="">
												</div>
											<div class="modal-header">
											<h5 class="modal-title"></h5>
											<button type="button" class="close" data-dismiss="modal" aria-label="Close">
												<span aria-hidden="true">&times;</span>
											</button>
											</div>
											<div class="modal-body">

											</div>
											<div class="modal-footer">
											<button type="button" class="btn btn-secondary" data-dismiss="modal">{{ __("Close") }}</button>
											</div>
										</div>
										</div>
</div>

{{-- HIGHLIGHT ENDS --}}


{{-- DELETE MODAL --}}

<div class="modal fade" id="confirm-delete" tabindex="-1" role="dialog" aria-labelledby="modal1" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">

	<div class="modal-header d-block text-center">
		<h4 class="modal-title d-inline-block">{{ __("Confirm Delete") }}</h4>
			<button type="button" class="close" data-dismiss="modal" aria-label="Close">
				<span aria-hidden="true">&times;</span>
			</button>
	</div>

      <!-- Modal body -->
      <div class="modal-body">
            <p class="text-center">{{ __("You are about to delete this Product.") }}</p>
            <p class="text-center">{{ __("Do you want to proceed?") }}</p>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer justify-content-center">
            <button type="button" class="btn btn-default" data-dismiss="modal">{{ __("Cancel") }}</button>
            <a class="btn btn-danger btn-ok">{{ __("Delete") }}</a>
      </div>

    </div>
  </div>
</div>
<div class="modal fade" id="confirm-bulk-delete" tabindex="-1" role="dialog" aria-labelledby="modal1" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">

	<div class="modal-header d-block text-center">
		<h4 class="modal-title d-inline-block">{{ __("Confirm Delete") }}</h4>
			<button type="button" class="close" data-dismiss="modal" aria-label="Close">
				<span aria-hidden="true">&times;</span>
			</button>
	</div>

      <!-- Modal body -->
      <div class="modal-body">
            <p class="text-center">{{ __("You are about to delete this Product.") }}</p>
            <p class="text-center">{{ __("Do you want to proceed?") }}</p>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer justify-content-center">
            <button type="button" class="btn btn-default" data-dismiss="modal">{{ __("Cancel") }}</button>
            <a class="btn btn-danger btn-bulk-ok">{{ __("Delete") }}</a>
      </div>

    </div>
  </div>
</div>
<div class="modal fade" id="product-not-selected-modal" tabindex="-1" role="dialog" aria-labelledby="modal1" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">

	<div class="modal-header d-block text-center">
		<h4 class="modal-title d-inline-block">{{ __("Confirm Delete") }}</h4>
			<button type="button" class="close" data-dismiss="modal" aria-label="Close">
				<span aria-hidden="true">&times;</span>
			</button>
	</div>

      <!-- Modal body -->
      <div class="modal-body">
            <p class="text-center">{{ __("Please select products.") }}</p>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer justify-content-center">
            <button type="button" class="btn btn-default" data-dismiss="modal">{{ __("Cancel") }}</button>
            <!-- <a class="btn btn-danger btn-ok">{{ __("Delete") }}</a> -->
      </div>

    </div>
  </div>
</div>
{{-- DELETE MODAL ENDS --}}
	<table id="product_excel_data" class="table table-hover dt-responsive" width="100%" style="display: none;">
		<thead>
			<tr>
				<th>Item Code</th>
				<th>Name (English)</th>
				<th>Name (Arabic)</th>
				<th>Category</th>
				<th>Sub Category</th>
				<th>Child Category</th>
				<th>Brand</th>
				<th>Attributes</th>
				<th>Price</th>
				<th>Stock</th>
				<th>Description (English)</th>
				<th>Description (Arabic)</th>
			</tr>
		</thead>
		<tbody>
			<?php foreach($productsData as $product):?>
			<tr>
				<?php //echo "<pre>";print_r($product);exit;?>
				<td><?= $product['item_code']?></td>
				<td><?= $product['name_en']?></td>
				<td><?= $product['name_ar']?></td>
				<td><?= $product['category']?></td>
				<td><?= $product['sub_category']?></td>
				<td><?= $product['child_category']?></td>
				<td><?= $product['brand']?></td>
				<td>
				<?php if(isset($product['attributes'])):?>
				
					<?php foreach($product['attributes'] as $attr):?>
						<?php echo $attr;?>
						<br>
					<?php endforeach;?>
				
				<?php endif;?>
				</td>
				<td><?= $product['price']?></td>
				<td><?= $product['stock']?></td>
				<td><?= strip_tags($product['description_en'])?></td>
				<td><?= strip_tags($product['description_ar'])?></td>
			</tr>
			<?php endforeach;?>
		</tbody>
	</table>
{{-- GALLERY MODAL --}}

		<div class="modal fade" id="setgallery" tabindex="-1" role="dialog" aria-labelledby="setgallery" aria-hidden="true">
			<div class="modal-dialog modal-dialog-centered modal-lg" role="document">
				<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title" id="exampleModalCenterTitle">{{ __("Image Gallery") }}</h5>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">×</span>
					</button>
				</div>
				<div class="modal-body">
					<div class="top-area">
						<div class="row">
							<div class="col-sm-6 text-right">
								<div class="upload-img-btn">
									<form  method="POST" enctype="multipart/form-data" id="form-gallery">
										{{ csrf_field() }}
									<input type="hidden" id="pid" name="product_id" value="">
									<input type="file" name="gallery[]" class="hidden" id="uploadgallery" accept="image/*" multiple>
											<label for="image-upload" id="prod_gallery"><i class="icofont-upload-alt"></i>{{ __("Upload File") }}</label>
									</form>
								</div>
							</div>
							<div class="col-sm-6">
								<a href="javascript:;" class="upload-done" data-dismiss="modal"> <i class="fas fa-check"></i> {{ __("Done") }}</a>
							</div>
							<div class="col-sm-12 text-center">( <small>{{ __("You can upload multiple Images") }}.</small> )</div>
						</div>
					</div>
					<div class="gallery-images">
						<div class="selected-image">
							<div class="row">


							</div>
						</div>
					</div>
				</div>
				</div>
			</div>
		</div>
<input type="hidden" id="get_sub_cat" value="<?= URL('/getsubcat')?>">
<input type="hidden" id="base_url" value="<?= URL('/');?>">

{{-- GALLERY MODAL ENDS --}}

@endsection    



@section('scripts')


{{-- DATA TABLE --}}
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.1/js/dataTables.buttons.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.1/js/buttons.flash.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.10.16/js/dataTables.bootstrap.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/responsive/2.2.1/js/dataTables.responsive.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/responsive/2.2.1/js/responsive.bootstrap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js" type="text/javascript"></script>
<script src="https://cdn.datatables.net/buttons/1.5.1/js/buttons.html5.min.js"></script>
<script src="{{asset('assets/admin/js/jquery.table2excel.js')}}"></script>
    <script type="text/javascript">

		var table = $('#geniustable').DataTable({
			      "order": [],
			      // "ordering": false,
          "displayLength": 10,
           "lengthMenu": [[5, 10, 25, 50, -1], [5, 10, 25, 50, "All"]],
              
               processing: true,
               serverSide: true,
               ajax: {
               		"url":'{{ route('admin-prod-datatables') }}',
               		"data":function(d) {
	               		d.category_id = $("#category").val();
	               		d.sub_category = $("#sub_category").val();
	               		d.sort = $("#sort").val();
	               		d.stock = $("#stock").val();
	               		d.vendor = $("#vendor").val();
	               		d.brand = $("#brand").val();
	               },
               },
               /*dom: 'lBfrtip',
			    buttons: [
		            'excelHtml5'
		        ],*/
               "autoWidth": false,
                "columnDefs": [
			      { "width": "10px", "targets": 0 },
			      { "width": "10px", "targets": 1 },
			      { "width": "1000px", "targets": 2 },
			      { "width": "50px", "targets": 3 },
			      { "width": "70px", "targets": 4 },
			      { "width": "10px", "targets": 5 },
			      { "width": "50px", "targets": 6 },
			    ],
               columns: [
                        { data: 'checkbox', searchable: false, orderable: false},
                        { data: 'sku', name: 'sku' },
                        { data: 'name', name: 'name' },
                        // { data: 'type', name: 'type' },
                        { data: 'stock', name: 'stock' },
                        { data: 'price', name: 'price' },
                        { data: 'status', searchable: false, orderable: false},
            			{ data: 'action', searchable: false, orderable: false }

                     ],
                language : {
                	processing: '<img src="{{asset('assets/images/'.$gs->admin_loader)}}">'
                },
				drawCallback : function( settings ) {
	    				$('.select').niceSelect();	
				}
            });

      	$(function() {
        $(".btn-area").append('<div class="col-sm-4 table-contents">'+
        	'<a class="add-btn" href="{{route('admin-prod-physical-create')}}">'+
          '<i class="fas fa-plus"></i> <span class="remove-mobile">{{ __("Add New Product") }}<span>'+
          '</a>'+
          '</div>');
        $("#category").change(function(){
        	$.ajax({
        		type: "post",
        		url: "{{ route('admin-get-cat') }}",
        		data:{category_id: $(this).val(),"_token": "{{ csrf_token() }}"},
        		success: function(res){
        			$("#sub_category").append(res);
        		}
        	})
        })
        $(".dataTable tbody tr th:eq(5)").css('width','3%');
        $("#btn-filter").click(function(){
        	table.draw();
        })
        $("#sort").change(function(){
        	table.draw();
        })
        $("#chk_all").click(function(){
        	var checkboxArr = [];
		    $('.chk_product').prop('checked', this.checked);
		    if ($(this).is(':checked')) {
		        $(".chk_product").each(function (index, element) {
		            checkboxArr.push($(element).val());
		        });
		    }
		    else
		    {
		        checkboxArr = [];
		    }
		});
		$(".header-action .nice-select .list li").click(function(){
			var status = $(this).data('value');
			var productIds = new Array();
			jQuery.each($(".chk_product:checked"), function() {
				productIds.push($(this).val());
			});
			var ids = productIds.join(",");
			if(ids != '')
			{
				$.ajax({
	                type: "POST",
	                url:"{{ route('admin-bulk-status-prod') }}",
	                data:{product_ids:ids,status:status,"_token": "{{ csrf_token() }}",},
	                success:function(data){
	                	var res = JSON.parse(data);
	                	if(res)
	                	{
	                		table.draw();
	                	}
	                }
	            })
			}
			else
			{
				$("#product-not-selected-modal").modal('show');
			}
		})
		$("#geniustable_length").append('<button type="button" id="btn-export-excel">Excel</button>');
		$("#btn-export-excel").click(function(){
	        $("#product_excel_data").table2excel({
	           exclude: ".noExl",
	          name: "Excel Document Name",
	          filename: "Products",
	          fileext: ".xls"
	        });
	    });
	    var html = $("#product_excel_data")[0].outerHTML;
	    $("#product_excel_data").remove();
	    $("#geniustable_wrapper").after(html);
		$(".btn-delete").click(function(){
			var productIds = new Array();
			jQuery.each($(".chk_product:checked"), function() {
				productIds.push($(this).val());
			});
			var ids = productIds.join(",");
			if(ids != '')
			{
				$(".btn-ok").addClass('bulk-delete-ok');
				$(".bulk-delete-ok").removeClass('btn-ok');
				$("#confirm-bulk-delete").modal('show');
			}
			else
			{
				$("#product-not-selected-modal").modal('show');
			}
		})
		$(".btn-bulk-ok").click(function(){
			var productIds = new Array();
			jQuery.each($(".chk_product:checked"), function() {
				productIds.push($(this).val());
			});
			var ids = productIds.join(",");
			$.ajax({
                type: "POST",
                url:"{{ route('admin-bulk-delete-prod') }}",
                data:{product_ids:ids,"_token": "{{ csrf_token() }}",},
                success:function(data){
                	var res = JSON.parse(data);
                	if(res)
                	{
                		$("#confirm-bulk-delete").modal('hide');
                		table.draw();
                	}
                }
            })
		})
		$(document).on("change","#action-select", function(){
			var id = $(this).find(':selected').data('id');
			if(this.value == 'edit')
			{
				window.location.href = $("#base_url").val()+'/admin/products/edit/'+id;
			}
			else if(this.value == 'view_gallary')
			{
				$('#pid').val(id);
		        $('.selected-image .row').html('');
		            $.ajax({
		                    type: "GET",
		                    url:"{{ route('admin-gallery-show') }}",
		                    data:{id:id},
		                    success:function(data){
		                      if(data[0] == 0)
		                      {
			                    $('.selected-image .row').addClass('justify-content-center');
			      				$('.selected-image .row').html('<h3>{{ __("No Images Found.") }}</h3>');
		     				  }
		                      else {
			                    $('.selected-image .row').removeClass('justify-content-center');
			      				$('.selected-image .row h3').remove();      
		                          var arr = $.map(data[1], function(el) {
		                          return el });

		                          for(var k in arr)
		                          {
		        				$('.selected-image .row').append('<div class="col-sm-6">'+
		                                        '<div class="img gallery-img">'+
		                                            '<span class="remove-img"><i class="fas fa-times"></i>'+
		                                            '<input type="hidden" value="'+arr[k]['id']+'">'+
		                                            '</span>'+
		                                            '<a href="'+'{{asset('assets/images/galleries').'/'}}'+arr[k]['photo']+'" target="_blank">'+
		                                            '<img src="'+'{{asset('assets/images/galleries').'/'}}'+arr[k]['photo']+'" alt="gallery image">'+
		                                            '</a>'+
		                                        '</div>'+
		                                  	'</div>');
		                          }                         
		                       }
		 						$("#setgallery").modal('show');
		                    }
		                  });
			}
			else if(this.value == 'highlight')
			{
				$('#modal2').find('.modal-title').html($('#headerdata').val()+' HIGHLIGHT');
				var href = $("#base_url").val()+'/admin/products/feature/'+id;
				  $('#modal2 .modal-content .modal-body').html('').load(href,function(response, status, xhr){
				      if(status == "success")
				      {
				        if(admin_loader == 1)
				          {
				            $('.submit-loader').hide();
				          }
				          $("#modal2").modal('show');
				      }
				    });
			}
			else if(this.value == 'delete')
			{
				var href = $("#base_url").val()+'/admin/products/delete/'+id;
				$("#confirm-delete").find('.btn-ok').attr('href', href);
				$("#confirm-delete").modal('show');
			}
		})
      });											
									


{{-- DATA TABLE ENDS--}}


</script>


<script type="text/javascript">
	

// Gallery Section Update

    $(document).on("click", ".set-gallery" , function(){
        var pid = $(this).find('input[type=hidden]').val();
        $('#pid').val(pid);
        $('.selected-image .row').html('');
            $.ajax({
                    type: "GET",
                    url:"{{ route('admin-gallery-show') }}",
                    data:{id:pid},
                    success:function(data){
                      if(data[0] == 0)
                      {
	                    $('.selected-image .row').addClass('justify-content-center');
	      				$('.selected-image .row').html('<h3>{{ __("No Images Found.") }}</h3>');
     				  }
                      else {
	                    $('.selected-image .row').removeClass('justify-content-center');
	      				$('.selected-image .row h3').remove();      
                          var arr = $.map(data[1], function(el) {
                          return el });

                          for(var k in arr)
                          {
        				$('.selected-image .row').append('<div class="col-sm-6">'+
                                        '<div class="img gallery-img">'+
                                            '<span class="remove-img"><i class="fas fa-times"></i>'+
                                            '<input type="hidden" value="'+arr[k]['id']+'">'+
                                            '</span>'+
                                            '<a href="'+'{{asset('assets/images/galleries').'/'}}'+arr[k]['photo']+'" target="_blank">'+
                                            '<img src="'+'{{asset('assets/images/galleries').'/'}}'+arr[k]['photo']+'" alt="gallery image">'+
                                            '</a>'+
                                        '</div>'+
                                  	'</div>');
                          }                         
                       }
 
                    }
                  });
      });


  $(document).on('click', '.remove-img' ,function() {
    var id = $(this).find('input[type=hidden]').val();
    $(this).parent().parent().remove();
	    $.ajax({
	        type: "GET",
	        url:"{{ route('admin-gallery-delete') }}",
	        data:{id:id}
	    });
  });

  $(document).on('click', '#prod_gallery' ,function() {
    $('#uploadgallery').click();
  });
                                        
                                
  $("#uploadgallery").change(function(){
    $("#form-gallery").submit();  
  });

  $(document).on('submit', '#form-gallery' ,function() {
		  $.ajax({
		   url:"{{ route('admin-gallery-store') }}",
		   method:"POST",
		   data:new FormData(this),
		   dataType:'JSON',
		   contentType: false,
		   cache: false,
		   processData: false,
		   success:function(data)
		   {
		    if(data != 0)
		    {
	                    $('.selected-image .row').removeClass('justify-content-center');
	      				$('.selected-image .row h3').remove();   
		        var arr = $.map(data, function(el) {
		        return el });
		        for(var k in arr)
		           {
        				$('.selected-image .row').append('<div class="col-sm-6">'+
                                        '<div class="img gallery-img">'+
                                            '<span class="remove-img"><i class="fas fa-times"></i>'+
                                            '<input type="hidden" value="'+arr[k]['id']+'">'+
                                            '</span>'+
                                            '<a href="'+'{{asset('assets/images/galleries').'/'}}'+arr[k]['photo']+'" target="_blank">'+
                                            '<img src="'+'{{asset('assets/images/galleries').'/'}}'+arr[k]['photo']+'" alt="gallery image">'+
                                            '</a>'+
                                        '</div>'+
                                  	'</div>');
		            }          
		    }
		                     
		                       }

		  });
		  return false;
 }); 


// Gallery Section Update Ends	


</script>
<style>
.filter-container .add-btn{    border: 0;
    padding: 12px 24px;}
.filter-container{margin:5px 5px 35px 5px;}
</style>



@endsection   