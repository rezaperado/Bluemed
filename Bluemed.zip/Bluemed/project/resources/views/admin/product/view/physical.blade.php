@extends('layouts.admin')
@section('styles')

<link href="{{asset('assets/admin/css/product.css')}}" rel="stylesheet"/>
<link href="{{asset('assets/admin/css/jquery.Jcrop.css')}}" rel="stylesheet"/>
<link href="{{asset('assets/admin/css/Jcrop-style.css')}}" rel="stylesheet"/>
<style>
.select2-container .select2-selection--single {
  height: auto!important;
  padding: 5px 0;
}
.select2-container--default .select2-selection--single .select2-selection__rendered {
  line-height: normal!important;
}
.select2-container .select2-selection--single .select2-selection__rendered {
  white-space: normal!important;
}
.btn-select-image{
    background: #1e7e34;
    color: #fff;
    padding: 5px 8px !important;
    border-radius: 5px;
    line-height: 2.5rem;
}
.btn-select-image:hover{
    color:#fff;
}
.btn-close{
    background: #1e7e34 !important;
    color: #fff;
    padding: 0px 20px !important;
    border-radius: 5px;
    line-height: 2.5rem;
    border: 0;
}
.image-radio {
    position: absolute;
    top: 5px;
    right: 0px;
    background: #fff;
    width: 20px;
    height: 20px;
    border: 1px solid rgba(0, 0, 0, 0.1);
    font-size: 12px;
    color: rgba(0, 0, 0, 0.5);
    /*border-radius: 50%;*/
    line-height: 20px;
    text-align: center;
    -webkit-box-shadow: 0px 5px 10px rgba(0, 0, 0, 0.2);
    box-shadow: 0px 5px 10px rgba(0, 0, 0, 0.2);
    cursor: pointer;
}
.image-radio input[type="checkbox"]{
    width: 20px;
    height: 30px;
    margin-top: -6px;
    cursor:pointer;
}
#select-color-image-modal .gallery-img{
    padding: 20px 0;
}
.btn-add-more-color {
    width: 140px;
    height: 40px;
    line-height: 40px;
    text-align: center;
    display: block;
    margin: 0 auto;
    background: #f7fafe;
    margin-top: 30px;
    font-size: 14px;
    -webkit-box-shadow: 0px 5px 20px rgba(0, 0, 0, 0.18);
    box-shadow: 0px 5px 20px rgba(0, 0, 0, 0.18);
    -webkit-transition: all 0.3s ease-in;
    -o-transition: all 0.3s ease-in;
    transition: all 0.3s ease-in;
}
#product-color-container .select2-container{
    width:100% !important;
}
.attachment-area h4.title{
	font-size: 20px;
    font-weight: 600;
    color: #0d3359;
}
.attachment-area .heading-area{
    text-align: center;
    border-bottom: 0 !important;
}
.attachment-area .input-field{
    border: 0;
}
.attachment-area #add-more-attachment
{
	    width: 140px;
    height: 40px;
    line-height: 40px;
    text-align: center;
    display: block;
    margin: 0 auto;
    background: #f7fafe;
    margin-top: 30px;
    font-size: 14px;
    -webkit-box-shadow: 0px 5px 20px rgba(0, 0, 0, 0.18);
    box-shadow: 0px 5px 20px rgba(0, 0, 0, 0.18);
    -webkit-transition: all 0.3s ease-in;
    -o-transition: all 0.3s ease-in;
    transition: all 0.3s ease-in;
}
.attachment-area{
	position: relative;
}
</style>
@endsection
@section('content')
<?php
$attachmentData = $data->attachment;
$attachmentData = explode(",", $attachmentData);
?>

						<div class="content-area">
							<div class="mr-breadcrumb">
								<div class="row">
									<div class="col-lg-12">
											<h4 class="heading"> {{ __('Show Product Detail') }}<a class="add-btn" href="{{ url()->previous() }}"><i class="fas fa-arrow-left"></i> {{ __('Back') }}</a></h4>
											<ul class="links">
												<li>
													<a href="{{ route('admin.dashboard') }}">{{ __('Dashboard') }} </a>
												</li>
												<li>
													<a href="{{ route('admin-vendor-manage') }}">{{ __('Vendor') }} </a>
												</li>
												<li>
													<a href="javascript:;">{{ __('Physical Product') }}</a>
												</li>
												<li>
													<a href="javascript:;">{{ __('Show') }}</a>
												</li>
											</ul>
									</div>
								</div>
							</div>
							<div class="add-product-content">
								<div class="row">
									<div class="col-lg-12">
										<div class="product-description">
											<div class="body-area">

					                      <div class="gocover" style="background: url({{asset('assets/images/'.$gs->admin_loader)}}) no-repeat scroll center center rgba(45, 45, 45, 0.5);"></div>
					                      <form id="geniusform" action="{{route('admin-prod-update',$data->id)}}" method="POST" enctype="multipart/form-data">
					                        {{csrf_field()}}


                        @include('includes.admin.form-both')  
                        						<div class="row">
													<div class="col-lg-4">
														<div class="left-area">
																<h4 class="heading">{{ __('Vendor') }}*</h4>
														</div>
													</div>
													<div class="col-lg-7">
														<select readonly=""  disabled=""id="cat" name="user_id" required="" >
															<option value="">{{ __('Select vendor') }}</option>
															  @foreach($vendor as $val)
																<option value="{{$val->id}}" {{$val->id == $data->user_id ? "selected":""}} >{{$val->name}}</option>
															@endforeach
														</select>
													</div>
												</div>
												<div class="row">
													<div class="col-lg-4">
														<div class="left-area">
																<h4 class="heading">{{ __('SKU') }}*</h4>
														</div>
													</div>
													<div class="col-lg-7">
															<input readonly=""  disabled="" type="text" class="input-field" placeholder="{{ __('Enter Product SKU') }}" name="sku" required="" value="{{ $data->sku }}">
													</div>
												</div>
												<div class="row">
													<div class="col-lg-4">
														<div class="left-area">
																<h4 class="heading">{{ __('Product Name') }}* </h4>
																<p class="sub-heading">{{ __('(English)') }}</p>
														</div>
													</div>
													<div class="col-lg-7">
														<input readonly=""  disabled="" type="text" class="input-field" placeholder="{{ __('Enter Product Name') }}" name="name" required="" value="{{ $data->name }}">
							                           
													</div>
													
													
													<div class="col-lg-4">
														<div class="left-area">
																<h4 class="heading">{{ __('Product Name') }}* </h4>
																<p class="sub-heading">{{ __('(Arabic)') }}</p>
														</div>
													</div>
													
													
													<div class="col-lg-7">
													<input readonly=""  disabled="" type="text" class="input-field" placeholder="{{ __('Enter Product Name') }}" name="name_ar" required="" value="{{ isset($data->name_ar) ? $data->name_ar : '' }}">
							                          <div class="checkbox-wrapper">
							                              <input readonly=""  disabled="" type="checkbox" name="product_condition_check" claivss="checkclick" id="conditionCheck" value="1" {{ $data->product_condition != 0 ? "checked":"" }}>
							                              <label for="conditionCheck">{{ __('Allow Product Condition') }}</label>
							                            </div>
													</div>
													
													
												</div>

						                        <div class="{{ $data->product_condition == 0 ? "showbox":"" }}">
						                            

												<div class="row">
													<div class="col-lg-4">
														<div class="left-area">
																<h4 class="heading">{{ __('Product Condition') }}*</h4>
														</div>
													</div>
													<div class="col-lg-7">
															<select readonly=""  disabled=""name="product_condition">
				                                                  <option value="2" {{$data->product_condition == 2 
                                                    ? "selected":""}}>{{ __('New') }}</option>
				                                                  <option value="1" {{$data->product_condition == 1 
                                                    ? "selected":""}}>{{ __('Used') }}</option>
															</select>
													</div>

												</div>


						                        </div>

												<div class="row">
													<div class="col-lg-4">
														<div class="left-area">
																<h4 class="heading">{{ __('Category') }}*</h4>
														</div>
													</div>
													<div class="col-lg-7">
															<select readonly=""  disabled=""id="cat" name="category_id" required="">
																	<option>{{ __('Select Category') }}</option>

                                              @foreach($cats as $cat)
                                                  <option data-href="{{ route('admin-subcat-load',$cat->id) }}" value="{{$cat->id}}" {{$cat->id == $data->category_id ? "selected":""}} >{{$cat->name}}</option>
                                              @endforeach
						                                     </select>
													</div>
												</div>

												<div class="row">
													<div class="col-lg-4">
														<div class="left-area">
																<h4 class="heading">{{ __('Sub Category') }}*</h4>
														</div>
													</div>
													<div class="col-lg-7">
															<select readonly=""  disabled=""<?= $data->subcategory_id?> id="subcat" name="subcategory_id">
																<option value="">{{ __('Select Sub Category') }}</option>
	                                                  
	                                                  @foreach($sub_cats as $sub)
	                                                  <option <?= $sub->id." ".$data->subcategory_id?> data-href="{{ route('admin-childcat-load',$sub->id) }}" value="{{$sub->id}}" {{$sub->id == $data->subcategory_id ? "selected":""}} >{{$sub->name}}</option>
	                                                  @endforeach                                                  
	                                                  


															</select>
													</div>
												</div>
												<div class="row">
													<div class="col-lg-4">
														<div class="left-area">
																<h4 class="heading">{{ __('Brand') }}</h4>
														</div>
													</div>
													<div class="col-lg-7">
														<select readonly=""  disabled=""id="brand" name="brand_id">
                                              				<option value="">{{ __('Select Brand') }}</option>
                                              				<?php foreach($brands as $brand):?>
                                              					<option value="<?= $brand->id?>" <?= ($brand->id == $data->brand_id) ? 'selected' : ''?>><?= $brand->name?></option>
                                              				<?php endforeach;?>
														</select>
													</div>
												</div>

												<div class="row">
													<div class="col-lg-4">
														<div class="left-area">
																<h4 class="heading">{{ __('Child Category') }}*</h4>
														</div>
													</div>
													<div class="col-lg-7">

															<select readonly=""  disabled=""id="childcat" name="childcategory_id" {{$data->subcategory_id == null ? "disabled":""}}>
                                                  				<option value="">{{ __('Select Child Category') }}</option>
	                                                  @if($data->subcategory_id != null)
	                                                  @if($data->childcategory_id == null)
	                                                  @foreach($child_categories as $child)
	                                                  <option value="{{$child->id}}" >{{$child->name}}</option>
	                                                  @endforeach
	                                                  @else
	                                                  @foreach($child_categories as $child)
	                                                  <option value="{{$child->id}} " {{$child->id == $data->childcategory_id ? "selected":""}}>{{$child->name}}</option>
	                                                  @endforeach
	                                                  @endif                                               
	                                                  @endif
															</select>
													</div>
												</div>

												
							                     <div class="row">
							                        <div class="col-lg-4">
							                          <div class="left-area">
							                              <h4 class="heading">{{ __('Feature Image') }} *</h4>
							                          </div>
							                        </div>
							                        <div class="col-lg-7">
	<div class="row">
	<div class="panel panel-body">
		<div class="span4 cropme text-center" id="landscape" style="width: 400px; height: 400px; border: 1px dashed black;">
		</div>
		</div>
	</div>

			


							                        </div>
							                      </div>

							                      <input readonly=""  disabled="" type="hidden" id="feature_photo" name="photo" value="{{ $data->photo }}" accept="image/*">

											


												<div class="row">
													<div class="col-lg-4">
														<div class="left-area">

														</div>
													</div>
													<div class="col-lg-7">
														<ul class="list">
															<li>
																<input readonly=""  disabled="" class="checkclick1" name="shipping_time_check" type="checkbox" id="check1" value="1" {{$data->ship != null ? "checked":""}}>
																<label for="check1">{{ __('Allow Estimated Shipping Time') }}</label>
															</li>
														</ul>
													</div>
												</div>



						                        <div class="{{ $data->ship != null ? "":"showbox" }}">

												<div class="row">
													<div class="col-lg-4">
														<div class="left-area">
																<h4 class="heading">{{ __('Product Estimated Shipping Time') }}* </h4>
														</div>
													</div>
													<div class="col-lg-7">
														<input readonly=""  disabled="" type="text" class="input-field" placeholder="{{ __('Estimated Shipping Time') }}" name="ship" value="{{ $data->ship == null ? "" : $data->ship }}">
													</div>
												</div>


						                        </div>
						                        
						                        
						                        
						                        
						      <!--                  		<div class="row">-->
												<!--	<div class="col-lg-4">-->
												<!--		<div class="left-area">-->

												<!--		</div>-->
												<!--	</div>-->
												<!--	<div class="col-lg-7">-->
												<!--		<ul class="list">-->
												<!--			<li>-->
												<!--				<input readonly=""  disabled="" class="checkclick1" name="product_length_check" type="checkbox" id="check4" value="1" {{$data->length != null ? "checked":""}}>-->
												<!--				<label for="check4">{{ __('Allow Product Length') }}</label>-->
												<!--			</li>-->
												<!--		</ul>-->
												<!--	</div>-->
												<!--</div>-->



						      <!--                     <div class="{{ $data->length != null ? "":"showbox" }}">-->

												<!--<div class="row" id="length-section" style="margin:0 auto;">-->
												   
    								<!--					<div class="col-lg-4">-->
    								<!--						<div class="left-area">-->
    								<!--								<h4 class="heading">{{ __('Product Length') }}* </h4>-->
    								<!--						</div>-->
    								<!--					</div>-->
    								<!--					<div class="col-lg-7">-->
    								<!--						<input readonly=""  disabled="" type="text" class="input-field" placeholder="{{ __('Product length') }}" name="length[]" value="{{ $data->length == null ? "" : $data->length }}">-->
    								<!--					</div>-->
    											
												<!--</div>-->


						      <!--                  </div>-->
						                        
						      <!--                  	<a href="javascript:;" id="length-btn" class="add-more" style="margin-top:10px;margin-bottom:10px"><i class="fas fa-plus"></i>{{ __('Add More Length') }} </a>-->
						                        
						                        
						                        
						                        

												<!-- <div class="row">
													<div class="col-lg-4">
														<div class="left-area">

														</div>
													</div>
													<div class="col-lg-7">
														<ul class="list">
															<li>
																<input readonly=""  disabled="" name="size_check" type="checkbox" id="size-check" value="1" {{ !empty($data->size) ? "checked":"" }}>
																<label for="size-check">{{ __('Allow Product Sizes') }}</label>
															</li>
														</ul>
													</div>
												</div> -->
													<div class="{{ !empty($data->size) ? "":"showbox" }}" id="size-display">
													<div class="row">
															<div  class="col-lg-4">
															</div>
															<div  class="col-lg-7">
																<div class="product-size-details" id="size-section">
																	@if(!empty($data->size))
																	 @foreach($data->size as $key => $data1)
																		<div class="allow_product_sizes" id="size_sub_section">
																		<span class="remove size-remove"><i class="fas fa-times"></i></span>
																		<div  class="row" >
																		    <div class="row row_child" id="product_size_row_{{$key}}">
																				<div class="col-md-3 col-sm-6">
																					<label>
																						{{ __('Size Name') }} :
																						<span>
																							{{ __('(eg. S,M,L,XL,XXL,3XL,4XL)') }}
																						</span>
																					</label>
																					<input readonly=""  disabled="" type="text" name="size[]" class="input-field" placeholder="Size Name" value="{{ $data->size[$key] }}">
																				</div>
																				<div class="col-md-3 col-sm-6">
																						<label>
																							{{ __('Size Qty') }} :
																							<span>
																								{{ __('(Number of quantity of this size)') }}
																							</span>
																						</label>
																					<input readonly=""  disabled="" type="number" name="size_qty[]" class="input-field" placeholder="Size Qty" min="1" value="{{ $data->size_qty[$key] }}">
																				</div>
																				<div class="col-md-3 col-sm-6">
																						<label>
																							{{ __('Size Price') }} :
																							<span>
																								{{ __('(This price will be added with base price)') }}
																							</span>
																						</label>
																					<input readonly=""  disabled="" type="number" name="size_price[]" class="input-field" placeholder="{{ __('Size Price') }}" min="0" value="{{ $data->size_price[$key] }}">
																				</div>
																				
																				<?php $getLengthRelatedToSize = \DB::table("product_lengths")->where('product_id',$data->id)->where("product_size",$data->size[$key])->get(); ?>
																					<div class="col-md-3 col-sm-6">
																						<label>
																							{{ __('Length') }} :
																						</label>
																					<input readonly=""  disabled="" type="number" name="size_length[{{$key}}][]"  class="input-field" placeholder="{{ __('Length') }}" min="0" value="{{ count($getLengthRelatedToSize)>0 ? $getLengthRelatedToSize[0]->product_length : '' }}">
																			    	</div>
																			    	@if(count($getLengthRelatedToSize) > 0)
																			    	    @foreach($getLengthRelatedToSize as $k=>$v)
																			    	    @if($k!=0)
																	    	        	<div class="col-md-12 col-sm-12" style="padding:2% 20%">
																					        <input readonly=""  disabled="" type="number" name="size_length[{{$key}}][]"  class="input-field" placeholder="{{ __('Product Length') }}" min="0" value="{{ $v->product_length }}">
																			        	</div>
																			        	@endif
																			        	@endforeach
																			    	@endif
																				</div>
																					<a href="javascript:;" id="length-btn" class="add-more length-btn" onclick="addMoreLength({{$key}})"><i class="fas fa-plus"  style="margin-top: 20px;"></i>{{ __('Add More Length') }} </a>
																			</div>
																		</div>
																	 @endforeach
																	@else 
																		<div class="allow_product_sizes">
																		<span class="remove size-remove"><i class="fas fa-times"></i></span>
																		<div  class="row">
																		     <div class="row row_child" id="product_size_row_0">
																				<div class="col-md-3 col-sm-6">
																					<label>
																						{{ __('Size Name') }} :
																						<span>
																							{{ __('(eg. S,M,L,XL,XXL,3XL,4XL)') }}
																						</span>
																					</label>
																					<input readonly=""  disabled="" type="text" name="size[]" class="input-field" placeholder="Size Name">
																				</div>
																				<div class="col-md-3 col-sm-6">
																						<label>
																							{{ __('Size Qty') }} :
																							<span>
																								{{ __('(Number of quantity of this size)') }}
																							</span>
																						</label>
																					<input readonly=""  disabled="" type="number" name="size_qty[]" class="input-field" placeholder="Size Qty" value="1" min="1">
																				</div>
																				<div class="col-md-3 col-sm-6">
																						<label>
																							{{ __('Size Price') }} :
																							<span>
																								{{ __('(This price will be added with base price)') }}
																							</span>
																						</label>
																					<input readonly=""  disabled="" type="number" name="size_price[]" class="input-field" placeholder="Size Price" value="0" min="0">
																				</div>
																				
																				
																				
																					<div class="col-md-3 col-sm-6">
																						<label>
																							{{ __('Length') }} :
																						</label>
																					<input readonly=""  disabled="" type="number" name="size_length[0][]" class="input-field" placeholder="Length" value="0" min="0">
																				</div>
																			</div>
																				<a href="javascript:;" id="length-btn" class="add-more length-btn" onclick="addMoreLength(0)"><i class="fas fa-plus"></i>{{ __('Add More Length') }} </a>
																			</div>
																		</div>
																	@endif
																</div>

																<a href="javascript:;" id="size-btn" class="add-more"><i class="fas fa-plus"></i>{{ __('Add More Size') }} </a>
															</div>
													</div>
												</div>

												<!-- <div class="row">
													<div class="col-lg-4">
														<div class="left-area">

														</div>
													</div>
													<div class="col-lg-7">
														<ul class="list">
															<li>
																<input readonly=""  disabled="" class="checkclick1" name="color_check" type="checkbox" id="check3" value="1" {{ !empty($data->color) ? "checked":"" }}>
																<label for="check3">{{ __('Allow Product Colors') }}</label>
															</li>
														</ul>
													</div>
												</div> -->



						                        <div class="{{ !empty($data->color) ? "":"showbox" }}">

													<div class="row">
														@if(!empty($data->color))
															<div  class="col-lg-4">
																<div class="left-area">
																	<h4 class="heading">
																		{{ __('Product Colors') }}*
																	</h4>
																	<p class="sub-heading">
																		{{ __('(Choose Your Favorite Colors)') }}
																	</p>
																</div>
															</div>
															<div  class="col-lg-7">
																	<div class="select-input-color" id="color-section">
																		@foreach($data->color as $key => $data1)
																		<div class="color-area">
																			<span class="remove color-remove"><i class="fas fa-times"></i></span>
											                                <div class="input-group colorpicker-component cp">
											                                  <input readonly=""  disabled="" type="text" name="color[]" value="{{ $data->color[$key] }}"  class="input-field cp"/>
											                                  <span class="input-group-addon"><i></i></span>
											                                </div>
											                         	</div>
											                         	@endforeach
											                         </div>
																	<a href="javascript:;" id="color-btn" class="add-more mt-4 mb-3"><i class="fas fa-plus"></i>{{ __('Add More Color') }} </a>
															</div>
														@else 
															<div  class="col-lg-4">
																<div class="left-area">
																	<h4 class="heading">
																		{{ __('Product Colors') }}*
																	</h4>
																	<p class="sub-heading">
																		{{ __('(Choose Your Favorite Colors)') }}
																	</p>
																</div>
															</div>
															<div  class="col-lg-7">
																	<div class="select-input-color" id="color-section">
																		<div class="color-area">
																			<span class="remove color-remove"><i class="fas fa-times"></i></span>
											                                <div class="input-group colorpicker-component cp">
											                                  <input readonly=""  disabled="" type="text" name="color[]" value="#000000"  class="input-field cp"/>
											                                  <span class="input-group-addon"><i></i></span>
											                                </div>
											                         	</div>
											                         </div>
																	<a href="javascript:;" id="color-btn" class="add-more mt-4 mb-3"><i class="fas fa-plus"></i>{{ __('Add More Color') }} </a>
															</div>


														@endif
													</div>

						                        </div>
						                        
						                 <!-----------------------------sleeve options ------------------------------------------>
						                        
						                  <?php $getProductSleeves = \DB::table("product_sleeves")->where('product_id',$data->id)->get();  ?> 
						                        	<!-- <div class="row">
													<div class="col-lg-4">
														<div class="left-area">

														</div>
													</div>
													<div class="col-lg-7">
														<ul class="list">
															<li>
																<input readonly=""  disabled="" class="checkclick1" name="sleeve_check" type="checkbox" id="check3" value="1" {{ count($getProductSleeves) > 0 ? "checked":"" }}>
																<label for="check3">{{ __('Allow Product Sleeves') }}</label>
															</li>
														</ul>
													</div>
												</div> -->


						                             
						                        <div class="{{ count($getProductSleeves) > 0 ? "":"showbox" }}">

													<div class="row">
														@if(count($getProductSleeves) > 0)
															<div  class="col-lg-4">
																<div class="left-area">
																	<h4 class="heading">
																		{{ __('Product Sleeves') }}*
																	</h4>
																</div>
															</div>
															<div  class="col-lg-7">
																	<div class="select-input-sleeve" id="sleeve-section">
																		@foreach($getProductSleeves as $key => $data1)
																		<div class="sleeve-area">
																			<span class="remove sleeve-remove"><i class="fas fa-times"></i></span>
											                                  <input readonly=""  disabled="" type="text" name="sleeve[]" value="{{ $data1->sleeve_type }}"  class="input-field"/>
											                         	</div>
											                         	@endforeach
											                         </div>
																	<a href="javascript:;" id="sleeve-btn" class="add-more mt-4 mb-3"><i class="fas fa-plus"></i>{{ __('Add More Sleeve') }} </a>
															</div>
														@else 
															<div  class="col-lg-4">
																<div class="left-area">
																	<h4 class="heading">
																		{{ __('Product Sleeves') }}*
																	</h4>
																</div>
															</div>
															<div  class="col-lg-7">
																	<div class="select-input-sleeve" id="sleeve-section">
																		<div class="sleeve-area">
																			<span class="remove sleeve-remove"><i class="fas fa-times"></i></span>
											                                  <input readonly=""  disabled="" type="text" name="sleeve[]" value="" class="input-field"/>
											                         	</div>
											                         </div>
																	<a href="javascript:;" id="sleeve-btn" class="add-more mt-4 mb-3"><i class="fas fa-plus"></i>{{ __('Add More Sleeve') }} </a>
															</div>


														@endif
													</div>

						                        </div> 
						                        
						                        
						                        
						                        
						                        
						                        
						                         <!-----------------------------sleeve options end------------------------------------------>

	<!-- <div class="row">
													<div class="col-lg-4">
														<div class="left-area">

														</div>
													</div>
													<div class="col-lg-7">
														<ul class="list">
															<li>
																<input readonly=""  disabled="" class="checkclick1" name="whole_check" type="checkbox" id="whole_check" value="1" {{ !empty($data->whole_sell_qty) ? "checked":"" }}>
																<label for="whole_check">{{ __('Allow Product Whole Sell') }}</label>
															</li>
														</ul>
													</div>
												</div> -->

						                    <div class="{{ !empty($data->whole_sell_qty) ? "":"showbox" }}">
												<div class="row">
													<div class="col-lg-4">
														<div class="left-area">

														</div>
													</div>
													<div class="col-lg-7">
														<div class="featured-keyword-area">
															<div class="feature-tag-top-filds" id="whole-section">
																@if(!empty($data->whole_sell_qty))

																	 @foreach($data->whole_sell_qty as $key => $data1)

																<div class="feature-area">
																	<span class="remove whole-remove"><i class="fas fa-times"></i></span>
																	<div class="row">
																		<div class="col-lg-6">
																		<input readonly=""  disabled="" type="number" name="whole_sell_qty[]" class="input-field" placeholder="{{ __('Enter Quantity') }}" min="0" value="{{ $data->whole_sell_qty[$key] }}" required="">
																		</div>

																		<div class="col-lg-6">
											                            <input readonly=""  disabled="" type="number" name="whole_sell_discount[]" class="input-field" placeholder="{{ __('Enter Discount Percentage') }}" min="0" value="{{ $data->whole_sell_discount[$key] }}" required="">
																		</div>
																	</div>
																</div>


																		@endforeach
																@else 


																<div class="feature-area">
																	<span class="remove whole-remove"><i class="fas fa-times"></i></span>
																	<div class="row">
																		<div class="col-lg-6">
																		<input readonly=""  disabled="" type="number" name="whole_sell_qty[]" class="input-field" placeholder="{{ __('Enter Quantity') }}" min="0">
																		</div>

																		<div class="col-lg-6">
											                            <input readonly=""  disabled="" type="number" name="whole_sell_discount[]" class="input-field" placeholder="{{ __('Enter Discount Percentage') }}" min="0" />
																		</div>
																	</div>
																</div>

																@endif
															</div>

															<a href="javascript:;" id="whole-btn" class="add-fild-btn"><i class="icofont-plus"></i> {{ __('Add More Field') }}</a>
														</div>
													</div>
												</div>
											</div>
											
											

<!--/////////////////////////////////attributes //////////////////////////////////-->
                                            <div class="row">
												<div class="col-lg-4">
													<div class="left-area">

													</div>
												</div>
												<div class="col-lg-7">
													<ul class="list">
														<li>
															<input readonly=""  disabled="" class="is_multiple_products_color_images" name="is_multiple_products_color_images" type="checkbox" id="is_multiple_products_color_images" <?= ($product_color_data->count() > 0) ? 'checked' : ''?>>
															<label for="is_multiple_products_color_images">{{ __('Allow Product Color Images ') }}</label>
														</li>
													</ul>
												</div>
											</div>
											<div class="<?= ($product_color_data->count() < 1) ? 'showbox' : ''?>" id="product-color-container">
                                                <div class="row">
													<div class="col-lg-4">
														<div class="left-area">

														</div>
													</div>
													<div class="col-lg-7">
														<div class="featured-keyword-area">
															<div class="heading-area">
																<h4 class="title">{{ __('Product Color Images') }}</h4>
															</div>

															<div class="feature-tag-top-filds" id="feature-section">
															    <?php foreach($product_color_data as $key => $prd_color):?>
																<div class="feature-area">
																	<span class="remove color-remove"><i class="fas fa-times"></i></span>
																	<div class="row">
																		<div class="col-lg-5">
																		    <a href="javascript:void(0);" class="btn-select-image" data-index="{{$key}}" data-toggle="modal" data-target="#select-color-image-modal">Select Image</a>
																		    <input readonly=""  disabled="" type="hidden" name="color_images[]" class="input-field" id="color_image_{{$key}}" value="{{$prd_color->image}}">
																		</div>

																		<div class="col-lg-7">
											                                <select readonly=""  disabled=""class="product-color" name="product_colors[]">
											                                    
											                                </select>
																		</div>
																	</div>
																</div>
																<?php endforeach;?>
															</div>

															<a href="javascript:;" id="btn-add-more-color" class="btn-add-more-color"><i class="icofont-plus"></i> {{ __('Add More Field') }}</a>
														</div>
													</div>
												</div>
											</div>

<?php //$pa = \DB::table("product_attributes")->get();
$pa = \DB::table("attribute_masters")->get(); 

$attr_values = array();$price_sku = array();
foreach ($product_attributes as $key => $value) {
    $attr_names = explode('-', $value->attribute_names);
    $attr_vals = explode('-', $value->attribute_values);
    //print_r($attr_names);exit;
    foreach($attr_names as $namekey => $name)
    {
        $attr_values[$key][$name] = $attr_vals[$namekey];
    }
    //$attr_values[$key] = explode('-', $value->attribute_values);
    $price_sku['sku'][] = $value->sku;
    $price_sku['qty'][] = $value->qty;
    $price_sku['price'][] = round($value->price,2);
}
/*echo "<pre>";
print_r($attr_values);exit;*/
$inv = \DB::table("inventories")->get();

$arraypa = json_decode(json_encode($pa), true);
?>
<div class="row">
	<div class="col-lg-4">
		<div class="left-area">

		</div>
	</div>
	<div class="col-lg-7">
		<ul class="list">
			<li>
				<input readonly=""  disabled="" class="is_multiple_products" name="is_multiple_products" type="checkbox" id="is_multiple_products" <?= ($data->is_multiple_products == 1) ? 'checked' : ''?>>
				<label for="is_multiple_products">{{ __('Allow Multitle Products') }}</label>
			</li>
		</ul>
	</div>
</div>
<div class="" id="attributes-display">
	<div class="row attributes-row <?= ($data->is_multiple_products == 1) ? '' : 'showbox'?>">
			<div  class="col-lg-4">
			  <h4 class="heading" style="text-align:right;margin-top:25px;">
				{{ __('Product Attributes') }}*
			</h4>
			</div>
			<div  class="col-lg-7">
				<div class="row row_child" style="overflow-x: scroll;overflow-y: hidden;">
					<table class="table w-100" id="product-attribute-table">
						<tbody>
							<tr>
								<th class="text-center" colspan="<?= $pa->count();?>">Attributes&nbsp;&nbsp;</th>
								<th class="text-center">Sku</th>
								<th class="text-center">Qty</th>
								<th class="text-center">Price</th>
								<th>&nbsp;</th>
							</tr>
							<tr >
								<?php foreach($pa as $key => $val):?>
								<th class="text-center"><?= $val->name_en?></th>
								<?php endforeach;?>
								<th class="text-center">&nbsp;</th>
								<th class="text-center">&nbsp;</th>
								<th class="text-center">&nbsp;</th>
								<th class="text-center">&nbsp;</th>
							</tr>
							<input readonly=""  disabled="" type="hidden" id="total_attr_count" value="<?= $product_attributes->count()?>">
							<?php if($product_attributes->count() > 0):?>
								<?php 
								foreach($attr_values as $attrkey => $attr_val):?>
									<tr class="attr_fields">
										<?php 
										//if(!isset($attr_val[$attrkey]))
											//continue;
										?>
										<?php foreach($pa as $key => $val):?>
											<td class="text-center min-w-100 p-5">
											    <?php if(strtolower($val->name_en) == 'color'):?>
											    <?php $colors = json_decode($color_data);?>
											    <select readonly=""  disabled=""class="form-control attr-color" name="attr[<?= $attrkey?>][<?= str_replace(' ','_',$val->name_en)?>]" style="margin-bottom: 0;">
													<?php $selected_colors = json_decode($selected_color_arr);
													$color_val = isset($attr_val[$val->name_en]) ? $attr_val[$val->name_en] : '';
													?>   
													<?php foreach($selected_colors as $color):?>
													    <option value="<?= $color->name?>" <?= ($color->name == $color_val) ? 'selected' : ''?>><?= $color->name?></option>
													<?php endforeach;?>
										        </select>
										        <?php else:?>
											    <input readonly=""  disabled="" type="text" class="form-control mr-b-0" name="attr[<?= $attrkey?>][<?= str_replace(' ','_',$val->name_en)?>]" value="<?= isset($attr_val[$val->name_en]) ? $attr_val[$val->name_en] : ''?>"></td>
											    <?php endif;?>
										<?php endforeach;?>
										<td class="text-center min-w-100 p-5"><input readonly=""  disabled="" type="text" class="form-control mr-b-0" name="attr[<?= $attrkey?>][sku]" value="<?= $price_sku['sku'][$attrkey]?>" required></td>
										<td class="text-center min-w-100 p-5"><input readonly=""  disabled="" type="number" class="form-control mr-b-0" name="attr[<?= $attrkey?>][qty]" value="<?= $price_sku['qty'][$attrkey]?>" required></td>
										<td class="text-center min-w-100 p-5"><input readonly=""  disabled="" type="number" class="form-control mr-b-0" name="attr[<?= $attrkey?>][price]" step="0.001" value="<?= number_format($price_sku['price'][$attrkey],3)?>" required></td>
										<td class="remove-row"><button class="btn btn-primary btn-remove-attr" type="button" title="Remove">-</button></td>
									</tr>
								<?php endforeach;?>
							<?php else:?>
									<tr class="attr_fields">
										<?php foreach($pa as $key => $val):?>
											<td class="text-center min-w-100 p-5"><input readonly=""  disabled="" type="text" class="form-control mr-b-0" name="attr[0][<?= str_replace(' ','_',$val->name_en)?>]"></td>
										<?php endforeach;?>
										<td class="text-center min-w-100 p-5"><input readonly=""  disabled="" type="text" class="form-control mr-b-0" name="attr[0][sku]"></td>
										<td class="text-center min-w-100 p-5"><input readonly=""  disabled="" type="number" class="form-control mr-b-0" name="attr[0][qty]"></td>
										<td class="text-center min-w-100 p-5"><input readonly=""  disabled="" type="number" class="form-control mr-b-0" step="0.001" name="attr[0][price]"></td>
										<td class="remove-row">&nbsp;</td>
									</tr>
							<?php endif;?>											
						</tbody>
					</table>
				</div>
			</div>
			<a href="javascript:;" id="attribute-btn" class="add-more btn-add-moreattr"><i class="fas fa-plus"></i>{{ __('Add More Attributes') }} </a>
		
	</div>
</div>








<!--/*////////////////////attributes end ////////////////////////////////////////////-->

                                            

											

												<div class="row current-price <?= ($data->is_multiple_products == 1) ? 'showbox' : ''?>">
													<div class="col-lg-4">
														<div class="left-area">
															<h4 class="heading">
																{{ __('Product Current Price') }}*
															</h4>
															<p class="sub-heading">
																({{ __('In') }} {{$sign->name}})
															</p>
														</div>
													</div>
													<div class="col-lg-7">
														<input readonly=""  disabled="" name="price" type="number" class="input-field" placeholder="e.g 20" step="0.001" min="0" value="{{number_format($data->price * $sign->value , 3)}}" required="">
													</div>
												</div>

												<div class="row previous-price <?= ($data->is_multiple_products == 1) ? 'showbox' : ''?>">
													<div class="col-lg-4">
														<div class="left-area">
																<h4 class="heading">{{ __('Product Previous Price') }}*</h4>
																<p class="sub-heading">{{ __('(Optional)') }}</p>
														</div>
													</div>
													<div class="col-lg-7">
														<input readonly=""  disabled="" name="previous_price" step="0.001" type="number" class="input-field" placeholder="e.g 20" value="{{number_format($data->previous_price * $sign->value , 3)}}" min="0">
													</div>
												</div>
												
												
													<div class="row">
													<div class="col-lg-4">
														<div class="left-area">
															<h4 class="heading">
																{{ __('Product Weight') }}*
															</h4>
														
														</div>
													</div>
													<div class="col-lg-7">
														<input readonly=""  disabled="" name="weight" type="number" class="input-field" placeholder="e.g 20" step="0.1" min="0" value="{{$data->weight}}" required="">
													</div>
												</div>
												
												
												
												<div class="product-stock <?= ($data->is_multiple_products == 1) ? 'showbox' : ''?>" id="stckprod">
												<div class="row">
													<div class="col-lg-4">
														<div class="left-area">
																<h4 class="heading">{{ __('Product Stock') }}*</h4>
																<p class="sub-heading">{{ __('(Leave Empty will Show Always Available)') }}</p>
														</div>
													</div>
													<div class="col-lg-7">
														<input readonly=""  disabled="" name="stock" type="text" class="input-field" placeholder="e.g 20" value="{{ $data->stock }}">
														<div class="checkbox-wrapper">
															<input readonly=""  disabled="" type="checkbox" name="measure_check" class="checkclick1" id="allowProductMeasurement" value="1" {{ $data->measure == null ? '' : 'checked' }}>
															<label for="allowProductMeasurement">{{ __('Allow Product Measurement') }}</label>
														</div>
													</div>
												</div>

												</div>

											<div class="{{ $data->measure == null ? 'showbox' : '' }}">

												<div class="row">
													<div class="col-lg-4">
														<div class="left-area">
																<h4 class="heading">{{ __('Product Measurement') }}*</h4>
														</div>
													</div>
													<div class="col-lg-3">
															<select readonly=""  disabled=""id="product_measure">
			                                                  <option value="" {{$data->measure == null ? 'selected':''}}>{{ __('None') }}</option>
			                                                  <option value="Gram" {{$data->measure == 'Gram' ? 'selected':''}}>{{ __('Gram') }}</option>
			                                                  <option value="Kilogram" {{$data->measure == 'Kilogram' ? 'selected':''}}>{{ __('Kilogram') }}</option>
			                                                  <option value="Litre" {{$data->measure == 'Litre' ? 'selected':''}}>{{ __('Litre') }}</option>
			                                                  <option value="Pound" {{$data->measure == 'Pound' ? 'selected':''}}>{{ __('Pound') }}</option>
			                                                  <option value="Custom" {{ in_array($data->measure,explode(',', 'Gram,Kilogram,Litre,Pound')) ? '' : 'selected' }}>{{ __('Custom') }}</option>
						                                     </select>
													</div>
													<div class="col-lg-1"></div>
													<div class="col-lg-3 {{ in_array($data->measure,explode(',', 'Gram,Kilogram,Litre,Pound')) ? 'hidden' : '' }}" id="measure">
														<input readonly=""  disabled="" name="measure" type="text" id="measurement" class="input-field" placeholder="Enter Unit" value="{{$data->measure}}">
													</div>
												</div>

											</div>


												<div class="row">
													<div class="col-lg-4">
														<div class="left-area">
															<h4 class="heading">
																	{{ __('Product Description (english)') }}*
															</h4>
														</div>
													</div>
													<div class="col-lg-7">
														<div class="text-editor">
															<textarea readonly=""  disabled="" cols="73" rows="5">{{$data->details}}</textarea> 
														</div>
													</div>
												</div>
												
												
												<div class="row">
													<div class="col-lg-4">
														<div class="left-area">
															<h4 class="heading">
																	{{ __('Product Description (Arabic)') }}*
															</h4>
														</div>
													</div>
													<div class="col-lg-7">
														<div class="text-editor">
															<textarea readonly=""  disabled="" cols="73" rows="5">{{ isset($data->details_ar) ? $data->details_ar : '' }}</textarea> 
														</div>
													</div>
												</div>
												<div class="row">
													<div class="col-lg-4">
														<div class="left-area">
															<h4 class="heading">
																	{{ __('Product Information') }}*
															</h4>
														</div>
													</div>
													<div class="col-lg-7">
														<div class="text-editor">
															<textarea readonly=""  disabled="" cols="73" rows="5">{{$data->product_info}}</textarea> 
														</div>
													</div>
												</div>


												<div class="row">
													<div class="col-lg-4">
														<div class="left-area">
															<h4 class="heading">
																	{{ __('Product Buy/Return Policy (English)') }}*
															</h4>
														</div>
													</div>
													<div class="col-lg-7">
														<div class="text-editor">
															<textarea readonly=""  disabled="" cols="73" rows="5">{{$data->policy}}</textarea> 
														</div>
													</div>
												</div>
												
												
													<div class="row">
													<div class="col-lg-4">
														<div class="left-area">
															<h4 class="heading">
																	{{ __('Product Buy/Return Policy (Arabic)') }}*
															</h4>
														</div>
													</div>
													<div class="col-lg-7">
														<div class="text-editor">
															<textarea readonly=""  disabled="" cols="73" rows="5">{{isset($data->policy) ? $data->policy : '' }}</textarea> 
														</div>
													</div>
												</div>
												
												
												


												<div class="row">
													<div class="col-lg-4">
														<div class="left-area">
																<h4 class="heading">{{ __('Youtube Video URL') }}*</h4>
																<p class="sub-heading">{{ __('(Optional)') }}</p>
														</div>
													</div>
													<div class="col-lg-7">
														<input readonly=""  disabled=""  name="youtube" type="text" class="input-field" placeholder="Enter Youtube Video URL" value="{{$data->youtube}}">
						                            <div class="checkbox-wrapper">
						                              <input readonly=""  disabled="" type="checkbox" name="seo_check" value="1" class="checkclick" id="allowProductSEO" {{ ($data->meta_tag != null || strip_tags($data->meta_description) != null) ? 'checked':'' }}>
						                              <label for="allowProductSEO">{{ __('Allow Product SEO') }}</label>
						                            </div>
													</div>
												</div>



						                        <div class="{{ ($data->meta_tag == null && strip_tags($data->meta_description) == null) ? "showbox":"" }}">
						                          <div class="row">
						                            <div class="col-lg-4">
						                              <div class="left-area">
						                                  <h4 class="heading">{{ __('Meta Tags') }} *</h4>
						                              </div>
						                            </div>
						                            <div class="col-lg-7">
						                              <ul id="metatags" class="myTags">
						                              	@if(!empty($data->meta_tag))
							                                @foreach ($data->meta_tag as $element)
							                                  <li>{{  $element }}</li>
							                                @endforeach
						                                @endif
						                              </ul>
						                            </div>
						                          </div>  

						                          <div class="row">
						                            <div class="col-lg-4">
						                              <div class="left-area">
						                                <h4 class="heading">
						                                    {{ __('Meta Description') }} *
						                                </h4>
						                              </div>
						                            </div>
						                            <div class="col-lg-7">
						                              <div class="text-editor">
						                                <textarea readonly=""  disabled="" cols="73" rows="5" placeholder="{{ __('Details') }}">{{ $data->meta_description }}</textarea> 
						                              </div>
						                            </div>
						                          </div>
						                        </div>

												<div class="row">
													<div class="col-lg-4">
														<div class="left-area">

														</div>
													</div>
													<div class="col-lg-7">
														<div class="featured-keyword-area">
															<div class="heading-area">
																<h4 class="title">{{ __('Feature Tags') }}</h4>
															</div>

															<div class="feature-tag-top-filds" id="feature-section">
																@if(!empty($data->features))

																	 @foreach($data->features as $key => $data1)

																<div class="feature-area">
																	<span class="remove feature-remove"><i class="fas fa-times"></i></span>
																	<div class="row">
																		<div class="col-lg-6">
																		<input readonly=""  disabled="" type="text" name="features[]" class="input-field" placeholder="{{ __('Enter Your Keyword') }}" value="{{ $data->features[$key] }}">
																		</div>

																		<div class="col-lg-6">
											                                <div class="input-group colorpicker-component cp">
											                                  <input readonly=""  disabled="" type="text" name="colors[]" value="{{ $data->colors[$key] }}" class="input-field cp"/>
											                                  <span class="input-group-addon"><i></i></span>
											                                </div>
																		</div>
																	</div>
																</div>


																		@endforeach
																@else 

																<div class="feature-area">
																
																	<div class="row">
																		<div class="col-lg-6">
																		<input readonly=""  disabled="" type="text" name="features[]" class="input-field" placeholder="{{ __('Enter Your Keyword') }}">
																		</div>

																		<div class="col-lg-6">
											                                <div class="input-group colorpicker-component cp">
											                                  <input readonly=""  disabled="" type="text" name="colors[]" value="#000000" class="input-field cp"/>
											                                  <span class="input-group-addon"><i></i></span>
											                                </div>
																		</div>
																	</div>
																</div>

																@endif
															</div>

															
														</div>
													</div>
												</div>
												<div class="row">
													<div class="col-lg-4">
														<div class="left-area">

														</div>
													</div>
													<input readonly=""  disabled="" type="hidden" id="attachment_count" value="<?= count($attachmentData)?>">
													<div class="col-lg-7">
														<div class="attachment-area">
															<div class="heading-area">
																<h4 class="title">{{ __('Attachment') }}</h4>
															</div>

															<div class="feature-tag-top-filds" id="attachment-section">
																<?php 
																$attachmentData = array_filter($attachmentData);
																if(!empty($attachmentData)){
																foreach($attachmentData as $key => $attachment):?>
																	<div class="attachment-area">
																		<input readonly=""  disabled="" type="hidden" name="hidden_attachment[]" value="<?= $attachment?>">
																		<div class="row">
																			<div class="col-lg-6">
																			<input readonly=""  disabled="" id="prd_<?= $key?>" type="file" name="attachment[]" class="input-field attachment-file" placeholder="{{ __('Upload document') }}" accept=".pdf,.doc,.docx,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document" value="<?= $attachment?>" style="display: none;">
																			<label for="prd_<?= $key?>"><a href="javascript:void(0);" class="btn-change-attachment" style="color:blue;">Change</a>&nbsp;&nbsp;<?= $attachment?></label>
																			</div>
																		</div>
																	</div>
																<?php endforeach;?>
																<?php 
																}
																else{
																?>
																<div class="attachment-area">
																	<div class="row">
																		<div class="col-lg-6">
																		<input readonly=""  disabled="" type="file" name="attachment[]" class="input-field" placeholder="{{ __('Upload document') }}" accept=".pdf,.doc,.docx,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document">
																		</div>

																	</div>
																</div>
																<?php }?>
															</div>

															
														</div>
													</div>
												</div>

						                        <div class="row">
						                          <div class="col-lg-4">
						                            <div class="left-area">
						                                <h4 class="heading">{{ __('Tags') }} *</h4>
						                            </div>
						                          </div>
						                          <div class="col-lg-7">
						                            <ul id="tags" class="myTags">
						                            	@if(!empty($data->tags))
							                                @foreach ($data->tags as $element)
							                                  <li>{{  $element }}</li>
							                                @endforeach
						                                @endif
						                            </ul>
						                          </div>
						                        </div>



												<div class="row">
													<div class="col-lg-4">
														<div class="left-area">
															
														</div>
													</div>
													
												</div>
											</form>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
        <div class="modal fade" id="select-color-image-modal" tabindex="-1" role="dialog" aria-labelledby="setgallery" aria-hidden="true">
        	<div class="modal-dialog modal-dialog-centered  modal-lg" role="document">
        		<div class="modal-content">
        		<div class="modal-header">
        			<h5 class="modal-title" id="exampleModalCenterTitle">{{ __('Select Image') }}</h5>
        			<button type="button" class="close" data-dismiss="modal" aria-label="Close">
        			<span aria-hidden="true">×</span>
        			</button>
        		</div>
        		<div class="modal-body">
        			<div class="gallery-images">
        				<div class="product-selected-image">
        					<div class="row">
        					    <?php foreach($gallery_images_arr as $image):?>
                                <div class="col-sm-3">
                                    <div class="img gallery-img">
                                        <a href="{{$image}}" target="_blank">
                                        <span class="image-radio"><input readonly=""  disabled="" type="checkbox" name="color_images[]" class="color_images" value="{{$image}}"></i></span>
                                        <img src="{{$image}}" alt="gallery image">
                                        </a>
                                    </div>
                                    <input readonly=""  disabled="" type="hidden" id="image_index_val">
                                </div>
                                <?php endforeach;?>
        					</div>
        				</div>
        			</div>
        		</div>
        		<div class="modal-footer">
					<button type="button" class="btn-close" data-dismiss="modal" aria-label="Close">
					Ok
					</button>
				</div>
        		</div>
        	</div>
        </div>
		<div class="modal fade" id="setgallery" tabindex="-1" role="dialog" aria-labelledby="setgallery" aria-hidden="true">
			<div class="modal-dialog modal-dialog-centered  modal-lg" role="document">
				<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title" id="exampleModalCenterTitle">{{ __('Image Gallery') }}</h5>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">×</span>
					</button>
				</div>
				<div class="modal-body">
					<div class="top-area">
						<div class="row">
							<div class="col-sm-6 text-right">
								<div class="upload-img-btn">
									<form  method="POST" enctype="multipart/form-data" id="form-gallery">
										{{ csrf_field() }}
									<input readonly=""  disabled="" type="hidden" id="pid" name="product_id" value="">
									<input readonly=""  disabled="" type="file" name="gallery[]" class="hidden gallery_image" id="uploadgallery" accept="image/*" multiple>
											<label for="image-upload" id="prod_gallery"><i class="icofont-upload-alt"></i>{{ __('Upload File') }}</label>
									</form>
								</div>
							</div>
							<div class="col-sm-6">
								<a href="javascript:;" class="upload-done" data-dismiss="modal"> <i class="fas fa-check"></i> {{ __('Done') }}</a>
							</div>
							<div class="col-sm-12 text-center">( <small>{{ __('You can upload multiple Images.') }}</small> )</div>
						</div>
					</div>
					<div class="gallery-images">
						<div class="selected-image">
							<div class="row">


							</div>
						</div>
					</div>
				</div>
				</div>
			</div>
		</div>
<input readonly=""  disabled="" type="hidden" id="get_base64image" value="<?= URL('/getbase64image');?>">
<input readonly=""  disabled="" type="hidden" id="base_url" value="<?= URL('/')?>">
@endsection

@section('scripts')

<script type="text/javascript">
function readAndPreview(file) {
    // Make sure `file.name` matches our extensions criteria
    if ( /\.(jpe?g|png|gif)$/i.test(file.name) ) {
      var reader = new FileReader();

      reader.addEventListener("load", function () {
        var image = this.result
        $.ajax({
            type: "POST",
            url: $("#get_base64image").val(),
            data:{image:image},
            beforeSend: function(){
                $(".gocover").show();  
            },
            success:function(data){
                $(".gocover").hide();
                var image = $("#base_url").val()+'/assets/images/products/'+data;
                $('.product-selected-image .row').append('<div class="col-sm-6">'+
                    '<div class="img gallery-img">'+
                        '<a href="'+image+'" target="_blank">'+
                        '<span class="image-radio"><input readonly=""  disabled="" type="checkbox" name="color_images[]" class="color_images" value="'+image+'"></i></span>'+
                        '<img src="'+image+'" alt="gallery image">'+
                        '</a>'+
                    '</div>'+
                    '<input readonly=""  disabled="" type="hidden" id="image_index_val">'+
              '</div> '
                  );
            }
        })
        
      }, false);

      reader.readAsDataURL(file);
    }
}
$(document).on("click",".upload-done", function(){
        var file_data = $('#uploadgallery').prop('files')[0];
        var files   = document.querySelector('.gallery_image').files;
        if (files) {
            [].forEach.call(files, readAndPreview);
        }
    })
    $(document).on('select2:select', function (e) {
        var color_arr = [];
        $('.select2-selection__rendered').each(function(index, element){
            //console.log('demo   '+$(element).attr('title'));
            color_arr.push($(element).attr('title'));
        });
        var uniqueColors = [];
        $.each(color_arr, function(i, el){
            if($.inArray(el, uniqueColors) === -1) uniqueColors.push(el);
        });
        var options = '';
        jQuery.each(uniqueColors, function(index, item) {
            options += '<option value="'+item+'">'+item+'</option>';
        });
        $(".attr-color").html(options);
    });
    $(document).on("click",".color-remove", function(){
       $(this).parent().remove(); 
       var color_arr = [];
        $('.select2-selection__rendered').each(function(index, element){
            //console.log('demo   '+$(element).attr('title'));
            color_arr.push($(element).attr('title'));
        });
        var uniqueColors = [];
        $.each(color_arr, function(i, el){
            if($.inArray(el, uniqueColors) === -1) uniqueColors.push(el);
        });
        var options = '';
        jQuery.each(uniqueColors, function(index, item) {
            options += '<option value="'+item+'">'+item+'</option>';
        });
        $(".attr-color").html(options);
    });
    $(document).on("click",".btn-close", function(){
        var image_arr = [];
        $(".color_images:checked").each(function() {
            image_arr.push($(this).val());
			$(this).prop('checked', false); 
        });
        console.log(image_arr);
        var color_index = $("#select-color-image-modal #image_index_val").val();
        $("#color_image_"+color_index).val(image_arr.join(","));
    })
	$(".is_multiple_products_color_images").click(function(){
	      if(this.checked) {
	         $("#product-color-container").removeClass('showbox');   
	         var color_arr = [];
            $('.select2-selection__rendered').each(function(index, element){
                //console.log('demo   '+$(element).attr('title'));
                color_arr.push($(element).attr('title'));
            });
            var uniqueColors = [];
            $.each(color_arr, function(i, el){
                if($.inArray(el, uniqueColors) === -1) uniqueColors.push(el);
            });
            var options = '';
            jQuery.each(uniqueColors, function(index, item) {
                options += '<option value="'+item+'">'+item+'</option>';
            });
            $(".attr-color").html(options);
	      }
	      else
	      {
	          $("#product-color-container").addClass('showbox');   
	      }
	});
	var colors = '<?= $color_data?>';
	colors = JSON.parse(colors);
	var selected_colors = '<?= $selected_color_arr?>';
	selected_colors = JSON.parse(selected_colors);
	//console.log(selected_colors);
    var colors_data = [];
    jQuery.each(colors, function(index, item) {
        console.log("---"+item.code+"---");
        console.log("==="+item.name+"===");
        colors_data.push({id:item.name,text:item.name,html:item.name+"<span style='background:"+item.code+";border:3px solid #ddd;margin: 0 10px;float: right;width: 1.5rem;height: 1.5rem;'>&nbsp;</span>"});
    });
    function template(data) {
    	return data.html;
    }
    $(".product-color").select2({
      data: colors_data,
       templateResult: template,
       templateSelection: template,
       escapeMarkup: function(m) {
          return m;
       }
    });
    jQuery.each(selected_colors, function(index, item) {
        console.log('test123');
        console.log(index);
        $('.product-color:eq('+index+')').val(item.name); // Select the option with a value of '1'
        $('.product-color:eq('+index+')').trigger('change');
        //$('.product-color:eq('+index+')').select2('data', {id:item.name,text:item.name,html:item.name+"<span style='background:"+item.code+";border:3px solid #ddd;margin: 0 10px;float: right;width: 1.5rem;height: 1.5rem;'>&nbsp;</span>"});
    });
    //$('#all_contacts').select2('data', {id: '123', text: 'res_data.primary_email'});
// Gallery Section Update
	$(".is_multiple_products").click(function(){
	 	if ($(this).is(':checked')) {
			$(".attributes-row").removeClass('showbox');
			$(".current-price,.previous-price,.product-stock").addClass('showbox');
			$("#price").removeAttr('required');
		}
		else
		{
			$("#price").attr('required',true);
			$(".attributes-row").addClass('showbox');
			$(".current-price,.previous-price,.product-stock").removeClass('showbox');
		}
	 })
    $(document).on("click", ".set-gallery" , function(){
        var pid = $(this).find('input[type=hidden]').val();
        $('#pid').val(pid);
        $('.selected-image .row').html('');
            $.ajax({
                    type: "GET",
                    url:"{{ route('admin-gallery-show') }}",
                    data:{id:pid},
                    success:function(data){
                      if(data[0] == 0)
                      {
	                    $('.selected-image .row').addClass('justify-content-center');
	      				$('.selected-image .row').html('<h3>{{ __('No Images Found.') }}</h3>');
     				  }
                      else {
	                    $('.selected-image .row').removeClass('justify-content-center');
	      				$('.selected-image .row h3').remove();      
                          var arr = $.map(data[1], function(el) {
                          return el });

                          for(var k in arr)
                          {
        				$('.selected-image .row').append('<div class="col-sm-3">'+
                                        '<div class="img gallery-img">'+
                                            '<span class="remove-img"><i class="fas fa-times"></i>'+
                                            '<input readonly=""  disabled="" type="hidden" value="'+arr[k]['id']+'">'+
                                            '</span>'+
                                            '<a href="'+'{{asset('assets/images/galleries').'/'}}'+arr[k]['photo']+'" target="_blank">'+
                                            '<img src="'+'{{asset('assets/images/galleries').'/'}}'+arr[k]['photo']+'" alt="gallery image">'+
                                            '</a>'+
                                        '</div>'+
                                  	'</div>');
                          }                         
                       }
 
                    }
                  });
      });


  $(document).on('click', '.remove-img' ,function() {
    var id = $(this).find('input[type=hidden]').val();
    $(this).parent().parent().remove();
	    $.ajax({
	        type: "GET",
	        url:"{{ route('admin-gallery-delete') }}",
	        data:{id:id}
	    });
  });

  $(document).on('click', '#prod_gallery' ,function() {
    $('#uploadgallery').click();
  });
   $(document).on("click",".btn-select-image", function(){
      var index = $(this).data('index');
      $("#image_index_val").val(index);
  })  
                                        
                                
  $("#uploadgallery").change(function(){
    $("#form-gallery").submit();  
  });

  $(document).on('submit', '#form-gallery' ,function() {
		  $.ajax({
		   url:"{{ route('admin-gallery-store') }}",
		   method:"POST",
		   data:new FormData(this),
		   dataType:'JSON',
		   contentType: false,
		   cache: false,
		   processData: false,
		   success:function(data)
		   {
		    if(data != 0)
		    {
	                    $('.selected-image .row').removeClass('justify-content-center');
	      				$('.selected-image .row h3').remove();   
		        var arr = $.map(data, function(el) {
		        return el });
		        for(var k in arr)
		           {
        				$('.selected-image .row').append('<div class="col-sm-6">'+
                                        '<div class="img gallery-img">'+
                                            '<span class="remove-img"><i class="fas fa-times"></i>'+
                                            '<input readonly=""  disabled="" type="hidden" value="'+arr[k]['id']+'">'+
                                            '</span>'+
                                            '<a href="'+'{{asset('assets/images/galleries').'/'}}'+arr[k]['photo']+'" target="_blank">'+
                                            '<img src="'+'{{asset('assets/images/galleries').'/'}}'+arr[k]['photo']+'" alt="gallery image">'+
                                            '</a>'+
                                        '</div>'+
                                  	'</div>');
		            }          
		    }
		                     
		                       }

		  });
		  return false;
 }); 


// Gallery Section Update Ends	

</script>

<script src="{{asset('assets/admin/js/jquery.Jcrop.js')}}"></script>

<script src="{{asset('assets/admin/js/jquery.SimpleCropper.js')}}"></script>

<script type="text/javascript">
	
$('.cropme').simpleCropper();
$('#crop-image').on('click',function(){
$('.cropme').click();
});
</script>


  <script type="text/javascript">
  $(document).ready(function() {

    let html = `<img src="{{ empty($data->photo) ? asset('assets/images/noimage.png') : filter_var($data->photo, FILTER_VALIDATE_URL) ? $data->photo : asset('assets/images/products/'.$data->photo) }}" alt="">`;
    $(".span4.cropme").html(html);

    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

  });


  $('.ok').on('click', function () {

 setTimeout(
    function() {


  	var img = $('#feature_photo').val();

      $.ajax({
        url: "{{route('admin-prod-upload-update',$data->id)}}",
        type: "POST",
        data: {"image":img},
        success: function (data) {
          if (data.status) {
            $('#feature_photo').val(data.file_name);
          }
          if ((data.errors)) {
            for(var error in data.errors)
            {
              $.notify(data.errors[error], "danger");
            }
          }
        }
      });

    }, 1000);



    });

  </script>

  <script type="text/javascript">

  $('#imageSource').on('change', function () {
    var file = this.value;
      if (file == "file"){
          $('#f-file').show();
          $('#f-link').hide();
      }
      if (file == "link"){
          $('#f-file').hide();
          $('#f-link').show();
      }
  });
  
  
   var cloneCount = 1;

   
  var plen = '<?php echo json_encode($pa) ?>';
  var jsonData = JSON.parse(plen);
  console.log(jsonData);
$("#attribute-btn").on('click', function(){

<?php if(isset($data)) { ?>

var p_id = '<?php echo $data->id ?>';
  
  var list = [];
   $.each(jsonData, function(i, item) {
       console.log(item);
        if(p_id==item.product_id){
        list.push(item.id);
        }
    });
    
    console.log(list);
    
    var lastid = list[list.length-1];
    
    console.log("lastttid=>"+lastid);

 $('#attr_sec_'+lastid)
          .clone()
          .attr('id', 'attr_sec_'+lastid+ cloneCount++)
          .insertAfter('[id^=attr_sec_'+lastid+']:last') 
           //            ^-- Use '#id' if you want to insert the cloned 
           //                element in the beginning
          .append( $("#attr_sec_"+lastid)); //<--For DEMO
          
    // $("#attribute-section").append( $("#attribute-section").clone());


<?php }else{ ?>
 $('#attribute-section')
          .clone()
          .attr('id', 'attribute-section'+ cloneCount++)
          .insertAfter('[id^=attribute-section]:last') 
           //            ^-- Use '#id' if you want to insert the cloned 
           //                element in the beginning
          .append( $("#attribute-section")); //<--For DEMO
          
    // $("#attribute-section").append( $("#attribute-section").clone());
    
    <?php } ?>

});

var output = [];
var p = '<?php echo json_encode($pa) ?>';
console.log(p);
var option = '';
for (var i=0;i<p.length;i++){
    console.log(p[i]);
   option += '<option value="'+ p[i] + '">' + p[i]['id'] + '</option>';
}
$('#mySelect').append(option);

// function getQty(key,value,thisdiv){
    
//     console.log(thisdiv);
//     var inventories = '<?php echo json_encode($inv) ?>';
    
//     $.each(JSON.parse(inventories), function(k,v){
//         if(v.attribute_id == value){
//             $("#attr_qty_"+key).val(v.qty);
//         } 
//     });
  
// }


function addMoreLength(v){
   console.log(v);
// var curr_id = $(v).closest('div').find('.row_child').attr('id');
// var s = curr_id.split("_");

    $("#product_size_row_"+v).append(''+
                            '<div class="col-md-12">'+
                                        '<div class="col-md-12 col-sm-6">'+
                                         '<span class="remove length-remove" style="float:right"><i class="fas fa-times" style="padding:5px;"></i>'+
                                            '<label style="float:right">'+
                                            'Product Length :'+
                                            '</label></span>'+
                                            '</div>'+
                                             '<div class="col-md-12 col-sm-6" style="padding: 2% 30%;">'+
                                            '<input readonly=""  disabled="" type="text" name="size_length['+v+'][]" class="input-field" placeholder="Product Length">'+
                                        '</div>'+
                                '</div>'
                            +'');
}

  </script>

<script src="{{asset('assets/admin/js/product.js')}}"></script>
@endsection
<style>
    .row_child div{
        display:grid;
    }
</style>