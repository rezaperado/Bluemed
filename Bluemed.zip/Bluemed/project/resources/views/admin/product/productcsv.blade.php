@extends('layouts.admin')
@section('styles')

<link href="{{asset('assets/admin/css/product.css')}}" rel="stylesheet"/>

@endsection
@section('content')

						<div class="content-area">
							<div class="mr-breadcrumb">
								<div class="row">
									<div class="col-lg-12">
											<h4 class="heading">{{ __("Product Bulk Upload") }}</h4>
											<ul class="links">
												<li>
													<a href="{{ route('admin.dashboard') }}">{{ __("Dashboard") }} </a>
												</li>
											<li>
												<a href="javascript:;">{{ __("Products") }} </a>
											</li>
											<li>
												<a href="{{ route('admin-prod-index') }}">{{ __("All Products") }}</a>
											</li>
												<li>
													<a href="{{ route('admin-prod-import') }}">{{ __("Bulk Upload") }}</a>
												</li>
											</ul>
									</div>
								</div>
							</div>
							<div class="add-product-content">
								<div class="row">
									<div class="col-lg-12 p-5">

					                      <div class="gocover" style="background: url({{asset('assets/alsalwa.png')}}) no-repeat scroll center center rgba(45, 45, 45, 0.5);    background-size: 200px;
" ></div>
					                      <form id="geniusform" action="{{route('admin-prod-importsubmit')}}" method="POST" enctype="multipart/form-data">
					                        {{csrf_field()}}

                        @include('includes.admin.form-both')  

											  <div class="row">
												  <div class="col-lg-12 text-right">
													  <span style="margin-top:10px;"><a class="btn btn-primary" href="<?= URL('/assets/NewSampleExcel.xlsx')?>">{{ __("Download Sample Excel") }}</a></span>
												  </div>

											  </div>
											  <hr>
											  <div class="row justify-content-center">
												  <div class="col-lg-12 d-flex justify-content-center text-center">
														<div class="csv-icon">
																<i class="fas fa-file-csv"></i>
														</div>
												  </div>
												  <div class="col-lg-12 d-flex justify-content-center text-center">
													  <div class="left-area mr-4">
														  <h4 class="heading">{{ __("Upload a File") }} *</h4>
													  </div>
													  <span class="file-btn">
														  <input type="file" id="csvfile" name="csvfile" accept=".csv" required>
														  <textarea name="excel_data" id="excel_data" style="display:none"></textarea>
													  </span>

												  </div>

											  </div>

						                        <input type="hidden" name="type" value="Physical">
												<div class="row">
													<div class="col-lg-12 mt-4 text-center">
														<button class="mybtn1 mr-5" type="submit">{{ __("Start Import") }}</button>
													</div>
												</div>
											</form>
									</div>
								</div>
							</div>
						</div>



@endsection

@section('scripts')
<script src="https://catamphetamine.github.io/read-excel-file/read-excel-file.min.js"></script>
<script src="{{asset('assets/admin/js/product.js')}}"></script>
<script>

			var input = document.getElementById('csvfile')

			input.addEventListener('change', function() {
			  readXlsxFile(input.files[0], { dateFormat: 'MM/DD/YY' }).then(function(data) {
			    // `data` is an array of rows
			    // each row being an array of cells.
/*			    console.log(JSON.stringify(data, null, 2));
			    console.log(jQuery("#excel_data").length);*/
                jQuery("#excel_data").val(JSON.stringify(data, null, 2));
			    // Applying `innerHTML` hangs the browser when there're a lot of rows/columns.
			    // For example, for a file having 2000 rows and 20 columns on a modern
			    // mid-tier CPU it parses the file (using a "schema") for 3 seconds
			    // (blocking) with 100% single CPU core usage.
			    // Then applying `innerHTML` hangs the browser.

			    // document.getElementById('result-table').innerHTML =
			    // 	'<table>' +
			    // 	'<tbody>' +
			    // 	data.map(function (row) {
			    // 		return '<tr>' +
			    // 			row.map(function (cell) {
			    // 				return '<td>' +
				   //  				(cell === null ? '' : cell) +
				   //  				'</td>'
			    // 			}).join('') +
			    // 			'</tr>'
			    // 	}).join('') +
			    // 	'</tbody>' +
			    // 	'</table>'
			  }, function (error) {
			  	console.error(error)
			  	alert("Error while parsing Excel file. See console output for the error stack trace.")
			  })
			})
		
		
</script>
@endsection