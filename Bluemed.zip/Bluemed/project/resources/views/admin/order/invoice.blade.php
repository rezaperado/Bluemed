@extends('layouts.admin')

@section('content')
<div class="content-area">
    <div class="mr-breadcrumb">
        <div class="row">
            <div class="col-lg-12">
                <h4 class="heading">{{ __('Order Invoice') }} <a class="add-btn" href="javascript:history.back();"><i
                            class="fas fa-arrow-left"></i> {{ __('Back') }}</a></h4>
                <ul class="links">
                    <li>
                        <a href="{{ route('admin.dashboard') }}">{{ __('Dashboard') }} </a>
                    </li>
                    <li>
                        <a href="javascript:;">{{ __('Orders') }}</a>
                    </li>
                    <li>
                        <a href="javascript:;">{{ __('Invoice') }}</a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
    <div class="order-table-wrap">
        <div class="invoice-wrap">
            <div class="invoice__title">
                <div class="row">
                    <div class="col-sm-6">
                        <div class="invoice__logo text-left">
                           <img src="{{ asset('assets/images/'.$gs->invoice_logo) }}" alt="woo commerce logo">
                        </div>
                    </div>
                    <div class="col-lg-6 text-right">
                        <a class="btn  add-newProduct-btn print" href="{{route('admin-order-print',$order->id)}}"
                        target="_blank"><i class="fa fa-print"></i> {{ __('Print Invoice') }}</a>
                    </div>
                </div>
            </div>
            <br>
            <div class="row invoice__metaInfo mb-4">
                <div class="col-lg-6">
                    <div class="invoice__orderDetails">
                        
                        <p><strong>{{ __('Order Details') }} </strong></p>
                        <span><strong>{{ __('Invoice Number') }} :</strong> {{ sprintf("%'.08d", $order->id) }}</span><br>
                        <span><strong>{{ __('Order Date') }} :</strong> {{ date('d-M-Y',strtotime($order->created_at)) }}</span><br>
                        <span><strong>{{  __('Order ID')}} :</strong> {{ $order->order_number }}</span><br>
                        @if($order->dp == 0)
                        <span> <strong>{{ __('Shipping Method') }} :</strong>
                            @if($order->shipping == "pickup")
                            {{ __('Pick Up') }}
                            @else
                            {{ __('Ship To Address') }}
                            @endif
                        </span><br>
                        @endif
                        <span> <strong>{{ __('Payment Method') }} :</strong> {{$order->method}}</span>
                    </div>
                </div>
            </div>
            <div class="row invoice__metaInfo">
           @if($order->dp == 0)
                <div class="col-lg-6">
                        <div class="invoice__shipping">
                            <p><strong>{{ __('Shipping Address') }}</strong></p>
                            <?php $name = $user->first_name.' '.$user->last_name;?>
                           <span><strong>{{ __('Customer Name') }}</strong>: {{$user->shipping_first_name == null ? $name : $user->shipping_first_name.' '.$user->shipping_last_name}}</span><br>
                           <?php $address = $user->area.' '.$user->block?>
                           <span><strong>{{ __('Address') }}</strong>: {{($user->shipping_area == null || $user->shipping_block == null) ? $address : $user->shipping_area.' '.$user->shipping_block}}</span><br>
                           <?php $city = $user->city;?>
                           <span><strong>{{ __('City') }}</strong>: {{$user->shipping_city == null ? $city : $user->shipping_city}}</span><br>
                           <?php $country = getcountry($user->country)?>
                           <span><strong>{{ __('Country') }}</strong>: {{$order->shipping_country == null ? $country : getcountry($user->shipping_country)}}</span>

                        </div>
                </div>

            @endif

                <div class="col-lg-6">
                        <div class="buyer">
                            <p><strong>{{ __('Billing Details') }}</strong></p>
                            <span><strong>{{ __('Customer Name') }}</strong>: {{$user->first_name}}&nbsp;{{$user->last_name}}</span><br>
                            <span><strong>{{ __('Address') }}</strong>: {{$user->area}} &nbsp;{{$user->block}}</span><br>
                            <span><strong>{{ __('City') }}</strong>: {{$user->city}}</span><br>
                            <span><strong>{{ __('Country') }}</strong>: {{getcountry($user->country)}}</span>
                        </div>
                </div>
            </div>

            <div class="row">
                <div class="col-sm-12">
                    <div class="invoice_table">
                        <div class="mr-table">
                            <div class="table-responsive">
                                 <table class="woocommerce-table woocommerce-table--order-details shop_table order_details table table-bordered">
                                                          <tr>
                                                            <th>#</th>
                                                            <th>{{ __('messages.sku') }}</th>
                                                            <th>Variation</th>
                                                            <th>{{ __('messages.product_name') }}</th>
                                                            <th>{{ __('messages.quantity') }}</th>
                                                            <th>{{ __('messages.price') }}</th>
                                                            <th>{{ __('messages.total_price') }}</th>
                                                          </tr>
                                                          <?php 
                                                                $total_price = 0;
                                                                $index = 1;
                                                                foreach($cart->items as $key=>$product):?>
                                                                <?php  $price = getVariationPrice($product['item']['id']);
                                                                  $total_price += $price*$product['qty'];
                                                                  ?>
                                                          <tr>
                                                            <td>{{$index}}</td>
                                                            
                                                            <td>{{$product['item']['sku']}}</td>
                                                            
                                                            <td> @if(isset($product['variations']['Size']))
                            
                            Size :- {{$product['variations']['Size']}} /
                            @endif
                            
                             @if(isset($product['variations']['Size']))
                            
                            Color :- {{$product['variations']['Color']}} /
                            @endif
                            
                             @if(isset($product['variations']['SKU']))
                            
                            SKU :- {{$product['variations']['SKU']}}
                            @endif</td>
                                                            
                                                            <td>{{strlen($product['item']['name']) > 25 ? substr($product['item']['name'],0,25).'...' : $product['item']['name']}}
                                                              </td>
                                                            <td>{{$product['qty']}}</td>
                                                            <td>{{$order->currency_sign}} {{number_format($price,3)}}</td>
                                                            <td>{{$order->currency_sign}} {{number_format($price*$product['qty'],3)}}</td>
                                                            
                                                          </tr>
                                                        <?php $index++;endforeach;?>
                                                        <td colspan="6" class="text-right">{{ __('messages.subtotal') }}</td><td>{{$order->currency_sign}}{{number_format($total_price * $order->currency_value,3)}}</td>
                                                        <?php if(!empty($order->shipping_cost)):?>
                                                        <tr>
                                                          <td colspan="6" class="text-right">{{ __('messages.shipping_charge') }}</td><td>{{$curr->sign}} {{number_format($order->shipping_cost,3)}}</td>
                                                        </tr>
                                                        <?php endif;?>
                                                        <tr>
                                                          <td colspan="6" class="text-right">{{ __('messages.total') }}</td><td>{{$order->currency_sign}}{{number_format($order->pay_amount,3)}}</td>
                                                        </tr>
                                                        </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Main Content Area End -->
</div>
</div>
</div>

@endsection