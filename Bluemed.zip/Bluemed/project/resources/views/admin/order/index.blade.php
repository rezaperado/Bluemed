@extends('layouts.admin') 

@section('styles')

<style type="text/css">
    
.input-field { 
    padding: 15px 20px; 
}

</style>

@endsection

@section('content')  

<input type="hidden" id="headerdata" value="{{ __('ORDER') }}">

                    <div class="content-area">
                        <div class="mr-breadcrumb">
                            <div class="row">
                                <div class="col-lg-12">
                                        <h4 class="heading">{{ __('All Orders') }}</h4>
                                        <ul class="links">
                                            <li>
                                                <a href="{{ route('admin.dashboard') }}">{{ __('Dashboard') }} </a>
                                            </li>
                                            <li>
                                                <a href="javascript:;">{{ __('Orders') }}</a>
                                            </li>
                                            <li>
                                                <a href="{{ route('admin-order-index') }}">{{ __('All Orders') }}</a>
                                            </li>
                                        </ul>
                                </div>
                            </div>
                        </div>
                        <div class="product-area">
                            <div class="row">

                                <div class="col-lg-12">
                                    @if(session()->has('success'))
                                        <div class="alert alert-success" style="width: 97%;margin:15px;">
                                            {{ session()->get('success') }}
                                        </div>
                                    @endif
                                    <?php $users = \DB::table("users")->get(); ?>
                                   
                                    
                                    <div class="mr-table allproduct">
                                        
                                        @include('includes.admin.form-success') 
                                        <div class="table-responsiv">
                                        <div class="gocover" style="background: url({{asset('assets/images/'.$gs->admin_loader)}}) no-repeat scroll center center rgba(45, 45, 45, 0.5);"></div>
                              
                              
                               <select name="user_name" id="user_name" style="width:20%;margin: 0px 20px 20px 20px;">
                                   <option value="">Select Customer</option>
                                    @foreach($users as $value)
                                        <option value="{{$value->id}}">{{$value->name}}</option>
                                    @endforeach
                                </select>             

                                <select name="status" id="delivery_status" style="width:20%;margin: 0px 20px 20px 20px;">
                                    <option value="">Select Delivery Status</option>
                                    <option value="pending">Pending</option>
                                    <option value="processing">Processing</option>
                                    <option value="on delivery">On Delivery</option>
                                    <option value="completed">Completed</option>
                                    <option value="declined">Declined</option>
                                </select>
                            
                              <button type="button" class="btn btn-primary" id="date_filter" style="margin:20px;">

                                <span>

                                  <i class="fa fa-calendar"></i>Filter by date

                                </span>

                                <i class="fa fa-caret-down"></i>

                              </button>
                              
                              <select name="filter_country" id="filter_country" style="width:20%;margin: 0px 20px 20px 20px;">
                                  <option value="0">Kuwait</option>
                                  <option value="1">International</option>
                              </select>

                                                
                            <button type="button" name="excel" value="excel" id="exportar" style="margin:20px;">Download Excel</button>
                               
                                 
                                                <table id="geniustable" class="table table-hover dt-responsive" cellspacing="0" width="100%">
                                                    <thead>
                                                        <tr>
                                                             <th>{{ __('Order Number') }}</th>
                                                              <th>{{ __('Order Date') }}</th>
                                                            <th>{{ __('Customer Email') }}</th>
                                                            <th>{{ __('Total Qty') }}</th>
                                                            <th>{{ __('Total Cost') }}</th>
                                                            <th>{{ __('Deliver Status') }}</th>
                                                            <th class="noExl">{{ __('Actions') }}</th>
                                                        </tr>
                                                    </thead>
                                                </table>
                                                
                                                <?php $orders = \DB::table("orders")->select('orders.*',DB::raw("CONCAT(users.first_name,' ',users.last_name) as fullname"),"users.email")->join('users', 'users.id', '=', 'orders.user_id')->get(); ?>
                                                <table id="allorderstable" class="table table-hover dt-responsive" cellspacing="0" width="100%" style="display:none;">
                                                    <thead>
                                                        <tr>
                                                            <th>Order ID/Number</th>
                                                            <th>Order Date</th>
                                                            <th>Customer Name</th>
                                                            <!-- <th>Address</th> -->
                                                            <!-- <th>City</th> -->
                                                            <!-- <th>Country</th> -->
                                                            <!-- <th>Post Code</th> -->
                                                            <!-- <th>Phone</th> -->
                                                            <th>Email</th>
                                                            <th>Product Name</th>
                                                            <th>Product Size</th>
                                                            <th>Product Length</th>
                                                            <th>Sleeve Length</th>
                                                            <th>Total Cost</th>
                                                            <th>Payment Method</th>
                                                            <th>Myfatoorah Reference ID</th>
                                                            <th>Myfatoorah Order ID</th>
                                                            <th>Myfatoorah Invoice ID</th>
                                                            <th>Transaction Date(My fatoorah)</th>
                                                        </tr>
                                                    </thead>
                                                    
                                                    <tbody>
                                                        <?php $orderArr = []; $custArr= []; ?>
                                                        @foreach($orders as $v)
                                                        <?php $getProductDetails = \DB::table("ordered_product_details")->where('order_number',$v->order_number)->get(); ?>
                                                    
                                                      @if(isset($getProductDetails))
                                                        @foreach($getProductDetails as $val)
                                                        <?php array_push($orderArr,$val->order_number); ?>
                                                        <tr>
                                                            <td>{{$v->order_number}}</td>
                                                            <td>{{$v->created_at}}</td>
                                                          
                                                            <td>{{$v->fullname}}</td>
                                                            
                                                            <td>{{$v->email}}</td>
                                                       
                                                            <td>{{$val->product_name}}</td>
                                                            
                                                       
                                                            <td>{{$v->pay_amount}}</td>
                                                            <td>{{$v->method}}</td>
                                                            <td></td>
                                                            <td></td>
                                                            <td></td>
                                                            <td></td>
                                                            
                                                            
                                                        </tr>
                                                          @endforeach
                                                          
                                                          @endif
                                                            @if(!in_array($v->order_number,$orderArr))
                                                           <tr>
                                                            <td>{{$v->order_number}}</td>
                                                            <td>{{$v->created_at}}</td>
                                                          
                                                            <td>{{$v->fullname}}</td>
                                                            
                                                            <td>{{$v->email}}</td>
                                                            <td></td>
                                                            <td></td>
                                                            <td></td>
                                                            <td></td>
                                                       
                                                            <td>{{$v->pay_amount}}</td>
                                                            <td>{{$v->method}}</td>
                                                            <td></td>
                                                            <td></td>
                                                            <td></td>
                                                            <td></td>
                                                            
                                                             <?php 
                                                            // array_push($orderArr,$v->order_number);
                                                            //  array_push($custArr,$v->customer_email);
                                                        
                                                            ?>
                                                            </tr>
                                                          @endif
                                                           <?php 
                                                            // array_push($orderArr,$v->order_number);
                                                            //  array_push($custArr,$v->customer_email);
                                                        
                                                            ?>
                                                        @endforeach
                                                    </tbody>
                                                </table>
                                                
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

{{-- ORDER MODAL --}}

<div class="modal fade" id="confirm-delete1" tabindex="-1" role="dialog" aria-labelledby="modal1" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
        <div class="submit-loader">
            <img  src="{{asset('assets/images/'.$gs->admin_loader)}}" alt="">
        </div>
    <div class="modal-header d-block text-center">
        <h4 class="modal-title d-inline-block">{{ __('Update Status') }}</h4>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
    </div>

      <!-- Modal body -->
      <div class="modal-body">
        <p class="text-center">{{ __("You are about to update the order's Status.") }}</p>
        <p class="text-center">{{ __('Do you want to proceed?') }}</p>
        <input type="hidden" id="t-add" value="{{ route('admin-order-track-add') }}">
        <input type="hidden" id="t-id" value="">
        <input type="hidden" id="t-title" value="">
        <textarea class="input-field" placeholder="Enter Your Tracking Note (Optional)" id="t-txt"></textarea>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer justify-content-center">
            <button type="button" class="btn btn-default" data-dismiss="modal">{{ __('Cancel') }}</button>
            <a class="btn btn-success btn-ok order-btn">{{ __('Proceed') }}</a>
      </div>

    </div>
  </div>
</div>

{{-- ORDER MODAL ENDS --}}



{{-- MESSAGE MODAL --}}
<div class="sub-categori">
    <div class="modal" id="vendorform" tabindex="-1" role="dialog" aria-labelledby="vendorformLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="vendorformLabel">{{ __('Send Email') }}</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                </div>
            <div class="modal-body">
                <div class="container-fluid p-0">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="contact-form">
                                <form id="emailreply">
                                    {{csrf_field()}}
                                    <ul>
                                        <li>
                                            <input type="email" class="input-field eml-val" id="eml" name="to" placeholder="{{ __('Email') }} *" value="" required="">
                                        </li>
                                        <li>
                                            <input type="text" class="input-field" id="subj" name="subject" placeholder="{{ __('Subject') }} *" required="">
                                        </li>
                                        <li>
                                            <textarea class="input-field textarea" name="message" id="msg" placeholder="{{ __('Your Message') }} *" required=""></textarea>
                                        </li>
                                    </ul>
                                    <button class="submit-btn" id="emlsub" type="submit">{{ __('Send Email') }}</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            </div>
        </div>
    </div>
</div>





{{-- MESSAGE MODAL ENDS --}}



@endsection    

@section('scripts')

{{-- DATA TABLE --}}
<script type="text/javascript" src="https://cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script>
<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css" />
<script src="{{asset('assets/admin/js/jquery.table2excel.js')}}"></script>

    <script type="text/javascript">

$("#user_name,#filter_country,#delivery_status").change(function(){
    // alert($(this).val());
     table.ajax.reload();
});


$('#date_filter').daterangepicker(

        function (start, end) {

            $('#sell_date_filter span').html(start.format(moment_date_format) + ' ~ ' + end.format(moment_date_format));

            sell_table.ajax.reload();

        }

    );

   $('#date_filter').on('apply.daterangepicker', function(ev, picker) {

        // $('#date_filter').html(start.format(moment_date_format) + ' ~ ' + end.format(moment_date_format));

        table.ajax.reload();

    });
    
    
    // var start_date = date.getFullYear()+"-"+date.getMonth()+"-01";
    //  var end_date = date.getFullYear()+"-"+date.getMonth()+"-30";
    
        var table = $('#geniustable').DataTable({
               "order": [],
              
               processing: true,
               serverSide: true,
               
                ajax: {
                    "url":'{{ route('admin-order-datatables') }}',
                    "data":function(d) {
                         var date = new Date(); 
                     
                var start = date.getFullYear()+"-"+date.getMonth()+"-01";

                var end = date.getFullYear()+"-"+date.getMonth()+"-30";
                
                 //d.start_date = start;

                //d.end_date = end;
                
                            d.user_name = $('#user_name').val();
                            d.filter_country = $("#filter_country").val();
                             d.filter_delivery_status = $("#delivery_status").val();
                          
                    }
                },
                
              
               columns: [
                        { data: 'id', name: 'id' },
                         { data: 'order_date', name: 'order_date' },
                        { data: 'fullname', name: 'fullname' },
                        //{ data: 'city', name: 'city' },
                        //{ data: 'country', name: 'country' },
                        { data: 'totalQty', name: 'totalQty' },
                        { data: 'pay_amount', name: 'pay_amount' },
                        { data: 'status', name: 'status' },
                        { data: 'action', searchable: false, orderable: false, class:'noExl'}
                     ],
               language : {
                    processing: '<img src="{{asset('assets/images/'.$gs->admin_loader)}}">'
                },
                drawCallback : function( settings ) {
                        $('.select').niceSelect();  
                }
            });
            
            
     $("#exportar").click(function(){
        $("#allorderstable").table2excel({
           exclude: ".noExl",
          name: "Excel Document Name",
          filename: "orderlist",
          fileext: ".xls"
        });
    });
    
 $('input[name="dates"]').daterangepicker();
                                                                
    </script>

{{-- DATA TABLE --}}
    
@endsection
<style type="text/css">
  #loading {
        position: relative;
        width: 100%;
        height: 100px;
        background: #fff url('../assets/admin/images/spinner.gif') no-repeat center center;
        z-index: 9999;
    }
    
    .mr-table .action-list a{
        padding:10px !important; 
    }
</style>