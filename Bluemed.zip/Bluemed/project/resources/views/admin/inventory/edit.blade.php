@extends('layouts.load')

@section('content')

            <div class="content-area">

              <div class="add-product-content">
                <div class="row">
                  <div class="col-lg-12">
                    <div class="product-description">
                      <div class="body-area">
                        @include('includes.admin.form-error')  
                      <form id="geniusformdata" action="{{route('admin-inv-update',$data->id)}}" method="POST" enctype="multipart/form-data">
                        {{csrf_field()}}


                           <?php $pa =  \DB::table("attribute_masters")->get(); ?>
                        
                         <div class="row">
                          <div class="col-lg-4">
                            <div class="left-area">
                                <h4 class="heading">{{ __('Product Attributes') }} *</h4>
                            </div>
                          </div>
                          <div class="col-lg-7">
                           <select name="attribute_id" >
                               @foreach($pa as $value)
                                    @if($data->attribute_id == $value->id)
                                         <option value="{{$value->id}}"  selected>{{$value->name_en}} - {{$value->units}}</option>
                                    @else
                                        <option value="{{$value->id}}"  >{{$value->name_en}} - {{$value->units}}</option>
                                    @endif
                               @endforeach
                           </select>
                          </div>
                        </div>
                        
                        
                         <div class="row">
                          <div class="col-lg-4">
                            <div class="left-area">
                                <h4 class="heading">{{ __('Qty') }} *</h4>
                            </div>
                          </div>
                          <div class="col-lg-7">
                            <input type="text" class="input-field" name="qty" placeholder="{{ __('Enter Qty') }}" required="" value="{{$data->qty}}">
                          </div>
                        </div>
                        
                       
                        
                        
                         <div class="row">
                          <div class="col-lg-4">
                            <div class="left-area">
                                <h4 class="heading">{{ __('Description') }} *</h4>
                            </div>
                          </div>
                          <div class="col-lg-7">
                            <input type="text" class="input-field" name="description" placeholder="{{ __('Enter Description') }}" required="" value="{{$data->description}}">
                          </div>
                        </div>
                        
                        
                        
                        

                      

                        <br>
                        <div class="row">
                          <div class="col-lg-4">
                            <div class="left-area">
                              
                            </div>
                          </div>
                          <div class="col-lg-7">
                            <button class="addProductSubmit-btn" type="submit">{{ __('Save') }}</button>
                          </div>
                        </div>
                      </form>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

@endsection