@extends('layouts.admin') 

@section('content')  
<div class="content-area">
	<div class="mr-breadcrumb">
      <div class="row">
        <div class="col-lg-12">
            <h4 class="heading">Upload Images/Documents</h4>
            <ul class="links">
              <li>
                <a href="{{ route('admin.dashboard') }}">Dashboard </a>
              </li>
              <li>
                <a href="javascript:;">Upload Images/Documents</a>
              </li>
            </ul>
        </div>
      </div>
    </div>
    <div class="product-area">
    	<div class="row">
    		<div class="col-lg-12">
          <p class="error text-bold">**PLEASE UPLOAD IMAGE/DOCUMENT WITHOUT SPACE IN NAME**</p>
    			<div class="mr-table allproduct">
    				<form id="image-upload" action="{{route('dropzone.store')}}" method="POST" enctype="multipart/form-data" class="dropzone" files="true">
    					{{csrf_field()}}
		            <div>
		                <h3>Upload Multiple Image/Document By Click On Box</h3>
		            </div>
		            </form>
    			</div>
    		</div>
    	</div>
    </div>
</div>
<style>
.error{margin: 15px 0 0;
    color: red;
    text-align: center;}
.dropzone .dz-message {
    margin: 3em 0 !important;
}
</style>
@endsection 