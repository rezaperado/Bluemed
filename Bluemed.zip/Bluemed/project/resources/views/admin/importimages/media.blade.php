@extends('layouts.admin') 

@section('content')  
<style>
.nav-links{
        margin: 0 5px;
    border: 2px solid #ddd;
    padding: 5px 10px;
    border-radius: 5px;
}
.btn-upload{
    background: #1e7e34;
    color: #fff;
    margin: 0 5px;
}
.btn-upload:hover{
    color: #fff;
}
.remove-image{
    position: absolute;
    top: -8px;
    right: 2px;
    background: #fff;
    width: 23px;
    height: 23px;
    border: 1px solid rgba(0, 0, 0, 0.1);
    font-size: 14px;
    color: #000;
    border-radius: 50%;
    line-height: 20px;
    text-align: center;
    -webkit-box-shadow: 0px 5px 10px rgba(0, 0, 0, 0.2);
    box-shadow: 0px 5px 10px rgba(0, 0, 0, 0.2);
    cursor: pointer;
    font-weight: 600;
}
</style>
<div class="content-area">
	<div class="mr-breadcrumb">
      <div class="row">
        <div class="col-lg-12">
            <h4 class="heading">Media <button class="btn btn-upload" type="button" style="float:right">Upload</button></h4>
            <ul class="links">
              <li>
                <a href="{{ route('admin.dashboard') }}">Dashboard </a>
              </li>
              <li>
                <a href="javascript:;">Media</a>
              </li>
            </ul>
        </div>
      </div>
    </div>
    <div class="product-area">
    	<div class="row bulk-upload-row" style="display:none;">
    		<div class="col-lg-12">
          		<div class="mr-table allproduct">
    				<form id="image-upload" action="{{route('dropzone.store')}}" method="POST" enctype="multipart/form-data" class="dropzone" files="true">
    					{{csrf_field()}}
		            <div>
		                <h3>Upload Multiple Image By Click On Box</h3>
		            </div>
		            </form>
    			</div>
    		</div>
    	</div>
    	<div class="row" style="padding:20px 10px;">
    	       <div class="col-md-10 col-lg-10" style="text-align:right;"></div>
    	       <div class="col-lg-3 col-md-3" style="display:none"><input type="text" class="input-field" id="txtSearch" placeholder="Search..."></div>
    	</div>
    	
    
    	<div class="table-responsive" style="padding-right:10%;padding-left:10%">
    	    	<button class="btn btn-danger" onclick="delete_all()">Delete Selected</button>
    	    	
												<table class="table " cellspacing="0" width="100%" id="genius1">
													<thead>
														<tr>
														     <th>#</th>
									                        <th>{{ __('Image') }}</th>
									           <th>{{ __('Name') }}</th>              <th>{{ __('Action') }}</th> 
									                        
														</tr>
													</thead>
										<tbody>
										
										
    	<?php
    	//$handle = opendir(public_path('assets/images/galleries'));
    	$width = 100;
        $height = 200;
        $per_page = 30000;
        $page = isset($_GET['page']) ? $_GET['page'] : 0;
        $has_previous = false;
        $has_next = false;
    	?>
    	
    
   
    	    
    	    <?php 
    	    //global $page, $per_page, $has_previous, $has_next;
	if ( $handle = opendir(public_path('assets/images/galleries')) ) 
	{
	    
		$count = 0;
		$skip = $page * $per_page;
		
		if ( $skip != 0 )
			$has_previous = true;
		while ( $count < $skip && ($file = readdir($handle)) !== false ) 
		{
			if ( !is_dir($file) && ($type = showPictureType($file)) != '' )
				$count++;
		}
		$count = 0;$index = 0;
		while ( $count < $per_page && ($file = readdir($handle)) !== false ) 
		{
			if ( !is_dir($file) && ($type = showPictureType($file)) != '' )
	 		{
	 		    $image_name =  $file;
				echo '<tr><td><input type="checkbox" class="sel_img" name="checked"></td><td><div class=" image-col" id="image_col_'.$index.'"><img src="'.URL('assets/images/galleries/'.$file).'" alt=""  style="border: 1px solid #ddd;margin: 3px;width:150px;"/></td><td><p style="text-align:left;" class="image-name" data-index="'.$index.'">'.$image_name.'</p></div></td><td><button onclick="remove_image(this)" class=" btn btn-danger rm-btn" data-image="'.$file.'" style="position: initial;">X</button></td></tr>';
				$count++;
				$index++;
			}
		}
		while ( ($file = readdir($handle)) !== false ) {
			if ( !is_dir($file) && ($type = showPictureType($file)) != '' ) 
			{
				$has_next = true;
				break;
			}
		}
	}
    	    ?>
    
    
    		</table>
										</div>
										
										
    </div>
</div>
<input type="hidden" id="remove_image" value="<?= URL('/removeimage')?>">
<style>
.error{margin: 15px 0 0;
    color: red;
    text-align: center;}
.dropzone .dz-message {
    margin: 3em 0 !important;
}
</style>
@endsection

@section('scripts')
<script>
$('#genius1').DataTable({  responsive: true , stateSave : true,});


function delete_all()
{
   
     $(".gocover").show();  
    $('input.sel_img[type=checkbox]:checked').each(function () {
   
        var image = $(this).parents('tr').find('.rm-btn').data('image');
    $.ajax({
            type: "POST",
            url: $("#remove_image").val(),
            data:{image:image},
            beforeSend: function(){
               
            },
            success:function(data){
               
                
            }
       });
       
       
});

 $(".gocover").hide();
       location.reload();
}
function remove_image(clrt)
{

       $.ajax({
            type: "POST",
            url: $("#remove_image").val(),
            data:{image:image},
            beforeSend: function(){
                $(".gocover").show();  
            },
            success:function(data){
                $(".gocover").hide();
                location.reload();
            }
       });
}
$(document).ready(function(){
    $(".remove-image1").click(function(){
       var image = $(this).data('image');
       $.ajax({
            type: "POST",
            url: $("#remove_image").val(),
            data:{image:image},
            beforeSend: function(){
                $(".gocover").show();  
            },
            success:function(data){
                $(".gocover").hide();
                location.reload();
            }
       });
    });
    $(".btn-upload").click(function(){
      $(".bulk-upload-row").toggle();
    });
    $("#txtSearch").keyup(function(){
        var filter = $(this).val();
        // Loop through the comment list
        $(".image-col .image-name").each(function(){
            var index = $(this).data('index');
            if ($(this).text().search(new RegExp(filter, "i")) < 0) {
                $("#image_col_"+index).hide();
            } else {
                $("#image_col_"+index).show();
            }
        });
    });
});
</script>
@endsection 