@extends('layouts.load')



@section('content')



            <div class="content-area">



              <div class="add-product-content">

                <div class="row">

                  <div class="col-lg-12">

                    <div class="product-description">

                      <div class="body-area">

                        @include('includes.admin.form-error')  

                      <form id="geniusformdata" action="{{route('admin-color-create')}}" method="POST" enctype="multipart/form-data">

                        {{csrf_field()}}



                        <div class="row">

                          <div class="col-lg-4">

                            <div class="left-area">

                                <h4 class="heading">{{ __('Color Name(English)') }} *</h4>

                            </div>

                          </div>

                          <div class="col-lg-7">

                            <input type="text" class="input-field" name="color_name" placeholder="{{ __('Color Name(English)') }}" value="">

                          </div>

                        </div>
                        <div class="row">

                          <div class="col-lg-4">

                            <div class="left-area">

                                <h4 class="heading">{{ __('Color Name(Arabic)') }} *</h4>

                            </div>

                          </div>

                          <div class="col-lg-7">

                            <input type="text" class="input-field" name="color_name_ar" placeholder="{{ __('Color Name(Arabic)') }}" value="">

                          </div>

                        </div>

                        <div class="row">

                          <div class="col-lg-4">

                            <div class="left-area">

                                <h4 class="heading">{{ __('Color Code') }} </h4>

                            </div>

                          </div>

                          <div class="col-lg-7">

                            <!--<input type="text" class="input-field" name="color_code" placeholder="{{ __('Color code') }}" value="">-->
                            <div class="input-group colorpicker-component cp">
                              <input type="text" name="color_code" value="#000000"  class="input-field cp"/>
                              <span class="input-group-addon" style="margin-top:-5px !important;padding:4px 0px !important;"><i></i></span>
                            </div>
                          </div>

                        </div>


                        <div class="row">

                          <div class="col-lg-4">

                            <div class="left-area">

                              

                            </div>

                          </div>

                          <div class="col-lg-7">

                            <button class="addProductSubmit-btn" type="submit">{{ __('Create Color') }}</button>

                          </div>

                        </div>

                      </form>

                      </div>

                    </div>

                  </div>

                </div>

              </div>

            </div>



@endsection



