@extends('layouts.load')
@section('content')

						<div class="content-area">
							<div class="add-product-content">
								<div class="row">
									<div class="col-lg-12">
										<div class="product-description">
											<div class="body-area">
                        @include('includes.admin.form-error') 
											<form id="geniusformdata" action="{{ route('admin-staff-update',$data->id) }}" method="POST" enctype="multipart/form-data">
												{{csrf_field()}}

						                        <div class="row">
						                          <div class="col-lg-4">
						                            <div class="left-area">
						                                <h4 class="heading">{{ __('Staff Profile Image') }} *</h4>
						                            </div>
						                          </div>
						                          <div class="col-lg-7">
						                            <div class="img-upload">
						                                <div id="image-preview" class="img-preview" style="background: url({{ $data->photo ? asset('assets/images/admins/'.$data->photo) : asset('assets/images/noimage.png') }});">
						                                    <label for="image-upload" class="img-label" id="image-label"><i class="icofont-upload-alt"></i>{{ __('Upload Image') }}</label>
						                                    <input type="file" name="photo" class="img-upload" id="image-upload">
						                                  </div>
						                            </div>
						                          </div>
						                        </div>


												<div class="row">
													<div class="col-lg-4">
														<div class="left-area">
																<h4 class="heading">{{ __('Name') }} *</h4>
														</div>
													</div>
													<div class="col-lg-7">
														<input type="text" class="input-field" name="name" placeholder="{{ __("User Name") }}" required="" value="{{ $data->name }}">
													</div>
												</div>


												<div class="row">
													<div class="col-lg-4">
														<div class="left-area">
																<h4 class="heading">{{ __("Email") }} *</h4>
														</div>
													</div>
													<div class="col-lg-7">
														<input type="email" class="input-field" name="email" placeholder="{{ __("Email Address") }}" required="" value="{{ $data->email }}">
													</div>
												</div>

												<div class="row">
													<div class="col-lg-4">
														<div class="left-area">
																<h4 class="heading">{{ __("Phone") }} *</h4>
														</div>
													</div>
													<div class="col-lg-7">
														<input type="text" class="input-field" name="phone" placeholder="{{ __("Phone Number") }}" required="" value="{{ $data->phone }}">
													</div>
												</div>


												<div class="row">
														<div class="col-lg-4">
															<div class="left-area">
																	<h4 class="heading">{{ __("Role") }} *</h4>
															</div>
														</div>
														<div class="col-lg-7">
																<select  name="role_id" required="">
																	<option value="">{{ __('Select Role') }}</option>
																	  @foreach(DB::table('roles')->get() as $dta)
																		<option value="{{ $dta->id }}" {{ $data->role_id == $dta->id ? 'selected' : '' }}>{{ $dta->name }}</option>
																	  @endforeach
																</select>
														</div>
												</div>

												<div class="row">
													<div class="col-lg-4">
														<div class="left-area">
																<h4 class="heading">{{ __("Password") }} *</h4>
														</div>
													</div>
													<div class="col-lg-7">
														<input type="password" class="input-field" name="password" placeholder="{{ __("Password") }}" value="">
													</div>
												</div>






<h5 class="text-center">{{ __('Permissions') }}</h5>
                        <hr>
                        
                        
                        <?php
                        foreach($data2 as $view){ ?>
                        <div class="main-mod">
                        <h5>{{$view->type}}</h5>
                        
                        <input type="checkbox" onclick="check_all(this)" >
                            <span class="slider round"></span>
                           &nbsp; &nbsp; Select All 
                        
                        <?php
                        $value=DB::table('modules')->where('controller','=',$view->controller)->get(); ?>
                        
                        <div class="row ">
                    <?php 
                    $pid= array();
                        foreach($permission as $p)
                        {
                            $pid[]=$p->module_id;
                        }
                        foreach($value as $val){ ?>
                        
                                <div class="col-lg-4 ">
                                    <label class="switch">
                                    <input type="checkbox" name="per[]" value="{{$val->id }}" @if(in_array($val->id,$pid)) checked @endif>
                                    <span class="slider round"></span>
                                   &nbsp; &nbsp; {{$val->module_name }} </label>
                                </div>
                               
                    <?php }  ?>
                         </div> 
                         <hr>
                         </div>
                         <?php } ?>


                       
                       
                       
                       
                       
						                        <div class="row">
						                          <div class="col-lg-4">
						                            <div class="left-area">
						                              
						                            </div>
						                          </div>
						                          <div class="col-lg-7">
						                            <button class="addProductSubmit-btn" type="submit">{{ __("Save") }}</button>
						                          </div>
						                        </div>

											</form>


											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
						
						
<script>
function check_all(clrt)
{
    if($(clrt).prop("checked") == true)
    {
        //alert(1);
        $(clrt).parents('.main-mod').find('input:checkbox').prop('checked', true);
    }
    else{
      $(clrt).parents('.main-mod').find('input:checkbox').prop('checked', false);
    }
}
</script>

@endsection