@extends('layouts.admin') 

@section('content')  
					<input type="hidden" id="headerdata" value="{{ __('CATEGORY') }}">
					<div class="content-area">
						<div class="mr-breadcrumb">
							<div class="row">
								<div class="col-lg-12">
										<h4 class="heading">{{ __('Main Categories') }}</h4>
										<ul class="links">
											<li>
												<a href="{{ route('admin.dashboard') }}">{{ __('Dashboard') }} </a>
											</li>
											<li><a href="javascript:;">{{ __('Manage Categories') }}</a></li>
											<li>
												<a href="{{ route('admin-cat-index') }}">{{ __('Main Categories') }}</a>
											</li>
										</ul>
								</div>
							</div>
						</div>
						<div class="product-area">
							<div class="row">
								<div class="col-lg-12">
									<div class="mr-table allproduct">

                        @include('includes.admin.form-success')  

										<div class="table-responsiv">
												<table id="geniustable" class="table table-hover dt-responsive" cellspacing="0" width="100%">
													<thead>
														<tr>
									                        <th>{{ __('Name') }}</th>
									                        <th>{{ __('Slug') }}</th>
									                        <th>{{ __('Status') }}</th>
									                        <th>{{ __('Order') }}</th>
									                        <th>{{ __('Actions') }}</th>
														</tr>
													</thead>
												</table>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>

{{-- ADD / EDIT MODAL --}}

										<div class="modal fade" id="modal1" tabindex="-1" role="dialog" aria-labelledby="modal1" aria-hidden="true">
										
										<div class="modal-dialog modal-dialog-centered" role="document">
										<div class="modal-content">
												<div class="submit-loader">
														<img  src="{{asset('assets/images/'.$gs->admin_loader)}}" alt="">
												</div>
											<div class="modal-header">
											<h5 class="modal-title"></h5>
											<button type="button" class="close" data-dismiss="modal" aria-label="Close">
												<span aria-hidden="true">&times;</span>
											</button>
											</div>
											<div class="modal-body">

											</div>
											<div class="modal-footer">
											<button type="button" class="btn btn-secondary" data-dismiss="modal">{{ __('Close') }}</button>
											</div>
										</div>
										</div>
</div>

{{-- ADD / EDIT MODAL ENDS --}}

{{-- BULK UPLOAD MODAL --}}

<div class="modal fade" id="bulk-upload-modal" tabindex="-1" role="dialog" aria-labelledby="modal1" aria-hidden="true">
	<div class="modal-dialog modal-lg modal-dialog-centered" role="document">
		<div class="modal-content">
			<div class="submit-loader">
				<img  src="{{asset('assets/images/'.$gs->admin_loader)}}" alt="">
			</div>
			<div class="modal-header">
				<h5 class="modal-title">Bulk Category Upload</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body">
				<form id="geniusformdata" action="{{route('admin-cat-bulkupload')}}" method="POST" enctype="multipart/form-data">
                    {{csrf_field()}}

                    <div class="row">
					  <div class="col-lg-12 text-right">
						  <span style="margin-top:10px;"><a class="btn btn-primary" href="<?= URL('/')?>/assets/category-csv-format.csv">Download Sample CSV</a></span>
					  </div>
				  	</div>
				  	<div class="row">
				  		<div class="col-md-12">
					  		<div class="alert alert-success import-success-message" style="display: none;">
							  <strong>Success!</strong> Indicates a successful or positive action.
							</div>
						</div>
				  	</div>
                    <div class="row justify-content-center">
					  <div class="col-lg-12 d-flex justify-content-center text-center">
							<div class="csv-icon">
									<i class="fas fa-file-csv"></i>
							</div>
					  </div>
					  <div class="col-lg-12 d-flex justify-content-center text-center">
						  <div class="left-area mr-4">
							  <h5 class="heading">Upload a File *</h5>
						  </div>
						  <span class="file-btn">
							  <input type="file" id="csvfile" name="csvfile" accept=".csv">
						  </span>
					  </div>
				  	</div>
	                <div class="row">
	                  <div class="col-lg-4">
	                    <div class="left-area">
	                      
	                    </div>
	                  </div>
	                  <div class="col-lg-7">
	                    <button class="btn-submit-csv" type="button">Submit</button>
	                  </div>
	                </div>
	            </form>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-secondary" data-dismiss="modal">{{ __('Close') }}</button>
			</div>
		</div>
	</div>
</div>

{{-- BULK UPLOAD MODAL ENDS --}}

{{-- DELETE MODAL --}}

<div class="modal fade" id="confirm-delete" tabindex="-1" role="dialog" aria-labelledby="modal1" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">

	<div class="modal-header d-block text-center">
		<h4 class="modal-title d-inline-block">{{ __('Confirm Delete') }}</h4>
			<button type="button" class="close" data-dismiss="modal" aria-label="Close">
				<span aria-hidden="true">&times;</span>
			</button>
	</div>

      <!-- Modal body -->
      <div class="modal-body">
            <p class="text-center">{{ __('You are about to delete this Category. Everything under this category will be deleted') }}.</p>
            <p class="text-center">{{ __('Do you want to proceed?') }}</p>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer justify-content-center">
            <button type="button" class="btn btn-default" data-dismiss="modal">{{ __('Cancel') }}</button>
            <a class="btn btn-danger btn-ok">{{ __('Delete') }}</a>
      </div>

    </div>
  </div>
</div>

{{-- DELETE MODAL ENDS --}}
<input type="hidden" id="bulkupload" value="<?= URL('/admin/category/storebulkcategory')?>">
<input type="hidden" id="categorylist" value="<?= URL('/admin/category')?>">
@endsection    


@section('scripts')

{{-- DATA TABLE --}}

    <script type="text/javascript">

		var table = $('#geniustable').DataTable({
			   ordering: false,
               processing: true,
               serverSide: true,
               ajax: '{{ route('admin-cat-datatables') }}',
               columns: [
                        { data: 'name', name: 'name' },
                        { data: 'slug', name: 'slug' },
                        { data: 'status', searchable: false, orderable: false},
                        { data: 'order', searchable: false, orderable: false},
            			{ data: 'action', searchable: false, orderable: false }

                     ],
                language : {
                	processing: '<img src="{{asset('assets/images/'.$gs->admin_loader)}}">'
                },
				drawCallback : function( settings ) {
	    				$('.select').niceSelect();	
				}
            });

      	$(function() {
        $(".btn-area").append('<div class="col-sm-5 table-contents">'+
        	'<a class="add-btn" data-href="{{route('admin-cat-create')}}" id="add-data" data-toggle="modal" data-target="#modal1">'+
          '<i class="fas fa-plus"></i> Add New Category'+
          '</a><a  class="add-btn" data-href="{{route('admin-cat-create')}}" id="add-data" data-toggle="modal" data-target="#bulk-upload-modal">'+
          '<i class="fas fa-upload"></i> Bulk Upload'+
          '</a>'+
          '</div>');
        $("#geniustable_length, #geniustable_filter").parent().removeClass('col-sm-4');
        $("#geniustable_length, #geniustable_filter").parent().addClass('col-sm-3');
        $(".btn-submit-csv").click(function(){
        	var file_data = $('#csvfile').prop('files')[0];   
		    var form_data = new FormData();                  
		    form_data.append('file', file_data);
		    form_data.append('_token', $('meta[name="csrf-token"]').attr('content'));
		          
			$.ajaxSetup({
			  headers: {
			    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
			  }
			});                      
		    $.ajax({
		        url: $("#bulkupload").val(), // point to server-side PHP script 
		        dataType: 'text',  // what to expect back from the PHP script, if anything
		        cache: false,
		        contentType: false,
		        processData: false,
		        data: form_data,                         
		        type: 'post',
		        success: function(response){
		            $("#geniusformdata").trigger('reset');
		            $(".import-success-message").html('Bulk Category File Imported Successfully. <a href='+$("#categorylist").val()+'>View Category Lists.</a>');
		            $(".import-success-message").show();
		        }
		     });
        })
      });											
									
</script>

{{-- DATATABLE ENDS --}}
<style>
.add-btn{margin:0 5px;}
.btn-submit-csv{
	background: #1e7e34;
    width: 160px;
    height: 40px;
    color: #fff;
    font-size: 14px;
    border: 0px;
    margin-top: 15px;
    -webkit-transition: all 0.3s ease-in;
    -o-transition: all 0.3s ease-in;
    transition: all 0.3s ease-in;
}
</style>
@endsection   