<div class="col-lg-4 col-md-4 col-6" style="padding:10px 10px;">


	<a href="{{ route('front.product', $prod->id) }}" class="item">
		<div class="item-img">
			@if(!empty($prod->features))
			<div class="sell-area">
				@foreach($prod->features as $key => $data1)
				<span class="sale" style="background-color:{{ $prod->colors[$key] }}">{{ $prod->features[$key] }}</span>
				@endforeach
			</div>
			@endif
			<img class="img-fluid"
				src="{{ $prod->photo ? asset('assets/images/thumbnails/'.$prod->thumbnail):asset('assets/images/noimage.png') }}"
				alt="" style="width:360px;">
		</div>
		<div class="info" style="padding: 4px 14px 10px;">
			<h5 class="name" style="text-align:center;height:20px !important">{{ $langg->rtl == 1 ? $prod->name_ar : $prod->name }}</h5>
			
			<h4 class="price" style="text-align:center">{{ getCurrency($prod->price) }} {{ getSymbol() }} <del></del></h4>
			
			<div class="item-cart-area-product">
				<ul class="item-cart-options" style="text-align:center;margin-top:10px;margin-bottom:10px">
					<li>
							@if(Auth::guard('web')->check())

							<span href="javascript:;" class="add-to-wish"
								data-href="{{ route('user-wishlist-add',$prod->id) }}" data-toggle="tooltip"
								data-placement="top" title="{{ $langg->lang54 }}"><i
									class="icofont-heart-alt"></i>
							</span>

							@else

							<span href="javascript:;" rel-toggle="tooltip" title="{{ $langg->lang54 }}"
								data-toggle="modal" id="wish-btn" data-target="#comment-log-reg"
								data-placement="top">
								<i class="icofont-heart-alt"></i>
							</span>

							@endif
					</li>
					<li>
						<span  class="quick-view" rel-toggle="tooltip" title="{{ $langg->lang55 }}" href="javascript:;" data-href="{{ route('product.quick',$prod->id) }}" data-toggle="modal" data-target="#quickview" data-placement="top">
								<i class="fas fa-shopping-basket"></i>
						</span>
					</li>
					<li style="display:none;">
							<span href="javascript:;" class="add-to-compare"
							data-href="{{ route('product.compare.add',$prod->id) }}" data-toggle="tooltip"
							data-placement="top" title="{{ $langg->lang57 }}" >
							<i class="icofont-exchange"></i>
						</span>
					</li>
				</ul>
			</div>
		</div>
	</a>

</div>