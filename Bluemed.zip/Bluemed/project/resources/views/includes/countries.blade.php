<option value="">{{ $langg->lang157 }}</option>
@if(Auth::check())
	@foreach (DB::table('countries')->get() as $data)
	<option value="{{ $data->id }}" {{ Auth::user()->country == $data->country_name ? 'selected' : '' }}>{{ $data->country_name }}</option>		
	@endforeach
@else
	@foreach (DB::table('countries')->get() as $data)
	<option value="{{ $data->id }}">{{ $data->country_name }}</option>		
	@endforeach
@endif