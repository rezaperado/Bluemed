<?php
$handle = curl_init();
 
//$url = "http://195.39.181.245:8619/jointProject/api/Focus/GetStock?PdtCode='KP19006450','KP19005634','KP19005794'";
$url = "http://168.187.178.135/Marafie/api/Focus/GetStock?PdtCode="; 
$code = curl_escape($handle, "'SCA 5550XX'");
$url = $url.$code;
// Set the url
curl_setopt($handle, CURLOPT_URL, $url);
// Set the result output to be a string.
curl_setopt($handle, CURLOPT_RETURNTRANSFER, true);
 
$output = curl_exec($handle);
if (curl_errno($handle)) {
    $error_msg = curl_error($handle);
    echo $error_msg;
}
curl_close($handle);
 
echo $output;